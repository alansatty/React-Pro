import { create } from 'zustand';

const useTopbarStore = create((set) => ({
    subtitle: '',
    setSubtitle: (subtitle) => set({ subtitle }),
}));

export default useTopbarStore;

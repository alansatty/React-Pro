import { create } from 'zustand';

const usePermissionsStore = create((set) => ({
    permissions: [],
    planPermissions: {},
    strategicPlan: "",
    isLoading: true,
    setStrategicPlan: (newPlan) => set({ strategicPlan: newPlan, isLoading: false }),
    setPermissions: (newPermissions,) => set({
        permissions: newPermissions,
        isLoading: false,

    }),
    setPlanPermissions: (newPlanPermissions) => set({ planPermissions: newPlanPermissions, isLoading: false }),
}));

export default usePermissionsStore;

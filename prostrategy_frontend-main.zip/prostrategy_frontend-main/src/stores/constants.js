export const hoverEff = {
    inputWrapper: [
      "group-data-[focus=true]:border-[#0098F5]",
      "dark:group-data-[focus=true]:border-[#0098F5]",
    ],
  }
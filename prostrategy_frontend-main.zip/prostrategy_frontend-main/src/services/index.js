import { auth } from "./auth/auth";
import { departments } from "./admin/departments";
import { user } from "./admin/user";
import { roles } from "./admin/roles";
import { settings } from "./admin/settings";
import { organizationGoals } from "./admin/organizationGoals";
import { departmentGoals } from "./admin/departmentGoals";
import { profile } from "./admin/profile";
import { chat } from "./admin/chat";
import { subscription } from "./admin/subscription";
import { strategicPlans, strategicPlanWithIntialData } from "./admin/strategicPlans";
import { dashboard } from "./admin/dashboard";
import { departmentStrategies, strategies } from "./admin/strategies";
import { strategicGraphs, strategyForecast, strategyFormData, StrategicPlanYearList } from "./admin/strategyFormData";
import { binder_template } from "./admin/template";

export const apiList = {
  auth,
  admin: {
    user,
    departments,
    roles,
    settings,
    organizationGoals,
    departmentGoals,
    profile,
    chat,
    subscription,
    strategicPlans,
    dashboard,
    strategies,
    departmentStrategies,
    strategyFormData,
    binder_template,
    strategyForecast,
    strategicGraphs,
    strategicPlanWithIntialData,
    StrategicPlanYearList
  },
};

export const settings = {
  index: {
    key: (organization_id, strategic_plan_id) =>
      `settigns-${organization_id}-strategic_plan_id-${strategic_plan_id}`,
    call: (strategicPlan) =>
      `/organization/users/organization_settings_details/${strategicPlan}`,
  },

  update: {
    call: (strategicPlan) =>
      `/organization/users/organization_settings_update/${strategicPlan}`,
  },

  get_rating: {
    key: (id, strategicPlan) =>
      `get_rating-${id}-strategic_plan_id-${strategicPlan}`,
    // call:()=>'/organization/organization_values',
    call: (strategicPlan) => {
      let url = `/organization/organization_values`;
      if (strategicPlan) {
        url += `?strategic_plan_id=${encodeURIComponent(strategicPlan)}`;
        return url;
      }
    },
  },
  get_department_rating: {
    key: (id) => `department_values-${id}`,
    // call:(id)=>`/organization/department_values/${id}`
    call: (id, strategicPlan) => {
      let url = `/organization/department_values/${id}`;
      if (strategicPlan) {
        url += `?strategic_plan_id=${encodeURIComponent(strategicPlan)}`;
        return url;
      }
    },
  },

  update_rating: {
    call: () => `/organization/organization_values/ratings`,
  },
  update_deparmten_rating: {
    call: (id) => `/organization/departments_values/${id}/ratings`,
  },

  strategydata_create: {
    key: (id) => `strategyd_values-${id}`,
    call: (strategyPlanId) =>
      `/organization/create_or_update_initial_strategy_setting/${strategyPlanId}`,
  },

  get_startegyData: {
    key: (id, isDataForm) => `strategyd_values-${id}-data_form-${isDataForm}`,
    call: (strategyPlanId, isDataForm) =>
      `/organization/get_initial_strategy_setting/${strategyPlanId}?data_form=${isDataForm == true ? true : false}`,
  },


  generate_organization_description: {
    call: (strategicPlan) => `/organization/ai_generate_organization_description/${strategicPlan}`,
  },
};

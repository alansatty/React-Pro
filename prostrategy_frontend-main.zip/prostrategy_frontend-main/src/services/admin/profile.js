export const profile = {
  details: {
    key: (id, strategicPlan) => `profileDetails-${id}-strategicPlan${strategicPlan}`,
    call: (id, strategicPlan) => `/organization/users/${id}/detail/${strategicPlan}`,
  },
  update: {
    call: (id) => `/organization/users/${id}/profile_update`,
  },
  reset_pass: {
    
    call: (id) => `/auth/reset_password/${id}`,
  },

};



export const strategicPlans = {
  create: {
    call: () => "/organization/strategic_plan/create",
  },

  list: {
    key: (page, perPage, id) => `strategic_plan_list-${id}-${page}-${perPage}`,
    call: (page = 1, perPage = 10) => `/organization/strategic_plan/list?page=${page}&per_page=${perPage}`,
  },

  detail: {
    key: (plan_id) => `detail-${plan_id}`,
    call: (plan_id) => `/organization/strategic_plan/details/${plan_id}`,
  },

  delete: {
    call: (plan_id) => `/organization/strategic_plan/delete/${plan_id}`,
  },

  update: {
    call: (plan_id) => `/organization/strategic_plan/update/${plan_id}`,
  },

  reorder: {
    call: () => `/organization/strategic_plan/reorder/`
  }
};

export const strategicPlanWithIntialData = {
  list: {
    key: (strategicIds) => `strategic_plan_list_for_strategic_analysis${strategicIds}`,
    call: () => `/organization/strategic_plan_list_for_strategic_analysis`,
  },
}
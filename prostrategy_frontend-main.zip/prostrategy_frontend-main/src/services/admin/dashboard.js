export const dashboard = {
    details: {
      key: (id, year) => (year ? `admin_dash-${id}-${year}` : `admin_dash-${id}`),
      call: (year=2024) => (year ? `/auth/dashboard?year=${year}` : "/auth/dashboard"),
    },
  };
export const strategyFormData = {
  list: {
    key: (perPage, page, strategic_plan_id, sortBy, orderBy, startDate, endDate, startYear, endYear, search, selectedDepartment) => {
      let key = `strategy_formdata_list-${strategic_plan_id}-${page}-${perPage}-${sortBy}-${orderBy}-${startDate}-${endDate}-${startYear}-${endYear}-${search}-${selectedDepartment}`;
      return key;
    },
    call: (perPage, page, selectedPlans, sortBy, orderBy, startDate, endDate, startYear, endYear, search, department, slug) => {
      // Convert Set to comma-separated string
      // Build base URL
      let url = `/organization/department_goals/strategies_form/list/?strategic_plan_ids=${selectedPlans}&page=${page}&per_page=${perPage}&slug=${slug}`;

      // Add other parameters
      if (search) url += `&search=${encodeURIComponent(search)}`;
      if (sortBy) url += `&sort_by=${encodeURIComponent(sortBy)}`;
      if (orderBy) url += `&order_by=${encodeURIComponent(orderBy)}`;
      if (startDate) url += `&start_date=${encodeURIComponent(startDate)}`;
      if (endDate) url += `&completion_date=${encodeURIComponent(endDate)}`;
      if (startYear) url += `&start_year=${encodeURIComponent(startYear)}`;
      if (endYear) url += `&completion_year=${encodeURIComponent(endYear)}`;
      if (department) url += `&department=${encodeURIComponent(department)}`;

      return url;
    }

  },
  departmentList: {
    list: {
      key: () => `departments_lists`,
      call: () => `/organization/departments/dropdown`

    },
  }
}

export const strategicGraphs = {
  list: {
    key: () => {
      let key = `strategic_graphs`;
      return key;
    },
    call: (plan_id) => {
      let url = `/organization/strategic_form_data/strategic_graphs/${plan_id}`;
      return url;
    },
  },
};

export const strategyForecast = {
  list: {
    key: () => `strategy_forecast`,
    call: (plan_id) => `/organization/strategic_form_data/forecast/${plan_id}`
  }
}


export const StrategicPlanYearList = {
  list: {
    key: (selectedPlans) => `strategy_year_list-${selectedPlans}`,
    call: (selectedPlans) => `/organization/strategic_plan_based_year_list?strategic_plan_ids=${selectedPlans}`
  }
}






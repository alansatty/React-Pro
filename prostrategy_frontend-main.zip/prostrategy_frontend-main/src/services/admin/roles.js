export const roles = {
  role_permission: {
    key: "role_permission",
    call: () => "/organization/roles/permission_dropdown",
  },

  create: {
    call: () => `/organization/roles/create`,
  },

  update: {
    call: (id) => `/organization/roles/${id}/update`
  },

  index: {
    key: (perPage, page, search = null, filters = {}) => {
      let key = `roles-${page}-${perPage}`;

      if (filters?.search) {
        key += `-search=${encodeURIComponent(filters?.search)}`;
      }
      if (filters?.role) {
        key += `-role_type=${encodeURIComponent(filters?.role)}`;
      }
      return key;
    },
    call: (perPage, page, search = null, filters = {}) => {
      let url = `/organization/roles?page=${page}&per_page=${perPage}`;
      if (filters?.search) {
        url += `&search=${encodeURIComponent(filters?.search)}`;
      }
      if (filters?.role) {
        url += `&role_type=${encodeURIComponent(filters?.role)}`;
      }
      return url;
    },
  },

  delete: {
    call: () => `/organization/roles/`,
  },

};

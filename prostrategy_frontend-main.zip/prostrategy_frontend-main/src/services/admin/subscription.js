export const subscription = {
  get_plans: {
    key: () => `get_plans`,
    call: () => "/subscription/get_subscription_plans",
  },

  get_planDetails: {
    key: (planId) => `get_planDetails-${planId}`,
    call: (planId) => `/subscription/subscription_plan_details/${planId}`,
  },

  current_plan: {
    key: () => `current_plan`,
    call: () => "/subscription/current_subscription_plan",
  },

  biling_history: {
    key: (page, perPage) => `biling_history${page}-${perPage}`,
    call: (page, perPage) => `/subscription/subscription_plan_history?page=${page}&per_page=${perPage}`,
  },

  cancel_subscription: {
    call: () => "/subscription/cancel_subscription",
  },

  proceed_checkout: {
    call: () => "/subscription/proceed_checkout",
  },
};

const params = new URLSearchParams();
export const user = {
  index: {
    key: (perPage, page, search = null, filters = {}) => {
      let key = `users-${page}-${perPage}`;
      if (filters?.search) {
        key += `-search=${encodeURIComponent(filters?.search)}`;
      }
      if (filters?.user_type) {
        key += `-user_type=${encodeURIComponent(filters?.user_type)}`;
      }
      if (filters?.role) {
        key += `-role=${encodeURIComponent(filters?.role)}`;
      }
      if (filters?.department) {
        key += `-department=${encodeURIComponent(filters?.department)}`;
      }
      if (filters?.user_status) {
        key += `-user_status=${encodeURIComponent(filters?.user_status)}`;
      }
      return key;
    },
    call: (perPage, page, search = null, filters = {}) => {
      let url = `/organization/users?page=${page}&per_page=${perPage}`;
      if (filters?.search) {
        url += `&search=${encodeURIComponent(filters?.search)}`;
        url = url.replace(/page=\d+&?/, "");
        return url;
      }
      if (filters?.user_type) {
        url += `&user_type=${encodeURIComponent(filters?.user_type)}`;
      }
      if (filters?.role) {
        url += `&role=${encodeURIComponent(filters?.role)}`;
      }
      if (filters?.department) {
        url += `&department=${encodeURIComponent(filters?.department)}`;
      }
      if (filters?.user_status) {
        url += `&user_status=${encodeURIComponent(filters?.user_status)}`;
      }
      return url;
    },
  },
  delete: {
    call: () => `/organization/users/`,
  },
  create: {
    call: () => "/organization/users/create",
  },
  details: {
    key: "details",
    call: (user_id, strategicPlan) => `/organization/users/${user_id}/detail/${strategicPlan}`,
  },
  update: {
    call: (user_id) => `/organization/users/${user_id}/update`,
  },

  rolesDropdown: {
    key: (roleType) => `roles_dropdown-${roleType}`,
    call: (roleType) => {
      let url = `/organization/roles/dropdown`;
      if (roleType) {
        url = `/organization/roles/dropdown?role_type=${roleType}`;
      }
      return url;
    },
  },
  departmentDropdown: {
    key: "departments_dropdown",
    call: () => "/organization/departments/dropdown",
  },

  autoSuggestion: {
    key: "department_auto_suggestion",
    call: () => `/organization/departments/dropdown/auto_suggestion`
  },

  resentMail: {
    key: "user_resent_mail",
    call: (USER_ID) => `/organization/users/resend_email/${USER_ID}`
  }
};



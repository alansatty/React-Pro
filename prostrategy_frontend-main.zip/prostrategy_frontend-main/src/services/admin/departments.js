export const departments = {
  index: {
    key: (page, perPage, strategicPlan, search = null) => {
      let key = `department_list-${strategicPlan}-${page}-perPage=${perPage}`;
      if (search) {
        key += `-search=${encodeURIComponent(search)}`;
      }
      return key;
    },
    call: (page, perPage, strategicPlan, search = null) => {
      let url = `/organization/departments?page=${page}&per_page${perPage}&strategic_plan=${strategicPlan}`;
      if (search) {
        url += `&search=${encodeURIComponent(search)}`;
        url = url.replace(/page=\d+&?/, "");
        return url;
      }
      return url;
    },
  },

  create: {
    call: (userId) => `/organization/departments/create`,
  },

  delete: {
    call: (Id) => `/organization/departments/${Id}/delete`,
  },

  update: {
    call: (Id) => `organization/departments/${Id}/update`,
  },
  detail: {
    key: (id) => `departments-${id}`,
    call: (id) => `organization/departments/${id}/detail`,
  },

  department_users: {
    key: (id) => `department_users-${id}`,
    call: (id) => `/organization/department/users/${id}`,
  },

  sutaining_options: {
    key: (strategicPlan, deptId) => `sustaining_option-strategicPlan-${strategicPlan}-${deptId}`,
    call: (strategicPlanId, deptId) =>
      `/organization/organization_goals/sustaining_objective_options/${strategicPlanId}?department=${deptId}`,
  },

  saved_sutaining_options: {
    key: (id) => `saved_sustaining_option_department-${id}`,
    // call: (id) =>
    //   `/organization/department_goals/sustaining_objectives_options/list/${id}`,
    call: (id, strategicPlan) => {
      let url = `/organization/department_goals/sustaining_objectives_options/list/${id}`;
      if (strategicPlan) {
        url += `?strategic_plan_id=${encodeURIComponent(strategicPlan)}`;
        return url;
      }
    },
  },
  update_sustaining_options: {
    call: (id) =>
      `/organization/department_goals/sustaining_objectives_options/save/${id}`,
  },
  sustaining_objective_create: {
    call: () => `/organization/department_goals/sus_objective/create`,
  },
  sustaining_objective_details: {
    key: (id) => `sustaining_objective_details_department-${id}`,
    // call: (id) => `/organization/department_goals/sus_objective/detail/${id}`,
    call: (id, strategicPlan) => {
      let url = `/organization/department_goals/sus_objective/detail/${id}`;
      if (strategicPlan) {
        url += `?strategic_plan_id=${encodeURIComponent(strategicPlan)}`;
        return url;
      }
    },
  },
  sustainging_business_essentials: {
    key: (id) => `business_essentials_sustaining-department-${id}`,
    call: (id, strategicPlan) =>
      `/organization/department_goals/business_essentials/sus_objective/${id}/${strategicPlan}`,
  },

  generate_statements: {
    key: (department_id) => `generate_statements-department-${department_id}`,
    call: (id) =>
      `/organization/department_goals/statements/sus_objective/${id}`,
  },

  get_sva_options: {
    key: `get_sva_options-department-`,
    call: () => `/organization/department_sva/get_sva_options`,
  },
  genarate_sva_criterea: {
    call: (id, strategicPlan) => `/organization/department_sva/criteria/${id}/${strategicPlan}`,
  },

  save_criterea_form: {
    call: (id) => `/organization/department_sva/save/criteria/${id}`,
  },

  get_saved_criterea: {
    key: (id) => `get_saved_criterea-${id}`,
    call: (id, strategicPlan) => {
      let url = `/organization/department_sva/get_saved/criteria/${id}`;
      if (strategicPlan) {
        url += `?strategic_plan_id=${encodeURIComponent(strategicPlan)}`;
      }
      return url;
    },
  },

  get_sva_dashboard: {
    key: (id) => `get_sva_dashboard-${id}`,
    // call: (id) => `/organization/department_sva/get/sva_dashboard/${id}`,
    call: (id, strategicPlan) => {
      let url = `/organization/department_sva/get/sva_dashboard/${id}`;
      if (strategicPlan) {
        url += `?strategic_plan_id=${encodeURIComponent(strategicPlan)}`;
      }
      return url;
    },
  },

  save_sva_dashboard: {
    call: (id) => `/organization/department_sva/save/sva_dashboard/${id}`,
  },

  swot_save: {
    call: (id) => `/organization/department_swot/save/criteria/${id}`,
  },

  get_swotValues: {
    key: (department_id) => `get_swotValues-${department_id}`,
    // call:()=>'/organization/organization_goals/detail',
    call: (strategicPlan, id) => {
      let url = `/organization/department_swot/get_saved/criteria/${id}`;
      if (strategicPlan) {
        url += `?strategic_plan_id=${encodeURIComponent(strategicPlan)}`;
        return url;
      }
    },
  },

  delete_goals_strategies: {
    key: (goal_id) => `delete_goals_and_strategies_${goal_id}`,
    call: (goal_id) =>
      `organization/department_goals/delete_goals_and_strategies/${goal_id}`,
  },
  genarate_swot_criterea: {
    call: (id, swot_id) => `/organization/department_swot/generate_department_swot_essentials/${id}/${swot_id}`

  },

  generate_description: {
    call: (strategicPlan) => `/organization/department/ai_generate_departments_description/${strategicPlan}`
  },

  reorder: {
    call: () => `/organization/departments/dept_reorder`
  },

  strategicReportPlanning: {
    key: (strategicPlanId, department_id, strategic_id) => `get_strategic_report_plan-${strategicPlanId}-${department_id}-${strategic_id}`,
    call: (STRATEGIC_PLAN_ID, DEPARTMENT_ID, DEPARTMENT_STRATEGY_ID) =>
      `/organization/strategic_binder_menu_data/${DEPARTMENT_ID}/${DEPARTMENT_STRATEGY_ID}/?strategic_plan=${STRATEGIC_PLAN_ID}`

  },

  departmentsReports: {
    key: (id, strategicPlanId) => `/organization/strategic_binder_support_select/${id}/?strategic_plan=${strategicPlanId}`,
    call: (id, strategicPlanId) => `/organization/strategic_binder_support_select/${id}/?strategic_plan=${strategicPlanId}`,

  },

  strategicMonitorList: {
    key: (id, strategicId, strategicPlan) => `/organization/strategic_binder_kickout/${id}-${strategicId}-${strategicPlan}`,
    call: (id, strategicId, strategicPlan) => `/organization/strategic_binder_kickout/${id}/${strategicId}/?strategic_plan=${strategicPlan}`
  },

  kickoutUser: {
    key: (strategicBinderId, slug) => `/organization/strategic_binder_kickout/${strategicBinderId}/?slug=${slug}`,
    call: (strategicBinderId, slug) => `/organization/strategic_binder_kickout/${strategicBinderId}/?slug=${slug}`
  }
  

};

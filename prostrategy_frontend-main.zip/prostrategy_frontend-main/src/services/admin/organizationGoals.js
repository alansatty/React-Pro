export const organizationGoals = {

  create_mission: {
    key: 'create_mission',
    call: () => '/organization/organization_goals/mission/create',
  },

  create_vision: {
    key: 'create_vision',
    call: () => '/organization/organization_goals/vision/create',
  },

  create_value: {
    key: 'create_value',
    call: () => '/organization/organization_goals/value/create',
  },

  business_essentials: {
    key: 'business_essentials',
    call: () => '/organization/organization_goals/business_essentials',
  },

  generate_statements: {
    key: 'generate_statements',
    call: () => '/organization/organization_goals/statements',
  },
  generate_statements_sustaining: {
    key: 'generate_statements_sustaining',
    call: () => '/organization/organization_goals/statements/sus_objective',
  },


  get_goals: {
    key: (organization_id) => `get_goals-${organization_id}`,
    // call:()=>'/organization/organization_goals/detail',
    call: (strategicPlan) => {
      let url = `/organization/organization_goals/detail`;
      if (strategicPlan) {
        url += `?strategic_plan_id=${encodeURIComponent(strategicPlan)}`;
        return url;
      }
    }
  },

  sutaining_options: {
    key: "sustaining_option",
    call: (strategicPlanId) => `/organization/organization_goals/sustaining_objective_options/${strategicPlanId}`
  },

  saved_sutaining_options: {
    key: (organization_id) => `saved_sustaining_option-${organization_id}`,
    // call:()=>'/organization/organization_goals/sustaining_objectives_options/list'
    call: (strategicPlan) => {
      let url = `/organization/organization_goals/sustaining_objectives_options/list`;
      if (strategicPlan) {
        url += `?strategic_plan_id=${encodeURIComponent(strategicPlan)}`;
        return url;
      }
    }
    ,
  },
  update_sustaining_options: {
    call: () => `organization/organization_goals/sustaining_objectives_options/save`
  },
  sustaining_objective_create: {
    call: () => `/organization/organization_goals/sus_objective/create`
  },
  sustaining_objective_details: {
    key: (organization_id) => `sustaining_objective_details-${organization_id}`,
    // call: () => `/organization/organization_goals/sus_objective/detail`
    call: (strategicPlan) => {
      let url = `/organization/organization_goals/sus_objective/detail`;
      if (strategicPlan) {
        url += `?strategic_plan_id=${encodeURIComponent(strategicPlan)}`;
        return url;
      }
    }
  },
  sustainging_business_essentials: {
    key: 'business_essentials_sustaining',
    call: () => '/organization/organization_goals/business_essentials/sus_objective',
  },


  swot_options: {
    key: "swot_options",
    call: () => '/organization/organization_swot/options'
  },

  swot_save: {
    call: () => `/organization/organization_swot/save/criteria`
  },


  get_swotValues: {
    key: (organization_id) => `get_swotValues-${organization_id}`,
    // call:()=>'/organization/organization_goals/detail',
    call: (strategicPlan) => {
      let url = `/organization/organization_swot/get_saved/criteria`;
      if (strategicPlan) {
        url += `?strategic_plan_id=${encodeURIComponent(strategicPlan)}`;
        return url;
      }
    }
  },

  get_sva_options: {
    key: `get_organization_sva_options`,
    call: () => `/organization/organization_sva/get_sva_options`,
  },

  get_saved_criterea: {
    key: () => `get_organization_saved_criterea`,
    call: (strategicPlan) => {
      let url = `/organization/organization_sva/get_saved/criteria`;
      if (strategicPlan) {
        url += `?strategic_plan_id=${encodeURIComponent(strategicPlan)}`;
      }
      return url;
    },
  },

  save_criterea_form: {
    call: () => `/organization/organization_sva/save/criteria`,
  },

  genarate_sva_criterea: {
    call: (strategicPlan) => `/organization/organization_sva/criteria/${strategicPlan}`,
  },

  get_sva_dashboard: {
    key: (id) => `get_sva_dashboard-${id}`,
    // call: (id) => `/organization/department_sva/get/sva_dashboard/${id}`,
    call: (strategicPlan) => {
      let url = `/organization/organization_sva/get/sva_dashboard`;
      if (strategicPlan) {
        url += `?strategic_plan_id=${encodeURIComponent(strategicPlan)}`;
      }
      return url;
    },
  },

  save_sva_dashboard: {
    call: (id) => `/organization/organization_sva/save/sva_dashboard`,
  },
  genarate_swot_criterea: {
    call: (id) => `/organization/organization_foundation/ai_generate_swot_essentials/${id}`
  }

}
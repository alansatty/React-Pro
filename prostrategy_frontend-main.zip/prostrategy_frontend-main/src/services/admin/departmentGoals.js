export const departmentGoals = {


    business_essentials: {
        key: (department_id) => `business_essentials-${department_id}`,
        call: (department_id,strategicPlan) => `/organization/department_goals/business_essentials/${department_id}/${strategicPlan}`,
    },

    generate_statements: {
        key: (department_id) => `generate_statements-${department_id}`,
        call: (department_id) => `/organization/department_goals/statements/${department_id}`,
    },

    create_mission: {
        key: 'create_mission',
        call: () => '/organization/department_goals/mission/create',
    },

    create_vision: {
        key: 'create_vision',
        call: () => '/organization/department_goals/vision/create',
    },

    create_value: {
        key: 'create_value',
        call: () => '/organization/department_goals/value/create',
    },

    get_goals: {
        key: (department_id) => `get_goals-${department_id}`,
        // call:(department_id)=> `/organization/department_goals/detail/${department_id}`
        call: (department_id, strategicPlan) => {
            let url = `/organization/department_goals/detail/${department_id}`;
            if (strategicPlan) {
                url += `?strategic_plan_id=${encodeURIComponent(strategicPlan)}`;
                return url;
            }
        }
    },

    
};

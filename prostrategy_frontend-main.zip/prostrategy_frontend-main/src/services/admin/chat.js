export const chat = {
    userList: {
        key: (id) => `user_list_${id}`,
        call: () => "/organization/chat/users",
    },
    sendMessage: {
        call: () => `/organization/chat/send_message`
    },
    myChats: {
        key: (page, search, id) =>
            search ? `my_chats-search-${search}-${id}` : `my_chats-${page}-${id}`,
        call: (page, search) =>
            search ? `/organization/chat/my_chats?search=${search}` : `/organization/chat/my_chats?page=${page}`,
    },
    conversation: {
        key: (chat_id, page) => `conversation-${chat_id}-${page}`,
        call: (chat_id, page) => `/organization/chat/my_chats/${chat_id}/conversations?page=${page}`,
    }
}
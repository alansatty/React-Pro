export const strategies = {
  genarate: {
    call: () => "/organization/organization_swot/generate_goals",
  },
  save: {
    call: () => `/organization/organization_swot/save_goals_and_strategies`,
  },
  get_saved: {
    key: (strategic_plan_id) => `strategies_${strategic_plan_id}_saved`,
    call: (strategic_plan_id) =>
      `/organization/organization_swot/get_goals?strategic_plan_id=${strategic_plan_id}`,
  },

  save_entryForm: {
    call: (strategyId) =>
      `/organization/organization_swot/strategies_form/${strategyId}`,
  },

  get_entryFormDetails: {
    key: (strategyId) => `EntryFormDetails-${strategyId}`,
    call: (strategyId) =>
      `/organization/organization_swot/strategies_form/details/${strategyId}`,
  },
};

export const departmentStrategies = {
  genarate: {
    call: () => "organization/department_goals/generate_goals",
  },

  genarateStrategies: {
    call: () => "organization/department_goals/generate_strategies",
  },

  save: {
    call: () => `/organization/department_goals/save_goals_and_strategies`,
  },

  get_saved: {
    key: (dept_id, strategic_plan_id) =>
      `${dept_id}_strategies_${strategic_plan_id}_saved`,
    call: (dept_id, strategic_plan_id) =>
      `/organization/department_goals/get_goals/${dept_id}?strategic_plan_id=${strategic_plan_id}`,
  },

  delete_goal_and_strategies: {
    key: (goal_id) => `delete_goals_and_strategies_${goal_id}`,
    call: () => `organization/department_goals/delete_goals_and_strategies`
  },

  save_entryForm: {
    call: (dept_id, strategyId) =>
      `/organization/department_goals/${dept_id}/strategies_form/${strategyId}`,
  },

  get_entryFormDetails: {
    key: (strategyId) => `EntryFormDetails-${strategyId}`,
    call: (dept_id, strategyId) =>
      `/organization/department_goals/strategies_form/details/${dept_id}/${strategyId}`,
  },

  get_departments: {
    key: (strategyId) => `departments-${strategyId}`,
    call: () =>
      `/organization/departments/dropdown`,
  },
  delete_strategies: {
    call: (depart_id) => `/organization/department_goals/delete_strategies_mapped_for_department/${depart_id}`
  },
  get_metricQuestions: {
    key: (strategicIds) => `organization_metric_data_form${strategicIds}`,
    call: (strategicIds) => `/organization/organization_metric_data_form/?strategic_plan_ids=${strategicIds}`,
  }
};

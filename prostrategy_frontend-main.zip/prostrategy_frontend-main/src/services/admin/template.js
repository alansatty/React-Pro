// export const binder_template = {
//   list: {
//     key: (id)=> `template-list-${id}`,
//     call: (id) => `/organization/template/list?strategic_plan_id=${id}`,
//   },

//   get: {
//     key: (STRATEGIC_PLAN_ID) => `/organization/binder/template-strategic_plan_id=${STRATEGIC_PLAN_ID}`,
//     call: (STRATEGIC_PLAN_ID) =>
//       `/organization/binder/template?strategic_plan_id=${STRATEGIC_PLAN_ID}`,
//   },
//   save: {
//     call: () => `/organization/binder/template/save`,
//   },

//   pdf: {
//     call: (docType)=> `/organization/binder/template/generate_document/${docType}`,
//   },
//   // generate_pdf
//   save_tableof_content: {
//     call: () => `/organization/binder/template/save/table_of_contents`,
//   }


// };


export const binder_template = {
  list: {
    key: (strategicBinderId, slug) => `template-list-${strategicBinderId}-slug-${slug}`,
    call: (strategicBinderId, slug) => `/organization/strategic_binder_support/${strategicBinderId}/?slug=${slug}`,
  },

  get: {
    key: (strategicBinderId, slug) => `/organization/binder/template=${strategicBinderId}-slug-${slug}`,
    call: (strategicBinderId, slug) => `/organization/strategic_binder_support/${strategicBinderId}/?slug=${slug}`,
  },
  save: {
    call: (strategicBinderId, slug) => `/organization/strategic_binder_support/${strategicBinderId}/?slug=${slug}`,
  },

  pdf: {
    call: (docType) => `/organization/binder/template/generate_document/${docType}`,
  },
  // generate_pdf
  save_tableof_content: {
    call: () => `/organization/binder/template/save/table_of_contents`,
  },

  strategic_planing_report :{
    key:(strategicPlanId)=> `/organization/strategic_binder_support_select_preview/${strategicPlanId}/`,
    call:(strategicPlanId)=> `/organization/strategic_binder_support_select_preview/${strategicPlanId}/`,
  },
  strategic_planing_report_preview: {
    key: (strategicPlan) => `/organization/strategic_support_preview/${strategicPlan}/`,
    call: (strategicPlan) => `/organization/strategic_support_preview/${strategicPlan}/`,
  },
  strategic_planing_report_download:{
    key: (strategicPlan,type) => `/organization/strategic_support_preview/${strategicPlan}/?file_type=${type}`,
    call: (strategicPlan,type) => `/organization/strategic_support_preview/${strategicPlan}/?file_type=${type}`,
  }
  
};


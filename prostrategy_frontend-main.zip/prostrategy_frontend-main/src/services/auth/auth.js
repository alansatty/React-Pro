export const auth = {
  login: {
    key: "login",
    call: () => "/auth/login",
  },

  register: {
    key: "register",
    call: () => "/auth/register",
  },

  forgotPassword: {
    key: "forgot_password",
    call: () => "/auth/forgot_password",
  },

  changePassword: {
    key: "change_password",
    call: (userId) => `/auth/reset_password/${userId}`,
  },

  resetPassword: {
    key: "resetPassword",
    call: (userId) => `/auth/reset_password/${userId}/profile`,
  },

  getPermissions: {
    key: (id) => `login_user_role_permission_list-${id}`,
    call: () => `/auth/login_user_role_permission_list`
  },

  getQuoteDetails : {
    key: (id) => `subscription_quote_deatils-${id}`,
    call: (id) => `/subscription/call_for_quote/subscription_request_detail/${id}`
  }

};

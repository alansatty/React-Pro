import usePermissionsStore from "../stores/usePermissionStore";

/**
 * hasPlanPermission
 *
 * This function checks if the user has the required permission to perform a specific action on a resource.
 *
 * @param {string} resource - The resource the user wants to perform an action on (e.g., "user", "project").
 * @param {string} action - The action the user wants to perform on the resource (e.g., "list", "create", "delete").
 *
 * @returns {boolean} - Returns `true` if the user has the permission for the given action on the resource, otherwise `false`.
 *
 * Usage:
 * 1. **In Menu Items**:
 *    Conditionally render a menu item based on user permissions.
 *
 *    Example:
 *    ```
 *    hasPlanPermission('user', 'list') ? <MenuLink href="/users">User Management</MenuLink> : null;
 *    ```
 *
 * 2. **For Button Visibility**:
 *    Show or hide buttons like "Create", "Edit", "Delete" based on the permissions.
 *
 *    Example:
 *    ```
 *    hasPlanPermission('user', 'create') && <button>Create User</button>;
 *    ```
 *
 * 3. **For Access Control**:
 *    Restrict access to certain pages or features by checking the required permissions before rendering the content.
 *
 * Important:
 * - This function depends on the `permissions` stored in the Zustand store.
 * - The `permissions` array should contain objects with `resource` and `action` fields, where:
 *    - `resource` is the resource type (e.g., "user")
 *    - `action` is an array of actions the user is allowed to perform on that resource (e.g., ["list", "create", "edit"])
 */

export default function hasPlanPermission(action, currentUsage = 0) {
  // Access the plan permissions from the state
  const PlanPermissions = usePermissionsStore.getState().planPermissions;
  //PlanPermissions["swot_analysis"] = true;
  // const PlanPermissions = usePermissionsStore((state) => state.planPermissions);

  // Check if the passed action is in the PlanPermissions object
  if (PlanPermissions.hasOwnProperty(action)) {
    const permissionValue = PlanPermissions[action];
  

    // Handle zero-value permissions: Treat `0` as not allowed
    if (permissionValue === 0) {
      return false;
    }

    // Handle count-based permissions
    if (typeof permissionValue === "number") {
      // If the permission is a count, check if the current usage is within the allowed limit
      return currentUsage < permissionValue;
    }

    // Handle boolean permissions
    return permissionValue === true || permissionValue === "True"; // Return true if the permission is explicitly "True"
  }

  // If the action doesn't exist in PlanPermissions, return false
  return false;
}

// const permissions=[
//     {
//         resource: "users",
//         action: [
//             "list",
//             // "create",
//             "edit",
//             "delete"
//         ]
//     },]

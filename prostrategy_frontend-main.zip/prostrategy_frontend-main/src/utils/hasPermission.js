import usePermissionsStore from "../stores/usePermissionStore";

/**
 * hasPermission
 *
 * This function checks if the user has the required permission to perform a specific action on a resource.
 *
 * @param {string} resource - The resource the user wants to perform an action on (e.g., "user", "project").
 * @param {string} action - The action the user wants to perform on the resource (e.g., "list", "create", "delete").
 *
 * @returns {boolean} - Returns `true` if the user has the permission for the given action on the resource, otherwise `false`.
 *
 * Usage:
 * 1. **In Menu Items**:
 *    Conditionally render a menu item based on user permissions.
 *
 *    Example:
 *    ```
 *    hasPermission('user', 'list') ? <MenuLink href="/users">User Management</MenuLink> : null;
 *    ```
 *
 * 2. **For Button Visibility**:
 *    Show or hide buttons like "Create", "Edit", "Delete" based on the permissions.
 *
 *    Example:
 *    ```
 *    hasPermission('user', 'create') && <button>Create User</button>;
 *    ```
 *
 * 3. **For Access Control**:
 *    Restrict access to certain pages or features by checking the required permissions before rendering the content.
 *
 * Important:
 * - This function depends on the `permissions` stored in the Zustand store.
 * - The `permissions` array should contain objects with `resource` and `action` fields, where:
 *    - `resource` is the resource type (e.g., "user")
 *    - `action` is an array of actions the user is allowed to perform on that resource (e.g., ["list", "create", "edit"])
 */

export default function hasPermission(resource, actions) {
  const permissions = usePermissionsStore.getState().permissions;


  if (!permissions || permissions.length === 0) return null;

  const actionArray = Array.isArray(actions) ? actions : [actions];
  const permission = permissions.find((perm) => perm.resource === resource);

  if (!permission) return false

  if (actionArray.length === 0) return true;

  // Check if all required actions are permitted
  return actionArray.every((action) =>
    Array.isArray(permission.action)
      ? permission.action.includes(action)
      : permission.action === action
  );
}

import { format, parse } from 'date-fns';

/**
 * Converts a date to MM/DD/YYYY format
 * @param date - Date string or Date object
 * @returns Formatted date string in MM/DD/YYYY
 */
export const formatDateMMDDYYYY = (date) => {
    if (!date) return '';

    try {
        // Ensure the date is parsed correctly
        const parsedDate = typeof date === 'string'
            ? parse(date, 'MM/dd/yyyy', new Date())
            : date;

        // Format the date to MM/DD/YYYY
        return format(parsedDate, 'MM/dd/yyyy');
    } catch (error) {
        console.error('Error formatting date:', error);
        return '';
    }
};

/**
 * Converts input date to a parseable format
 * @param inputDate - Date string in various formats
 * @returns Parsed date in MM/DD/YYYY
 */
export const convertToMMDDYYYY = (inputDate) => {
    if (!inputDate) return '';

    const inputFormats = [
        'yyyy-MM-dd',
        'dd/MM/yyyy',
        'MM/dd/yyyy',
        'dd-MM-yyyy',
        'MM-dd-yyyy',
    ];

    for (const formatString of inputFormats) {
        try {
            const parsedDate = parse(inputDate, formatString, new Date());

            // Validate the parsed date
            if (!isNaN(parsedDate.getTime())) {
                // Convert to MM/DD/YYYY format
                return format(parsedDate, 'MM/dd/yyyy');
            }
        } catch (error) {
            continue;
        }
    }

    // If no format matches, return the original input
    return inputDate;
};

/**
 * Parses a date for input elements (YYYY-MM-DD)
 * @param inputDate - Date string in MM/DD/YYYY format
 * @returns Date string in YYYY-MM-DD format
 */
export const parseDate = (inputDate) => {
    if (!inputDate) return '';

    try {
        const parsedDate = parse(inputDate, 'MM/dd/yyyy', new Date());

        return format(parsedDate, 'yyyy-MM-dd');
    } catch (error) {
        return inputDate;
    }
};

// Example usage in a component
export const DateDisplay = ({ date }) => {
    const formattedDate = formatDateMMDDYYYY(date);
    return <span>{formattedDate}</span>;
};
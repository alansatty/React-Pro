export const formatTimestamp = (date) => {
  const options = {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false, // 24-hour format
    timeZone: "America/New_York", // USA timezone
  };

  // Use Intl.DateTimeFormat to get parts
  const dateParts = new Intl.DateTimeFormat("en-US", options).formatToParts(
    date
  );

  // Extract individual parts
  const day = dateParts.find((part) => part.type === "day").value;
  const month = dateParts.find((part) => part.type === "month").value;
  const year = dateParts.find((part) => part.type === "year").value;
  const hour = dateParts.find((part) => part.type === "hour").value;
  const minute = dateParts.find((part) => part.type === "minute").value;

  // Construct desired format
  return `${day} ${month} ${year} ${hour}:${minute}`;
};

export const getCurrentDate = ({
  includeYear = true,
  includeMonth = true,
  includeDay = true,
} = {}) => {
  const now = new Date();

  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0"); // Months are 0-based, so add 1
  const day = String(now.getDate()).padStart(2, "0");

  const parts = [];
  if (includeYear) parts.push(year);
  if (includeMonth) parts.push(month);
  if (includeDay) parts.push(day);

  return parts.join("-"); // Customize separator if needed
};

export const parseBackendDate = (dateString, splitKey) => {
  if (!dateString) return null;

  const [month, day, year] = dateString.split(splitKey).map(Number);
  const correctedYear = year < 100 ? 2000 + year : year;
  const date = new Date(correctedYear, month - 1, day);

  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, "0");
  const dd = String(date.getDate()).padStart(2, "0");

  return `${yyyy}-${mm}-${dd}`;
};

export const formatDateForBackend = (date) => {
  if (!date) return null;

  // Ensure `date` is a valid Date object
  if (Object.prototype.toString.call(date) !== "[object Date]" || isNaN(date)) {
    console.error("Invalid date object:", date);
    return null;
  }

  const day = String(date.getDate()).padStart(2, "0"); // Get day (1-31)
  const month = String(date.getMonth() + 1).padStart(2, "0"); // Get month (0-11, so add 1)
  const year = date.getFullYear(); // Get full year (e.g., 2025)
  return `${year}-${month}-${day}`; // Format as YYYY-MM-DD
};

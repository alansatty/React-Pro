import React from "react";

const Checked_icon = (props) => {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 16 17"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <g clipPath="url(#clip0_2302_19213)">
        <path
          d="M8 0.5C3.58897 0.5 0 4.08897 0 8.5C0 12.911 3.58897 16.5 8 16.5C12.411 16.5 16 12.911 16 8.5C16 4.08897 12.411 0.5 8 0.5ZM12.4712 6.39474L7.3584 11.4674C7.05764 11.7682 6.57644 11.7882 6.25564 11.4875L3.54887 9.0213C3.22807 8.72055 3.20802 8.2193 3.48872 7.8985C3.78947 7.57769 4.29073 7.55764 4.61153 7.8584L6.75689 9.82331L11.3283 5.25188C11.6491 4.93108 12.1504 4.93108 12.4712 5.25188C12.792 5.57268 12.792 6.07393 12.4712 6.39474Z"
          fill="#02205F"
        />
      </g>
      <defs>
        <clipPath id="clip0_2302_19213">
          <rect
            width="16"
            height="16"
            fill="white"
            transform="translate(0 0.5)"
          />
        </clipPath>
      </defs>
    </svg>
  );
};

export default Checked_icon;

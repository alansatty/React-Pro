// Modified useTabNavigation hook
import { useState, useEffect } from 'react';

const useTabNavigation = (isDirty) => {
    const [showModal, setShowModal] = useState(false);
    const [targetTab, setTargetTab] = useState(null);
    const [isNavigating, setIsNavigating] = useState(false);

    useEffect(() => {
        if (!isDirty) {
            setTargetTab(null);
            setIsNavigating(false);
        }
    }, [isDirty]);

    // Reset
    useEffect(() => {
        if (isNavigating && targetTab) {
            const timer = setTimeout(() => {
                setIsNavigating(false);
            }, 100);

            return () => clearTimeout(timer);
        }
    }, [isNavigating, targetTab]);

    const handleTabClick = (tab = '') => {
        if (isDirty) {
            setTargetTab(tab);
            setShowModal(true);
            return false;
        } else {

            setTargetTab(tab);
            setIsNavigating(true);
            return true;
        }
    };

    const confirmTabChange = () => {
        setShowModal(false);
        setIsNavigating(true);
    };

    const cancelTabChange = () => {
        setShowModal(false);
        setTargetTab(null);
        setIsNavigating(false);
    };

    const resetNavigation = () => {
        setTargetTab(null);
        setIsNavigating(false);
        setShowModal(false);
    };


    return {
        showModal,
        targetTab,
        isNavigating,
        handleTabClick,
        confirmTabChange,
        cancelTabChange,
        resetNavigation
    };
};

export default useTabNavigation;
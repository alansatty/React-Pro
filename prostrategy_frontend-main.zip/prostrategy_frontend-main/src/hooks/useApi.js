import { useMemo, useCallback } from "react";
import useSWR from "swr";
import useSWRMutation from "swr/mutation";
import axios from "axios";
import { useAuth } from "../providers/authProviders";
import toast from "react-hot-toast";
import { useNavigate } from "react-router";

// eslint-disable-next-line no-undef
axios.defaults.baseURL = import.meta.env.VITE_API_BASE_URL;

export const useApi = (key, url, options = {}) => {
  const auth = useAuth();
  const navigate = useNavigate();
  const { method = "GET", headers = {}, ...restOptions } = options;
  const authToken = useMemo(() => auth?.user?.token, [auth?.user?.token]);
  const baseConfig = useMemo(
    () => ({
      headers: {
        Authorization: authToken ? `Bearer ${authToken}` : undefined,
        "Content-Type": "application/json",
        ...headers,
      },
      ...restOptions,
    }),
    [authToken, headers, restOptions]
  );

  const handleUnauthorizedError = () => {
    auth.logOut();
  };

  const fetcher = useCallback(async () => {
    const config = {
      method: "GET",
      url,
      ...baseConfig,
    };
    try {
      const response = await axios(config);
      return response.data;
    } catch (error) {

      // Handle 400 Bad Request
      if (error.response && error.response.status === 400) {
        return Promise.reject(error.response.data);
      }

      if (error.response && error.response.status === 403) {
        toast.error(error.response.data.detail);
        navigate("/dashboard");
      }
      if (error.response && error.response.status === 406) {
        toast.error(error.response.data.data);
        navigate("/dashboard");
      }

      if (error.response && error.response.status === 401) {
        toast.dismiss();

        if (error?.response?.data?.plan_expired) {
          toast.error(error?.response?.data?.plan_expired);
        }

        if (error?.response?.data?.detail) {
          toast.error(error?.response?.data?.detail);
        }

        handleUnauthorizedError();
        return Promise.reject({
          status: 401,
          message: "Unauthorized",
        });
      } else {
        return Promise.reject({
          status: error.response ? error.response.status : 500,
          message: error.message || "An error occurred",
        });
      }
    }
  }, [url, baseConfig]);

  const mutationFetcher = useCallback(
    async (url, { arg }) => {
      const isFormData = arg?.requestBody instanceof FormData;
      let urlpath = arg?.dynamicPath ? `${url}${arg.dynamicPath}` : url;
      const config = {
        method: method || "POST",
        url: urlpath,
        ...baseConfig,
        headers: {
          ...baseConfig.headers,
          "Content-Type": isFormData ? undefined : "application/json",
        },
        data: arg?.requestBody,
      };

      try {
        const response = await axios(config);
        return response.data;
      } catch (error) {
        if (error.response && error.response.status === 400) {
          return Promise.reject(error.response.data);
        }

        if (error.response && error.response.status === 403) {
          toast.error(error.response.data.detail);
          // auth?.logOut()
          navigate("/dashboard");
        }
        if (error.response && error.response.status === 406) {
          toast.error(error.response.data.data);
          navigate("/dashboard");
        }
        if (error.response && error.response.status === 401) {
          toast.dismiss();
          if (error?.response?.data?.plan_expired) {
            toast.error(error?.response?.data?.plan_expired);
          }
          handleUnauthorizedError();
        }
        if (error.response) {
          return Promise.reject({
            status: error.response.status,
            data: error.response.data,
          });
        } else {
          return Promise.reject({
            message: error.message,
          });
        }
      }
    },
    [url, method, baseConfig]
  );

  const swrOptions = useMemo(
    () => ({
      shouldRetryOnError: false,
      isPaused: () => false,
      ...options.swrOptions,
    }),
    [options.swrOptions]
  );

  const {
    data: responseData,
    error,
    isLoading,
    isValidating,
  } = useSWR(method === "GET" ? key : null, fetcher, swrOptions);

  const {
    trigger,
    mutate,
    isMutating,
    error: mutationError,
  } = useSWRMutation(url, mutationFetcher);

  return {
    data: responseData,
    error,
    isLoading,
    trigger,
    mutate,
    isMutating,
    isValidating,
    mutationError,
  };
};

export default useApi;

// // useInactivityTimer.js
// import { useEffect, useRef } from 'react';

// const useInactivityTimer = (callback, delay) => {
//     const timerRef = useRef(null);

//     const resetTimer = () => {
//         if (timerRef.current) {
//             clearTimeout(timerRef.current);
//         }
//         timerRef.current = setTimeout(callback, delay);
//     };

//     useEffect(() => {
//         const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'];

//         events.forEach(event => {
//             window.addEventListener(event, resetTimer);
//         });

//         resetTimer(); // Initialize the timer

//         return () => {
//             if (timerRef.current) {
//                 clearTimeout(timerRef.current);
//             }
//             events.forEach(event => {
//                 window.removeEventListener(event, resetTimer);
//             });
//         };
//     }, [callback, delay]);

//     return { resetTimer };
// };

// export default useInactivityTimer;

// useInactivityTimer.js
import { useEffect, useRef, useCallback } from 'react';
import toast from 'react-hot-toast';
// or your toast library

const useInactivityTimer = (callback, delay, warningDelay) => {
    const timerRef = useRef(null);
    const warningTimerRef = useRef(null);
    const toastIdRef = useRef(null);

    const showWarning = () => {
        toast.error("You've been inactive for more than 5 minutes. Please save your progress before continuing.", {
            duration: 5000
        });
    };

    const resetTimer = () => {
        // Clear existing timers
        if (timerRef.current) clearTimeout(timerRef.current);
        if (warningTimerRef.current) clearTimeout(warningTimerRef.current);

        // Clear warning toast if it exists

        // Set warning timer (1 minute)
        warningTimerRef.current = setTimeout(() => {
            showWarning();
        }, warningDelay);

        // Set main callback timer (2 minutes)
        timerRef.current = setTimeout(callback, delay);
    };

    useEffect(() => {
        const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'];

        events.forEach(event => {
            window.addEventListener(event, resetTimer);
        });

        resetTimer(); // Initialize the timer

        return () => {
            if (timerRef.current) clearTimeout(timerRef.current);
            if (warningTimerRef.current) clearTimeout(warningTimerRef.current);
            // if (toastIdRef.current) toast.dismiss(toastIdRef.current);

            events.forEach(event => {
                window.removeEventListener(event, resetTimer);
            });
        };
    }, [callback, delay, warningDelay, showWarning]);

    return { resetTimer };
};

export default useInactivityTimer;
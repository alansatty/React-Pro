import { useEffect, useState, useCallback } from "react";
import { useNavigate, useLocation, useBlocker } from "react-router-dom";

const useBinderUnsavedChanges = (isFormDirty) => {
    const location = useLocation();
    const navigate = useNavigate();
    const [showModal, setShowModal] = useState(false);
    const [nextPath, setNextPath] = useState(null);
    const [pendingAction, setPendingAction] = useState(null);
    const [allowNavigation, setAllowNavigation] = useState(false);
    
    // Handle browser tab/window close
    useEffect(() => {
        const handleBeforeUnload = (event) => {
            if (isFormDirty) {
                event.preventDefault();
                event.returnValue = "You have unsaved changes. Are you sure you want to leave?";
            }
        };

        window.addEventListener("beforeunload", handleBeforeUnload);
        return () => {
            window.removeEventListener("beforeunload", handleBeforeUnload);
        };
    }, [isFormDirty]);

    // Only block navigation when the form is dirty
    const blocker = useBlocker(
        ({ nextLocation }) =>
            isFormDirty &&
            !allowNavigation &&
            nextLocation.pathname !== location.pathname

    );

    // Handle showing the confirmation modal when navigation is blocked
    useEffect(() => {
        if (blocker.state === "blocked") {
            setShowModal(true);
            setNextPath(blocker.location.pathname);
        }
    }, [blocker]);

    const confirmNavigation = useCallback(() => {
        setShowModal(false);

        if (nextPath) {
            // For route navigation
            setAllowNavigation(true);
            blocker.reset?.(); // Reset the blocker if this method is available
        } else if (pendingAction) {
            // Execute the pending action
            pendingAction();
        }

        setPendingAction(null);
    }, [blocker, nextPath, pendingAction]);

    const cancelNavigation = useCallback(() => {
        setShowModal(false);
        setPendingAction(null);
        setNextPath(null);
        blocker.reset?.(); // Reset the blocker if available
    }, [blocker]);

    const triggerNavigation = useCallback((action) => {
        if (isFormDirty) {

            setShowModal(true);
            setPendingAction(() => action);
            return false; // Navigation is pending
        }
        return true; // Navigation can proceed immediately
    }, [isFormDirty]);

    // Handle actual navigation after confirmation
    useEffect(() => {
        if (allowNavigation && nextPath) {
            navigate(nextPath);
            setAllowNavigation(false);
            setNextPath(null);
        }
    }, [allowNavigation, nextPath, navigate]);

    return {
        showModal,
        confirmNavigation,
        cancelNavigation,
        triggerNavigation,
        setShowModal
    };
};

export default useBinderUnsavedChanges;
import useSWRInfinite from 'swr/infinite';
import axios from 'axios';
import { useAuth } from '../providers/authProviders';
import { useMemo } from 'react';


export const useApiInfinite = (key, url, searchFilters = {}, options = {}) => {
    const auth = useAuth();
    const authToken = useMemo(() => auth?.user?.token, [auth?.user?.token]);
    const { method = 'GET', headers = {}, pageSize = 10, ...restOptions } = options;

    const fetcher = async (url) => {
        const config = {
            method: 'GET',
            url,
            headers: {
                Authorization: authToken ? `Bearer ${authToken}` : undefined,
                'Content-Type': 'application/json',
                ...headers,
            },
            ...restOptions,
        };

        const response = await axios(config);
        return response.data;
    };
    const createQueryString = (filters) => {
        const query = new URLSearchParams();
        Object.keys(filters).forEach((key) => {
            if (filters[key]) query.append(key, filters[key]);
        });
        return query.toString();
    };

    const getKey = (pageIndex, previousPageData) => {
        if (previousPageData && previousPageData?.length === 0) return null;
        const queryString = createQueryString(searchFilters);
        return `${url}?page=${pageIndex + 1}&pageSize=${pageSize}${queryString ? `&${queryString}` : ''}`;
    };

    // const getKey = (pageIndex, previousPageData) => {
    //     if (previousPageData && previousPageData?.length === 0) return null;
    //     return `${url}?page=${pageIndex + 1}&pageSize=${pageSize}`;
    // };

    const { data, error, size, setSize, isValidating } = useSWRInfinite(getKey, fetcher, {
        revalidateFirstPage: false,
        errorRetryCount: 3,
    });

    const isLoading = !data && !error;

    return {
        data,
        error,
        isLoading,
        isValidating,
        setSize,
        size,
    };
};

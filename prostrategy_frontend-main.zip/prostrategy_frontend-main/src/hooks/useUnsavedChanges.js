import { useEffect, useState } from "react";
import { useNavigate, useLocation, useBlocker } from "react-router-dom";

const useUnsavedChanges = (isFormDirty, pendingNavigation, handleNavigationConfirm = () => { }) => {
  const location = useLocation();
  const navigate = useNavigate();

  const [showModal, setShowModal] = useState(false);
  const [nextPath, setNextPath] = useState(null);
  const [allowNavigation, setAllowNavigation] = useState(false);

  useEffect(() => {
    if (pendingNavigation && isFormDirty) {
      setShowModal(true);
    }
  }, [pendingNavigation, isFormDirty]);

  useEffect(() => {
    const handleBeforeUnload = (event) => {
      if (isFormDirty) {
        event.preventDefault();
        event.returnValue = "You have unsaved changes. Are you sure you want to leave?";
      }
    };

    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
    };
  }, [isFormDirty]);

  // Prevent React Router navigation
  useBlocker(({ nextLocation }) => {
    if (isFormDirty && !allowNavigation && nextLocation.pathname !== location.pathname) {
      setShowModal(true);
      setNextPath(nextLocation.pathname);
      return true; // Block navigation
    }
    return false; // Allow navigation
  });

  // Handle actual navigation after confirmation
  useEffect(() => {
    if (allowNavigation && nextPath) {
      navigate(nextPath, { replace: true });
      setAllowNavigation(false);
      setNextPath(null);
    }
  }, [allowNavigation, nextPath, navigate]);

  const confirmNavigation = () => {
    setShowModal(false);

    if (nextPath) {
      // For route navigation
      setAllowNavigation(true);
    } else {
      // For side tab navigation
      handleNavigationConfirm(true);
    }
  };

  const cancelNavigation = () => {
    setShowModal(false);
    setNextPath(null);
    handleNavigationConfirm(false);
  };

  const saveClicked = () => {
    setShowModal(false);
    setNextPath(null);
    setAllowNavigation(true);
    handleNavigationConfirm(false);
  }

  return { showModal, confirmNavigation, cancelNavigation, setShowModal, saveClicked };
};

export default useUnsavedChanges;
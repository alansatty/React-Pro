import { useEffect } from "react";

/**
 * A custom hook to show a browser alert when the user tries to leave the page with unsaved changes.
 * @param {boolean} isDirty - Whether the form or page has unsaved changes.
 */
export const useBeforeUnload = (isDirty) => {
  useEffect(() => {
    const handleBeforeUnload = (event) => {
      if (isDirty) {
        event.preventDefault();
        event.returnValue = ""; // Required for Chrome
      }
    };
      
    // Add the event listener
    window.addEventListener("beforeunload", handleBeforeUnload);

    // Clean up the event listener
    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
    };
  }, [isDirty]); // Re-run the effect when `isDirty` changes
};
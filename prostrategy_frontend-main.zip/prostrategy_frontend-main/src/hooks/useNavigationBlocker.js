import { useEffect } from "react";
import { useBlocker } from "react-router-dom";

/**
 * A custom hook to block in-app navigation when there are unsaved changes.
 * @param {boolean} isDirty - Whether the form or page has unsaved changes.
 */
export const useNavigationBlocker = (isDirty) => {
  const blocker = useBlocker(({ currentLocation, nextLocation }) => {
    return isDirty && currentLocation.pathname !== nextLocation.pathname;
  });

  useEffect(() => {
    if (blocker.state === "blocked" && isDirty) {
      const confirmNavigation = window.confirm(
        "You have unsaved changes. Are you sure you want to leave?"
      );
      if (confirmNavigation) {
        blocker.proceed();
      } else {
        blocker.reset();
      }
    }
  }, [blocker, isDirty]);
};
import hasPermission from "../utils/hasPermission";
import { Navigate } from "react-router-dom";
import usePermissionsStore from "../stores/usePermissionStore";
import { PageSpinner } from "../components";
import hasPlanPermission from "../utils/hasPlanPermission";
import { useEffect, useState } from "react";

const ProtectedRoute = ({ children, page, action, planPermission = "", adminOnly = false }) => {
  const [permissionChecked, setPermissionChecked] = useState(false);
  const [hasAccess, setHasAccess] = useState(false);
  const isLoading = usePermissionsStore((state) => state.isLoading);
  const permissions = usePermissionsStore((state) => state.permissions);
  const isAdminUser = usePermissionsStore((state) => state.isAdminUser); // Get admin status from store

  useEffect(() => {
    if (!isLoading && permissions && permissions.length > 0) {

      const userHasPermission = hasPermission(page, action);
      const planHasPermission = planPermission ? hasPlanPermission(planPermission) : true;
      const adminCheck = adminOnly ? isAdminUser : true;

      setHasAccess(userHasPermission && planHasPermission || adminCheck);
      setPermissionChecked(true);
    }
  }, [isLoading, permissions]);

  if (isLoading || !permissionChecked) {
    return <PageSpinner />;
  }

  if (!hasAccess) {
    return <Navigate to="/not-authorized" />;
  }

  return children;
};


export default ProtectedRoute;

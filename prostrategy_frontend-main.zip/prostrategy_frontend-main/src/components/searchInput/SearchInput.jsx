import { useCallback } from "react";
import debounce from "lodash.debounce";
import { IconSearch } from "@tabler/icons-react";
import { Input } from "@nextui-org/input";
import { Tooltip } from "@nextui-org/tooltip";

const SearchInput = ({
  value,
  placeholder = "Search...",
  onSearch,
  onClear,
  debounceDelay = 300,
  radius = "sm",
  size = "md",
  className,
  setSearch,
  isDisabled = false,
  hover = false,
}) => {
  const debouncedSearch = useCallback(
    debounce((query) => {
      if (onSearch) {
        onSearch(query);
      }
    }, debounceDelay),
    []
  );

  const handleSearchChange = (e) => {
    const { value } = e.target;
    setSearch(value);
    debouncedSearch(value);
  };

  const handleClear = () => {
    onClear();
    debouncedSearch("");
  };

  const inputComponent = (
    <Input
      isClearable
      variant="bordered"
      value={value}
      classNames={{
        inputWrapper: [
          "h-[46px]",
          "group-data-[focus=true]:border-[#0098F5]",
          "dark:group-data-[focus=true]:border-[#0098F5]",
        ],
      }}
      className={`w-full ${className}`}
      placeholder={placeholder}
      startContent={<IconSearch className="text-gray-400" size={18} />}
      onClear={handleClear}
      onChange={handleSearchChange}
      radius={radius}
      size={size}
      isDisabled={isDisabled}
    />
  );

  return hover ? (
    <Tooltip content="Search strategic or department" placement="bottom">
      <div>{inputComponent}</div>
    </Tooltip>
  ) : (
    inputComponent
  );
};

export default SearchInput;

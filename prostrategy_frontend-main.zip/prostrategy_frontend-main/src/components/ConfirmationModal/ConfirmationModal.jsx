import { Button } from '@nextui-org/button';
import { Modal, ModalBody, ModalContent, ModalFooter, ModalHeader } from '@nextui-org/modal';
function ConfirmationModal({ isOpen, onClose, onConfirm, isLoading, deleteTitle = null, deleteMessage = null, buttonText = null, buttonColor = null }) {
    return (
        <Modal isOpen={isOpen} onClose={onClose}>
            <ModalContent>
                {(onClose) => (
                    <>
                        <ModalHeader className="flex flex-col gap-1">{deleteTitle || 'Delete Confirmation'}</ModalHeader>
                        <ModalBody>
                            {deleteMessage || <p>Are you sure you want to delete this?</p>}
                        </ModalBody>
                        <ModalFooter>
                            <Button onPress={onConfirm} color={buttonColor || "danger"} isLoading={isLoading} spinnerPlacement='end'>{buttonText == "yesNo" ? "Yes" : buttonText == "ConfirmType" ? "Confirm" : "Delete"}</Button>
                            <Button onPress={onClose} color="default">{buttonText == "yesNo" ? "No" : "Cancel"}</Button>
                        </ModalFooter>
                    </>
                )}
            </ModalContent>
        </Modal>
    )
}

export default ConfirmationModal;
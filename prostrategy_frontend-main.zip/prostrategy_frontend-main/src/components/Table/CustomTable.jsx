import { Pagination } from "@nextui-org/pagination";
import { Divider } from "@nextui-org/divider";
import clsx from "clsx";
import { useState, useRef, useEffect } from "react";
import {
  IconArrowDown,
  IconArrowUp,
  IconGripVertical,
} from "@tabler/icons-react";
import { Spinner } from "@nextui-org/spinner";
import { DndProvider, useDrag, useDrop } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";


const DraggableRow = ({
  item,
  index,
  columns,
  renderCell,
  page,
  rowIndex,
  moveRow,
  isClickable,
  handleClick,
  striped,
  id,
  isDraggable,
}) => {
  const ref = useRef(null);
  const orderIdRef = useRef("");

  const [{ isDragging }, drag] = useDrag({
    type: "ROW",
    item: () => {
      // Capture order_id immediately when drag starts
      const currentOrderId =
        ref.current?.getAttribute("data-order-id") || item.order_id;
      orderIdRef.current = currentOrderId;

      return {
        index,
        id: item.id,
        originalIndex: index,
        order_id: currentOrderId, // Store directly in the item
        setOrderId: (orderId) => {
          orderIdRef.current = orderId;
        },
        getOrderId: () => orderIdRef.current || currentOrderId, // Fallback to the initial value
      };
    },
    canDrag: isDraggable,
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  const [{ isOver, handlerId }, drop] = useDrop({
    accept: "ROW",
    collect: (monitor) => ({
      isOver: monitor.isOver({ shallow: true }),
      handlerId: monitor.getHandlerId(),
    }),
    hover(draggedItem, monitor) {
      if (!ref.current) return;

      const dragIndex = draggedItem.index;
      const hoverIndex = index;

      // Don't replace items with themselves
      if (dragIndex === hoverIndex) return;

      // Get rectangle on screen
      const hoverBoundingRect = ref.current.getBoundingClientRect();

      // Get vertical middle
      const hoverMiddleY =
        (hoverBoundingRect.bottom - hoverBoundingRect.top) / 2;

      // Get mouse position
      const clientOffset = monitor.getClientOffset();
      if (!clientOffset) return;

      // Get pixels to the top
      const hoverClientY = clientOffset.y - hoverBoundingRect.top;

      // Only perform the move when the mouse has crossed half of the item's height
      // When dragging downwards, only move when the cursor is below 50%
      // When dragging upwards, only move when the cursor is above 50%

      // Dragging downwards
      if (dragIndex < hoverIndex && hoverClientY < hoverMiddleY) {
        return;
      }

      // Dragging upwards
      if (dragIndex > hoverIndex && hoverClientY > hoverMiddleY) {
        return;
      }

      // Store the current order_id for the API call
      const currentOrderId =
        ref.current.getAttribute("data-order-id") || item.order_id;

      // Make sure we have a valid order_id
      if (currentOrderId) {
        orderIdRef.current = currentOrderId;
        draggedItem.setOrderId(currentOrderId);
        draggedItem.order_id = currentOrderId; // Set directly on the item as well
      }

      // Time to actually perform the action
      moveRow(currentOrderId, dragIndex, hoverIndex);

      // Note: we're mutating the monitor item here!
      // Generally it's better to avoid mutations,
      // but it's good here for the sake of performance
      // to avoid expensive index searches.
      draggedItem.index = hoverIndex;
    },
    drop(draggedItem, monitor) {
      // Get the order_id with fallbacks to ensure we always have a value
      const orderId =
        draggedItem.getOrderId() || draggedItem.order_id || item.order_id;

      if (orderId) {
        moveRow(orderId, draggedItem.index, index, true);
      } else {
        console.error("Failed to get order_id for reordering");
      }
    },
  });

  drag(drop(ref));

  return (
    <tr
      data-handler-id={handlerId}
      data-row-index={rowIndex}
      data-order-id={item.order_id}
      ref={ref}
      key={item?.id}
      className={clsx(
        "border-b border-gray-200 h-12",
        isClickable ? "hover:bg-gray-100 cursor-pointer" : "",
        striped && (rowIndex - 1) % 2 === 0 && "bg-gray-50",
        isDragging && "opacity-40 bg-blue-50",
        isOver && "bg-blue-50"
      )}
      style={{
        cursor: isDraggable ? "move" : isClickable ? "pointer" : "default",
      }}
    >
      {columns?.map((column, colIndex) => (
        <td
          onClick={() => {
            if (isClickable && !isDraggable) {
              if (item?.goal_strategy_id) {
                handleClick(item?.goal_strategy_id);
              } else {
                handleClick(item?.id);
              }
            }
          }}
          key={column.uid}
          className={clsx(
            "px-4 py-2 text-sm text-gray-600",
            column.uid === "drag_handle" && "w-8"
          )}
        >
          {column.uid === "drag_handle" && isDraggable ? (
            <div className="cursor-move flex justify-center">
              <IconGripVertical size={16} />
            </div>
          ) : (
            renderCell(item, column.uid, page, rowIndex - 1) // Adjust rowIndex for renderCell if needed
          )}
        </td>
      ))}
    </tr>
  );
};

export default function CustomTable({
  columns,
  renderCell,
  isClickable = false,
  handlePageChange,
  isLoading,
  responceData,
  page,
  handleClick,
  striped = false,
  headerColor = "#E9ECF2",
  headerTextClasses = "text-gray-700",
  isOrderBy = false,
  handleSortby,
  handleOrderBy,
  isstricky,
  isDraggable = false,
  onRowReorder,
  isForecast = false,
  setPage,
  setPerPage,
  perPage,
  isForcastTable = false,
}) {

  const [sortBy, setSortBy] = useState("");
  const [orderBy, setOrderBy] = useState("asc");
  const [data, setData] = useState([]);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handlePerPageChange = (size) => {
    setPerPage(size);
    setPage(1);
  };

  const forecastTableRef = useRef(null);
  const [scrollTop, setScrollTop] = useState(0);

  const handleScroll = (e) => {
    setScrollTop(e.target.scrollTop);
  };

  useEffect(() => {
    const table = forecastTableRef.current;
    if (isForecast && table) {
      table.addEventListener("scroll", handleScroll);
      return () => table.removeEventListener("scroll", handleScroll);
    }
  }, [isForecast]);

  useEffect(() => {
    if (responceData?.data) {
      setData(responceData?.data);
    }
  }, [responceData]);

  // Add drag handle column if draggable
  const tableColumns = isDraggable
    ? [{ name: "", uid: "drag_handle" }, ...columns]
    : columns;

  const handleSort = (columnKey) => {
    if (sortBy === columnKey) {
      const newOrder = orderBy === "asc" ? "desc" : "asc";
      setOrderBy(newOrder);
      handleOrderBy?.(newOrder);
    } else {
      setSortBy(columnKey);
      setOrderBy("asc");
      handleSortby?.(columnKey);
      handleOrderBy?.("asc");
    }
  };

  const moveRow = (order_id, dragIndex, hoverIndex, isFinalDrop = false) => {
    // Skip if no order_id is provided
    if (!order_id) {
      console.error("No order_id provided for moveRow");
      return;
    }

    // Create a stable copy of the data
    const newData = [...data];
    const draggedRow = { ...newData[dragIndex] };

    // Remove from old position and insert at new position
    newData.splice(dragIndex, 1);
    newData.splice(hoverIndex, 0, draggedRow);

    // Update local state immediately for visual feedback
    setData(newData);

    // Only call API on final drop
    if (isFinalDrop && onRowReorder) {
      onRowReorder(draggedRow?.id, order_id);
    }
  };

  const renderSortIcon = (columnKey) => {
    if (sortBy === columnKey) {
      return orderBy === "asc" ? <IconArrowDown /> : <IconArrowUp />;
    }
    return <IconArrowUp />;
  };

  return (
    <DndProvider backend={HTML5Backend}>
      <>
        {isForecast ? (
          <div className="flex flex-col h-full">
            <div
              className="flex justify-end mb-3">
            </div>
            {/* Outer container with proper height and hidden scrollbar */}
            <div className="relative flex-1">
              {/* Scrollable content area with hidden scrollbar */}
              <div
                // className="h-full w-[1300px]"
                className={`h-full ${columns?.length >= 13 ? "w-[3000px]" : "w-[1900px]"}`}
              // style={{
              //   scrollbarWidth: "none",
              //   msOverflowStyle: "none",
              // }}
              >
                {/* Custom scrollbar container */}
                < div className="relative ">
                  {/* Sticky header with proper column widths */}

                  <div className="sticky top-0  z-50 bg-[#E9ECF2] shadow-sm">
                    <div className="flex">
                      {/* Metric column */}
                      <div className="w-[200px] px-4 py-2 text-left text-sm font-semibold text-gray-700" style={{ minWidth: "120px" }}>
                        {/* Empty - just for spacing */}
                      </div>
                      {/* Year columns */}
                      {columns
                        .filter((col) => col.uid !== "metric")
                        .map((column) => (
                          <div
                            key={column.uid}
                            className="flex-1 px-4 py-2 text-left text-sm font-semibold text-gray-700"
                            style={{ minWidth: "100px" }} // Set fixed min-width for year columns
                          >
                            {column.name}
                          </div>
                        ))}
                    </div>
                  </div>

                  {/* Table content */}
                  <table className="min-w-full table-auto bg-white rounded-md">
                    <colgroup>
                      <col style={{ width: "200px" }} />{" "}
                      {/* Fixed width for metric column */}
                      {columns
                        .filter((col) => col.uid !== "metric")
                        .map((_, index) => (
                          <col
                            key={index}
                            style={{ minWidth: "100px" }}
                          /> /* Fixed min-width for year columns */
                        ))}
                    </colgroup>
                    <thead className="hidden">
                      {/* Hidden original header */}
                    </thead>
                    <tbody>
                      {isLoading ? (
                        <tr>
                          <td
                            colSpan={tableColumns.length}
                            className="text-center py-4"
                          >
                            <div className="flex justify-center items-center h-64">
                              <Spinner size="lg" />
                            </div>
                          </td>
                        </tr>
                      ) : data?.length > 0 ? (
                        data.map((item, rowIndex) => (
                          <tr
                            key={item?.id || rowIndex}
                            className={clsx(
                              "border-b border-gray-200 h-12",
                              isClickable
                                ? "hover:bg-gray-100 cursor-pointer"
                                : "",
                              striped && rowIndex % 2 === 0 && "bg-gray-50"
                            )}
                          >
                            {tableColumns.map((column) => (
                              <td
                                key={column.uid}
                                className={clsx(
                                  "px-4 py-2 text-sm text-gray-600",
                                  column.uid === "metric"
                                    ? "w-[200px]"
                                    : "min-w-[100px]"
                                )}
                              >
                                {renderCell(item, column.uid, page, rowIndex)}
                              </td>
                            ))}
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td
                            colSpan={tableColumns.length}
                            className="text-center py-4"
                          >
                            No records.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        ) : isstricky ? (
          <div className="overflow-x-auto mt-6 min-h-[calc(100vh-50vh)]">
            <table className="min-w-full table-auto bg-white rounded-md">
              {/* Sticky Header */}
              <thead className="bg-white z-10">
                <tr className="sticky top-0 z-20 ">
                  {columns?.map((column, index) => (
                    <th
                      key={column.uid}
                      className={clsx(
                        "px-4 py-2 text-left text-sm font-semibold",
                        headerTextClasses,
                        index < 2
                          ? "sticky left-0 z-30 bg-[#E9ECF2] shadow-md"
                          : "z-20 bg-[#E9ECF2]" // Freeze first two columns
                      )}
                      style={{ top: 0, zIndex: 50 }}
                    >
                      <div className="flex justify-between items-center">
                        <span>{column.name}</span>
                        {isOrderBy &&
                          [
                            "name",
                            "department_choices",
                            "start_date",
                            "production_date",
                            "added_asset_value",
                            "new_members",
                            "initial_capex",
                            "annual_opex",
                            "annual_revenue",
                            "expected_years_productive",
                            "annual_cost_savings",
                            "metric_one",
                            "metric_two",
                            "metric_three",
                            "metric_four",
                            "metric_five",
                            "metric_six",
                            "metric_seven",
                            "metric_eight",
                          ].includes(column.uid) && (
                            <span
                              className="ml-2 cursor-pointer"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleSort(column?.uid);
                              }}
                            >
                              {renderSortIcon(column?.uid)}
                            </span>
                          )}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>

              {/* Table Body */}
              <tbody>
                {isLoading ? (
                  <tr>
                    <td colSpan={columns.length} className="text-center py-4">
                      <div className="flex justify-center items-center h-64">
                        <Spinner size="lg" />{" "}
                      </div>
                    </td>
                  </tr>
                ) : data?.length > 0 ? (
                  data.map((item, rowIndex) => (
                    <tr
                      key={item?.id}
                      className={clsx(
                        "border-b border-gray-200 h-12",
                        isClickable ? "hover:bg-gray-100 cursor-pointer" : "",
                        striped && rowIndex % 2 === 0 && "bg-gray-50"
                      )}
                      style={{
                        position: rowIndex < 2 ? "sticky" : "relative", // Freeze first two rows
                        top:
                          rowIndex === 0
                            ? "42px"
                            : rowIndex === 1
                              ? "84px"
                              : "auto",
                        zIndex: rowIndex < 2 ? 15 : "auto",
                        backgroundColor: "white",
                      }}
                    >
                      {columns.map((column, index) => (
                        <td
                          onClick={() => {
                            if (isClickable) {
                              if (item?.goal_strategy_id) {
                                handleClick(item?.goal_strategy_id);
                              } else {
                                handleClick(item?.id);
                              }
                            }
                          }}
                          key={column.uid}
                          className={clsx(
                            "px-4 py-2 text-sm text-gray-600",
                            index < 2
                              ? "sticky left-0 z-10 bg-white shadow-md"
                              : "" // Freeze first two columns
                          )}
                          style={{
                            zIndex: index < 2 ? 10 : "auto",
                          }}
                        >
                          {renderCell(item, column.uid, page, rowIndex)}
                        </td>
                      ))}
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={columns.length} className="text-center py-4">
                      No records.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="overflow-x-auto mt-6 min-h-[calc(100vh-50vh)]">
            <table className="min-w-full table-auto bg-white rounded-md">
              <thead className={`bg-[${headerColor}]`}>
                <tr>
                  {tableColumns?.map((column) => (
                    <th
                      key={column.uid}
                      className={clsx(
                        "px-4 py-2 text-left text-sm font-semibold",
                        headerTextClasses
                      )}
                    >
                      <div className="flex justify-between items-center">
                        <span>{column.name}</span>
                        {isOrderBy &&
                          column.uid !== "drag_handle" &&
                          (column.uid === "name" ||
                            column.uid === "department_choices" ||
                            column.uid === "start_date" ||
                            column.uid === "production_date" ||
                            column.uid === "added_asset_value" ||
                            column.uid === "new_members" ||
                            column.uid === "initial_capex" ||
                            column.uid === "annual_opex" ||
                            column.uid === "annual_revenue" ||
                            column.uid === "expected_years_productive" ||
                            column.uid === "metric_one" ||
                            column.uid === "metric_two" ||
                            column.uid === "metric_three" ||
                            column.uid === "metric_four" ||
                            column.uid === "annual_cost_savings") && (
                            <span
                              className="ml-2 cursor-pointer"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleSort(column?.uid);
                              }}
                            >
                              {renderSortIcon(column?.uid)}
                            </span>
                          )}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr>
                    <td
                      colSpan={tableColumns.length}
                      className="text-center py-4"
                    >
                      <div className="flex justify-center items-center h-64">
                        <Spinner size="lg" />
                      </div>
                    </td>
                  </tr>
                ) : data?.length > 0 ? (
                  data.map((item, rowIndex) => (
                    <DraggableRow
                      key={item?.id || rowIndex}
                      item={item}
                      index={rowIndex}
                      columns={tableColumns}
                      renderCell={renderCell}
                      page={page}
                      rowIndex={rowIndex + 1} // This will now correctly start from 1
                      moveRow={moveRow}
                      isClickable={isClickable}
                      handleClick={handleClick}
                      striped={striped}
                      id={item?.id}
                      isDraggable={isDraggable}
                    />
                  ))
                ) : (
                  <tr>
                    <td
                      colSpan={tableColumns.length}
                      className="text-center py-4"
                    >
                      No records.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )
        }

        <div className="mt-4">
          <Divider orientation="horizontal" className="my-4" />
          <div className="flex justify-between items-center">
            <div className="text-sm text-gray-600">
              {/* ©{" "}
              {getCurrentDate({
                includeYear: true,
                includeMonth: false,
                includeDay: false,
              })}{" "} */}
              {/* ProStrategy.ai . All Rights Reserved | Support Contact us */}
            </div>
            {!isForcastTable ? (
              <div className="flex items-center gap-4">
                {/* Records Per Page Dropdown - Click to open */}
                <div className="relative" ref={dropdownRef}>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setIsDropdownOpen(!isDropdownOpen);
                    }}
                    className="flex items-center text-sm text-gray-600 hover:text-primary"
                  >
                    {perPage} Records Per Page {isDropdownOpen ? "▲" : "▼"}
                  </button>

                  {isDropdownOpen && (
                    <div // Add this to your dropdown div
                      className={`absolute bottom-full right-0 mb-2 bg-white border rounded shadow-md z-50 transition-all duration-200 ${isDropdownOpen
                        ? "opacity-100 translate-y-0"
                        : "opacity-0 translate-y-2"
                        }`}
                    >
                      {[10, 20, 30, 40, 50, 100].map((size) => (
                        <div
                          key={size}
                          onClick={(e) => {
                            e.stopPropagation();
                            handlePerPageChange(size);
                            setIsDropdownOpen(false);
                          }}
                          className={`px-4 py-2 text-sm hover:bg-gray-100 cursor-pointer ${size === perPage ? "bg-gray-100 font-medium" : ""
                            }`}
                        >
                          {size}
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {responceData?.total_pages > 1 && (
                  <Pagination
                    classNames={{
                      wrapper: "bg-white",
                      item: "bg-white text-black",
                      cursor: "bg-white text-primary",
                      prev: "bg-white text-black",
                      next: "bg-white text-black",
                    }}
                    className="bg-white"
                    radius="none"
                    variant="light"
                    isCompact
                    showControls
                    showShadow={false}
                    page={page}
                    total={responceData.total_pages}
                    onChange={handlePageChange}
                  />
                )}
              </div>
            ) : null}
          </div>
        </div>
      </>
    </DndProvider >
  );
}

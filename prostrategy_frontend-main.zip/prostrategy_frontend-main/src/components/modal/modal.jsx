import { Button } from "@nextui-org/button";
import {
  Modal,
  ModalBody,
  ModalContent,
  ModalFooter,
  ModalHeader,
} from "@nextui-org/modal";
import React from "react";

const modal = ({isOpen, onOpenChange  , content , size='sm' , scrollBehavior=""}) => {
  return (
    <Modal isOpen={isOpen} onOpenChange={onOpenChange} size={size}  scrollBehavior={scrollBehavior}> 
      <ModalContent>
        {(onClose) => (
          <>
             {content}
          </>
        )}
      </ModalContent>
    </Modal>
  );
};

export default modal;

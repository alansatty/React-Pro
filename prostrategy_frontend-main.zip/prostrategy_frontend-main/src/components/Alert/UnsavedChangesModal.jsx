import { useState, useEffect } from "react";
import { Button } from "@nextui-org/button";
import {
  Modal,
  ModalBody,
  ModalContent,
  ModalFooter,
  ModalHeader,
} from "@nextui-org/modal";

const UnsavedChangesModal = ({ isConfirmNavigation, isCancelNavigation }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <Modal
      isDismissable={false}
      isKeyboardDismissDisabled={true}
      isOpen={isVisible}
      onClose={isCancelNavigation}
      backdrop="transparent"
      className="fixed top-4 left-1/2 transform -translate-x-1/2 flex justify-center"
    >
      <ModalContent
        className={`
                w-full 
                max-w-md 
                transition-all 
                shadow-small
                duration-300 
                ease-in-out 
                transform
                ${isVisible ? "translate-y-0 opacity-100" : "-translate-y-full opacity-0"}
            `}
      >
        {() => (
          <>
            <ModalHeader className="flex flex-col gap-1 text-danger">
              Warning!
            </ModalHeader>
            <ModalBody>
              <p className="text-base">
                You have unsaved changes. Are you sure you want to leave?
              </p>
            </ModalBody>
            <ModalFooter>
              <Button onClick={isConfirmNavigation} color="danger">
                Leave
              </Button>
              <Button onClick={isCancelNavigation} color="default">
                Stay
              </Button>
            </ModalFooter>
          </>
        )}
      </ModalContent>
    </Modal>
  );
};

export default UnsavedChangesModal;

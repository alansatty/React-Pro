
import { Button } from "@nextui-org/button";
import { Modal, ModalBody, ModalContent } from "@nextui-org/modal";
import ProstrategyLogo from "../../assets/icons/ProstrategyLogo";
export default function AlerModal({
  isOpen,
  onOpenChange,
  title,
  desc,
  clickFunction
}) {
  return (
    <>
      <Modal isDismissable={false} hideCloseButton isOpen={isOpen} onOpenChange={onOpenChange} placement="center">
        <ModalContent className="text-black py-6">
          {(onClose) => (
            <>
              <ModalBody>
                <div>
                  <div className="flex items-center justify-center">
                    <ProstrategyLogo />
                  </div>
                </div>
                <div className=" py-3 px-1 text-center">
                  <h3 className="text-xl font-bold">{title}</h3>
                  <p className="text-gray-600 text-wrap font-lg py-4">{desc}</p>
                </div>
                <div className="flex justify-center gap-2">
                  <Button color="primary" radius="sm" onPress={() => {
                    onOpenChange(false)
                    clickFunction()
                  }}>
                    Okay
                  </Button>
                </div>
              </ModalBody>
            </>
          )}
        </ModalContent>
      </Modal>
    </>
  );
}
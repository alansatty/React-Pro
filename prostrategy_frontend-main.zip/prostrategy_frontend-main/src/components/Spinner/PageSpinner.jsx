import { Spinner } from '@nextui-org/spinner'
import React from 'react'
import { cn } from '../../utils/twMege'

function PageSpinner({className="",text=""}) {
  return (
    <div className={cn('grid place-items-center h-screen w-full',className)}><Spinner /></div>
  )
}

export default PageSpinner
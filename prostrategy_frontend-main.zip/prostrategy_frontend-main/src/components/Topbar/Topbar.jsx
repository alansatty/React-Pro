import { Button } from "@nextui-org/button";
import {
  Dropdown,
  DropdownItem,
  DropdownMenu,
  DropdownTrigger,
} from "@nextui-org/dropdown";
import {
  useLocation,
  useNavigate,
  useParams,
  useSearchParams,
} from "react-router-dom";
import { useAuth } from "../../providers/authProviders";
import {
  IconChevronDown,
} from "@tabler/icons-react";
import Breadcrumb from "../BreadCrumbs/BreadCrumbs";
import useApi from "../../hooks/useApi";
import useTopbarStore from "../../stores/torbarStore";
import HelpModal from "./HelpModal";
import { UserManagementHelp } from "./helpComponents/UserManagementHelp";
import DashboardHelp from "./helpComponents/DashboardHelp";
import BusinessTargetsHelp, {
  UserEditHelp,
  CreateNewRoleHelp,
  DepartmentBusinessTargetsHelp,
  DepartmentDashboardHelp,
  DepartmentSVADashboardHelp,
  // DepartmentSVAFormHelp,
  EditRoleHelp,
  OrganizationGoalsHelp,
  OrganizationValueHelp,
  OrganizationVisionHelp,
  RoleHelp,
  SustainingObjectivesHelp,
  UserCreateHelp,
  OrganizationSettingsHelp,
  DepartmentMissionHelp,
  DepartmentVisionHelp,
  DepartmentValueHelp,
  ObjectiveHelpDepartment,
  GoalAndStrategyHelp,
  SWOTFormHelp,
  StrategyDataHelp,
  SubscriptionPlanDetails,
  ProfileHelp,
  ProfileBillingHistoryHelp,
  StrategicReportHelp,
  ChatHelp,
  SwotDashboardHelp,
  StrategicPlansPageHelp,
  DepartmentSWOTDashboardHelp,
  OrganizationFoundationshelp,
  DepartmentSWOTFormHelp,
  StrategicReportEditorHelp,
  DepartmentSVAFormMinimumHelp,
  DepartmentSVAFormMarketCompetitive,
  DepartmentSVAFormLeadership,
  DepartmentSVAFormElite,
  GoalsAndStrategy,
  InitialStrategicSettings,
} from "./helpComponents/Helps";
import PageSpinner from "../Spinner/PageSpinner";
import { apiList } from "../../services";
import { useQueryState } from "nuqs";
import usePermissionsStore from "../../stores/usePermissionStore";

function Topbar() {

  const auth = useAuth();
  const location = useLocation();
  const { subtitle } = useTopbarStore(); // Using store for subtitle
  const [searchParams] = useSearchParams();
  const section = searchParams.get("section");
  const [tableofcont, setTableOfCont] = useQueryState("TableofContents");

  const navigate = useNavigate();

  const routes = {
    "/dashboard": { title: "Dashboard", prev: null, prevLink: null },
    "/users": { title: "User Management", prev: null, prevLink: null },
    "/users/create": {
      title: "Create New User",
      prev: "User Management",
      prevLink: "/users",
    },
    "/users/edit/:id": {
      title: "Edit User",
      prev: "User Management",
      prevLink: "/users",
    },
    "/role-management": {
      title: "Role Management",
      prev: null,
      prevLink: null,
    },
    "/role-management/create": {
      title: "Create New Role",
      prev: "Role Management",
      prevLink: "/role-management",
    },
    "/departments": { title: "Departments Foundation", prev: null, prevLink: null },

    "/settings/organization_tab": {
      title: "Settings - Organization",
      prev: null,
      prevLink: null,
    },
    "/settings/strategic_data_tab": {
      title: "Settings - Initial Strategic Data",
      prev: null,
      prevLink: null,
    },
    "/settings/user_management_tab": {
      title: "Settings - User Management",
      prev: null,
      prevLink: null,
    },
    "/settings/general": {
      title: "Settings - Profile",
      prev: null,
      prevLink: null,
    },
    // "/organizationgoals/mission_tab": {
    //   title: "Settings - Organization Business Target",
    //   prev: null,
    //   prevLink: null,
    // },

    "/organizationgoals/mission_tab": {
      title: "Organization Foundation - Mission",
      prev: null,
      prevLink: null,
    },
    "/organizationgoals/vision_tab": {
      title: "Organization Foundation - Vision",
      prev: null,
      prevLink: null,
    },
    "/organizationgoals/value_tab": {
      title: "Organization Foundation - Value",
      prev: null,
      prevLink: null,
    },
    "/organizationgoals/sustaining_tab": {
      title: "Organization Foundation - Organization Pillars",
      prev: null,
      prevLink: null,
    },

    "/organizationgoals/svaform": {
      title: "Organization Foundation SVA Form",
      prev: null,
      prevLink: null,
    },

    "/organizationgoals/sva_dashboard": {
      title: "Organization Foundation SVA Dashboard",
      prev: null,
      prevLink: null,
    },

    "/organizationgoals/swot_tab": {
      title: "Organization Foundation SWOT Form",
      prev: null,
      prevLink: null,
    },

    "/organizationgoals/analysis_tab": {
      title: "Organization Foundation SWOT Analysis",
      prev: null,
      prevLink: null,
    },

    "/organizationgoals/goals_tab": {
      title: "Organization Foundation Goals",
      prev: null,
      prevLink: null,
    },

    "/departments/target/:id": {
      title: "Department Business Targets",
      prev: "Departments",
      prevLink: "/departments",
    },
    "/departments/dept_users/:id": {
      title: "Department Users",
      prev: "Departments",
      prevLink: "/departments",
    },
    "/departments/:id": {
      title: "Department Foundation",
      prev: null,
      prevLink: "/departments",
    },
    // "/departments/:id/department_goals": {
    //   title: "Department Goals",
    //   prev: "Departments",
    //   prevLink: "/departments",
    // },
    "/departments/:id/mission": {
      title: "Department Mission",
      prev: "Departments",
      prevLink: "/departments",
    },
    "/departments/:id/Vision": {
      title: "Department Vision",
      prev: "Departments",
      prevLink: "/departments",
    },
    "/departments/:id/sustaining_objective": {
      title: "Department Pillars",
      prev: "Departments",
      prevLink: "/departments",
    },
    "/departments/:id/Value": {
      title: "Department Value",
      prev: "Departments",
      prevLink: "/departments",
    },
    "/departments/:id/svaform": {
      title: "Department SVA Form",
      prev: "Departments",
      prevLink: "/departments",
    },
    "/departments/:id/sva_dashboard": {
      title: "Department SVA Dashboard",
      prev: "Departments",
      prevLink: "/departments",
    },

    "/departments/:id/swot_tab": {
      title: "Department SWOT Form",
      prev: "Departments",
      prevLink: "/departments",
    },

    "/departments/:id/analysis_tab": {
      title: "Department SWOT Analysis",
      prev: "Departments",
      prevLink: "/departments",
    },

    "/departments/:id/goals_and_strategies_tab": {
      title: "Department Goals And Strategies",
      prev: "Departments",
      prevLink: "/departments",
    },
    "/departments/:id/goals_and_strategies_tab/:stragicId/strategic-planing-report": {
      title: "Department Goals And Strategies List ",
      prev: "Departments",
      prevLink: "/departments",
    },
    "/departments/:id/goals_and_strategies_list": {
      title: "Department Goals And Strategies List",
      prev: "Departments",
      prevLink: "/departments",
    },
    "/departments/:id/department_report_tab": {
      title: "Department Report",
      prev: "Departments",
      prevLink: "/departments",
    },
    "/departments/:id/goals_and_strategies_list/:stragicId/strategic-monitor-list": {
      title: "Department Goals And Strategies ",
      prev: "Departments",
      prevLink: "/departments",
    },


    "/profile/general": {
      title: "Profile - Details",
      prev: null,
      prevLink: null,
    },

    "/settings/account_tab": {
      title: "Settings - Account",
      prev: null,
      prevLink: null,
    },

    "/pricingplans": {
      title: "Pricing Plans",
      prev: "Profile - Subscription Plan",
      prevLink: "/settings/account_tab",
    },

    "/checkout/:planId": {
      title: "Checkout Plan",
      prev: "Pricing Plans",
      prevLink: "/pricingplans",
    },

    "/profile/billing_history": {
      title: "Profile - Billing History",
      prev: null,
      prevLink: null,
    },

    "/chats": {
      title: "Chats",
      prev: null,
      prevLink: null,
    },

    "/strategicplans": {
      title: "Strategic Plans",
      prev: null,
      prevLink: null,
    },

    "/strategy_form_data/goals_and_strategy": {
      title: "Goals & Strategy",
      prev: null,
      prevLink: null,
    },
    "/strategy_form_data/gantt_chart_tab": {
      title: "Gantt Chart",
      prev: null,
      prevLink: null,
    },
    "/strategy_form_data/Forecast": {
      title: "Forecast",
      prev: null,
      prevLink: null,
    },
    "/strategy_form_data/Graphs": {
      title: "Graph",
      prev: null,
      prevLink: null,
    },
    "/strategy_form_data/data_tab": {
      title: "Strategy Data",
      prev: null,
      prevLink: null,
    },
    "/organizationgoals/bussiness_target": {
      title: "Organization Foundation - Bussiness Target",
      prev: null,
      prevLink: null,
    },
  };

  const helpContentByRoute = {
    "/users": {
      title: "User Management Help",
      ContentComponent: UserManagementHelp,
    },
    "/dashboard": {
      title: "Dashboard Help",
      ContentComponent: DashboardHelp,
    },
    "/users/create": {
      title: "User Create Help",
      ContentComponent: UserCreateHelp,
    },
    "/users/edit/": {
      title: "User Edit Help",
      ContentComponent: UserEditHelp,
    },
    "/role-management": {
      title: "Role Management Help",
      ContentComponent: RoleHelp,
    },
    "/role-management/create": {
      title: "Role Create Help",
      ContentComponent: CreateNewRoleHelp,
    },

    "/role-management/edit/": {
      title: "Role Edit Help",
      ContentComponent: EditRoleHelp,
    },
    "/organizationgoals/mission_tab": {
      title: "Organization Goals Mission Help",
      ContentComponent: OrganizationGoalsHelp,
    },
    "/organizationgoals/vision_tab": {
      title: "Organization Goals Vision Help",
      ContentComponent: OrganizationVisionHelp,
    },
    "/organizationgoals/value_tab": {
      title: "Organization Goals Value Help",
      ContentComponent: OrganizationValueHelp,
    },
    "/organizationgoals/sustaining_tab": {
      title: "Organization Goals SustainingObjectivesTab Help",
      ContentComponent: SustainingObjectivesHelp,
    },
    "/departments": {
      title: "Department Help",
      ContentComponent: DepartmentDashboardHelp,
    },
    "/departments/target/:id": {
      title: "Department Business Target Help",
      ContentComponent: DepartmentBusinessTargetsHelp,
    },
    "/departments/:id/Department_goals": {
      title: "Department Goals Help",
      ContentComponent: DepartmentSVADashboardHelp,
    },
    "departments/MinimumRequirements": {
      title: "Department Minimum Requirements help",
      ContentComponent: DepartmentSVAFormMinimumHelp,
    },
    "departments/MarketCompetitive": {
      title: "Department Sva Dashboard Help",
      ContentComponent: DepartmentSVAFormMarketCompetitive,
    },
    "departments/Leadership": {
      title: "Department Sva Dashboard Help",
      ContentComponent: DepartmentSVAFormLeadership,
    },
    "departments/Elite": {
      title: "Department Sva Dashboard Help",
      ContentComponent: DepartmentSVAFormElite,
    },
    "/departments/:id/Sva_dash": {
      title: "Department Sva Dashboard Help",
      ContentComponent: DepartmentSVADashboardHelp,
    },
    "/settings/organization_tab": {
      title: "settings Organization help ",
      ContentComponent: OrganizationSettingsHelp,
    },
    "/settings/strategic_data_tab": {
      title: "settings Initial Strategic help ",
      ContentComponent: InitialStrategicSettings,
    },
    "/department_goals?section=mission": {
      title: "Department Mission",
      ContentComponent: DepartmentMissionHelp,
    },
    "/department_goals?section=vision": {
      title: "Department Vision",
      ContentComponent: DepartmentVisionHelp,
    },
    "/department_goals?section=value": {
      title: "Department Value",
      ContentComponent: DepartmentValueHelp,
    },
    "/department_goals?section=sustaining_objective": {
      title: "Department SustainingObjective",
      ContentComponent: ObjectiveHelpDepartment,
    },
    "/departments/:id/goals_and_strategies_tab": {
      title: "Goals And Strategies",
      ContentComponent: GoalAndStrategyHelp,
    },
    "/organizationgoals/swot_tab": {
      title: "SWOTForm",
      ContentComponent: SWOTFormHelp,
    },
    "/strategy_form_data/data_tab": {
      title: "Strategy Data ",
      ContentComponent: StrategyDataHelp,

    },
    "/settings/account_tab": {
      title: "Subscription Plan",
      ContentComponent: SubscriptionPlanDetails,
    },
    "/profile/general": {
      title: "Profile General",
      ContentComponent: ProfileHelp
    },
    "/profile/billing_history": {
      title: "Profile billing history",
      ContentComponent: ProfileBillingHistoryHelp
    },
    "/strategic-planing-report?TableofContents=1": {
      title: "strategic planing report",
      ContentComponent: StrategicReportHelp
    },
    "/strategic-planing-report?TableofContents=2": {
      title: "Table of Contents 2",
      ContentComponent: StrategicReportEditorHelp
    },

    "/chats": {
      title: "chats",
      ContentComponent: ChatHelp
    },
    "/organizationgoals/analysis_tab": {
      title: "analysis tab",
      ContentComponent: SwotDashboardHelp
    },
    "/strategicplans": {
      title: "strategic plans",
      ContentComponent: StrategicPlansPageHelp
    },

    "/departments/:id/analysis_tab": {
      title: "analysis tab",
      ContentComponent: DepartmentSWOTDashboardHelp
    },
    "/organizationgoals/goals_tab": {
      title: "goals tab",
      ContentComponent: OrganizationFoundationshelp
    },
    "/departments/:id/swot_tab": {
      title: "swot tab",
      ContentComponent: DepartmentSWOTFormHelp
    },
    "/goals_and_strategy": {
      title: "goals and strategy",
      ContentComponent: GoalsAndStrategy
    }
    // Add more routes as needed
  };

  const getHelpContentByRoute = (path) => {
    // (path, "glooo");
    // Check for exact match in static routes
    if (helpContentByRoute[path]) {
      return helpContentByRoute[path];
    }

    // Handle dynamic routes like "/departments/target/:id"
    if (section?.includes("mission")) {
      return helpContentByRoute["/department_goals?section=mission"];
    }
    if (section?.includes("sustaining_objective")) {
      return helpContentByRoute[
        "/department_goals?section=sustaining_objective"
      ];
    }
    if (section?.includes("vision")) {
      return helpContentByRoute["/department_goals?section=vision"];
    }
    if (section?.includes("value")) {
      return helpContentByRoute["/department_goals?section=value"];
    }
    if (path.includes("/departments/target/")) {
      return helpContentByRoute["/departments/target/:id"];
    }

    if (tableofcont && tableofcont == 1) {
      return helpContentByRoute["/strategic-planing-report?TableofContents=1"];
    }
    if (tableofcont && tableofcont == 2) {
      return helpContentByRoute["/strategic-planing-report?TableofContents=2"];
    }

    if (path.includes('/goals_and_strategy')) {
      return helpContentByRoute["/goals_and_strategy"]
    }
    if (path.includes("/sva_dashboard")) {
      return helpContentByRoute["/departments/:id/Sva_dash"];
    }
    if (path.includes("/role-management/edit/")) {
      return helpContentByRoute["/role-management/edit/"];
    }
    if (path.includes("/users/edit/")) {
      return helpContentByRoute["/users/edit/"];
    }
    if (path.includes('/goals_and_strategies_tab')) {
      return helpContentByRoute["/departments/:id/goals_and_strategies_tab"]
    }
    if (path.includes("/organizationgoals/swot_tab")) {
      return helpContentByRoute["/organizationgoals/swot_tab"]
    }

    if (path.includes('/data_tab')) {
      return helpContentByRoute["/strategy_form_data/data_tab"]
    }

    if (path.includes('/subscription_plan')) {
      return helpContentByRoute["/settings/account_tab"]
    }

    if (path.includes('/general')) {
      return helpContentByRoute['/profile/general']
    }
    if (path.includes('/billing_history')) {
      return helpContentByRoute['/profile/billing_history']
    }
    if (path.includes('/strategic-planing-report')) {
      return helpContentByRoute['/strategic-planing-report']
    }
    if (path.includes('/organizationgoals/analysis_tab')) {
      return helpContentByRoute['/analysis_tab']
    }
    if (path.includes('/analysis_tab')) {
      return helpContentByRoute['/departments/:id/analysis_tab']
    }
    if (path.includes('/goals_tab')) {
      return helpContentByRoute['/organizationgoals/goals_tab']
    }
    if (path.includes('/swot_tab')) {
      return helpContentByRoute['/departments/:id/swot_tab']
    }

    if (section?.includes('Minimum Requirements')) {
      return helpContentByRoute['departments/MinimumRequirements']
    }

    if (section?.includes('Market Competitive')) {
      return helpContentByRoute['departments/MarketCompetitive']
    }

    if (section?.includes('Leadership')) {
      return helpContentByRoute['departments/Leadership']
    }

    if (section?.includes('Elite')) {
      return helpContentByRoute['departments/Elite']
    }

    return {
      title: "Help",
      ContentComponent: () => <p>No specific help available for this page.</p>,
    };
  };
  const currentPath = location.pathname;

  const getRouteInfo = (path) => {
    if (routes[path]) {
      return routes[path];
    }

    if (path.includes("/users/edit")) {
      return routes["/users/edit/:id"];
    }

    if (path.includes("/departments/target")) {
      return routes["/departments/target/:id"];
    }

    if (path.includes("/departments/dept_users")) {
      return routes["/departments/dept_users/:id"];
    }

    if (path.includes("/department_goals")) {
      return routes["/departments/:id/department_goals"];
    }

    if (path.includes("/svaform")) {
      return routes["/departments/:id/svaform"];
    }

    if (path.includes('/mission')) {
      return routes['/departments/:id/mission']
    }

    if (path.includes('/Vision')) {
      return routes['/departments/:id/Vision']
    }

    if (path.includes('/sustaining_objective')) {
      return routes['/departments/:id/sustaining_objective']
    }

    if (path.includes('/Value')) {
      return routes['/departments/:id/Value']
    }

    if (path.includes("/sva_dashboard")) {
      return routes["/departments/:id/sva_dashboard"];
    }

    if (path.includes("/swot_tab")) {
      return routes["/departments/:id/swot_tab"];
    }

    if (path.includes("/analysis_tab")) {
      return routes["/departments/:id/analysis_tab"];
    }
    if (path.includes("/goals_and_strategies_tab")) {
      return routes["/departments/:id/goals_and_strategies_tab"];
    }
    if (path.includes("/strategic-planing-report")) {
      return routes["/departments/:id/goals_and_strategies_tab/:stragicId/strategic-planing-report"];
    }
    if (path.includes("/goals_and_strategies_list")) {
      return routes["/departments/:id/goals_and_strategies_list"];
    }

    if (path.includes("/strategic-planing-report")) {
      return routes["/departments/:id/goals_and_strategies_list/:stragicId/strategic-monitor-list"];
    }
    if (path.includes("/department_report_tab")) {
      return routes["/departments/:id/department_report_tab"];
    }
    if (path.includes("/departments/")) {
      return routes["/departments/:id"];
    }

    if (path.includes("/checkout/")) {
      return routes["/checkout/:planId"];
    }

    if (path.includes("/data_tab")) {
      return routes["/strategy_form_data/data_tab"]
    }
    if (path.includes('/billing_history')) {
      return routes['/profile/billing_history']
    }


    return { title: "ProStrategy", prev: null, prevLink: null };
  };

  const { title, prev, prevLink } = getRouteInfo(currentPath);

  const helpContent = getHelpContentByRoute(currentPath);

  // const shouldDisplaySubtitle = () => {
  //   const routesWithoutSubtitle = ['/recipients'];
  //   return !routesWithoutSubtitle.includes(location.pathname);
  // };
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
  const { data, error, isLoading } = useApi(
    strategicPlan ? apiList.admin.profile.details.key(auth?.user?.user_id, strategicPlan) : null,
    strategicPlan ? apiList.admin.profile.details.call(auth?.user?.user_id, strategicPlan) : null
  );

  const hasLogo = data?.data?.organization_logo ? true : false
  const logoUrl = data?.data?.organization_logo;

  if (isLoading) {
    return <PageSpinner className="bg-white" />;
  }


  return (
    <div className="fixed top-0 z-30 w-full bg-white py-3 px-14 md:pl-56 flex justify-between items-center shadow">
      <div className="ml-36 mt-1">
        {prev ? (
          <Breadcrumb
            prev={
              currentPath.includes("/departments/target") ||
                currentPath.includes("/departments/dept_users") ||
                currentPath.includes("/department_goals") ||
                currentPath.includes("/svaform") ||
                currentPath.includes("/sva_dashboard") ||
                currentPath.includes("/swot_tab") ||
                currentPath.includes("/analysis_tab") ||
                currentPath.includes("/goals_and_strategies_tab") ||
                currentPath.includes("/goals_and_strategies_list") ||
                currentPath.includes("/department_report_tab") ||
                currentPath.includes("/mission") ||
                currentPath.includes("/Vision") ||
                currentPath.includes("/Value") ||
                currentPath.includes("/sustaining_objective") ||
                currentPath.includes("/strategic-planing-report")

                ? `Departments / ${subtitle}`
                : prev
            }
            current={title}
            prevLink={prevLink}
          />
        ) : (
          <h2 className="font-semibold text-md">{title}</h2>
        )}
      </div>
      <div className="flex gap-2">
        {hasLogo && (
          <div className="mr-2 flex items-center">
            <img
              src={logoUrl}
              alt="Organization Logo"
              className="h-8 w-auto max-w-[120px] object-contain"
              onError={(e) => {
                e.target.style.display = 'none'; // Hide if image fails to load
              }}
            />
          </div>
        )}
        {/* <Button radius="sm" className="bg-black text-white " > <IconHelp />Help</Button> */}
        <HelpModal
          title={helpContent?.title}
          ContentComponent={helpContent?.ContentComponent}
        />
        <Dropdown>
          <DropdownTrigger>
            <Button
              variant="bordered"
              radius="sm"
              className="font-medium"
              endContent={<IconChevronDown size={"1.6em"} color="#717171" />}
            >
              {/* {auth?.user?.name} */}
              {data?.data?.full_Name}
            </Button>
          </DropdownTrigger>
          <DropdownMenu aria-label="Action event example">
            <DropdownItem key="profile" onClick={() => navigate("/profile")}>
              Profile
            </DropdownItem>
            <DropdownItem
              key="signout"
              className="text-danger"
              color="danger"
              onClick={() => auth?.logOut()}
            >
              Sign Out
            </DropdownItem>
          </DropdownMenu>
        </Dropdown>
      </div>
    </div>
  );
}

export default Topbar;

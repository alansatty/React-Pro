
import { Button } from "@nextui-org/button";
import { Divider } from "@nextui-org/divider";
import { Modal, ModalBody, ModalContent, ModalFooter, ModalHeader, useDisclosure } from "@nextui-org/modal";
import { IconHelp } from "@tabler/icons-react";

const HelpModal = ({ title, ContentComponent, isStatic = false, isReadMore = false, text = '' }) => {
  const { isOpen, onOpen, onOpenChange } = useDisclosure();

  return (
    <>
      {isReadMore ? (<span className="text-primary hover:underline ml-1 cursor-pointer" onClick={onOpen}>
        Read more.
      </span>) : (<Button onPress={onOpen} size={isStatic ? "sm" : "md"} radius="sm" className="bg-black text-white">
        <span className="flex gap-1 items-center">
          <IconHelp />
          {text ? text : 'Help'}
        </span>
      </Button>)}
      <Modal
        radius="sm"
        size="4xl"
        isOpen={isOpen}
        onOpenChange={onOpenChange}
        isDismissable={false}
        isKeyboardDismissDisabled={true}
        classNames={{
        }}
      >
        <ModalContent>
          {(onClose) => (
            <>
              <ModalHeader className="flex flex-col gap-1">{"Help"}</ModalHeader>
              <Divider />
              <ModalBody>
                <ContentComponent />
              </ModalBody>
              <ModalFooter>
                <Button color="danger" variant="light" onPress={onClose}>
                  Close
                </Button>
              </ModalFooter>
            </>
          )}
        </ModalContent>
      </Modal>
    </>
  );
};

export default HelpModal;

import {
  IconPencil,
  IconTrash,
} from "@tabler/icons-react";
import { useSearchParams } from "react-router-dom";



export const UserCreateHelp = () => {
  return (
    <div className=" bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
      <p className="mb-4 text-gray-700">To complete the Create User form:</p>

      <ul className="space-y-4">
        <li className="flex items-start space-x-3">
          {/* <div className="flex-shrink-0">
            <IconUser className="h-6 w-6 text-gray-500" />
          </div> */}
          <div>
            <p className="font-semibold">Full Name:</p>
            <span>
              The name <strong>"Jos Butler"</strong> is already filled in.
            </span>
          </div>
        </li>

        <li className="flex items-start space-x-3">
          {/* <div className="flex-shrink-0">
            <IconMail className="h-6 w-6 text-gray-500" />
          </div> */}
          <div>
            <p className="font-semibold">Email:</p>
            <span>
              The email <strong>"josbutler@gmail.com"</strong> is also filled in
              correctly.
            </span>
          </div>
        </li>

        <li className="flex items-start space-x-3">
          {/* <div className="flex-shrink-0">
            <IconTag className="h-6 w-6 text-gray-500" />
          </div> */}
          <div>
            <p className="font-semibold">User Type:</p>
            <span>
              <strong>"Department User"</strong> has been selected. Ensure this
              is the correct classification for the user.
            </span>
          </div>
        </li>

        <li className="flex items-start space-x-3">
          {/* <div className="flex-shrink-0">
            <IconDropletDown className="h-6 w-6 text-gray-500" />
          </div> */}
          <div>
            <p className="font-semibold">Department:</p>
            <span>A dropdown is visible with the following options:</span>
            <ul className="list-disc ml-6">
              <li>Human Resources (HR)</li>
              <li>Finance</li>
              <li>Marketing</li>
              <li>Product Development</li>
              <li>Research and Development (R&D)</li>
              <li>Operations</li>
            </ul>
            <span>
              Choose the appropriate department for <strong>Jos Butler</strong>{" "}
              by selecting the relevant option.
            </span>
          </div>
        </li>

        <li className="flex items-start space-x-3">
          {/* <div className="flex-shrink-0">
            <IconBriefcase className="h-6 w-6 text-gray-500" />
          </div> */}
          <div>
            <p className="font-semibold">Role:</p>
            <span>
              After selecting the department, fill in the specific role for{" "}
              <strong>Jos Butler</strong> from the available options.
            </span>
          </div>
        </li>
      </ul>

      <p className="mt-6">
        Once all fields are completed, you can either click{" "}
        <strong>Create</strong> to create the user or <strong>Cancel</strong> to
        discard changes.
      </p>

      <p className="mt-4">
        This form allows you to assign specific department and role
        responsibilities for new users in the system.
      </p>
    </div>
  );
};

export const UserEditHelp = () => {
  return (
    <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
      <p className="mb-4 text-gray-700">To complete the Edit User form:</p>

      <ul className="space-y-4">
        <li className="flex items-start space-x-3">
          <div>
            <p className="font-semibold">Full Name:</p>
            <span>
              The user's full name, <strong>"Jos Butler"</strong>, is already
              filled in. You can edit this field if necessary.
            </span>
          </div>
        </li>

        <li className="flex items-start space-x-3">
          <div>
            <p className="font-semibold">Email:</p>
            <span>
              The email, <strong>"josbutler@gmail.com"</strong>, is pre-filled.
              Make sure the email is correct or update it if needed.
            </span>
          </div>
        </li>

        <li className="flex items-start space-x-3">
          <div>
            <p className="font-semibold">User Type:</p>
            <span>
              The user type, <strong>"Department User"</strong>, is selected.
              You can change this if the user's role has changed (e.g., to Admin
              or Manager).
            </span>
          </div>
        </li>

        <li className="flex items-start space-x-3">
          <div>
            <p className="font-semibold">Department:</p>
            <span>
              A dropdown is visible with the user's current department
              pre-selected. You can choose from options such as:
            </span>
            <ul className="list-disc ml-6">
              <li>Human Resources (HR)</li>
              <li>Finance</li>
              <li>Marketing</li>
              <li>Product Development</li>
              <li>Research and Development (R&D)</li>
              <li>Operations</li>
            </ul>
            <span>
              If <strong>Jos Butler</strong> has moved to a different
              department, select the new department from the dropdown.
            </span>
          </div>
        </li>

        <li className="flex items-start space-x-3">
          <div>
            <p className="font-semibold">Role:</p>
            <span>
              After selecting the department, review or update the specific role
              assigned to <strong>Jos Butler</strong>.
            </span>
          </div>
        </li>
      </ul>

      <p className="mt-6">
        Once you've made the necessary changes, click <strong>Update</strong> to
        update the user's information, or <strong>Cancel</strong> to discard the
        changes.
      </p>

      <p className="mt-4">
        This form allows you to modify an existing user’s details, such as their
        department, role, and email, to keep the system up to date with their
        current responsibilities.
      </p>
    </div>
  );
};

export const RoleHelp = () => {
  return (
    <div className="p-6 bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
      <p className="mb-4 text-gray-700">
        Role Management page in ProStrategy.ai, lists various roles within the
        Organization. Shown are the current roles that have been configured.
      </p>

      <p className="font-semibold mb-2">Each role has the following options:</p>

      <ul className="space-y-4">
        <li className="flex items-start space-x-3">
          <div className="flex-shrink-0">
            <IconPencil className="h-6 w-6 text-gray-500" />
          </div>
          <div>
            <p className="font-semibold">
              Allows you to modify the details and permissions associated with
              the role.
            </p>
          </div>
        </li>

        <li className="flex items-start space-x-3">
          <div className="flex-shrink-0">
            <IconTrash className="h-6 w-6 text-gray-500" />
          </div>
          <div>
            <p className="font-semibold">
              Allows you to remove the role from the system.
            </p>
          </div>
        </li>
      </ul>

      <p className="mt-6">
        There is also an option to <strong>Create Role</strong> by clicking the
        blue button, allowing administrators to define new roles and assign
        custom permissions.
      </p>

      <p className="mt-4">
        You can filter roles by selecting from the <strong>Role Type</strong>{" "}
        dropdown menu, helping you focus on specific categories such as Admin or
        Department roles.
      </p>

      <p className="mt-4">
        This tool is useful for managing user access and responsibilities within
        the Organization efficiently.
      </p>
    </div>
  );
};

export const CreateNewRoleHelp = () => (
  <div className=" bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
    <p className="mb-4 text-gray-700">
      The Create New Role page under the Role Management section in
      ProStrategy.ai allows you to create and customize roles with detailed
      permissions. Here's how you can complete this form:
    </p>

    <ul className="space-y-4">
      <li className="flex items-start space-x-3">
        {/* <div className="flex-shrink-0">
        <IconTag className="h-6 w-6 text-gray-500" />
      </div> */}
        <div>
          <p className="font-semibold">Role Name:</p>
          <span>
            Enter the name of the role you are creating (e.g., "HR Manager,"
            "Marketing Admin").
          </span>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        {/* <div className="flex-shrink-0">
        <IconTag className="h-6 w-6 text-gray-500" />
      </div> */}
        <div>
          <p className="font-semibold">Role Type:</p>
          <span>Select one of the following options for the role type:</span>
          <ul className="list-disc ml-6">
            <li>
              <strong>Admin Role:</strong> Grants system-wide administrative
              access.
            </li>
            <li>
              <strong>Department Role:</strong> Role specific to certain
              departments.
            </li>
            <li>
              <strong>Guest User Role:</strong> Limited access, typically for
              external or temporary users.
            </li>
          </ul>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        {/* <div className="flex-shrink-0">
        <IconShieldCheck className="h-6 w-6 text-gray-500" />
      </div> */}
        <div>
          <p className="font-semibold">Select Permissions:</p>
          <span>
            Under each section, specify the following permissions by checking
            the corresponding boxes:
          </span>
          <ul className="list-disc ml-6">
            <li>
              <strong>Permissions (User Management, Role Management):</strong>{" "}
              Decide if the user can List, Create, Edit, or Delete in these
              sections.
            </li>
            <li>
              <strong>Organization Goals:</strong> Choose whether the role can
              Edit or have Read Only access to Organization Mission, Vision,
              Value, and Organization Pillars.
            </li>
            <li>
              <strong>Departments Management:</strong> Choose permissions for
              managing departments, such as the ability to List, Create, Edit,
              or Delete.
            </li>
            <li>
              <strong>Departments Goals:</strong> Define whether the user can
              Edit or have Read Only access to goals like Mission, Vision, and
              Value.
            </li>
            <li>
              <strong>Department SVA Dashboard:</strong> Set permissions for
              editing or viewing "Expected Delivery."
            </li>
            <li>
              <strong>Department SVA Form:</strong> Set permissions for fields
              like "Minimum Requirements," "Market Competitive," "Leadership,"
              and "EFIs."
            </li>
            <li>
              <strong>Settings:</strong> Define if the role can Edit or have
              Read Only access to Organization settings, such as Business
              Targets.
            </li>
          </ul>
        </div>
      </li>
    </ul>

    <p className="mt-6">
      After defining all permissions, click <strong>Save</strong> to create the
      role or <strong>Cancel</strong> to discard your changes.
    </p>

    <p className="mt-4">
      This form enables granular control over what a specific role can access or
      modify, helping align user permissions with their responsibilities in the
      Organization.
    </p>
  </div>
);

export const EditRoleHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
    <p className="mb-4 text-gray-700">
      The Edit Role page under the Role Management section in ProStrategy.ai
      allows you to modify existing roles and update their permissions as
      needed. Here’s how you can complete this form:
    </p>

    <ul className="space-y-4">
      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Role Name:</p>
          <span>
            The current role name, such as <strong>"HR Manager"</strong> or{" "}
            <strong>"Marketing Admin"</strong>, is already displayed. You can
            edit this field if the role name needs to change.
          </span>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Role Type:</p>
          <span>
            The selected role type is visible (e.g.,{" "}
            <strong>"Admin Role"</strong>, <strong>"Department Role"</strong>,
            or <strong>"Guest User Role"</strong>). You can change this type if
            necessary:
          </span>
          <ul className="list-disc ml-6">
            <li>
              <strong>Admin Role:</strong> Grants system-wide administrative
              access.
            </li>
            <li>
              <strong>Department Role:</strong> Role specific to certain
              departments.
            </li>
            <li>
              <strong>Guest User Role:</strong> Limited access, typically for
              external or temporary users.
            </li>
          </ul>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Edit Permissions:</p>
          <span>
            Review and update permissions for this role by checking or
            unchecking the appropriate boxes:
          </span>
          <ul className="list-disc ml-6">
            <li>
              <strong>Permissions (User Management, Role Management):</strong>{" "}
              Decide if the user can List, Create, Edit, or Delete in these
              sections.
            </li>
            <li>
              <strong>Organization Goals:</strong> Specify if the role can Edit
              or have Read Only access to Organization Mission, Vision, Value,
              and Organization Pillars.
            </li>
            <li>
              <strong>Departments Management:</strong> Adjust permissions for
              managing departments, such as the ability to List, Create, Edit,
              or Delete.
            </li>
            <li>
              <strong>Departments Goals:</strong> Define whether the user can
              Edit or have Read Only access to goals like Mission, Vision, and
              Value.
            </li>
            <li>
              <strong>Department SVA Dashboard:</strong> Set permissions for
              editing or viewing the "Expected Delivery."
            </li>
            <li>
              <strong>Department SVA Form:</strong> Modify permissions for
              fields like "Minimum Requirements," "Market Competitive,"
              "Leadership," and "EFIs."
            </li>
            <li>
              <strong>Settings:</strong> Update whether the role can Edit or
              have Read Only access to Organization settings, such as Business
              Targets.
            </li>
          </ul>
        </div>
      </li>
    </ul>

    <p className="mt-6">
      After making the necessary changes, click <strong>Save</strong> to update
      the role or <strong>Cancel</strong> to discard your changes.
    </p>

    <p className="mt-4">
      This form allows you to adjust the permissions and responsibilities of an
      existing role, ensuring that user roles stay aligned with changes in the
      Organization.
    </p>
  </div>
);

export const OrganizationGoalsHelp = () => {
  return (
    <div className="p-2 bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
      <p className="mb-4 text-gray-700">
        The Organization Goals section, specifically under the Mission tab in
        ProStrategy.ai, allows you to review or update your Organization's
        mission statement. Here’s how to interact with this form:
      </p>

      <ul className="space-y-4">
        <li className="flex items-start space-x-3">
          <div>
            <p className="font-semibold">
              Does your company currently have a mission statement?
            </p>
            <span>
              This section allows you to specify whether your Organization
              already has a mission statement. In this case, "Yes" is selected.
            </span>
          </div>
        </li>

        <li className="flex items-start space-x-3">
          <div>
            <p className="font-semibold">
              Do you want to continue with the existing mission or create a new
              one?
            </p>
            <span>
              You can choose between:
              <ul className="list-disc ml-6">
                <li>
                  <strong>Use Existing One:</strong> Retain the current mission
                  statement (selected in the image).
                </li>
                <li>
                  <strong>Use AI to help Create New Mission Statement:</strong>{" "}
                  Select this option if you wish to use AI to assist in creating
                  a new mission statement.
                </li>
              </ul>
            </span>
          </div>
        </li>

        <li className="flex items-start space-x-3">
          <div>
            <p className="font-semibold">Mission Statement:</p>
            <span>
              The current mission statement is displayed in the text box:
              <blockquote className="ml-6">
                "We are passionate enthusiasts, lifelong learners, and dedicated
                doers. As innovators, disruptors, and problem solvers, we are on
                a mission to unlock the power of technology to address
                real-world challenges and drive meaningful change."
              </blockquote>
            </span>
          </div>
        </li>
      </ul>

      <p className="mt-6">
        After making any updates or confirming that you want to continue with
        the existing mission statement, click <strong>Save Changes</strong> to
        confirm your decision.
      </p>

      <p className="mt-4">
        This section is useful for reviewing or updating your Organization's
        mission statement, with the option to either retain the current one or
        use AI to help craft a new one.
      </p>
    </div>
  );
};

export const DepartmentMissionHelp = () => {
  return (
    <div className="p-2 bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
      <p className="mb-4 text-gray-700">
        The Department Goals section, specifically under the Mission tab in
        ProStrategy.ai, allows you to review or update your Department's mission
        statement. Here’s how to interact with this form:
      </p>

      <ul className="space-y-4">
        <li className="flex items-start space-x-3">
          <div>
            <p className="font-semibold">
              Does your Department currently have a mission statement?
            </p>
            <span>
              This section allows you to specify whether your Department already
              has a mission statement. In this case, "Yes" is selected.
            </span>
          </div>
        </li>

        <li className="flex items-start space-x-3">
          <div>
            <p className="font-semibold">
              Do you want to continue with the existing mission or create a new
              one?
            </p>
            <span>
              You can choose between:
              <ul className="list-disc ml-6">
                <li>
                  <strong>Use Existing One:</strong> Retain the current mission
                  statement (selected in the image).
                </li>
                <li>
                  <strong>Use AI to help Create New Mission Statement:</strong>{" "}
                  Select this option if you wish to use AI to assist in creating
                  a new mission statement.
                </li>
              </ul>
            </span>
          </div>
        </li>

        <li className="flex items-start space-x-3">
          <div>
            <p className="font-semibold">Mission Statement:</p>
            <span>
              The current mission statement is displayed in the text box:
              <blockquote className="ml-6">
                "We are passionate enthusiasts, lifelong learners, and dedicated
                doers. As innovators, disruptors, and problem solvers, we are on
                a mission to unlock the power of technology to address
                real-world challenges and drive meaningful change."
              </blockquote>
            </span>
          </div>
        </li>
      </ul>

      <p className="mt-6">
        After making any updates or confirming that you want to continue with
        the existing mission statement, click <strong>Save Changes</strong> to
        confirm your decision.
      </p>

      <p className="mt-4">
        This section is useful for reviewing or updating your Department's
        mission statement, with the option to either retain the current one or
        use AI to help craft a new one.
      </p>
    </div>
  );
};

export const DepartmentDashboardHelp = () => {
  return (
    <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
      <p className="mb-4 text-gray-700">
        The "Department Dashboard" form allows you to create and manage
        departments within your Organization. Here’s how to fill it out:
      </p>

      <ul className="space-y-4">
        <li className="flex items-start space-x-3">
          <div>
            <p className="font-semibold">Department Name:</p>
            <span>
              Enter a unique and descriptive name for the department. For
              example, "Marketing" or "Digital Marketing."
            </span>
          </div>
        </li>

        <li className="flex items-start space-x-3">
          <div>
            <p className="font-semibold">Department Type:</p>
            <span>
              Specify the type of department, such as HR, IT, Finance, or a more
              specific designation like "Mobile App Development" or "Data
              Analytics."
            </span>
          </div>
        </li>

        <li className="flex items-start space-x-3">
          <div>
            <p className="font-semibold">Department Information:</p>
            <span>
              Provide detailed information about the department’s function,
              goals, and role within the Organization. For example, a marketing
              department might handle digital campaigns or brand management.
            </span>
          </div>
        </li>

        <li className="flex items-start space-x-3">
          <div>
            <p className="font-semibold">
              Use Organization Business Target Ratings?
            </p>
            <span>
              Select "Yes" if the department’s goals should align with the
              Organization’s business targets or KPIs. Choose "No" if the
              department doesn't need to follow those targets.
            </span>
          </div>
        </li>
      </ul>

      <p className="mt-6">
        After filling out all fields, click <strong>Create</strong> to establish
        the new department within the system.
      </p>
    </div>
  );
};

export const OrganizationVisionHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
    <p className="mb-4 text-gray-700">
      The "Organization Goals" section, specifically under the Vision tab in
      ProStrategy.ai, helps you manage your company's vision statement. Here's
      how to interact with this form:
    </p>

    <ul className="space-y-4">
      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">
            Does your Company currently have a vision statement?
          </p>
          <span>
            The "Yes" option is selected, indicating that the company has a
            vision statement.
          </span>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">
            Do you want to continue with the existing vision or create a new
            one?
          </p>
          <span>
            The "Use Existing One" option is selected, meaning the Organization
            intends to retain the current vision statement.
          </span>
          <p className="mt-2">
            There is also an option to{" "}
            <strong>Use AI to help Create New Vision Statement</strong> if you
            wish to generate a new one.
          </p>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Vision Statement:</p>
          <span>The current vision statement is displayed as follows:</span>
          <blockquote className="ml-4 italic text-gray-600">
            "We are passionate enthusiasts, lifelong learners, and dedicated
            doers. As innovators, disruptors, and problem solvers, we are on a
            mission to unlock the power of technology to address real-world
            challenges and drive meaningful change."
          </blockquote>
        </div>
      </li>
    </ul>

    <p className="mt-6">
      After reviewing or editing the vision statement, click{" "}
      <strong>Save Changes</strong> to confirm your decision.
    </p>

    <p className="mt-4">
      This process allows you to either maintain the current vision or use AI
      assistance to craft a new one, ensuring alignment with your Organization's
      goals and values.
    </p>
  </div>
);

export const DepartmentVisionHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
    <p className="mb-4 text-gray-700">
      The "Department Goals" section, specifically under the Vision tab in
      ProStrategy.ai, helps you manage your Department's vision statement.
      Here's how to interact with this form:
    </p>

    <ul className="space-y-4">
      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">
            Does your Department currently have a vision statement?
          </p>
          <span>
            The "Yes" option is selected, indicating that the Department has a
            vision statement.
          </span>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">
            Do you want to continue with the existing vision or create a new
            one?
          </p>
          <span>
            The "Use Existing One" option is selected, meaning the Department
            intends to retain the current vision statement.
          </span>
          <p className="mt-2">
            There is also an option to{" "}
            <strong>Use AI to help Create New Vision Statement</strong> if you
            wish to generate a new one.
          </p>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Vision Statement:</p>
          <span>The current vision statement is displayed as follows:</span>
          <blockquote className="ml-4 italic text-gray-600">
            "We are passionate enthusiasts, lifelong learners, and dedicated
            doers. As innovators, disruptors, and problem solvers, we are on a
            mission to unlock the power of technology to address real-world
            challenges and drive meaningful change."
          </blockquote>
        </div>
      </li>
    </ul>

    <p className="mt-6">
      After reviewing or editing the vision statement, click{" "}
      <strong>Save Changes</strong> to confirm your decision.
    </p>

    <p className="mt-4">
      This process allows you to either maintain the current vision or use AI
      assistance to craft a new one, ensuring alignment with your Department's
      goals and values.
    </p>
  </div>
);

export const OrganizationValueHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
    <p className="mb-4 text-gray-700">
      The "Organization Goals" section, specifically under the Value tab in
      ProStrategy.ai, helps you manage your company's value statement. Here's
      how to interact with this form:
    </p>

    <ul className="space-y-4">
      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">
            Does your company currently have a value statement?
          </p>
          <span>
            The "Yes" option is selected, indicating that the Organization
            currently has a value statement.
          </span>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">
            Do you want to continue with the existing value or create a new one?
          </p>
          <span>
            The "Use Existing One" option is selected, meaning the Organization
            intends to retain the current value statement.
          </span>
          <p className="mt-2">
            There is also an option to{" "}
            <strong>Use AI to help Create New Value Statement</strong> if you
            wish to generate a new one.
          </p>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Value Statement:</p>
          <span>The current value statement is displayed as follows:</span>
          <blockquote className="ml-4 italic text-gray-600">
            "We are passionate enthusiasts, lifelong learners, and dedicated
            doers. As innovators, disruptors, and problem solvers, we are on a
            mission to unlock the power of technology to address real-world
            challenges and drive meaningful change."
          </blockquote>
        </div>
      </li>
    </ul>

    <p className="mt-6">
      After reviewing or editing the value statement, click{" "}
      <strong>Save Changes</strong> to confirm your decision.
    </p>

    <p className="mt-4">
      This section allows you to either maintain the existing value statement or
      use AI assistance to create a new one, ensuring alignment with the
      company’s core principles and objectives.
    </p>
  </div>
);

export const DepartmentValueHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
    <p className="mb-4 text-gray-700">
      The "Department Goals" section, specifically under the Value tab in
      ProStrategy.ai, helps you manage your Department's value statement. Here's
      how to interact with this form:
    </p>

    <ul className="space-y-4">
      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">
            Does your Department currently have a value statement?
          </p>
          <span>
            The "Yes" option is selected, indicating that the Department
            currently has a value statement.
          </span>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">
            Do you want to continue with the existing value or create a new one?
          </p>
          <span>
            The "Use Existing One" option is selected, meaning the Department
            intends to retain the current value statement.
          </span>
          <p className="mt-2">
            There is also an option to{" "}
            <strong>Use AI to help Create New Value Statement</strong> if you
            wish to generate a new one.
          </p>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Value Statement:</p>
          <span>The current value statement is displayed as follows:</span>
          <blockquote className="ml-4 italic text-gray-600">
            "We are passionate enthusiasts, lifelong learners, and dedicated
            doers. As innovators, disruptors, and problem solvers, we are on a
            mission to unlock the power of technology to address real-world
            challenges and drive meaningful change."
          </blockquote>
        </div>
      </li>
    </ul>

    <p className="mt-6">
      After reviewing or editing the value statement, click{" "}
      <strong>Save Changes</strong> to confirm your decision.
    </p>

    <p className="mt-4">
      This section allows you to either maintain the existing value statement or
      use AI assistance to create a new one, ensuring alignment with the
      Department’s core principles and objectives.
    </p>
  </div>
);

export const SustainingObjectivesHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
    <p className="mb-4 text-gray-700">
      The "Organization Pillars" section within the Organization Goals tab
      helps you identify the key pillars for your company’s long-term
      success. You are presented with 15 key areas to consider when selecting
      your Organization Pillars for strategic planning.
    </p>

    <p className="mb-4">
      You are asked to choose 5 to 9 areas that will guide the development of
      your Organization's Organization Pillars. Here are the options provided:
    </p>

    <ul className="list-disc ml-6 space-y-2">
      <li>
        <strong>Growth</strong>
      </li>
      <li>
        <strong>Operations</strong>
      </li>
      <li>
        <strong>Customer Experience</strong>
      </li>
      <li>
        <strong>Innovation</strong>
      </li>
      <li>
        <strong>Risk Management</strong>
      </li>
      <li>
        <strong>Sustainability</strong>
      </li>
      <li>
        <strong>Technology</strong>
      </li>
      <li>
        <strong>Financial Health</strong>
      </li>
      <li>
        <strong>Talent and Workforce</strong>
      </li>
      <li>
        <strong>Compliance and Regulation</strong>
      </li>
      <li>
        <strong>Partnerships and Alliances</strong>
      </li>
      <li>
        <strong>Brand and Reputation</strong>
      </li>
      <li>
        <strong>Culture and Values</strong>
      </li>
      <li>
        <strong>Community Impact</strong>
      </li>
      <li>
        <strong>Leadership and Governance</strong>
      </li>
    </ul>

    <p className="mt-6">
      Select the areas that are most important to your Organization. Once
      selected, click <strong>Next</strong> to proceed with defining the
      Organization Pillars based on your choices.
    </p>

    <p className="mt-4">
      This step is crucial for aligning the Organization’s long-term strategies
      with its priorities, ensuring the right focus for future success.
    </p>

    <h4>in Next Step:</h4>
    <p>For Example we are Taking Growth Pillar</p>
    <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll p-4">
      <p className="mb-4 text-gray-700">
        The Organization Pillars section under the Growth Pillar helps you
        evaluate and manage the company’s growth-related goals. Here's a
        breakdown of the available options:
      </p>

      <ul className="list-disc ml-6 space-y-2">
        <li>
          <strong>Does your company currently have a growth pillar?:</strong>
          If <em>Yes</em> is selected, this confirms that the company has an
          existing growth pillar in place.
        </li>
        <li>
          <strong>
            Do you want to continue with the existing growth pillar or create
            a new one?:
          </strong>
          If <em>Use Existing One</em> is selected, the company plans to
          maintain the current growth pillar. Alternatively, you can choose
          to create a new pillar.
        </li>
        <li>
          <strong>Use AI to help Create New Growth pillar:</strong>
          This option allows you to generate a new growth pillar with the
          assistance of AI, if desired.
        </li>
        <li>
          <strong>Text Box:</strong>
          Use the text box provided to enter or update your growth pillar.
        </li>
        <li>
          <strong>Save:</strong>
          After reviewing or entering the growth pillar, click <em>
            Save
          </em>{" "}
          to confirm and save the changes.
        </li>
      </ul>

      <p className="mt-6">
        This process enables you to either continue with the current growth
        pillar or create new ones, ensuring alignment with the company’s
        broader growth goals.
      </p>
    </div>
  </div>
);

export const ObjectiveHelp = ({ type }) => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll p-4">
    <p className="mb-4 text-gray-700">
      The Organization Pillars section under the {type} pillar helps you
      evaluate and manage the company’s {type}-related goals.
    </p>

    <ul className="list-disc ml-6 space-y-2">
      <li>
        <strong>Does your company currently have a {type} pillar?:</strong>
        If <em>Yes</em> is selected, this confirms that the company has an
        existing {type} pillar in place.
      </li>
      <li>
        <strong>
          Do you want to continue with the existing {type} pillar or create a
          new one?:
        </strong>
        If <em>Use Existing One</em> is selected, the company plans to maintain
        the current {type} pillar. Alternatively, you can choose to create a
        new pillar.
      </li>
      <li>
        <strong>Use AI to help Create New {type} pillar:</strong>
        This option allows you to generate a new {type} pillar with the
        assistance of AI, if desired.
      </li>
      <li>
        <strong>Text Box:</strong>
        Use the text box provided to enter or update your {type} pillar.
      </li>
      <li>
        <strong>Save:</strong>
        After reviewing or entering the {type} pillar, click <em>Save</em> to
        confirm and save the changes.
      </li>
    </ul>

    <p className="mt-6">
      This process enables you to either continue with the current {type}{" "}
      pillars or create new ones, ensuring alignment with the company’s
      broader {type} goals.
    </p>
  </div>
);

export const ObjectiveHelpDepartment = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll p-4">
    <p className="mb-4 text-gray-700">
      The Organization Pillars section under the pillar helps you evaluate
      and manage the company’s pillar-related goals.
    </p>

    <ul className="list-disc ml-6 space-y-2">
      <li>
        <strong>Does your company currently have a pillar?:</strong>
        If <em>Yes</em> is selected, this confirms that the company has an
        existing pillar in place.
      </li>
      <li>
        <strong>
          Do you want to continue with the existing pillar or create a new
          one?:
        </strong>
        If <em>Use Existing One</em> is selected, the company plans to maintain
        the current pillar. Alternatively, you can choose to create a new
        pillar.
      </li>
      <li>
        <strong>Use AI to help Create New pillar:</strong>
        This option allows you to generate a new pillar with the assistance
        of AI, if desired.
      </li>
      <li>
        <strong>Text Box:</strong>
        Use the text box provided to enter or update your pillar.
      </li>
      <li>
        <strong>Save:</strong>
        After reviewing or entering the pillar, click <em>Save</em> to
        confirm and save the changes.
      </li>
    </ul>

    <p className="mt-6">
      This process enables you to either continue with the current pillars or
      create new ones, ensuring alignment with the company’s broader goals.
    </p>
  </div>
);

export const DepartmentBusinessTargetsHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
    <p className="mb-4 text-gray-700">
      The Business Targets form for a specific department allows you to evaluate
      key areas of performance, setting internal goals or evaluating existing
      ones. Here's how to fill out the form:
    </p>

    <p className="mb-4">
      You will rate each of the following categories on a scale of 1 to 10:
    </p>

    <ul className="list-disc ml-6 space-y-2">
      <li>
        <strong>Environmental sustainability:</strong> Evaluate how important
        sustainability efforts are for the department’s operations. If the
        department focuses heavily on environmental factors, such as reducing
        waste or energy consumption, rank it as high priority.
      </li>
      <li>
        <strong>Philanthropic efforts:</strong> Consider the department’s
        involvement in charity or community-driven initiatives. If this is key
        to the department's mission, rank it accordingly.
      </li>
      <li>
        <strong>Community outreach:</strong> Assess how the department engages
        with the broader community, especially in ways that align with Organization
        social responsibility.
      </li>
      <li>
        <strong>Social responsibility:</strong> Evaluate the department’s
        commitment to social causes, including diversity, inclusion, and ethical
        work practices within operations.
      </li>
      <li>
        <strong>Ethical practices:</strong> Reflect on the department's ethical
        standards, emphasizing practices like transparency, honesty, and
        integrity.
      </li>
    </ul>

    <p className="mt-6">
      Analyze each target based on the department's objectives, impact on the
      business, and strategic alignment with the Organization’s overall goals.
    </p>

    <p className="mt-4">
      Rank the factors with the most critical aspect as "10" and the least
      relevant as "1". Once all fields are rated, click <strong>Save</strong> to
      update the department's business targets.
    </p>

    <p className="mt-4">
      Remember, the department's business targets should align with the
      company's long-term goals to ensure a consistent and effective approach.
    </p>
  </div>
);

export const DepartmentSVADashboardHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
    <p className="mb-4 text-gray-700">
      This dashboard view tracks business targets for the SEO and Digital
      Marketing department, focusing on various categories and performance
      criteria across a timeline from 2024 to 2027. Here's a breakdown of the
      sections and columns:
    </p>

    <ul className="space-y-4">
      <li>
        <p className="font-semibold">Criteria:</p>
        <span>
          These are different performance areas or goals like "Technical SEO,"
          "Content Management Systems," "Keyword Research," and "Data Analysis"
          under the <strong>"Minimum Requirements"</strong> category. Other
          categories include:
        </span>
        <ul className="list-disc ml-6 space-y-2">
          <li>
            <strong>Market Competitive:</strong> Intermediate goals to maintain
            competitiveness in the market.
          </li>
          <li>
            <strong>Leadership:</strong> Advanced goals to establish leadership
            within the industry.
          </li>
          <li>
            <strong>Elite:</strong> Highly advanced goals aimed at top-tier
            performance in the industry.
          </li>
        </ul>
      </li>

      <li>
        <p className="font-semibold">Timeline:</p>
        <span>
          The timeline is broken down into quarters (Q1, Q2, Q3, Q4) for each
          year from 2024 to 2027, providing a clear view of the department's
          expected goals over time.
        </span>
      </li>

      <li>
        <p className="font-semibold">Expected Delivery:</p>
        <span>
          The blue dots represent the expected completion timeline for each
          specific criterion. For example, for "Technical SEO," the delivery is
          planned in Q1 2024.
        </span>
      </li>
    </ul>

    <p className="mt-6">
      This dashboard is designed to help track the department’s performance and
      progress over time, ensuring that each goal is met within the specified
      timeline and contributing to the overall success of the Organization.
    </p>
  </div>
);

export const DepartmentSVAFormMinimumHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
    <p className="mb-4 text-gray-700">
      This form defines the baseline requirements for your department, ensuring alignment with market demands,
      operational efficiency, and strategic objectives. Proper selection helps establish a solid foundation for
      growth and competitiveness.
    </p>

    <ul className="space-y-4">
      <li>
        <p className="font-semibold">Criteria Selection (1 to 7):</p>
        <span>
          You must select at least 5 and no more than 7 key requirements.
          Focus on the most essential elements for your department’s success, such as:
        </span>
        <ul className="list-disc ml-6 mt-2 space-y-1">
          <li>Core technical skills</li>
          <li>Operational best practices</li>
          <li>Minimum service offerings</li>
          <li>Key resources</li>
        </ul>
        <span>
          These criteria serve as guidelines to ensure your department functions effectively at a foundational
          level while maintaining market relevance.
        </span>
      </li>

      <li>
        <p className="font-semibold">AI Assistance:</p>
        <span>
          Use the "AI Help" button for data-driven recommendations tailored to industry standards and current
          market trends. This feature enhances decision-making by aligning your selections with best practices
          in similar departments.
        </span>
      </li>
    </ul>

    <p className="mt-6">
      By carefully defining these requirements, your department will be positioned to meet industry expectations,
      maintain operational efficiency, and support long-term growth.
    </p>
  </div>
);

export const DepartmentSVAFormMarketCompetitive = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
    <p className="mb-4 text-gray-700">
      This form helps define the key capabilities your department needs to remain competitive in the industry.
      By selecting the right criteria, you ensure that your department meets current market expectations,
      operational efficiency, and strategic goals.
    </p>

    <ul className="space-y-4">
      <li>
        <p className="font-semibold">Criteria Selection (1 to 7):</p>
        <span>
          You must select at least 5 and no more than 7 competitive attributes.
          Focus on elements that differentiate your department and enhance market positioning, such as:
        </span>
        <ul className="list-disc ml-6 mt-2 space-y-1">
          <li>Advanced technical skills</li>
          <li>Optimized workflows and efficiencies</li>
          <li>Enhanced service offerings</li>
          <li>Technology integration</li>
          <li>Compliance with industry benchmarks</li>
        </ul>
        <span>
          These selections should go beyond basic operations, ensuring your department can compete effectively
          and provide measurable value in the marketplace.
        </span>
      </li>

      <li>
        <p className="font-semibold">AI Assistance:</p>
        <span>
          Click the "AI Help" button for tailored suggestions based on industry benchmarks, competitor analysis,
          and emerging trends. This feature supports data-driven decision-making, ensuring your department aligns
          with leading market practices.
        </span>
      </li>
    </ul>

    <p className="mt-6">
      By defining your department’s market-competitive criteria, you position it for sustained success, industry
      leadership, and continuous improvement in a fast-evolving business landscape.
    </p>
  </div>
);

export const DepartmentSVAFormLeadership = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
    <p className="mb-4 text-gray-700">
      This form defines the key attributes required for your department to operate at a leadership level within your industry.
      By selecting the right criteria, you ensure your department is positioned as an innovator, setting trends rather than following them.
    </p>

    <ul className="space-y-4">
      <li>
        <p className="font-semibold">Criteria Selection (1 to 7):</p>
        <span>
          Select at least 5 and no more than 7 leadership attributes.
          Focus on elements that drive innovation, influence industry standards, and enhance long-term strategic impact, such as:
        </span>
        <ul className="list-disc ml-6 mt-2 space-y-1">
          <li>Cutting-edge technology adoption</li>
          <li>Industry-leading best practices</li>
          <li>Talent development and thought leadership</li>
          <li>Proactive risk management and compliance</li>
          <li>High-impact operational strategies</li>
        </ul>
        <span>
          These selections should position your department as a recognized leader, capable of shaping industry trends and driving organizational excellence.
        </span>
      </li>

      <li>
        <p className="font-semibold">AI Assistance:</p>
        <span>
          Click the "AI Help" button for personalized recommendations based on global industry leaders, market disruptors, and forward-thinking strategies.
          This tool ensures your selections align with top-tier organizations and help you stay ahead of the competition.
        </span>
      </li>
    </ul>

    <p className="mt-6">
      By defining leadership-level capabilities, your department will become a benchmark for success, influence industry direction,
      and foster long-term innovation.
    </p>
  </div>
);

export const DepartmentSVAFormElite = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
    <p className="mb-4 text-gray-700">
      This form defines the highest level of excellence for your department, ensuring it operates as an industry pioneer and global benchmark.
      Selecting the right criteria positions your department at the forefront of innovation, influence, and operational superiority.
    </p>

    <ul className="space-y-4">
      <li>
        <p className="font-semibold">Criteria Selection (1 to 7):</p>
        <span>
          Choose at least 5 and no more than 7 elite-level attributes.
          Focus on elements that establish unmatched expertise, groundbreaking innovation, and transformative impact, such as:
        </span>
        <ul className="list-disc ml-6 mt-2 space-y-1">
          <li>AI-driven decision-making and predictive analytics</li>
          <li>Global thought leadership and industry influence</li>
          <li>Exclusive, high-impact strategic initiatives</li>
          <li>Next-generation technology integration</li>
          <li>Best-in-class employee experience and retention</li>
        </ul>
        <span>
          These selections ensure your department is not only a leader but a pioneer, setting new standards for excellence and defining the future of your industry.
        </span>
      </li>

      <li>
        <p className="font-semibold">AI Assistance:</p>
        <span>
          Click the "AI Help" button to receive elite-level recommendations based on world-class organizations, disruptive innovators, and emerging global trends.
          This tool ensures your department is aligned with the highest benchmarks of success.
        </span>
      </li>
    </ul>

    <p className="mt-6">
      By defining elite-level capabilities, your department becomes a driving force for innovation, an industry authority, and a model of sustained excellence.
    </p>
  </div>
);



export const DepartmentSVAFormHelp = ({ option }) => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
    <p className="mb-4 text-gray-700">
      This form helps define the {option} option for your department,
      ensuring that the department meets the baseline needs of the market and
      remains competitive. Here's how to fill out this form:
    </p>

    <ul className="space-y-4">
      <li>
        <p className="font-semibold">Criteria 1 to 7:</p>
        <span>
          Enter the foundational elements necessary for your department’s
          success. These might include basic technical skills, operational
          practices, or key resources. These requirements should serve as a
          guideline for the department to operate effectively at a minimal
          level.
        </span>
      </li>

      <li>
        <p className="font-semibold">AI Help:</p>
        <span>
          There is an "AI Help" button available that can assist you by
          generating relevant suggestions based on industry standards and
          current market trends. This feature ensures that your department’s
          {" "}{option} option align with the latest market demands and best
          practices.
        </span>
      </li>
    </ul>

    <p className="mt-6">
      This form ensures that your department aligns its capabilities with market
      demands, operational needs, and the Organization's broader strategic
      objectives. By defining the {option} option, you set the foundation
      for future growth and competitiveness.
    </p>
  </div>
);

export const SignUpHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
    <p className="mb-4 text-gray-700">
      Follow these steps to fill out the "Create Account" form and sign up:
    </p>

    <ul className="space-y-4">
      <li>
        <p className="font-semibold">Full Name:</p>
        <span>
          Enter your full name in the "Full Name" field. For example: "John
          Smith."
        </span>
      </li>

      <li>
        <p className="font-semibold">Email:</p>
        <span>
          Enter your email address in the "Email" field. For example:
          "example@test.com."
        </span>
      </li>

      <li>
        <p className="font-semibold">Organization Name:</p>
        <span>
          Input the name of your Organization in the "Organization Name" field.
          For example: "XYZ Company."
        </span>
      </li>

      <li>
        <p className="font-semibold">Password:</p>
        <span>
          Create a password in the "Password" field. Ensure it meets any
          requirements, such as minimum length or including special characters.
        </span>
      </li>

      <li>
        <p className="font-semibold">Confirm Password:</p>
        <span>
          Re-enter the same password in the "Confirm Password" field to confirm
          it.
        </span>
      </li>

      <li>
        <p className="font-semibold">Agree to Terms & Conditions:</p>
        <span>
          Check the box next to "I agree to Terms & Conditions" after reviewing
          them.
        </span>
      </li>

      <li>
        <p className="font-semibold">Sign Up:</p>
        <span>
          Once all fields are completed and the box is checked, click the "Sign
          Up" button to create your account.
        </span>
      </li>

      <li>
        <p className="font-semibold">Log In:</p>
        <span>
          If you already have an account, click "Log In" at the bottom of the
          form to sign in instead of creating a new account.
        </span>
      </li>
    </ul>

    <p className="mt-6">
      Make sure to double-check all fields before submitting to ensure a
      successful sign-up.
    </p>
  </div>
);

export const LoginHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
    <p className="mb-4 text-gray-700">
      To fill out the <strong>Login</strong> form, follow these steps:
    </p>

    <ul className="space-y-4">
      <li className="flex items-start space-x-3">
        <p className="font-semibold">Email:</p>
        <span>
          Enter your email address in the <strong>Email</strong> field. Example:
          "example@test.com."
        </span>
      </li>

      <li className="flex items-start space-x-3">
        <p className="font-semibold">Password:</p>
        <span>
          Enter your password in the <strong>Password</strong> field. You can
          click <strong>Show</strong> to view the password as you type.
        </span>
      </li>

      <li className="flex items-start space-x-3">
        <p className="font-semibold">Forgot Password?:</p>
        <span>
          If you have forgotten your password, click on the{" "}
          <strong>Forgot Password?</strong> link to reset it.
        </span>
      </li>
    </ul>

    <p className="mt-6">
      Once your email and password are entered correctly, click the{" "}
      <strong>Login</strong> button to access your account.
    </p>

    <p className="mt-4">
      If you don’t have an account, click <strong>Sign Up</strong> at the bottom
      to create a new one.
    </p>
  </div>
);

export const ForgotPasswordHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
    <p className="mb-4 text-gray-700">
      To fill out the "Forgot Password?" form, follow these steps:
    </p>
    <ul className="space-y-4">
      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Email:</p>
          <span>
            Enter the email address associated with your account in the "Email"
            field. Example: "example@test.com."
          </span>
        </div>
      </li>
      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Reset Password:</p>
          <span>
            Click the "Reset Password" button. You will receive a link in your
            email inbox to reset your password.
          </span>
        </div>
      </li>
      <li className="flex items-start space-x-3">
        <div>
          <span>
            Once you receive the reset link in your email, follow the
            instructions provided to create a new password for your account.
          </span>
        </div>
      </li>
    </ul>
  </div>
);

export const SetNewPasswordHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
    <p className="mb-4 text-gray-700">
      To fill out the "Set New Password" form, follow these steps:
    </p>

    <ul className="space-y-4">
      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Password:</p>
          <span>
            Enter your new password in the "Password" field. Ensure it meets any
            requirements such as length, special characters, etc. You can click
            "Show" to view the password as you type.
          </span>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Confirm Password:</p>
          <span>
            Re-enter the same new password in the "Confirm Password" field to
            ensure accuracy. Again, you can click "Show" to see what you’re
            typing.
          </span>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Set Password:</p>
          <span>
            Once both fields are filled out and match, click the "Set Password"
            button to finalize the process and save your new password.
          </span>
        </div>
      </li>
    </ul>

    <p className="mt-4">This will complete your password reset.</p>
  </div>
);

export const SetPasswordHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
    <p className="mb-4 text-gray-700">
      To complete the "Welcome to ProStrategy.ai" form and set your password,
      follow these steps:
    </p>

    <ul className="space-y-4">
      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Password:</p>
          <span>
            Enter a new password in the "Password" field. Ensure that it meets
            any security requirements, such as length or character types. You
            can click "Show" to view the password as you type if needed.
          </span>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Confirm Password:</p>
          <span>
            Re-enter the same password in the "Confirm Password" field to
            confirm it matches the one entered above.
          </span>
        </div>
      </li>
    </ul>

    <p className="mt-6">
      Once both fields are filled out and the passwords match, click{" "}
      <strong>Save Changes</strong> to finalize your profile setup.
    </p>

    <p className="mt-4">
      Completing this step will finalize your registration or account setup
      process for ProStrategy.ai.
    </p>
  </div>
);

export const OrganizationSettingsHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
    <p className="mb-4 text-gray-700">
      The Settings section under the Organization tab in ProStrategy.ai allows
      you to input key details about your Organization. Follow the steps below
      to complete the form:
    </p>

    <ul className="space-y-4">
      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Organization Name:</p>
          <span>
            Enter the full name of your Organization in the "Organization Name"
            field. Example: <strong>"ProStrategy AI Inc."</strong>
          </span>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Organization Type:</p>
          <span>
            Specify the type of Organization in the "Organization Type" field.
            Example: <strong>"Bank," "Hospital," "Retail,"</strong> etc.
          </span>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Organization Information:</p>
          <span>
            Provide a brief description or relevant information about your
            Organization in the "Organization Information" field. This could
            include details like your industry, mission, or key services.
            Example:{" "}
            <strong>
              "A technology-driven Organization specializing in AI-powered
              solutions for financial institutions."
            </strong>
          </span>
        </div>
      </li>
    </ul>

    <p className="mt-6">
      After entering the required information, click{" "}
      <strong>Save Changes</strong> to save the details.
    </p>

    <p className="mt-4">
      This section helps in configuring the Organization's profile, which will
      be used across the platform for strategic planning and AI-generated
      insights.
    </p>
  </div>
);

export const InitialStrategicSettings = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
    <p className="mb-4 text-gray-700">
      The Initial Strategic Settings page allows you to define and configure your organization's key performance metrics. Here you can:
    </p>

    <ul className="space-y-4">
      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Metric Setup:</p>
          <span>
            Create and customize your metrics by specifying names, formats, and data collection questions. Each metric can be configured with help text to guide users during data entry.
          </span>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Calculation Type:</p>
          <span>
            Choose between Static (manually entered values) or Dynamic (automatically calculated) for each metric. Static metrics require periodic updates while Dynamic metrics update based on other data.
          </span>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Data Form Inclusion:</p>
          <span>
            Metrics you include will appear in the data collection forms, allowing your team to input or view the relevant information. You can control which metrics are visible in forms.
          </span>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Year Selection:</p>
          <span>
            Set the fiscal year for your strategic planning. This ensures all metrics and calculations are aligned with your organization's reporting period.
          </span>
        </div>
      </li>
    </ul>

    <p className="mt-4 text-gray-700">
      After configuring your metrics, the system will calculate and display the strategic data based on your settings. You can always return to update these settings as your strategic needs evolve.
    </p>
  </div>
)

export const BusinessTargetsHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
    <p className="mb-4 text-gray-700">
      The Business Targets section under Settings in ProStrategy.ai helps you prioritize various aspects of your business strategy.
      You can rate each area from 1 to 10, where 1 is the least important and 10 is the most important.
      You may use any number from 1 to 10 as often as you like in each category.
      Below are the extended categories to consider:
    </p>

    <ul className="space-y-4">
      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Core Values:</p>
          <ul className="list-disc ml-6">
            <li>Do the right thing</li>
            <li>Honesty and transparency</li>
            <li>Ethical decision-making</li>
            <li>Accountability to others</li>
            <li>Uphold strong principles</li>
          </ul>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Target Audience:</p>
          <ul className="list-disc ml-6">
            <li>Demographics analysis</li>
            <li>Customer needs</li>
            <li>Market segmentation</li>
            <li>Buying behavior</li>
            <li>Audience preferences</li>
          </ul>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Company Vision:</p>
          <ul className="list-disc ml-6">
            <li>Long-term goals</li>
            <li>Strategic growth</li>
            <li>Future impact</li>
            <li>Innovative direction</li>
            <li>Aspirational objectives</li>
          </ul>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Market Position:</p>
          <ul className="list-disc ml-6">
            <li>Competitive differentiation</li>
            <li>Value proposition</li>
            <li>Industry ranking</li>
            <li>Market leadership</li>
            <li>Brand strength</li>
          </ul>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Competitive Advantages:</p>
          <ul className="list-disc ml-6">
            <li>Unique offerings</li>
            <li>Pricing strategy</li>
            <li>Operational efficiency</li>
            <li>Superior customer service</li>
            <li>Innovative solutions</li>
          </ul>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Industry Trends:</p>
          <ul className="list-disc ml-6">
            <li>Technological advancements</li>
            <li>Market demands</li>
            <li>Regulatory changes</li>
            <li>Consumer behavior shifts</li>
            <li>Emerging competitors</li>
          </ul>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Customer Feedback:</p>
          <ul className="list-disc ml-6">
            <li>Satisfaction ratings</li>
            <li>Service improvements</li>
            <li>Pain points</li>
            <li>Product suggestions</li>
            <li>Customer loyalty</li>
          </ul>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Stakeholder Goals:</p>
          <ul className="list-disc ml-6">
            <li>Investor returns</li>
            <li>Employee satisfaction</li>
            <li>Community engagement</li>
            <li>Long-term growth</li>
            <li>Organizational stability</li>
          </ul>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Brand Identity:</p>
          <ul className="list-disc ml-6">
            <li>Public perception</li>
            <li>Logo design</li>
            <li>Brand messaging</li>
            <li>Visual identity</li>
            <li>Company values</li>
          </ul>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Social Impact:</p>
          <ul className="list-disc ml-6">
            <li>Environmental sustainability</li>
            <li>Philanthropic efforts</li>
            <li>Community outreach</li>
            <li>Social responsibility</li>
            <li>Ethical practices</li>
          </ul>
        </div>
      </li>
    </ul>

    <p className="mt-6">
      After selecting the importance of these business targets, click{" "}
      <strong>Save Changes</strong> to save your selections.
    </p>

    <p className="mt-4">
      This section helps guide a comprehensive strategic review, ensuring
      alignment between company goals and external influences like industry
      trends and stakeholder needs.
    </p>
  </div>
);


export default BusinessTargetsHelp;


export const StrategyPlanForm = () => {
  const [searchParams] = useSearchParams();
  const isEdit = searchParams.get("edit");

  return (
    <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll p-4">
      <h2 className="text-xl font-bold mb-4">Help for Strategic Plan Form</h2>

      <ul className="space-y-4">
        <li className="flex items-start space-x-3">
          <div>
            <p className="font-semibold">Strategic Plan Name (Required):</p>
            <span>
              Enter a clear and concise name for the strategic plan. This should
              reflect the plan's focus and time frame. Example:{" "}
              <strong>"2024 Growth & Innovation Strategy" or "Five-Year Strategic Roadmap"</strong>
            </span>
          </div>
        </li>

        <li className="flex items-start space-x-3">
          <div>
            <p className="font-semibold">Strategic Plan Information (Required, 250 Characters Max):</p>
            <span>
              Provide a brief overview of the strategic plan’s key objectives and
              priorities. This should summarize the main focus areas and intended
              outcomes within the character limit.
            </span>
            <div className="mt-2">
              <strong>Example:</strong>
              <p className="text-gray-700">
                "Our 2024 Strategic Plan focuses on growth, digital transformation,
                and member experience. Priorities include AI-driven services,
                community outreach, efficiency, and cybersecurity to drive success
                and competitiveness in an evolving financial world."
              </p>
            </div>
          </div>
        </li>
      </ul>

      <p className="mt-6">
        After entering the required information, click <strong>{isEdit ? "Update" : "Create"}</strong> to save the details.
      </p>

      <p className="mt-4">
        This section helps in configuring the Strategic Plan profile, which will
        be used across the platform for strategic planning and AI-generated
        insights.
      </p>
    </div>

  )
};


export const SWOTFormHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll p-4">
    <h2 className="text-xl font-bold mb-4">How to Fill Out an Organizational SWOT Analysis</h2>
    <p className="mt-4">
      A SWOT Analysis helps assess the overall organization’s Strengths, Weaknesses, Opportunities, and Threats to guide strategic decision-making. Below are the 10 key factors to consider in each category:
    </p>
    <ul className="space-y-4">
      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">1. Strengths (Internal, Positive Factors)</p>
          <p className="mt-2"> Identify what makes the organization strong and competitive.</p>
          <ul className="list-disc ml-6 space-y-2">
            <li>  Strong brand recognition and market reputation</li>
            <li>Loyal customer/member base and high retention rates</li>
            <li>Financial stability and strong cash reserves</li>
            <li>High-quality products and services</li>
            <li>Advanced technology and digital capabilities</li>
            <li>Skilled and experienced workforce</li>
            <li>Efficient operational processes and supply chain management</li>
            <li>Strong customer service and support infrastructure</li>
            <li>Unique value proposition or market differentiation</li>
            <li>Strong partnerships and industry relationships</li>
          </ul>
        </div>
      </li>
      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">2. Weaknesses (Internal, Negative Factors)</p>
          <p className="mt-2">Identify internal challenges that may limit success.</p>
          <ul className="list-disc ml-6 space-y-2">
            <li>Outdated technology or legacy systems</li>
            <li>Limited product or service diversification</li>
            <li>Weak digital presence and online engagement</li>
            <li>High employee turnover and retention challenges</li>
            <li>Inefficient processes causing operational bottlenecks</li>
            <li>Overreliance on a few key customers or partners</li>
            <li>Weak financial performance or high debt burden</li>
            <li>Poor customer/member engagement strategies</li>
            <li>Lack of innovation or slow adaptability to market changes</li>
            <li>Increasing compliance and regulatory burdens</li>
          </ul>
        </div>
      </li>
      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">3. Opportunities (External, Positive Factors)</p>
          <p className="mt-2">Identify external factors that can drive organizational growth.</p>
          <ul className="list-disc ml-6 space-y-2">
            <li>Emerging market trends and evolving customer needs</li>
            <li>Expansion into new geographic markets or segments</li>
            <li>Strategic partnerships and industry collaborations</li>
            <li>Advances in technology improving efficiency and automation</li>
            <li>Growing demand for specific products or services</li>
            <li>Regulatory changes that create new opportunities</li>
            <li>Increasing consumer focus on sustainability and ESG initiatives</li>
            <li>Digital transformation and AI-driven improvements</li>
            <li>Potential for mergers, acquisitions, or new business models</li>
            <li>Untapped customer/member segments offering growth potential</li>
          </ul>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">4. Threats (External, Negative Factors)</p>
          <p className="mt-2">Identify external risks that could impact organizational success.</p>
          <ul className="list-disc ml-6 space-y-2">
            <li>Increasing competition from industry rivals and new entrants</li>
            <li>Economic downturns affecting revenue and financial stability</li>
            <li>Rapid technological advancements disrupting traditional models</li>
            <li>Cybersecurity risks and increasing data breach threats</li>
            <li>Regulatory changes increasing compliance costs and complexity</li>
            <li>Shifting consumer behaviors and expectations</li>
            <li>Supply chain disruptions and rising operational costs</li>
            <li>Negative public perception or brand reputation risks</li>
            <li>Talent shortages and workforce challenges</li>
            <li>Interest rate fluctuations impacting financial performance</li>
          </ul>
        </div>
      </li>
    </ul>

    <p className="mt-4">
      <strong>Tip:</strong> When conducting a <strong>SWOT Analysis for the overall organization,</strong> be data-driven and strategic. Focus on factors that influence long-term sustainability, competitive positioning, and market leadership. Ensure all inputs are well-documented, and <strong>make sure to save changes</strong> before finalizing your analysis.
    </p>
  </div>
);
export const StrategyDataHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll p-4">


    <p className="mb-4 text-gray-700">
      The <strong>Strategy Data</strong> page displays all data collected from completed <strong>strategy forms</strong> for each initiative.
    </p>

    <ul className="list-disc ml-6 space-y-2">
      <li >
        This data is used to develop <strong> forecasts and production metrics</strong> for the organization.

      </li>
      <li>All information is  <strong>editable,</strong>and any changes will automatically <strong>update forecasts and delivery dates.</strong>
      </li>

    </ul>

    <p className="mt-4">
      Ensure accuracy when editing, as updates impact strategic projections.
    </p>
  </div>
);

export const SubscriptionPlanDetails = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll p-4">
    <p>
      This page displays the subscription plan you are currently enrolled in. Here, you can review your plan details, including features, benefits, and billing information. If you wish to upgrade, downgrade, or manage your subscription, options may be available based on your selected plan. For further assistance, please contact support.
    </p>
  </div>
);

export const ProfileHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll p-4">
    <p className="mb-4">
      This page displays your name, email, and a section to change your password.
      To update your name or email, enter the new details and click <strong>'Save Changes'</strong> to save.
      To change your password, enter your new password and click <strong>'Reset Password'</strong> to apply the change.
      Make sure to save any updates before leaving this page.
    </p>
  </div>
);

export const ProfileBillingHistoryHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll p-4">

    <p className="mb-4 text-gray-700">
      This page displays your billing history, including details of past invoices and subscription status.    </p>

    <ul className="list-disc ml-6 space-y-2">
      <li>
        View <strong> Invoice #, Invoice Date, Subscription Plan Type, Amount, Expiry Date, Payment Status,</strong> and<strong> Plan Status (Active/Inactive).</strong>
      </li>
      <li>
        Use the Download button to save a copy of any invoice.
      </li>
    </ul>

    <p className="mt-4">
      For any billing inquiries, please contact support.
    </p>
  </div>
);


export const StrategicReportHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll p-4">

    <p className="mb-4 text-gray-700">
      The <strong>Strategic Report</strong> page provides a <strong>Table of Contents</strong> displaying all the data captured in your strategic plan.</p>

    <ul className="list-disc ml-6 space-y-2">
      <li>
        The report is organized into <strong>headings and subheadings</strong> with <strong>checkboxes</strong> to select the data you want to include.
      </li>
      <li>
        Each section allows you to <strong>upload images</strong> to enhance the report. Click the <strong>'Upload Image'</strong> button to add visuals.
      </li>
      <li>
        Once you've selected your content, click <strong>'Next'</strong> to generate and review your report in an <strong> editable format.</strong>
      </li>
    </ul>

    <p className="mt-4">
      Make sure to review your selections before proceeding!
    </p>
  </div>
);


export const ChatHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll p-4">

    <p className="mb-4 text-gray-700">
      The Chat Screen displays:</p>

    <ul className="list-disc ml-6 space-y-2">
      <li >
        <strong>Chat History</strong> – View past conversations with other users.
      </li>
      <li> <strong>User Availability</strong> – See which users are currently online in <strong>ProStrategy.AI</strong>.
      </li>
    </ul>

    <p className="mt-4">
      Use this screen to track discussions and connect with available team members in real time.
    </p>
  </div>
);



export const SwotDashboardHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll p-4">

    <p className="mb-4 text-gray-700">
      The <strong>SWOT Dashboard</strong> provides a comprehensive view of all<strong> Strengths, Weaknesses, Opportunities, and Threats </strong>for the organization at a glance.</p>

    <ul className="list-disc ml-6 space-y-2">
      <li >
        Use this dashboard to quickly analyze key factors impacting strategic planning.
      </li>
      <li>The data is displayed in an easy-to-read format for decision-making.
      </li>
      <li>If you need to <strong>edit or update any information,</strong> return to the <strong>SWOT Form</strong> to make changes.
      </li>
    </ul>

    <p className="mt-4">
      Ensure your SWOT data is accurate and up to date for effective strategic insights.
    </p>
  </div>
);

export const StrategicPlansPageHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll p-4">

    <p className="mb-4 text-gray-700">
      The<strong> Strategic Plans</strong> page displays all recorded <strong>Strategic Plans</strong> in<strong> ProStrategy.AI.</strong>
    </p>
    <p className="mb-4 text-gray-700">
      Strategic planning is a <strong>dynamic process,</strong> with frequent <strong>additions, subtractions, and updates.</strong> While many organizations follow <strong>annual strategic planning cycles,</strong> you can create and manage<strong> multiple strategic plans </strong>as needed.
    </p>
    <ul className="list-disc ml-6 space-y-2">
      <li >
        Strategic plans can be created for the <strong>entire organization,</strong> specific <strong>divisions</strong>, or <strong>subsidiaries</strong>.
      </li>
      <li>Plans can be organized by <strong>dates, subjects, or business objectives</strong>.
      </li>
      <li>All your strategic plans will be <strong>visible and accessible</strong> on this page.

      </li>
    </ul>
    <p className="mt-4">
      Use this page to track, manage, and refine your organization's strategic direction.
    </p>
    <h2 className="text-xl font-bold mt-4 mb-4">Adding a Strategic Plan</h2>
    <p className="mb-4 text-gray-700">
      To add a new Strategic Plan, follow these steps:
    </p>

    <ol className="list-disc ml-6 space-y-2">
      <li>Click the <strong>"Add Strategic Plan"</strong> button.</li>
      <li>Enter the <strong>Strategic Plan Name.</strong>
      </li>
      <li>Provide a <strong>brief description</strong> in the<strong> Strategic Plan Information</strong> field.
      </li>
      <li>Select the <strong>Application Date</strong> for when this plan will take effect.</li>
      <li>Click the <strong>"Create"</strong> button to finalize and save your new strategic plan.
      </li>

    </ol>
    <p className="mt-4">
      Once created, your plan will be visible on the<strong> Strategic Plans</strong> page for further development and management.
    </p>
  </div>
);


export const DepartmentSWOTDashboardHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll p-4">

    <p className="mb-4 text-gray-700">
      The <strong>Department SWOT Dashboard</strong> provides a <strong>comprehensive view </strong>of all<strong> Strengths,
        Weaknesses, Opportunities, and Threats</strong> specific to your <strong>department</strong>. While similar to the <strong>Organizational SWOT Dashboard,
          this dashboard</strong> focuses on department-level insights that impact performance and strategy.</p>

    <ul className="list-disc ml-6 space-y-2">
      <li >
        Use this dashboard to <strong>analyze key factors</strong> affecting your department’s effectiveness.
      </li>
      <li>Data is displayed in an <strong>easy-to-read format</strong> for quick decision-making.

      </li>
      <li>If you need to <strong>edit or update any information</strong>, return to the<strong> Department SWOT Form</strong> to make changes.
      </li>
    </ul>

    <p className="mt-4">
      Ensure your department’s SWOT data is accurate and up to date to support informed strategic decisions.
    </p>
  </div>
);


export const OrganizationFoundationshelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll p-4">

    <p className="mb-4 text-gray-700">
      In the <strong>Organization Goals</strong> section, you can either <strong>enter your own goal</strong> or use <strong>AI Help</strong> for goal suggestions.</p>

    <ul className="list-disc ml-6 space-y-2">
      <li>To enter your own goal, simply type it into the<strong> Goal # field.</strong></li>
      <li>Once entered, click <strong>"+ Add New Goal"</strong> to add it to the list.</li>
      <li>When all goals are set, click <strong>"Save Changes"</strong> to ensure they are stored.</li>
    </ul>
    <p className="mt-4">
      Use AI Help for inspiration or create customized goals tailored to your organization's strategy.
    </p>
    <h2 className="text-xl font-bold mb-4">AI Help for Organization Goals</h2>
    <p className="mb-4 text-gray-700">
      If you choose to use <strong>AI Help</strong> for goal suggestions, you must first complete:</p>

    <ul className="list-disc ml-6 space-y-2">
      <li>The <strong>Strategic Value Analysis (SVA) Form</strong></li>
      <li>The <strong>SVA Dashboard Form</strong></li>
    </ul>
    <p className="mt-4">
      <strong>ProStrategy.AI</strong> uses data from these forms to generate tailored goal recommendations. Ensure both forms are completed before using AI Help for the most relevant suggestions.
    </p>

    <h2 className="text-xl font-bold mb-4">AI Help for Goal Suggestions</h2>
    <p className="mb-4 text-gray-700">
      When you select <strong>AI Help, ProStrategy.AI</strong> will generate <strong>20 goal suggestions</strong>that align with your organization's:</p>

    <ul className="list-disc ml-6 space-y-2">
      <li><strong>Mission, Vision, and Values</strong></li>
      <li><strong>Strategic Pillars</strong></li>
      <li><strong>SWOT Analysis</strong></li>
      <li><strong>Strategic Value Analysis (SVA)</strong></li>
      <li><strong>Industry and Organizational Description</strong></li>
    </ul>
    <p className="mt-4">
      You may select <strong>up to 20 goals</strong> from the list.
    </p>

    <ul className="list-disc ml-6 space-y-2">
      <li>Simply <strong>click on the goals</strong> you want to include.
      </li>
      <li>When finished, <strong>click "Use Goals"</strong> to add them to your existing goals.</li>
      <li>You will be returned to the <strong>Organization Goals</strong> page.
      </li>

    </ul>
    <p className="mt-4">
      Make sure to click "Save Changes" to preserve your newly selected goals.

    </p>

  </div>
);

export const DepartmentSWOTFormHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll p-4">
    <p className="mb-4 text-gray-700">
      The <strong>Department SWOT Form</strong> helps assess the <strong>Strengths, Weaknesses, Opportunities, and Threats </strong>
      specific to an individual department within the organization. While similar to the Organizational SWOT, this form
      focuses on department-level factors that impact its performance and strategic direction.
    </p>

    <ul className="space-y-4">
      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">1. Strengths (Internal, Positive Factors)</p>
          <p className="mt-2">Identify what makes this department strong and effective.</p>
          <ul className="list-disc ml-6 space-y-2">
            <li>Specialized expertise and skilled team members</li>
            <li>Strong internal processes and workflow efficiency</li>
            <li>Advanced technology or tools specific to the department</li>
            <li>High team collaboration and communication</li>
            <li>Positive reputation within the organization</li>
            <li>Consistent achievement of department goals</li>
            <li>Strong leadership and decision-making</li>
            <li>Well-defined department structure and responsibilities</li>
            <li>Effective use of data and analytics</li>
            <li>Strong relationships with other departments</li>
          </ul>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">2. Weaknesses (Internal, Negative Factors)</p>
          <p className="mt-2">Identify internal challenges that may limit department success.</p>
          <ul className="list-disc ml-6 space-y-2">
            <li>Skill gaps or lack of specialized training</li>
            <li>Inefficiencies in processes or outdated workflows</li>
            <li>Limited budget or resource constraints</li>
            <li>Dependency on other departments for critical tasks</li>
            <li>Technology limitations impacting performance</li>
            <li>High workload leading to burnout</li>
            <li>Lack of innovation or adaptability to changes</li>
            <li>Poor internal communication or misalignment with organizational goals</li>
            <li>Slow response times or delays in project execution</li>
            <li>Compliance or regulatory challenges affecting department functions</li>
          </ul>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">3. Opportunities (External, Positive Factors)</p>
          <p className="mt-2">Identify external factors that can drive department growth and improvement.</p>
          <ul className="list-disc ml-6 space-y-2">
            <li>New technology solutions to enhance productivity</li>
            <li>Collaboration with other departments for efficiency gains</li>
            <li>External training and professional development opportunities</li>
            <li>Process automation to reduce manual workload</li>
            <li>Industry best practices that can be adopted</li>
            <li>Increased budget or resource allocation for improvements</li>
            <li>Market trends that align with department goals</li>
            <li>New partnerships or vendor collaborations</li>
            <li>Enhanced data analytics for better decision-making</li>
            <li>Organizational growth creating new responsibilities and expansion</li>
          </ul>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">4. Threats (External, Negative Factors)</p>
          <p className="mt-2">Identify external risks that could impact the department’s success.</p>
          <ul className="list-disc ml-6 space-y-2">
            <li>Increased workload due to organizational expansion</li>
            <li>Rapid technology changes requiring constant adaptation</li>
            <li>Budget cuts or resource limitations</li>
            <li>Compliance changes affecting department operations</li>
            <li>Competing priorities with other departments</li>
            <li>Staff retention challenges or hiring difficulties</li>
            <li>Negative feedback from internal or external stakeholders</li>
            <li>Economic downturns impacting department initiatives</li>
            <li>Cybersecurity risks affecting department operations</li>
            <li>Shifting organizational strategies requiring department realignment</li>
          </ul>
        </div>
      </li>
    </ul>

    <p className="mt-4 text-gray-700">
      <strong>Tip:</strong> When conducting a Department SWOT Analysis, focus on the unique strengths and challenges of your specific team.
      Ensure all data is relevant to your department’s role and make sure to save changes before finalizing your analysis.
    </p>
  </div>
);


export const GoalAndStrategyHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll p-4">
    <h2 className="text-xl font-bold mb-4">Department Goals & Strategies Help</h2>

    <h3 className="font-semibold">Difference Between a Goal and a Supporting Strategy</h3>
    <p className="mb-4">
      <strong>Goal</strong> – A goal is a broad, high-level outcome that the organization or department aims to achieve. It defines what needs to be accomplished.
    </p>
    <p className="italic mb-2">Example: Increase member engagement by 20% within the next year.</p>

    <p className="mb-4">
      <strong>Supporting Strategy</strong> – A supporting strategy outlines the specific actions, methods, or approaches that will be used to achieve the goal. It defines how the goal will be accomplished.
    </p>
    <p className="italic mb-4">Example: Launch a personalized digital marketing campaign targeting inactive members.</p>

    <p className="mb-4">
      In short, a goal sets the destination, while supporting strategies define the path to get there. Every goal should have at least one clear, actionable strategy to ensure successful execution.
    </p>

    <h3 className="font-semibold">Adding a New Goal</h3>
    <ul className="list-disc ml-6 space-y-2 mb-4">
      <li>Upon arriving at this page, you will see the goals that have already been added by your department.</li>
      <li>To add a new goal, click the <strong>"Add New Goal"</strong> button. This will take you to the New Goal page.</li>
      <li>You may manually enter a goal in the field labeled <strong>"Enter Goal Here"</strong>.</li>
      <li>Alternatively, you can use <strong>AI Help</strong> to generate goal suggestions tailored to your department.</li>
      <li>At least one strategy is required when adding a goal to define how the goal will be achieved.</li>
      <li>Ensure all added goals and strategies align with your department’s objectives, and save changes before exiting.</li>
    </ul>

    <h3 className="font-semibold">Manually Adding a Goal and Strategy</h3>
    <ul className="list-disc ml-6 space-y-2 mb-4">
      <li>Enter your desired goal in the <strong>"Enter Goal Here"</strong> field.</li>
      <li>Type your supporting strategy in the provided field.</li>
      <li>Once entered, make sure to save changes to ensure your goal and strategy are recorded.</li>
    </ul>

    <h3 className="font-semibold">Adding a Goal with AI Help</h3>
    <ul className="list-disc ml-6 space-y-2 mb-4">
      <li>Click on the <strong>"AI Help"</strong> button.</li>
      <li>A form titled <strong>"AI Help - Create Goals & Strategies"</strong> will appear.</li>
      <li>AI will generate three goal suggestions based on your Department SWOT and Department SVA Information.</li>
      <li>You may select one goal at a time from the generated options.</li>
      <li>Each selected goal will automatically include 10 supporting strategies.</li>
      <li>Click on a goal to view its strategies, then click <strong>"Use Goals & Strategies"</strong> to confirm.</li>
      <li>You will be returned to the Goals & Strategies window, where your selected goal and strategies will be added to the list.</li>
      <li>Make sure to click the <strong>"Save Changes"</strong> button to preserve your new goal and strategies.</li>
    </ul>
  </div>
);
export const StrategicReportEditorHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll p-4">
    <h2 className="text-xl font-bold mb-4">Strategic Report Editor Help</h2>

    <p>This page displays your Strategic Report in an editable format, allowing you to make changes before finalizing.</p>

    <ul className="list-disc ml-6 space-y-2">
      <li><strong>Edit:</strong> Modify any section of the report as needed.</li>
      <li><strong>Download:</strong> Save a copy of your report to your device. You may download it as a DOCX or PDF.</li>
      <li><strong>Save Changes:</strong> Ensure your updates are stored.</li>
      <li><strong>Reset Template:</strong> This will remove all data and restore the default template. Use with caution.</li>
    </ul>

    <p className="mt-4">Review your edits carefully before resetting or downloading your report.</p>
  </div>
);

export const MemorializingUpdatingStrategyHelp = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll p-4">
    <h2 className="text-xl font-bold mb-4">Memorializing and Updating a Strategy</h2>

    <p>Once a strategy is created, it must be memorialized using the "+ Entry Form" button.</p>
    <ul className="list-disc ml-6 space-y-2">
      <li>Click "+ Entry Form" to open the strategy form.</li>
      <li>Complete all required fields and click "Save Changes" to ensure the strategy is added to the Strategic Database.</li>
    </ul>

    <p className="mt-4">If a strategy form has already been added and requires updates:</p>
    <ul className="list-disc ml-6 space-y-2">
      <li>Click the "+ Update Form" button.</li>
      <li>The form will reappear with all fields editable.</li>
      <li>Make the necessary updates, then save changes to ensure all modifications are reflected in the Strategic Database.</li>
    </ul>
  </div>
);



export const GoalsAndStrategy = () => (
  <div className="bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll p-4">
    <h2 className="text-red-600 font-bold text-lg mb-4">Engineering Department Goals</h2>
    <ul className="list-disc ml-6 space-y-2">
      <li><strong>Deliver Superior Customer Service and Experience</strong></li>
      <ul className="list-disc ml-6 space-y-2">
        <li>Enhance mobile and digital banking facilities to meet increasing member demand for instant service.</li>
        <li>Implement Banking-as-a-Service (BaaS) & Embedded Finance to provide seamless banking experience.</li>
        <li>Prioritize customer feedback to continually improve and tailor services that suit their needs.</li>
      </ul>
    </ul>
  </div>
);



export const UserManagementHelp = () => (
  <div className=" bg-white rounded-lg max-h-[calc(100vh-30vh)] overflow-y-scroll">
    <p className="mb-4 text-gray-700">
      Here's a guide to understanding and managing users based on the visible fields and options:
    </p>

    <ul className="space-y-4">
      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">User List:</p>
          <span>The table lists users with details such as:</span>
          <ul className="list-disc ml-6">
            <li><strong>Name:</strong> The user's full name.</li>
            <li><strong>Email:</strong> Their email address.</li>
            <li><strong>User Type:</strong> Categorized as "Department User" or "Admin User."</li>
            <li><strong>Role:</strong> Specific role within the company (e.g., "Sales Executive" or "Digital Marketer").</li>
            <li><strong>Department:</strong> The department they belong to (e.g., "Sales Team" or "Digital Marketing").</li>
          </ul>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Filter Options:</p>
          <span>At the top of the table, you have filter options:</span>
          <ul className="list-disc ml-6">
            <li><strong>Select User Type:</strong> Allows filtering based on user type (e.g., Admin, Department User).</li>
            <li><strong>Select Role:</strong> Lets you filter based on the user's role.</li>
            <li><strong>Select Department:</strong> You can filter users by department.</li>
          </ul>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Add User:</p>
          <span>On the right-hand side, the <strong>Add User</strong> button enables you to add new users to the system by inputting their details and assigning them roles and departments.</span>
        </div>
      </li>

      <li className="flex items-start space-x-3">
        <div>
          <p className="font-semibold">Pagination:</p>
          <span>At the bottom right, the pagination tool allows you to navigate through multiple pages of users, indicating that this list can span across many users (up to 100+ pages).</span>
        </div>
      </li>
    </ul>

    <p className="mt-6">
      This interface is designed for managing and organizing users efficiently within the Organization, allowing administrators to maintain clear oversight of roles and responsibilities.
    </p>
  </div>
);

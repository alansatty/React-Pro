import { BreadcrumbItem, Breadcrumbs } from "@nextui-org/breadcrumbs";
import { useNavigate } from "react-router-dom";

export default function Breadcrumb({ prev, current, size = "lg", prevLink }) {
  const navigate = useNavigate();

  const handlePrevClick = () => {
    if (prevLink) {
      navigate(prevLink);
    }
  };

  return (
    <Breadcrumbs size={size} separator="/" itemClasses={{ separator: "px-2" }}>
      {prev && (
        <BreadcrumbItem onClick={handlePrevClick} className="cursor-pointer font-semibold text-md">
          {prev}
        </BreadcrumbItem>
      )}
      <BreadcrumbItem className="font-semibold text-md" color="primary" isCurrent={true}>
        {current}
      </BreadcrumbItem>
    </Breadcrumbs>
  );
}

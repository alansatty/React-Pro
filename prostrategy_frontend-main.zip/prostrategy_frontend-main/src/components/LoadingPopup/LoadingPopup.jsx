import Typewriter from "typewriter-effect";

const LoadingPopup = ({ isTypeWriter = true, strings = [
  "Uploading...",
  "Images uploading...",
  "Just a moment, please wait",
  "Wait for a moment...",
] }) => {
  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 backdrop-blur-sm z-[1000]">
      <div className="bg-white p-6 rounded-lg shadow-lg flex items-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
        {isTypeWriter && (
          <div className="ml-3 text-gray-700">
            <Typewriter
              options={{
                strings: strings,
                autoStart: true,
                loop: true,
                pauseFor: 1500, // Pause time between phrases in milliseconds
              }}
            />
          </div>
        )}
      </div>
    </div>
  );
};

export default LoadingPopup;


import { Input } from "@nextui-org/input";
import { cn } from "../../utils/twMege";
// Assuming this is using `twMerge` for Tailwind merging

const FormInput = ({
    label,
    type,
    fieldName,
    required,
    errors,
    register,
    isVisible,
    toggleVisibility,
    radius = "sm",
    size = "md",
    labelPlacement = "outside",
    placeholder = "",
    isReadOnly = false,
    classNames: customClassNames = {},
    ...props
}) => {
    // Password visibility toggle content
    const endContent =
        type === "password" ? (
            <button
                className="focus:outline-none"
                type="button"
                onClick={toggleVisibility}
                aria-label="toggle password visibility"
            >
                {isVisible ? (
                    <span className="text-[#0098F5]">Hide</span>
                ) : (
                    <span className="text-[#0098F5]">Show</span>
                )}
            </button>
        ) : null;

    // Dynamic class names
    const mergedClassNames = {
        label: cn("text-black", customClassNames.label),
        inputWrapper: cn(
            "group-data-[focus=true]:border-[#0098F5]",
            "dark:group-data-[focus=true]:border-[#0098F5]",
            customClassNames.inputWrapper                 // Custom background color, or other custom styles
        ),
        ...customClassNames,
    };

    return (
        <Input
            radius={radius}
            size={size}
            isRequired={required}
            type={isVisible && type === "password" ? "text" : type}
            label={label}
            variant={isReadOnly ? "flat" : "bordered"}
            labelPlacement={labelPlacement}
            endContent={endContent}
            placeholder={placeholder}
            {...(register && register(fieldName))}
            color={errors && errors[fieldName] ? "danger" : ""}
            isInvalid={errors && !!errors[fieldName]}
            errorMessage={errors && errors[fieldName]?.message || ""}
            className="mb-8  group-data-[focus=true]:border-blue-500"

            classNames={mergedClassNames}
            isReadOnly={isReadOnly}
            {...props}
        />
    );
};

export default FormInput;

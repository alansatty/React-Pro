import React from 'react';
import hasPermission from '../../utils/hasPermission';

const PermissionWrapper = ({ resource, actions, children }) => {
    const isAllowed = hasPermission(resource, actions);
    
    if (!isAllowed) {
        return null;
    }

    return <>{children}</>; // Render the children if permission is granted
};

export default PermissionWrapper;

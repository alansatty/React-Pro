import { IconCircleX } from "@tabler/icons-react";
import SlidingPane from "react-sliding-pane";
import "react-sliding-pane/dist/react-sliding-pane.css";



function Drawer({ drawerState, setDrawerState, title, subTitle = "", Content }) {
    return (
        <div>

            <SlidingPane
             closeIcon={<div>
                <span className="text-xl"> <IconCircleX  color='#11181C' className="w-12 h-12" /></span>
             </div>}
                overlayClassName="z-50 "
                width="600px"
                isOpen={drawerState}
                title={title}
                
                subtitle={subTitle}
                onRequestClose={() => {
                    // triggered on "<" on left top click or on outside click
                    setDrawerState(false);
                }}

            >
                <Content />

            </SlidingPane>

        </div>
    )
}

export default Drawer
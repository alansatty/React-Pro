import { Button } from "@nextui-org/button";
import { Tooltip } from "@nextui-org/tooltip";
import { useNavigate } from "react-router-dom";
import AiHelpIcon from "../../assets/icons/aihelp-icon";
import useApi from "../../hooks/useApi";
import { apiList } from "../../services";

const CustomTooltip = ({
  tooltipTitle,
  tooltipContent,
  buttonText,
  CustomButton = null,
  navigateTo,
}) => {
  const navigate = useNavigate(); // Initialize navigation

  const handleNavigate = () => {
    navigate(navigateTo); // Navigate to the given path
  };

  const {
    data: currentPlanData,
    error: currentPlanError,
    isLoading: currentPlanDataLoading,
  } = useApi(
    apiList.admin.subscription.current_plan.key(),
    apiList.admin.subscription.current_plan.call()
  );


  return (
    <Tooltip
      content={
        <div className="px-2 py-2 max-w-60">
          <div className="text-small font-bold">{tooltipTitle}</div>
          <div className="text-tiny">{tooltipContent}</div>
          {buttonText && (
            <Button
              size="sm"
              className="mt-2 bg-blue-500 hover:bg-blue-600 text-white"
              onClick={handleNavigate}
            >
              {buttonText}
            </Button>
          )}
        </div>
      }
      placement="top"
    >
      {CustomButton ? (
       CustomButton
      ) : (
        <Button
          radius="sm"
          color="primary"
          className="mt-0 bg-[#39465F]/50"
          disabled={true}
        >
          <AiHelpIcon />
          AI Help
        </Button>
      )}
    </Tooltip>
  );
};

export default CustomTooltip;

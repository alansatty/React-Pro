import * as React from "react";
import * as ReactDOM from "react-dom/client";
import {
  createBrowserRouter,
  RouterProvider,
  Navigate,
} from "react-router-dom";
import "./index.css";
import "../public/font/stylesheet.css";
import LoginPage from "./app/(public)/auth/login/page";
import NotFound from "./app/(public)/404/page";
import SignUpPage from "./app/(public)/auth/signup/page";
import DashboardPage from "./app/(private)/admin/dashboard/page";
import AdminLayout from "./app/(private)/admin/layout";
import UserManagement from "./app/(private)/admin/userManagement/page";
import OrganizationGoals from "./app/(private)/admin/organizationgoals/page";
import Settings from "./app/(private)/admin/settings/page";
import ForgotPassword from "./app/(public)/auth/forgot-password/page";
import ChangePassword from "./app/(public)/auth/change-password/page";
import { Toaster } from "react-hot-toast";
import AuthProvider from "./providers/authProviders";
import PrivateLayout from "./app/(private)/layout";
import PublicLayout from "./app/(public)/auth/layout";
import DepartmentsPage from "./app/(private)/admin/departments/page";
// import CreateUser from "./app/(private)/admin/userManagement/createUser/page";
import CreateRolePage from "./app/(private)/admin/roleManagement/createRole/page";
import DepartmentDetailes from "./app/(private)/admin/departments/[id]/page";
// import EditUser from "./app/(private)/admin/userManagement/editUser/page";
import SetupPassword from "./app/(public)/auth/setup-password/page";
import "sweetalert2/dist/sweetalert2.min.css";
import UpdateRole from "./app/(private)/admin/roleManagement/updateRole/page";
import ProtectedRoute from "./middleware/ProtectedRoute";
import NotAutorized from "./app/(public)/not-authorized/page";
import { DepartmentTarget } from "./app/(private)/admin/departments/[departmentTarget]/page";
import DepartmentUsers from "./app/(private)/admin/departments/[departmentUsers]/page";
import Chats from "./app/(private)/admin/chats/page";
import { ProfilePage } from "./app/(private)/admin/profile/page";
import PricingPlans from "./app/(private)/admin/pricingPlans/page";
import Checkout from "./app/(private)/admin/checkout/page";
import PublicCheckout from "./app/(public)/publicCheckout/page";
import CheckoutSuccess from "./app/(public)/publicCheckout/components/CheckoutSuccess";
import { NuqsAdapter } from 'nuqs/adapters/react-router/v6'
import StrategyFormData from "./app/(private)/admin/strategyFormData/page";
import { GSComparison } from "./app/(private)/admin/GSComparison/page";
import DepartmentStrategicReport from "./app/(private)/admin/departments/[id]/[stragicId]/page";
import PaymentSuccess from "./app/(private)/admin/checkout/components/PaymentSuccess";
import StrategicReport from "./app/(private)/admin/StrategicReport/page";
import EditorPreview from "./app/(private)/admin/StrategicReport/components/EditorPreview";
import StrategicMonitorList from "./app/(private)/admin/departments/[id]/[stragicId]/_components/StrategicMonitorList";
import TenantAdminLogin from "./providers/TenantAdminLogin";



const router = createBrowserRouter([
  {
    element: <PrivateLayout />,
    children: [
      {
        path: "/",
        element: <AdminLayout />,
        children: [
          {
            index: true,
            element: <Navigate to="/dashboard" replace />, // Redirect to /recipients
          },
          {
            path: "/dashboard",
            element: <DashboardPage />,
          },
          {
            path: "/users",
            element: <UserManagement />,
          },
          // {
          //   path: "/users/create",
          //   element: (
          //     <ProtectedRoute page={"users"} action={"create"}>
          //       <CreateUser />
          //     </ProtectedRoute>
          //   ),
          // },
          // {
          //   path: "/users/edit/:id",
          //   element: (
          //     <ProtectedRoute page={"users"} action={"edit"}>
          //       <EditUser />
          //     </ProtectedRoute>
          //   ),
          // },
          // {
          //   path: "/role-management",
          //   element: (
          //     <ProtectedRoute
          //       page={"roles"}
          //       action={"list"}
          //       planPermission={"custom_roles_allowed"}
          //     >
          //       <RoleManagement />
          //     </ProtectedRoute>
          //   ),
          // },
          {
            path: "/settings/role-management/create",
            element: (
              <ProtectedRoute
                page={"roles"}
                action={"create"}
                planPermission={"custom_roles_allowed"}
              >
                <CreateRolePage />
              </ProtectedRoute>
            ),
          },
          {
            path: "/role-management/edit/:id",
            element: (
              <ProtectedRoute
                page={"roles"}
                action={"edit"}
                planPermission={"custom_roles_allowed"}
              >
                <UpdateRole />
              </ProtectedRoute>
            ),
          },
          // {
          //   path: "/strategic_plans",
          //   element: (
          //     <ProtectedRoute
          //       page={"strategic_plans"}
          //       action={"list"}
          //       planPermission={"strategy_plans_allowed_count"}
          //     >
          //       <StrategicPlans />
          //     </ProtectedRoute>
          //   ),
          // },
          {
            path: "/organizationgoals",
            element: <OrganizationGoals />,
          },
          {
            path: "/organizationgoals/:tabId",
            element: <OrganizationGoals />,
          },
          {
            path: "/strategy_form_data",
            element: (
              <ProtectedRoute
                page={"dept_strategy_data"}
                action={"has_access"}
              // planPermission={"strategy_plans_allowed_count"}
              >
                <StrategyFormData />
              </ProtectedRoute>
            ),
          },
          {
            path: "/strategy_form_data/:tabId",
            element: (
              <ProtectedRoute
                page={"dept_strategy_data"}
                action={"has_access"}
              // planPermission={"strategy_plans_allowed_count"}
              >
                <StrategyFormData />
              </ProtectedRoute>
            ),
          },
          {
            path: "/settings",
            element: (
              < Settings />
            )
          },
          {
            path: "/settings/:tabId",
            element: (
              // <ProtectedRoute adminOnly={true}>
              <Settings />
              // </ProtectedRoute>
            ),
          },
          {
            path: "/settings/:tabId/:subTabId",
            element: (
              // <ProtectedRoute adminOnly={true}>
              <Settings />
              // </ProtectedRoute>
            ),
          },
          {
            path: "/departments",
            element: <DepartmentsPage />,
          },
          {
            path: "/departments/:id",
            element: <DepartmentDetailes />,
          },
          {
            path: "/departments/:id/:tabId",
            element: <DepartmentDetailes />,
          },
          {
            path: "/departments/:id/goals_and_strategies_tab/:strategicId/strategic-planing-report",
            element: <DepartmentStrategicReport />,
          },
          {
            path: "/departments/:id/goals_and_strategies_list/:strategicId/strategic-monitor-list",
            element: <StrategicMonitorList />
          },
          {
            path: "/departments/target/:id",
            element: <DepartmentTarget />,
          },
          {
            path: "/departments/dept_users/:id",
            element: <DepartmentUsers />,
          },
          {
            path: "/chats",
            element: <Chats />,
          },
          {
            path: "/profile",
            element: <ProfilePage />,
          },
          {
            path: "/profile/:tabId",
            element: <ProfilePage />,
          },
          {
            path: "/pricingplans",
            element: <PricingPlans />,
          },
          {
            path: "/checkout/:planId",
            element: <Checkout />,
          },
          {
            path: "/payment/success",
            element: <PaymentSuccess />,
          },
          // {
          //   path: "/strategic-planing-report",
          //   element: <PlaygroundApp />, // here we need add new component for Preview and selecting option
          // },
          {
            path: "/strategic_report",
            element: <StrategicReport />, // here we need add new component for Preview and selecting option
          },
          {
            path: "/goals_and_strategy",
            element: <GSComparison />,
          },
          {
            path: "/strategic_report/preview",
            element: <EditorPreview />,
          },
          // {
          //   path: "/strategic-planing-report",
          //   element: <DeptStrategicCheckboxList />,
          // },

        ],
      },
    ],
  },

  {
    element: <TenantAdminLogin><PublicLayout /></TenantAdminLogin>,
    children: [
      {
        path: "/login",
        element: <LoginPage />,
      },
      {
        path: "/signup",
        element: <SignUpPage />,
      },
    ],
  },
  {
    path: "/forgot-password",
    element: <ForgotPassword />,
  },
  {
    path: "/change-password",
    element: <ChangePassword />,
  },
  {
    path: "/setup-password",
    element: <SetupPassword />,
  },
  {
    path: "/not-authorized",
    element: <NotAutorized />,
  },
  {
    path: "/subscription_checkout",
    element: <PublicCheckout />,
  },
  {
    path: "/checkout/success",
    element: <CheckoutSuccess />,
  },
  {
    path: "*",
    element: <NotFound />,
  },
]);

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <AuthProvider>
      <NuqsAdapter>
        <RouterProvider router={router} />
        <Toaster position="top-center" reverseOrder={false} />
      </NuqsAdapter>
    </AuthProvider>
  </React.StrictMode>
);

// uncomment the above lines to use the react lzzy loading feature

// import * as React from "react";
// import * as ReactDOM from "react-dom/client";
// import {
//   createBrowserRouter,
//   RouterProvider,
//   Navigate,
// } from "react-router-dom";
// import "./index.css";
// import "../public/font/stylesheet.css";
// import { Toaster } from "react-hot-toast";
// import AuthProvider from "./providers/authProviders";
// import PrivateLayout from "./app/(private)/layout";
// import PublicLayout from "./app/(public)/auth/layout";
// import AdminLayout from "./app/(private)/admin/layout";
// import "sweetalert2/dist/sweetalert2.min.css";
// import ProtectedRoute from "./middleware/ProtectedRoute";
// import { NuqsAdapter } from 'nuqs/adapters/react-router/v6';

// // Lazy-loaded components
// const LoginPage = React.lazy(() => import("./app/(public)/auth/login/page"));
// const NotFound = React.lazy(() => import("./app/(public)/404/page"));
// const SignUpPage = React.lazy(() => import("./app/(public)/auth/signup/page"));
// const DashboardPage = React.lazy(() => import("./app/(private)/admin/dashboard/page"));
// const UserManagement = React.lazy(() => import("./app/(private)/admin/userManagement/page"));
// const OrganizationGoals = React.lazy(() => import("./app/(private)/admin/organizationgoals/page"));
// const Settings = React.lazy(() => import("./app/(private)/admin/settings/page"));
// const ForgotPassword = React.lazy(() => import("./app/(public)/auth/forgot-password/page"));
// const ChangePassword = React.lazy(() => import("./app/(public)/auth/change-password/page"));
// const DepartmentsPage = React.lazy(() => import("./app/(private)/admin/departments/page"));
// const RoleManagement = React.lazy(() => import("./app/(private)/admin/roleManagement/page"));
// const CreateRolePage = React.lazy(() => import("./app/(private)/admin/roleManagement/createRole/page"));
// const DepartmentDetailes = React.lazy(() => import("./app/(private)/admin/departments/[id]/page"));
// const SetupPassword = React.lazy(() => import("./app/(public)/auth/setup-password/page"));
// const UpdateRole = React.lazy(() => import("./app/(private)/admin/roleManagement/updateRole/page"));
// const NotAutorized = React.lazy(() => import("./app/(public)/not-authorized/page"));
// const DepartmentTarget = React.lazy(() => import("./app/(private)/admin/departments/[departmentTarget]/page"));
// const DepartmentUsers = React.lazy(() => import("./app/(private)/admin/departments/[departmentUsers]/page"));
// const Chats = React.lazy(() => import("./app/(private)/admin/chats/page"));
// const ProfilePage = React.lazy(() => import("./app/(private)/admin/profile/page"));
// const PricingPlans = React.lazy(() => import("./app/(private)/admin/pricingPlans/page"));
// const Checkout = React.lazy(() => import("./app/(private)/admin/checkout/page"));
// const StrategicPlans = React.lazy(() => import("./app/(private)/admin/strategicPlans/page"));
// const PublicCheckout = React.lazy(() => import("./app/(public)/publicCheckout/page"));
// const CheckoutSuccess = React.lazy(() => import("./app/(public)/publicCheckout/components/CheckoutSuccess"));
// const PlaygroundApp = React.lazy(() => import("./app/(private)/admin/Binder/App"));
// const StrategyFormData = React.lazy(() => import("./app/(private)/admin/strategyFormData/page"));
// const GSComparison = React.lazy(() => import("./app/(private)/admin/GSComparison/page"));
// const SunEditorPage = React.lazy(() => import("./app/(private)/admin/SunBinder/components/page"));
// const DepartmentStrategicReport = React.lazy(() => import("./app/(private)/admin/departments/[id]/[stragicId]/page"));
// const PaymentSuccess = React.lazy(() => import("./app/(private)/admin/checkout/components/PaymentSuccess"));
// const StrategicReport = React.lazy(() => import("./app/(private)/admin/StrategicReport/page"));
// const DeptStrategicCheckboxList = React.lazy(() => import("./app/(private)/admin/StrategicReport/components/DeptStrategicCheckboxList"));
// const EditorPreview = React.lazy(() => import("./app/(private)/admin/StrategicReport/components/EditorPreview"));
// const StrategicMonitorList = React.lazy(() => import("./app/(private)/admin/departments/[id]/[stragicId]/_components/StrategicMonitorList"));

// // Suspense fallback component
// const SuspenseFallback = () => (
//   <div className="flex items-center justify-center min-h-screen">
//     <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
//   </div>
// );

// // Wrapper component for lazy loading with Suspense
// const LazyComponent = ({ children }) => (
//   <React.Suspense fallback={<SuspenseFallback />}>
//     {children}
//   </React.Suspense>
// );

// const router = createBrowserRouter([
//   {
//     element: <PrivateLayout />,
//     children: [
//       {
//         path: "/",
//         element: <AdminLayout />,
//         children: [
//           {
//             index: true,
//             element: <Navigate to="/dashboard" replace />,
//           },
//           {
//             path: "/dashboard",
//             element: <DashboardPage />,
//           },
//           {
//             path: "/users",
//             element: (
//               <LazyComponent>
//                 <UserManagement />
//               </LazyComponent>
//             ),
//           },
//           {
//             path: "/settings/role-management/create",
//             element: (
//               <LazyComponent>
//                 <ProtectedRoute
//                   page={"roles"}
//                   action={"create"}
//                   planPermission={"custom_roles_allowed"}
//                 >
//                   <CreateRolePage />
//                 </ProtectedRoute>
//               </LazyComponent>
//             ),
//           },
//           {
//             path: "/role-management/edit/:id",
//             element: (
//               <LazyComponent>
//                 <ProtectedRoute
//                   page={"roles"}
//                   action={"edit"}
//                   planPermission={"custom_roles_allowed"}
//                 >
//                   <UpdateRole />
//                 </ProtectedRoute>
//               </LazyComponent>
//             ),
//           },
//           {
//             path: "/organizationgoals",
//             element: (
//               <LazyComponent>
//                 <OrganizationGoals />
//               </LazyComponent>
//             ),
//           },
//           {
//             path: "/organizationgoals/:tabId",
//             element: (
//               <LazyComponent>
//                 <OrganizationGoals />
//               </LazyComponent>
//             ),
//           },
//           {
//             path: "/strategy_form_data",
//             element: (
//               <LazyComponent>
//                 <ProtectedRoute
//                   page={"dept_strategy_data"}
//                   action={"has_access"}
//                 >
//                   <StrategyFormData />
//                 </ProtectedRoute>
//               </LazyComponent>
//             ),
//           },
//           {
//             path: "/strategy_form_data/:tabId",
//             element: (
//               <LazyComponent>
//                 <ProtectedRoute
//                   page={"dept_strategy_data"}
//                   action={"has_access"}
//                 >
//                   <StrategyFormData />
//                 </ProtectedRoute>
//               </LazyComponent>
//             ),
//           },
//           {
//             path: "/settings",
//             element: (
//               <LazyComponent>
//                 <Settings />
//               </LazyComponent>
//             )
//           },
//           {
//             path: "/settings/:tabId",
//             element: (
//               <LazyComponent>
//                 <Settings />
//               </LazyComponent>
//             ),
//           },
//           {
//             path: "/settings/:tabId/:subTabId",
//             element: (
//               <LazyComponent>
//                 <Settings />
//               </LazyComponent>
//             ),
//           },
//           {
//             path: "/departments",
//             element: (
//               <LazyComponent>
//                 <DepartmentsPage />
//               </LazyComponent>
//             ),
//           },
//           {
//             path: "/departments/:id",
//             element: (
//               <LazyComponent>
//                 <DepartmentDetailes />
//               </LazyComponent>
//             ),
//           },
//           {
//             path: "/departments/:id/:tabId",
//             element: (
//               <LazyComponent>
//                 <DepartmentDetailes />
//               </LazyComponent>
//             ),
//           },
//           {
//             path: "/departments/:id/goals_and_strategies_tab/:strategicId/strategic-planing-report",
//             element: (
//               <LazyComponent>
//                 <DepartmentStrategicReport />
//               </LazyComponent>
//             ),
//           },
//           {
//             path: "/departments/:id/goals_and_strategies_list/:strategicId/strategic-monitor-list",
//             element: (
//               <LazyComponent>
//                 <StrategicMonitorList />
//               </LazyComponent>
//             )
//           },
//           {
//             path: "/departments/target/:id",
//             element: (
//               <LazyComponent>
//                 <DepartmentTarget />
//               </LazyComponent>
//             ),
//           },
//           {
//             path: "/departments/dept_users/:id",
//             element: (
//               <LazyComponent>
//                 <DepartmentUsers />
//               </LazyComponent>
//             ),
//           },
//           {
//             path: "/chats",
//             element: (
//               <LazyComponent>
//                 <Chats />
//               </LazyComponent>
//             ),
//           },
//           {
//             path: "/profile",
//             element: (
//               <LazyComponent>
//                 <ProfilePage />
//               </LazyComponent>
//             ),
//           },
//           {
//             path: "/profile/:tabId",
//             element: (
//               <LazyComponent>
//                 <ProfilePage />
//               </LazyComponent>
//             ),
//           },
//           {
//             path: "/pricingplans",
//             element: (
//               <LazyComponent>
//                 <PricingPlans />
//               </LazyComponent>
//             ),
//           },
//           {
//             path: "/checkout/:planId",
//             element: (
//               <LazyComponent>
//                 <Checkout />
//               </LazyComponent>
//             ),
//           },
//           {
//             path: "/payment/success",
//             element: (
//               <LazyComponent>
//                 <PaymentSuccess />
//               </LazyComponent>
//             ),
//           },
//           {
//             path: "/strategic_report",
//             element: (
//               <LazyComponent>
//                 <StrategicReport />
//               </LazyComponent>
//             ),
//           },
//           {
//             path: "/goals_and_strategy",
//             element: (
//               <LazyComponent>
//                 <GSComparison />
//               </LazyComponent>
//             ),
//           },
//           {
//             path: "/sun-editor",
//             element: (
//               <LazyComponent>
//                 <SunEditorPage />
//               </LazyComponent>
//             ),
//           },
//           {
//             path: "/strategic_report/preview",
//             element: (
//               <LazyComponent>
//                 <EditorPreview />
//               </LazyComponent>
//             ),
//           },
//         ],
//       },
//     ],
//   },
//   {
//     element: <PublicLayout />,
//     children: [
//       {
//         path: "/login",
//         element: (
//           <LazyComponent>
//             <LoginPage />
//           </LazyComponent>
//         ),
//       },
//       {
//         path: "/signup",
//         element: (
//           <LazyComponent>
//             <SignUpPage />
//           </LazyComponent>
//         ),
//       },
//     ],
//   },
//   {
//     path: "/forgot-password",
//     element: (
//       <LazyComponent>
//         <ForgotPassword />
//       </LazyComponent>
//     ),
//   },
//   {
//     path: "/change-password",
//     element: (
//       <LazyComponent>
//         <ChangePassword />
//       </LazyComponent>
//     ),
//   },
//   {
//     path: "/setup-password",
//     element: (
//       <LazyComponent>
//         <SetupPassword />
//       </LazyComponent>
//     ),
//   },
//   {
//     path: "/not-authorized",
//     element: (
//       <LazyComponent>
//         <NotAutorized />
//       </LazyComponent>
//     ),
//   },
//   {
//     path: "/subscription_checkout",
//     element: (
//       <LazyComponent>
//         <PublicCheckout />
//       </LazyComponent>
//     ),
//   },
//   {
//     path: "/checkout/success",
//     element: (
//       <LazyComponent>
//         <CheckoutSuccess />
//       </LazyComponent>
//     ),
//   },
//   {
//     path: "*",
//     element: (
//       <LazyComponent>
//         <NotFound />
//       </LazyComponent>
//     ),
//   },
// ]);

// ReactDOM.createRoot(document.getElementById("root")).render(
//   <React.StrictMode>
//     <AuthProvider>
//       <NuqsAdapter>
//         <RouterProvider router={router} />
//         <Toaster position="top-center" reverseOrder={false} />
//       </NuqsAdapter>
//     </AuthProvider>
//   </React.StrictMode>
// );
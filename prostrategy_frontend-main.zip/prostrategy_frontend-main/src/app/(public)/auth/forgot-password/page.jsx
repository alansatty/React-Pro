import React from "react";
import AuthWrapperLayout from "../components/AuthWrapperLayout/AuthWrapperLayout";
import { FormInput } from "../../../../components";
import { EmailIcon } from "../../../../assets/icons/emailIcon";
import { Button } from "@nextui-org/button";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { resetPasswordValidation } from "../../../../../validationSchema/authValidation";
import useApi from "../../../../hooks/useApi";
import { apiList } from "../../../../services";
import toast from "react-hot-toast";
import HelpModal from "../../../../components/Topbar/HelpModal";
import { ForgotPasswordHelp } from "../../../../components/Topbar/helpComponents/Helps";

const ForgotPassword = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setError
  } = useForm({
    resolver: yupResolver(resetPasswordValidation),
  });

  const { trigger, isMutating } = useApi(
    null,
    apiList.auth.forgotPassword.call(),
    { method: "POST" }
  );

  const handleForgotPassword = async (data) => {
    if (data) {

      try {
        let response = await trigger({ requestBody: data });


        toast.success(response?.data?.msg);

        reset();
      } catch (error) {
        console.error("Error:", error);
        setError("email", {
          type: "server",
          message: error?.data?.data || "An unexpected error occurred.",
        });
        toast.error(error?.data?.data);
      }
    }
  };

  return (
    <AuthWrapperLayout>
      <div className="fixed bottom-2 right-3  m-4">
        <HelpModal
          title={"Login help"}
          ContentComponent={ForgotPasswordHelp}
          isStatic={true}
        />
      </div>
      <form onSubmit={handleSubmit(handleForgotPassword)}>
        <h3 className="text-center text-black text-[28px] font-[500]">
          Forgot Password?
        </h3>
        <p className="text-center text-[#2A2E34] text-[16px]">
          Enter your email to receive a reset link{" "}
        </p>
        <div className="mt-4 p-5">
          <FormInput
            label={
              <label htmlFor="email">
                Email
                <span className="text-red-600 text-base ml-1">*</span>
              </label>
            }
            placeholder="example@gmail.com"
            size="lg"
            className="mb-10"
            type="email"
            startContent={<EmailIcon className="text-[#D6D9DE] me-3" />}
            fieldName="email"
            errors={errors}
            register={register}
          />

          <Button
            radius="sm"
            type="submit"
            className="bg-appSecondary text-white py-6"
            fullWidth
            isLoading={isMutating}
          >
            Reset Password
          </Button>
        </div>
      </form>
    </AuthWrapperLayout>
  );
};

export default ForgotPassword;

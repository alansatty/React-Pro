import React, { useState } from "react";
import AuthWrapperLayout from "../components/AuthWrapperLayout/AuthWrapperLayout";
import { FormInput } from "../../../../components";
import { PassIcon } from "../../../../assets/icons/passIcon";
import { Button } from "@nextui-org/button";
import { apiList } from "../../../../services";
import useApi from "../../../../hooks/useApi";
import { yupResolver } from "@hookform/resolvers/yup";
import { changePasswordValidation } from "../../../../../validationSchema/authValidation";
import { useForm } from "react-hook-form";
import { useLocation, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { SetNewPasswordHelp } from "../../../../components/Topbar/helpComponents/Helps";
import HelpModal from "../../../../components/Topbar/HelpModal";

const ChangePassword = () => {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const userId = searchParams.get("user");

  const navigate = useNavigate()

  const [isPassVisible, setIsPassVisible] = useState(false);
  const [isConfirmPassVisible, setIsConfirmPassVisible] = useState(false);

  const passToggleVisibility = () => setIsPassVisible(!isPassVisible);
  const confirmPassToggleVisibility = () =>
    setIsConfirmPassVisible(!isConfirmPassVisible);

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(changePasswordValidation),
  });

  const { trigger, isMutating } = useApi(
    null,
    apiList.auth.changePassword.call(userId),
    { method: "PUT" }
  );

  const handleChangePassword = async (data) => {
    if (data) {

      try {
        let response = await trigger({ requestBody: data });

        toast.success(response?.data?.msg)
        navigate("/login")
      } catch (error) {
        console.error("Error:", error);
        toast.error(error.data?.msg);
      }
    }
  };
  return (
    <AuthWrapperLayout>
              <div className="fixed bottom-2 right-3  m-4">

     
<HelpModal title={"Login help"} ContentComponent={SetNewPasswordHelp} isStatic={true} />
</div>
      <form onSubmit={handleSubmit(handleChangePassword)}>
        <h3 className="text-center text-black text-[28px] font-[500]">
          Set New Password
        </h3>
        <div className="mt-4 p-5">
          <FormInput
            label={
              <label htmlFor="password">
                Password
                <span className="text-red-600 text-base ml-1">*</span>
              </label>
            }
            placeholder="Enter Password"
            size="lg"
            type="password"
            className="mb-10"
            startContent={<PassIcon className="text-[#D6D9DE] me-3" />}
            isVisible={isPassVisible}
            toggleVisibility={passToggleVisibility}
            fieldName="new_password"
            errors={errors}
            register={register}
          />

          <FormInput
           label={
            <label htmlFor="confirm_password">
              Confirm Password
              <span className="text-red-600 text-base ml-1">*</span>
            </label>
          }
            placeholder="Enter Confirm Password"
            size="lg"
            type="password"
            className="mb-5"
            startContent={<PassIcon className="text-[#D6D9DE] me-3" />}
            isVisible={isConfirmPassVisible}
            toggleVisibility={confirmPassToggleVisibility}
            fieldName="confirm_password"
            errors={errors}
            register={register}
          />

          <Button
            radius="sm"
            type="submit"
            className="bg-appSecondary text-white py-6"
            fullWidth
            isLoading={isMutating}
          >
            Change Password
          </Button>
        </div>
      </form>
    </AuthWrapperLayout>
  );
};

export default ChangePassword;

import { Button } from "@nextui-org/button";
import React, { useState } from "react";
import AuthWrapperLayout from "../components/AuthWrapperLayout/AuthWrapperLayout";
import { FormInput, Modal } from "../../../../components";
import { Checkbox } from "@nextui-org/checkbox";
import { Link, useNavigate, useNavigation } from "react-router-dom";
import { UserIcon } from "../../../../assets/icons/userIcon";
import { EmailIcon } from "../../../../assets/icons/emailIcon";
import { OrgIcon } from "../../../../assets/icons/orgIcon";
import { PassIcon } from "../../../../assets/icons/passIcon";
import { useForm } from "react-hook-form";
import { signupValidation } from "../../../../../validationSchema/authValidation";
import { yupResolver } from "@hookform/resolvers/yup";
import useApi from "../../../../hooks/useApi";
import { apiList } from "../../../../services";
import toast from "react-hot-toast";
import { useAuth } from "../../../../providers/authProviders";
import { ModalBody, ModalHeader, useDisclosure } from "@nextui-org/modal";
import HelpModal from "../../../../components/Topbar/HelpModal";
import {
  LoginHelp,
  SignUpHelp,
} from "../../../../components/Topbar/helpComponents/Helps";

function SignUpPage() {
  const [isPassVisible, setIsPassVisible] = useState(false);
  const [isConfirmPassVisible, setIsConfirmPassVisible] = useState(false);
  const auth = useAuth();
  const { isOpen, onOpen, onOpenChange } = useDisclosure();
  const navigate = useNavigate();

  const passToggleVisibility = () => setIsPassVisible(!isPassVisible);
  const confirmPassToggleVisibility = () =>
    setIsConfirmPassVisible(!isConfirmPassVisible);

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setError,
  } = useForm({
    resolver: yupResolver(signupValidation),
  });

  const { trigger, isMutating } = useApi(null, apiList.auth.register.call(), {
    method: "POST",
  });

  const handleRegister = async (data) => {
    if (data) {
      try {
        let response = await trigger({ requestBody: data });

        auth.loginAction(response);
        // navigate("/login")
        toast.success("Signup completed Successfully !");
      } catch (error) {
        console.error("Error: ====", error);

        if (error.status === "validation_error") {
          const apiErrors = error.data;

          // Iterate through API errors and set them in the form
          Object.entries(apiErrors).forEach(([field, messages]) => {
            setError(field, {
              type: "server",
              message: messages.join(", "), // Show all error messages for the field
            });
          });
        }
      }
    }
  };

  const modalContent = () => {
    return (
      <>
        <ModalHeader className="flex flex-col gap-1">
          Terms and Conditions
        </ModalHeader>
        <ModalBody>
          <p className="font-semibold">Terms and Conditions for ProStrategy</p>
          <p>
            <span className="font-semibold">Effective Date:</span> Sep 26, 2024
          </p>
          <ol className="list-decimal pl-5 space-y-5 mb-10">
            <li>
              <strong>Acceptance of Terms:</strong> By accessing or using the
              services provided by ProStrategy, you agree to be bound by these
              Terms and Conditions. If you do not agree, please do not use our
              services.
            </li>
            <li>
              <strong>Services Provided:</strong> ProStrategy offers [describe
              services, e.g., consulting, strategic planning, training, etc.].
              Detailed descriptions of our services can be found on our website.
            </li>
            <li>
              <strong>User Responsibilities:</strong>
              <ul className="list-disc pl-5">
                <li>
                  You agree to provide accurate, current, and complete
                  information.
                </li>
                <li>
                  You will use our services only for lawful purposes and in
                  accordance with these terms.
                </li>
              </ul>
            </li>
            <li>
              <strong>Payment Terms:</strong>
              <ul className="list-disc pl-5">
                <li>
                  All fees are outlined on our website and are subject to
                  change.
                </li>
                <li>
                  Payment must be made in full before services are rendered
                  unless otherwise agreed upon.
                </li>
              </ul>
            </li>
            <li>
              <strong>Intellectual Property:</strong> All content, trademarks,
              and intellectual property related to ProStrategy are owned by
              ProStrategy. You may not use, reproduce, or distribute any
              materials without express written permission.
            </li>
            <li>
              <strong>Limitation of Liability:</strong> ProStrategy will not be
              liable for any indirect, incidental, or consequential damages
              arising from your use of our services. Our total liability is
              limited to the amount paid for services in the past six months.
            </li>
            <li>
              <strong>Indemnification:</strong> You agree to indemnify and hold
              ProStrategy harmless from any claims, losses, liabilities,
              damages, or expenses (including legal fees) arising out of your
              use of our services or violation of these terms.
            </li>
            <li>
              <strong>Termination:</strong> ProStrategy reserves the right to
              terminate or suspend your access to our services at any time,
              without notice, for conduct that we believe violates these terms
              or is harmful to other users or ProStrategy.
            </li>
            <li>
              <strong>Changes to Terms:</strong> ProStrategy reserves the right
              to modify these Terms and Conditions at any time. Any changes will
              be posted on our website, and your continued use of our services
              will signify your acceptance of the updated terms.
            </li>
            <li>
              <strong>Contact Information:</strong> For any questions or
              concerns regarding these Terms and Conditions, please contact us
              at info@prostrategy.ai.
            </li>
          </ol>
        </ModalBody>
      </>
    );
  };

  return (
    <AuthWrapperLayout>
      <div className="fixed bottom-2 right-3  m-4">
        <HelpModal
          title={"Login help"}
          ContentComponent={SignUpHelp}
          isStatic={true}
        />
      </div>
      <Modal
        isOpen={isOpen}
        onOpenChange={onOpenChange}
        content={modalContent()}
        size="4xl"
        scrollBehavior="inside"
      />

      <form onSubmit={handleSubmit(handleRegister)}>
        <h3 className="text-center text-black text-[28px] font-[500]">
          Create Free Account
        </h3>
        <div className="mt-4 p-5">
          <FormInput
            label={
              <label htmlFor="name">
                Full Name
                <span className="text-red-600 text-base ml-1">*</span>
              </label>
            }
            placeholder="John smith"
            size="lg"
            className="mb-10"
            fieldName="name"
            type="text"
            startContent={<UserIcon className="text-[#D6D9DE] me-3" />}
            errors={errors}
            register={register}
          />

          <FormInput
            label={
              <label htmlFor="email">
                Email
                <span className="text-red-600 text-base ml-1">*</span>
              </label>
            }
            placeholder="example@gmail.com"
            size="lg"
            className="mb-10"
            type="email"
            startContent={<EmailIcon className="text-[#D6D9DE] me-3" />}
            errors={errors}
            register={register}
            fieldName="email"
          />
          <FormInput
            label={
              <label htmlFor="organization_name">
                Organization Name
                <span className="text-red-600 text-base ml-1">*</span>
              </label>
            }
            placeholder="XYZ Company"
            size="lg"
            className="mb-10"
            type="text"
            startContent={<OrgIcon className="text-[#D6D9DE] me-3" />}
            errors={errors}
            register={register}
            fieldName="organization_name"
          />
          <FormInput
            label={
              <label htmlFor="password">
                Password
                <span className="text-red-600 text-base ml-1">*</span>
              </label>
            }
            placeholder="Enter Password"
            size="lg"
            type="password"
            className="mb-10"
            startContent={<PassIcon className="text-[#D6D9DE] me-3" />}
            isVisible={isPassVisible}
            toggleVisibility={passToggleVisibility}
            errors={errors}
            register={register}
            fieldName="password"
          />

          <FormInput
            label={
              <label htmlFor="confirmPassword">
                Confirm Password
                <span className="text-red-600 text-base ml-1">*</span>
              </label>
            }
            placeholder="Enter Confirm Password"
            size="lg"
            type="password"
            className="mb-5"
            startContent={<PassIcon className="text-[#D6D9DE] me-3" />}
            isVisible={isConfirmPassVisible}
            toggleVisibility={confirmPassToggleVisibility}
            errors={errors}
            register={register}
            fieldName="confirmPassword"
          />

          <Checkbox {...register("terms")} isInvalid={errors.terms}>
            I agree with{" "}
            <Link
              className="text-appSecondary hover:underline"
              onClick={onOpen}
            >
              Terms & Conditions
            </Link>
          </Checkbox>

          {errors.terms && (
            <p className="text-tiny text-danger mt-1 ml-6">
              {errors.terms?.message}
            </p>
          )}

          <Button
            radius="sm"
            type="submit"
            className="bg-appSecondary text-white py-6 mt-5"
            fullWidth
            isLoading={isMutating}
          >
            Sign up
          </Button>

          <p className="text-center mt-3">
            Already have a account?{" "}
            <Link className="text-[#02205F] hover:underline" to={"/login"}>
              Log In
            </Link>
          </p>
        </div>
      </form>
    </AuthWrapperLayout>
  );
}

export default SignUpPage;


import { Card, CardBody } from "@nextui-org/card";
import React from "react";
import ProstrategyLogo from "../../../../../assets/icons/ProstrategyLogo";
import { NavLink, useNavigate } from "react-router-dom";

function AuthWrapperLayout({ children }) {

    const navigate = useNavigate()

  return (
    <section className="w-full min-h-screen font-sans bg-auth-bg bg-cover bg-center "  style={{
        backgroundImage: `url('/authBgImage.svg')`
      }}>
      <div className="p-10 pb-0">
         <div className="w-fit cursor-pointer">
          <NavLink to="https://prostrategy.ai/">
          <ProstrategyLogo />
          </NavLink>
         </div>
      </div>
      <div className="flex items-center justify-center pb-10 relative ">
      
        <Card shadow="sm" className="w-[500px]">
          <CardBody>
            <div className="p-3">{children}</div>
          </CardBody>
        </Card>
      </div>
    </section>
  );
}

export default AuthWrapperLayout;

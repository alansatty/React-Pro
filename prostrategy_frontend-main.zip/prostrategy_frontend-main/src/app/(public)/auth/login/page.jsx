import { Button } from "@nextui-org/button";
import { useEffect, useRef, useState } from "react";
import AuthWrapperLayout from "../components/AuthWrapperLayout/AuthWrapperLayout";
import { FormInput } from "../../../../components";
import { EmailIcon } from "../../../../assets/icons/emailIcon";
import { PassIcon } from "../../../../assets/icons/passIcon";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { yupResolver } from "@hookform/resolvers/yup";
import { loginValidation } from "../../../../../validationSchema/authValidation";
import { useForm } from "react-hook-form";
import useApi from "../../../../hooks/useApi";
import { apiList } from "../../../../services";
import { useAuth } from "../../../../providers/authProviders";
import toast from "react-hot-toast";
import HelpModal from "../../../../components/Topbar/HelpModal";
import { LoginHelp } from "../../../../components/Topbar/helpComponents/Helps";
import axios from "axios";
import { Spinner } from "@nextui-org/spinner";


function LoginPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [tenantLoginLoading, setTenantLoginLoading] = useState(false)
  const tenantEmail = searchParams.get('email')
  const [isPassVisible, setIsPassVisible] = useState(false);
  const passToggleVisibility = () => setIsPassVisible(!isPassVisible);
  const navigate = useNavigate()

  const {
    register,
    handleSubmit,
    formState: { errors },
    setError,
  } = useForm({
    resolver: yupResolver(loginValidation),
  });

  const { trigger, isMutating } = useApi(null, apiList.auth.login.call(), {
    method: "POST",
  });

  const auth = useAuth();


  const handleLogin = async (data) => {
    if (data) {
      try {
        let response = await trigger({ requestBody: data });
        auth.loginAction(response.data);

        toast.success("Login completed Successfully !");
      } catch (error) {
        console.error("Error:", error);

        if (error.status === "validation_error") {
          const apiErrors = error.data;

          // Iterate through API errors and set them in the form
          Object.entries(apiErrors).forEach(([field, messages]) => {
            // toast.error(messages.join(", "))
            setError(field, {
              type: "server",
              message: messages.join(", "), // Show all error messages for the field
            });
          });
        } else {
          toast.error(error?.msg || error?.message);
        }
      }
    }
  };

  return (
    <>
      {/* {tenantLoginLoading ? (
        <AuthTenantLoginLayout>
          <Spinner />
        </AuthTenantLoginLayout>
      ) : ( */}
      <AuthWrapperLayout>
        <div className="fixed bottom-2 right-3 m-4">
          <HelpModal title={"Login help"} ContentComponent={LoginHelp} isStatic={true} />
        </div>
        <form onSubmit={handleSubmit(handleLogin)}>
          <h3 className="text-center text-black text-[28px] font-[500]">Login</h3>
          <div className="mt-4 p-5">
            <FormInput
              label={
                <label htmlFor="email">
                  Email
                  <span className="text-red-600 text-base ml-1">*</span>
                </label>
              }
              placeholder="example@gmail.com"
              size="lg"
              className="mb-10"
              type="email"
              startContent={<EmailIcon className="text-[#D6D9DE] me-3" />}
              fieldName="email"
              errors={errors}
              register={register}
              validation={{
                required: "Email is required",
                pattern: {
                  value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                  message: "Please enter a valid email address"
                }
              }}
            />
            <FormInput
              label={
                <label htmlFor="password">
                  Password
                  <span className="text-red-600 text-base ml-1">*</span>
                </label>
              }
              placeholder="Enter Password"
              size="lg"
              type={isPassVisible ? "text" : "password"}
              className="mb-5"
              startContent={<PassIcon className="text-[#D6D9DE] me-3" />}
              isVisible={isPassVisible}
              toggleVisibility={passToggleVisibility}
              fieldName="password"
              errors={errors}
              register={register}
              validation={{
                required: "Password is required"
              }}
            />

            <div className="flex justify-end">
              <Link
                className="text-[#02205F] hover:underline mb-5"
                to={"/forgot-password"}
              >
                Forgot Password
              </Link>
            </div>

            <Button
              radius="sm"
              type="submit"
              className="bg-appSecondary text-white py-6"
              fullWidth
              isLoading={isMutating}
            >
              Log In
            </Button>

            <p className="text-center mt-3">
              Don't have an account?{" "}
              <Link className="text-[#02205F] hover:underline" to={"/signup"}>
                Sign Up
              </Link>
            </p>
          </div>
        </form>
      </AuthWrapperLayout>
      {/* )} */}
    </>
  );
}

export default LoginPage;
import React from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../../../providers/authProviders';


function PublicLayout() {
  console.log("worked")
  const location = useLocation();
  const auth = useAuth();
  if (auth?.user?.token) {
    return <Navigate to='/' state={{ from: location }} replace />;
  }
  return <Outlet />;
}

export default PublicLayout;

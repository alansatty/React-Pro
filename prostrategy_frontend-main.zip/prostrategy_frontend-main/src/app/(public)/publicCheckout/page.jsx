import PaymentDetails from "./components/PaymentDetails";
import ContactInfo from "./components/ContactInfo";
import { Navigate, useSearchParams } from "react-router-dom";
import useApi from "../../../hooks/useApi";
import { apiList } from "../../../services";
import { PageSpinner } from "../../../components";

const PublicCheckout = () => {
  const [searchParams] = useSearchParams();

  // // Get the page from URL params, default to 1 if not present
  const quoteId = searchParams.get("call_for_quote_user_id");

  if (!quoteId) {
    return <Navigate to="/not-authorized" />;
  }

  const { data, error, isLoading } = useApi(
    apiList.auth.getQuoteDetails.key(quoteId),
    apiList.auth.getQuoteDetails.call(quoteId)
  );

  if (isLoading) {
    return <PageSpinner />;
  }



  return (
    <div className="bg-[#F4F7FA] p-3 flex flex-col md:flex-row items-start gap-3 ">
      {/* Payment Details Section */}
      <PaymentDetails planData={data?.data} />

      {/* Contact Information Section */}
      <ContactInfo quoteId={quoteId} planData={data?.data} />
    </div>
  );
};

export default PublicCheckout;

import { Button } from "@nextui-org/button";
import { IconCircleCheck } from "@tabler/icons-react";
import React, { useState, useEffect } from "react";
import ProstrategyLogo from "../../../../assets/icons/ProstrategyLogo";

const CheckoutSuccess = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b py-20 text-center rounded-md bg-white  p-4">
      {/* Success Icon with Animation */}
      {/* <div
        className={`mb-6 transform transition-all duration-1000 scale-100 opacity-100`}
      >
        <IconCircleCheck
          className="mx-auto text-primary animate-bounce"
          size={100}
        />
      </div> */}

      <div className="mb-6 flex justify-center">
        <ProstrategyLogo />
      </div>

      {/* Success Message */}
      <h1 className="text-3xl font-bold text-gray-800 mb-4">
        Payment Successful!
      </h1>
      <p className="text-gray-600 mb-8">
        Thank you for your payment. Your transaction has been completed
        successfully.
      </p>

      {/* Countdown Message */}
      <p className="text-sm text-gray-500 font-medium mb-6">
        Please check your email to complete your profile and gain access to the
        portal.
      </p>
    </div>
  );
};

export default CheckoutSuccess;

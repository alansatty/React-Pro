import { Button } from "@nextui-org/button";
import { Controller, useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import FormInput from "../../../../components/FormInput/FormInput";
import { PublicPaymentInfoSchema } from "../../../../../validationSchema/authValidation";
import { useEffect, useState } from "react";
import useApi from "../../../../hooks/useApi";
import { apiList } from "../../../../services";
import {
  Elements,
  EmbeddedCheckout,
  EmbeddedCheckoutProvider,
} from "@stripe/react-stripe-js";
import { loadStripe } from "@stripe/stripe-js";
import toast from "react-hot-toast";
import axios from "axios";
import Select from "react-select";
import { Country, State, City } from "country-state-city";
import { cn } from "../../../../utils/twMege";
import useUnsavedChanges from "../../../../hooks/useUnsavedChanges";
import UnsavedChangesModal from "../../../../components/Alert/UnsavedChangesModal";

// import Swal from "sweetalert2/dist/sweetalert2.js";

// eslint-disable-next-line no-undef
axios.defaults.baseURL = import.meta.env.VITE_API_BASE_URL;

const ContactInfo = ({ quoteId, planData }) => {
  const [stripePromise, setStripePromise] = useState(null);
  const [clientSecret, setClientSecret] = useState(null);
  const [publicKey, setPublicKey] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const [countries, setCountries] = useState([]);
  const [states, setStates] = useState([]);
  const [cities, setCities] = useState([]);


  const {
    register,
    handleSubmit,
    control,
    watch,
    setValue,
    formState: { errors, isDirty },
  } = useForm({
    resolver: yupResolver(PublicPaymentInfoSchema),
    defaultValues: {
      name: planData?.name,
      email: planData?.email,
      organization_name: planData?.organization_name,
      country: { value: "US", label: "United States" },
    },
  });

  const { showModal, confirmNavigation, cancelNavigation } = useUnsavedChanges(isDirty);


  // const { trigger, isMutating } = useApi(
  //   null,
  //   apiList.admin.subscription.proceed_checkout.call(),
  //   { method: "POST" }
  // );

  useEffect(() => {
    // Set states for United States
    const stateOptions = State.getStatesOfCountry("US").map((state) => ({
      value: state.isoCode,
      label: state.name,
    }));
    setStates(stateOptions);
  }, []);

  const selectedCountry = watch("country");
  const selectedState = watch("state");


  useEffect(() => {
    if (selectedState) {
      const cityOptions = City.getCitiesOfState("US", selectedState.value).map(
        (city) => ({
          value: city.name,
          label: city.name,
        })
      );
      if (cityOptions.length === 0) {
        // No cities available, set city to the state name
        setCities([{ value: selectedState.value, label: selectedState.label }]);
        setValue("city", {
          value: selectedState.value,
          label: selectedState.label,
        });
      } else {
        setCities(cityOptions);
        setValue("city", null);
      }
      setValue("postal_code", "");
    }
  }, [selectedState, setValue]);

  useEffect(() => {
    if (selectedCountry && selectedState) {
      const cityOptions = City.getCitiesOfState(
        selectedCountry.value,
        selectedState.value
      ).map((city) => ({
        value: city.name,
        label: city.name,
      }));
      if (cityOptions.length === 0) {
        // No cities available, set city to the state name
        setCities([{ value: selectedState.value, label: selectedState.label }]);
        setValue("city", {
          value: selectedState.value,
          label: selectedState.label,
        });
      } else {
        setCities(cityOptions);
        setValue("city", null);
      }
      setValue("postal_code", "");
    }
  }, [selectedCountry, selectedState, setValue]);

  const handleRegister = async (data) => {

    try {
      if (data) {
        const formData = {
          ...data,
          country: data.country.label,
          state: data.state.label,
          city: data.city.label,
          call_for_quote_user_id: quoteId,
          duration: "life_time",
        };

        // const response = await trigger({ requestBody: formData });

        setIsLoading(true);

        // Make the POST request with axios
        const response = await axios.post(
          "/subscription/proceed_checkout", // Update with the correct endpoint
          formData
        );

        // Set Stripe keys from API response
        const { public_key, client_secret } = response.data;

        setPublicKey(public_key);
        setStripePromise(loadStripe(public_key));
        setClientSecret(client_secret);
      }
    } catch (error) {
      if (
        error?.response?.data?.status === "validation_error" &&
        error?.response?.data
      ) {
        const validationErrors = error?.response?.data?.data;
        // for (const [field, messages] of Object.entries(validationErrors)) {
        //   setError(field, { type: "manual", message: messages[0] });
        // }
        // return;
      }
      if (error?.status == 400) {
        toast.error(error?.data?.msg);
      }
    } finally {
      setIsLoading(false);
    }
  };

  if (clientSecret && publicKey && stripePromise) {
    const options = {
      // passing the client secret obtained from the server
      clientSecret: clientSecret,
    };

    return (
      <div className="shadow-lg  w-full md:w-1/2">
        <EmbeddedCheckoutProvider stripe={stripePromise} options={options}>
          <EmbeddedCheckout />
        </EmbeddedCheckoutProvider>
      </div>
    );
  }

  return (
    <div className="bg-[#E6F0FF] shadow-sm  rounded-lg p-10 w-full md:w-1/2">
      {showModal && (
        <UnsavedChangesModal
          isConfirmNavigation={confirmNavigation}
          isCancelNavigation={cancelNavigation}
        />
      )}
      <form onSubmit={handleSubmit(handleRegister)}>
        <h2 className="text-2xl font-bold">Contact Information</h2>

        <div className="pt-5 ">
          <FormInput
            label="Organization Name"
            placeholder="Enter Organization name"
            size="lg"
            className="mb-10  "
            fieldName="organization_name"
            type="text"
            errors={errors}
            register={register}
            // classNames={{
            //   inputWrapper: "bg-white",
            // }}
            isReadOnly={true}
          />

          <FormInput
            label="Full Name"
            placeholder="Enter Full Name"
            size="lg"
            className="mb-10  "
            fieldName="name"
            type="text"
            errors={errors}
            register={register}
            // classNames={{
            //   inputWrapper: "bg-white",
            // }}
            isReadOnly={true}
          />

          <FormInput
            label="Email"
            placeholder="Enter Email"
            size="lg"
            className="mb-10  "
            type="email"
            errors={errors}
            register={register}
            fieldName="email"
            isReadOnly={true}
          />

          <FormInput
            label="Address Information"
            placeholder="Enter Address Line 1"
            size="lg"
            className="mb-2  "
            type="type"
            errors={errors}
            register={register}
            fieldName="line1"
            classNames={{
              inputWrapper: "bg-white",
            }}
          />
          <FormInput
            placeholder="Enter Address Line 2"
            size="lg"
            className="mb-2  "
            type="type"
            errors={errors}
            register={register}
            fieldName="line2"
            classNames={{
              inputWrapper: "bg-white",
            }}
          />

          {/* <div className="flex gap-3">
            <FormInput
              placeholder="Enter City"
              size="lg"
              className="mb-2  "
              type="type"
              errors={errors}
              register={register}
              fieldName="city"
              classNames={{
                inputWrapper: "bg-white",
              }}
            />{" "}
            <FormInput
              placeholder="Enter State"
              size="lg"
              className="mb-2  "
              type="type"
              errors={errors}
              register={register}
              fieldName="state"
              classNames={{
                inputWrapper: "bg-white",
              }}
            />
          </div> */}

          {/* <div className="flex gap-3">
            <FormInput
              placeholder="Enter Country"
              size="lg"
              className="mb-2  "
              type="type"
              errors={errors}
              register={register}
              fieldName="country"
              classNames={{
                inputWrapper: "bg-white",
              }}
            />{" "}
            <FormInput
              placeholder="Zip Code"
              size="lg"
              className="mb-2  "
              type="type"
              errors={errors}
              register={register}
              fieldName="postal_code"
              classNames={{
                inputWrapper: "bg-white",
              }}
            />
          </div> */}

          <div className=" flex gap-2">
            <div className="w-full">
              <label
                className={cn(errors?.country?.message ? "text-danger" : "")}
                htmlFor="country"
              >
                Country
              </label>
              <Controller
                name="country"
                control={control}
                render={({ field }) => (
                  <Select
                    {...field}
                    options={[{ value: "US", label: "United States" }]}
                    value={{ value: "US", label: "United States" }}
                    isDisabled={true}
                    classNames={{
                      inputWrapper: "bg-white",
                    }}
                  />
                )}
              />
              {errors.country && (
                <p className="text-red-500 text-sm mt-1">
                  {errors.country.message}
                </p>
              )}
            </div>

            <div className="w-full">
              <label
                className={cn(errors?.state?.message ? "text-danger" : "")}
                htmlFor="state"
              >
                State
              </label>
              <Controller
                name="state"
                control={control}
                render={({ field }) => (
                  <Select
                    {...field}
                    styles={{
                      menu: (base) => ({
                        ...base,
                        zIndex: 9999,
                        position: "absolute",
                      }),
                      menuList: (base) => ({ ...base, zIndex: 9999 }),
                    }}
                    options={states}
                    placeholder="Select State"
                    classNames={{
                      inputWrapper: "bg-white",
                    }}
                    isDisabled={!selectedCountry}
                  />
                )}
              />
              {errors.state && (
                <p className="text-red-500 text-sm mt-1">
                  {errors?.state?.message}
                </p>
              )}
            </div>
          </div>

          <div className="flex gap-2 mt-4">
            <div className="w-full">
              <label
                className={cn(errors?.city?.message ? "text-danger" : "")}
                htmlFor="city"
              >
                City
              </label>
              <Controller
                name="city"
                control={control}
                render={({ field }) => (
                  <Select
                    {...field}
                    options={cities}
                    placeholder="Select City"
                    isDisabled={!selectedState}
                    classNames={{
                      inputWrapper: "bg-white",
                    }}
                  />
                )}
              />
              {errors.city && (
                <p className="text-red-500 text-sm mt-1">
                  {errors.city.message}
                </p>
              )}
            </div>
            <div className="w-full">
              <FormInput
                placeholder="Zip Code"
                size="md"
                label={"Zip code"}
                labelPlacement="outside"
                className="mb-2"
                type="text"
                errors={errors}
                register={register}
                fieldName="postal_code"
                classNames={{
                  inputWrapper: "bg-white",
                }}
              />
            </div>
          </div>

          <Button
            radius="sm"
            type="type"
            color="primary"
            className="bg-appSecondary mt-5"
            isLoading={isLoading}
          >
            Proceed to payment
          </Button>
        </div>
      </form>
    </div>
  );
};

export default ContactInfo;

import React from "react";
import { NavLink } from "react-router-dom";
import Checked_icon from "../../../../assets/icons/checked-icon";
import ProstrategyLogo from "../../../../assets/icons/ProstrategyLogo";

const PaymentDetails = ({ planData, period, setPeriodState }) => {
  const { quote_details, amount, duration, duration_period } = planData;

  // Map of feature names for display
  // const featureNames = {
  //   ai_presentation_suite: "AI Presentation Suite",
  //   custom_role_permission: "Custom Role Permission",
  //   strategic_value_analysis: "Strategic Value Analysis",
  //   ai_features_allowed: "AI Features Allowed",
  //   users_allowed_count: "Users Allowed Count",
  //   custom_roles_allowed: "Custom Roles Allowed",
  //   mission_vision_value: "Mission Vision Value",
  //   sva_dashboard_allowed: "SVA Dashboard Allowed",
  //   sustainable_objectives: "Organization pillars",
  //   departments_allowed_count: "Departments Allowed Count",
  //   strategy_plans_allowed_count: "Strategy Plans Allowed Count",
  //   organization_business_targets: "Organization Business Targets",
  //   swot_analysis: "SWOT Analysis",
  //   goal_strategic: "Goal Strategic",
  //   strategic_form: "Strategic Form",
  //   internal_chat: "Internal Chat",

  // };

  const featureNames = {
    // 🔹 Old ones you already had
    ai_presentation_suite: "AI Presentation Suite",
    custom_role_permission: "Custom Role Permission",
    strategic_value_analysis: "Strategic Value Analysis",
    ai_features_allowed: "AI Features Allowed",
    users_allowed_count: "Users Allowed Count",
    custom_roles_allowed: "Custom Roles Allowed",
    mission_vision_value: "Mission Vision Value",
    sva_dashboard_allowed: "SVA Dashboard Allowed",
    sustainable_objectives: "Organization Pillars",
    departments_allowed_count: "Unlimited Departments",
    strategy_plans_allowed_count: "Strategy Plans Allowed Count",
    organization_business_targets: "Organization Business Targets",
    swot_analysis: "SWOT Analysis",
    goal_strategic: "Goal Strategic",
    strategic_form: "Strategic Form",
    internal_chat: "Internal Chat",
    email_support: "Email Support",

    // 🔹 New ones from your JSON/screenshot
    org_sva_swot_goals_ai: "Organization SVA/SWOT/Goals With AI",
    ai_organization_training: "AI Organization Training",
    quarter_strategy_workshop: "Quarter Strategy Workshop",
    gantt_chart_forecast_graph: "Gantt Chart/Forecast/Graph",
    org_base_goals_with_pillars_ai: "Organization Mission/Vision/Value/Pillars With AI",
    department_base_goals_with_pillars_ai: "Department Base Goals With Pillars AI",
    department_sva_swot_goals_ai: "Department SVA SWOT Goals AI",
    select_multiple_strategic_plans: "Strategy Analysis Multiple Strategic Plans",
    dedicated_account_manager_and_enterprise_onboarding:
      "Dedicated Account Manager And Enterprise Onboarding",
    priority_email_and_quarterly_strategic_review_calls:
      "Priority Email And Quarterly Strategic Review Calls",
  };


  // Filter features based on true or specific values
  const featureList = Object.entries(quote_details).filter(([key, value]) => {
    // Include features with true or positive values
    return (
      Boolean(value) ||
      [
        "users_allowed",
        "departments_allowed",
        "strategic_plan_allowed",
      ].includes(key)
    );
  });

  return (
    <div className="bg-white shadow-sm  rounded-lg p-10 w-full md:w-1/2">
      <div className="pb-10">
        <div className="w-fit cursor-pointer">
          <NavLink to="https://prostrategy.ai/">
            <ProstrategyLogo />
          </NavLink>
        </div>
      </div>
      <h2 className="text-2xl font-bold">Payment Details</h2>
      <p className="text-gray-600 capitalize">Subscribe to Enterprise Plan</p>
      <div className="text-3xl font-bold mt-4">
        ${amount}
        {/* <span className="text-lg font-medium text-[#656565]">
          /{duration.toLowerCase()}
        </span> */}
      </div>

      <div className="bg-blue-50 p-4 rounded-sm mt-3">
        <h3 className="font-semibold text-gray-800 capitalize">
          Subscription Features
        </h3>

        <div className="flex flex-col gap-2 mt-4">
          {/* Add the duration period dynamically */}
          <li className="flex gap-2">
            <span>
              <Checked_icon />
            </span>
            <span className="text-start">
              Duration - {duration_period}{" "}
              {duration === "monthly" ? "Month" : "Year"}
              {duration_period > 1 ? "s" : ""}
            </span>
          </li>
          {featureList.length > 0 ? (
            featureList.map(([key, value]) => {
              // Skip showing both department AI flags individually
              if (
                (key === "department_base_goals_with_pillars_ai" ||
                  key === "department_sva_swot_goals_ai") &&
                (quote_details.department_base_goals_with_pillars_ai ||
                  quote_details.department_sva_swot_goals_ai)
              ) {
                // Render only once for "Department AI"
                if (key === "department_base_goals_with_pillars_ai") {
                  return (
                    <li className="flex gap-2" key="department_ai">
                      <span>
                        <Checked_icon />
                      </span>
                      <span className="text-start">Department AI</span>
                    </li>
                  );
                }
                // skip the second one
                return null;
              }

              let displayText;

              // Handle specific keys
              if (key === "users_allowed_count") {
                displayText = `User Allowed Counts - ${value} User${value > 1 ? "s" : ""
                  }`;
              } else if (key === "departments_allowed_count") {
                displayText = `Unlimited Departments`;
              } else if (key === "strategy_plans_allowed_count") {
                displayText = `Strategy Plans Allowed Count - ${value} Strategic Plan${value > 1 ? "s" : ""
                  }`;
              } else {
                // Use the feature name map or fallback to key
                displayText = featureNames[key] || key;
              }

              return (
                <li className="flex gap-2" key={key}>
                  <span>
                    <Checked_icon />
                  </span>
                  <span className="text-start">{displayText}</span>
                </li>
              );
            })
          ) : (
            <p className="text-gray-500">No features available for this plan.</p>
          )}

        </div>
      </div>

      <div className="mt-6 space-y-2">
        <div className="flex justify-between pb-4 border-b mr-4">
          <div>
            <p className="font-lg font-bold">Enterprise Plan</p>
            {/* <span className="text-small font-medium text-[#656565]">
              billed {duration.toLowerCase()}
            </span> */}
          </div>
          <span>${amount}</span>
        </div>

        {/* <div className="flex justify-between pb-4 border-b mr-4">
          <span>Sub Total</span>
          <span>${amount}</span>
        </div> */}
        <div className="flex justify-between font-bold pb-4 pt-2 mr-4">
          <span>Total</span>
          <span>${amount}</span>
        </div>
      </div>
    </div>
  );
};

export default PaymentDetails;

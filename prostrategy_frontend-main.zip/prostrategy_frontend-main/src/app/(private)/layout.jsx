import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../../providers/authProviders';

const PrivateLayout = () => {

  const location = useLocation();
  const auth = useAuth();
  if (!auth?.user?.token) {
    return <Navigate to='/login' state={{ from: location }} replace />;
  }

  if (auth?.user?.token) {
    return <Outlet />;
  }

  return <Navigate to='/login' state={{ from: location }} replace />;
};

export default PrivateLayout;
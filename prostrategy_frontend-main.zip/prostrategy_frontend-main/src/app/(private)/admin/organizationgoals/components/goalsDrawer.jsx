import { Button } from "@nextui-org/button";
import { Card } from "@nextui-org/card";
import { IconCircleX, IconInfoCircle, IconReload } from "@tabler/icons-react";
import SlidingPane from "react-sliding-pane";
import "react-sliding-pane/dist/react-sliding-pane.css";
import toast from "react-hot-toast";
import { Skeleton } from "@nextui-org/skeleton";

function AiHelpGoalsDrawer({
  drawerState,
  setDrawerState,
  title,
  getGoalsWithlimitNumber,
  onSaveGoals,
  AIUsedCount,
  AIGoalData,
  AILoading,
  selectedGoal,
  setSelectedGoal,
  handleIsDirty
}) {

  const handleSelectGoals = (goal) => {
    if (selectedGoal.includes(goal)) {
      // Remove if already selected
      setSelectedGoal(selectedGoal.filter((item) => item !== goal));
    } else if (selectedGoal.length >= 10) {
      // Error if more than 5 goals are selected
      toast.error("Only 10 goals can be selected.");
    } else {
      // Add the new goals
      setSelectedGoal([...selectedGoal, goal]);
    }
  };

  const useSelectedGoals = () => {

    if (selectedGoal.length === 0) {
      toast.error(
        `Please select at least one goal`
      );
      return;
    }

    if (selectedGoal.length <= 20) {
      onSaveGoals(selectedGoal);
      setDrawerState(false);
      setSelectedGoal([]);
      handleIsDirty(true)
    } else {
      toast.error("Please select only up to 20 goals.");
    }
  };

  const handleGetMore = () => {
    if (AIUsedCount < 2) {
      getGoalsWithlimitNumber();
    } else {
      toast.error("Maximum Goal selection reached!");
    }
  };

  return (
    <div>
      <SlidingPane
        closeIcon={
          <div>
            <span className="text-xl">
              <IconCircleX color="#11181C" className="w-12 h-12" />
            </span>
          </div>
        }
        overlayClassName="z-50 "
        width="600px"
        isOpen={drawerState}
        title={title}
        onRequestClose={() => setDrawerState(false)}
      >
        <div>
          <h5 className="text-gray-600 p-1 font-semibold">
            Based on the Organization Name, Organization Type, Organization Description, Organization Business Targets, Web Address, Geographic Market Focus, Client Training, Organization SVA, Organization SVA Dashboard and Organization Goals, here are the suggested Organization Goals.
          </h5>
          <div className="flex gap-2 items-start text-sm">
            <IconInfoCircle className="mb-1 h-7 w-7" />
            <p>
              You can generate and select up to 10 goals from the list
              to create Organization Goals.
            </p>
          </div>

          <div className="mt-4 grid grid-cols-1 gap-4 max-h-[calc(78vh-30vh)] overflow-auto p-2">
            {AILoading
              ? Array.from({ length: 4 }).map((_, index) => (
                <Card
                  key={index}
                  bordered
                  shadow="none"
                  radius="md"
                  className={`p-4 border-[#E2E9F0] bg-[#F4F7FA] border`}
                >
                  <Skeleton className="rounded-lg">
                    <div className="h-10 rounded-lg bg-default-300"></div>
                  </Skeleton>
                </Card>
              ))
              : AIGoalData.map((goal, index) => (
                <Card
                  bordered
                  key={index}
                  shadow="none"
                  isPressable
                  radius="sm"
                  className={`p-2 bg-[#F4F7FA] w-full border text-start min-h-12 flex justify-center ${selectedGoal.includes(goal)
                    ? "border-primary border-2"
                    : "border-[#E2E9F0]"
                    }`}
                  onClick={() => handleSelectGoals(goal)}
                >
                  {index + 1} : {goal}
                </Card>
              ))}
          </div>

          <div className="flex justify-between mt-4">
            {AIUsedCount < 2 ? (
              <Button
                radius="sm"
                variant="bordered"
                color="primary"
                startContent={!AILoading && <IconReload />}
                auto
                className="bg-white text-black"
                onClick={handleGetMore}
                isLoading={AILoading}
              >
                {AILoading ? "Getting" : "Get 5 more"}
              </Button>
            ) : (
              <div></div>
            )}

            <Button
              color="primary"
              radius="sm"
              className="capitalize"
              onClick={useSelectedGoals}
              // disabled={selectedGoal.length === 0}
              isLoading={AILoading}
            >
              Use Goals
            </Button>
          </div>
        </div>
      </SlidingPane>
    </div>
  );
}

export default AiHelpGoalsDrawer;

import { Button } from "@nextui-org/button";
import { Textarea } from "@nextui-org/input";
import { Radio, RadioGroup } from "@nextui-org/radio";
import { useEffect, useState } from "react";
import AiHelpIcon from "../../../../../assets/icons/aihelp-icon";
import { apiList } from "../../../../../services";
import useApi from "../../../../../hooks/useApi";
import { ValueSchema } from "../../../../../../validationSchema/authValidation";
import { useAuth } from "../../../../../providers/authProviders";
import { Card } from "@nextui-org/card";
import {
  IconInfoCircle,
} from "@tabler/icons-react";
import toast from "react-hot-toast";
import AiHelpDrawer from "./AiHelpDrawer";
import hasPermission from "../../../../../utils/hasPermission";
import { PageSpinner, PermissionWrapper } from "../../../../../components";
import { mutate } from "swr";
import { OrganizationValueHelp } from "../../../../../components/Topbar/helpComponents/Helps";
import HelpModal from "../../../../../components/Topbar/HelpModal";
import hasPlanPermission from "../../../../../utils/hasPlanPermission";
import usePermissionsStore from "../../../../../stores/usePermissionStore";
import { useNavigate } from "react-router-dom";
import CustomTooltip from "../../../../../components/CustomTooltip/CustomTooltip";
import withReactContent from "sweetalert2-react-content";
import ProstrategyLogo from "../../../../../assets/icons/ProstrategyLogo";
import UnsavedChangesModal from "../../../../../components/Alert/UnsavedChangesModal";
import useUnsavedChanges from "../../../../../hooks/useUnsavedChanges";
import Swal from "sweetalert2/dist/sweetalert2.js";
const MySwal = withReactContent(Swal);

function ValueTab() {
  const navigate = useNavigate();
  const [isDirty, setIsDirty] = useState(false);
  const [drawerStep, setDrawerStep] = useState(1);
  const [statements, setStatements] = useState([]);
  const [error, setError] = useState('')
  const [isOpen, setIsOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [isValueStatement, setIsValueStatement] = useState("");
  const [existingValue, setIsExistingValue] = useState("");
  const [fullBusinessEssentials, setFullBusinessEssentials] = useState([]); // Store business essentials data
  const [businessEssentialData, setBusinessEssentialData] = useState([]); // Store business essentials data
  const [value, setValue] = useState("");
  const [savedValue, setsavedValue] = useState("");
  const [ValueError, setValueError] = useState(null); // Track validation errors for mission
  const [getMoreCount, setGetMoreCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [selectedBusinessEssentials, setSelectedBusinessEssentials] = useState(
    []
  );
  const [isEditable, setIsEditable] = useState(null);
  const auth = useAuth();
  const { showModal, confirmNavigation, cancelNavigation } =
    useUnsavedChanges(isDirty);
  const [customLoading, setCustomLoading] = useState(false);

  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
  const {
    data: currentPlanData,
  } = useApi(
    apiList.admin.subscription.current_plan.key(),
    apiList.admin.subscription.current_plan.call()
  );

  const toggleDrawer = () => {
    if (error === "To proceed, please update the business targets in the Settings menu") {
      MySwal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>
            <h2 className="text-xl font-semibold">Warning!</h2>
            <p className="mt-2">Please update the business targets to get AI Help.</p>
          </div>
        ),
        confirmButtonText: "Go to Business Targets",
        customClass: {
          confirmButton:
            "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
        },
      }).then((result) => {
        if (result.isConfirmed) {
          navigate("/organizationgoals/bussiness_target");
        }
      });
      return
    }
    if (getMoreCount == 0) useBusinessEssentials();
    if (fullBusinessEssentials.length > 0 || BELoading) {
      setIsOpen((prev) => !prev);
    } else {
      // toast.error("Please update the Settings to get AI Help.");
      MySwal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>
            <h2 className="text-xl font-semibold">Warning!</h2>
            <p className="mt-2">Please update the Settings to get AI Help.</p>
          </div>
        ),
        confirmButtonText: "Go to Settings",
        customClass: {
          confirmButton:
            "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
        },
      }).then((result) => {
        if (result.isConfirmed) {
          navigate("/settings/organization_tab"); // Navigate to the settings page
        }
      });
    }
  };

  const getBusinessEssentials = async () => {
    try {
      const bodyData = {
        organization_goal: "value",
        strategic_plan_id: strategicPlan
        // businessEssentialData: businessEssentialData,
      };

      let response = await businessEssentials({ requestBody: bodyData });
      setFullBusinessEssentials(response?.data);
    } catch (error) {
      console.log(error);
      if (error?.msg) {
        setError(error?.msg)
      }
      // setIsOpen((prev) => !prev);
      // toast.error(error.data.message);
    } finally {
      // setLoading(false);
    }
  };

  const useBusinessEssentials = () => {
    // Only load if more data is available and count is less than 3
    if (
      getMoreCount < 2 &&
      fullBusinessEssentials?.length > businessEssentialData?.length
    ) {
      const nextDataStart = getMoreCount == 0 ? getMoreCount : 15;
      const nextDataEnd = getMoreCount == 0 ? 15 : 20;

      // Append the next 4 items to the business essentials data
      setBusinessEssentialData((prevData) => [
        ...prevData,
        ...fullBusinessEssentials.slice(nextDataStart, nextDataEnd),
      ]);

      // Increment the count for more data loading
      setGetMoreCount(getMoreCount + 1);
    }
  };

  const { data: Goals, isLoading: loadingState } = useApi(
    apiList.admin.organizationGoals.get_goals.key(auth?.user?.organization_id),
    strategicPlan ? apiList.admin.organizationGoals.get_goals.call(strategicPlan) : null
  );

  useEffect(() => {
    setValue(Goals?.data?.value);
    setsavedValue(Goals?.data?.value);
    getBusinessEssentials();
    if (Goals?.data?.value) {
      setEditMode(true);
    } else {
      setEditMode(false);
    }
  }, [Goals]);

  const mutateFn = async () => {
    setCustomLoading(true);
    await mutate(
      apiList.admin.organizationGoals.get_goals.key(auth?.user?.organization_id)
    );
    setCustomLoading(false);
  };

  useEffect(() => {
    mutateFn();
  }, [strategicPlan]);

  const { trigger, isMutating } = useApi(
    null,
    strategicPlan ? apiList.admin.organizationGoals.create_value.call(strategicPlan) : null,
    { method: "POST" }
  );

  const { trigger: businessEssentials, isMutating: BELoading } = useApi(
    null,
    apiList.admin.organizationGoals.business_essentials.call(),
    { method: "POST" }
  );

  useEffect(() => {
    if (!loadingState) {
      setLoading(false);
    }
    if (!BELoading) {
      if (getMoreCount == 0) useBusinessEssentials();
    }
  }, [loadingState, BELoading]);

  // Real-time validation on input change
  const handleValueChange = async (e) => {
    setIsDirty(true);
    const value = e.target.value;
    setValue(value);
    validateValue(value);
  };

  const validateValue = async (value) => {
    try {
      await ValueSchema.validate({ value: value });
      setValueError(null); // Clear errors if validation passes
    } catch (error) {
      setValueError(error.message); // Set validation error
    }
  };

  const onSubmit = async (e) => {
    e.preventDefault();

    // Validate the mission statement using Yup
    try {
      await ValueSchema.validate({ value });
      setValueError(""); // Clear errors if validation passes

      const bodyData = {
        content: value,
        organization: auth?.user?.organization_id,
        strategic_plan_id: strategicPlan,
      };

      let response = await trigger({ requestBody: bodyData });
      // toast.success("Value created successfully");
      // toast.success(response?.data);
      setIsDirty(false);
      mutate(
        apiList.admin.organizationGoals.get_goals.key(
          auth?.user?.organization_id
        )
      );

      MySwal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>
            <h2 className="text-xl font-semibold">Success!</h2>
            <p className="mt-2">{response?.data}</p>
          </div>
        ),
        confirmButtonText: "Okay",
        customClass: {
          confirmButton: "my-confirm-button",
        },
      });
      setEditMode(!editMode);
    } catch (error) {
      setValueError(error?.message); // Set the validation error message
      console.log(error);
      if (!isValueStatement || !existingValue) {
        if (error?.message) {
          toast.error(error?.message);
        }
      }
      if (error?.data) {
        if (error?.data?.message) {
          toast.error(error?.data?.message);
        }
      }
    }
  };

  const handleFullStatementChange = (index, value) => {

    const updatedStatements = [...statements];
    updatedStatements[index] = value;
    setStatements(updatedStatements);
  };

  const changeEditMode = () => {
    setIsExistingValue("yes");
    setIsValueStatement("yes");
    setEditMode(!editMode);
  };

  if (loadingState || loading || customLoading) {
    return <PageSpinner />;
  }

  const renderContent = () => {
    if (
      !hasPermission("org_value", "read_only") &&
      !hasPermission("org_value", "edit")
    ) {
      return <div>Value Not Available for the Organization</div>;
    }

    if (
      hasPermission("org_value", "read_only") &&
      !hasPermission("org_value", "edit")
    ) {
      if (!editMode) {
        return <div>Value Not Available for the Organization</div>;
      }
    }
    if (editMode) {
      return (
        <div className={`my-2 mb-4 w-[80%]`}>
          <h5 className="text-gray-600 p-1">Value</h5>

          <Card
            bordered
            shadow="none"
            radius="md"
            className={`p-2 bg-[#F4F7FA] border text-start   border-[#E2E9F0]`}
          >
            {value}
          </Card>
          <PermissionWrapper resource={"org_value"} actions={["edit"]}>
            <span
              className="mt-1 text-default-500 float-end cursor-pointer"
              onClick={changeEditMode}
            >
              Edit
            </span>
          </PermissionWrapper>
        </div>
      );
    }

    const handleIsDirty = (dirty) => {
      setIsDirty(dirty);
    };

    return (
      <div>
        <form onSubmit={onSubmit} noValidate>
          {showModal && (
            <UnsavedChangesModal
              isCancelNavigation={cancelNavigation}
              isConfirmNavigation={confirmNavigation}
            />
          )}
          <div className="flex justify-between gap-5">
            <div className="flex gap-2   p-1 px-2 w-fit mb-5">
              <span>
                <IconInfoCircle />
              </span>
              <p>
                The "Organization Goals" section, specifically under the Value
                tab in ProStrategy.ai, helps you manage your company's value
                statement. Here's how to interact with this form
                <HelpModal
                  title={"Organization Goals Value Help"}
                  ContentComponent={OrganizationValueHelp}
                  isReadMore={true}
                />
              </p>
            </div>
            <PermissionWrapper resource={"org_value"} actions={["edit"]}>
              <Button
                radius="sm"
                color="primary"
                className="mb-2 bg-[#0098F5]"
                type="submit"
                isLoading={isMutating}
              >
                Save Changes
              </Button>
            </PermissionWrapper>
          </div>
          <div>
            <p className="mb-6">
              Does your Company currently have a value statement?{" "}
            </p>
            <RadioGroup
              className="mb-5"
              orientation="horizontal"
              value={isValueStatement}
              onValueChange={(value) => {
                setIsValueStatement(value);
                if (value == "no") {
                  setValue("");
                }
                if (existingValue === "yes" && value == "yes" && savedValue) {
                  setValue(savedValue);
                  validateValue(savedValue);
                }
              }}
            >
              <Radio value="yes">Yes</Radio>
              <Radio value="no">No</Radio>
            </RadioGroup>
          </div>

          {isValueStatement == "yes" && (
            <div>
              <p className="mb-6">
                Do you want to continue with the existing value or create a new
                one?
              </p>
              <RadioGroup
                className="mb-5"
                orientation="horizontal"
                value={existingValue}
                onValueChange={(value) => {
                  setIsExistingValue(value);
                  if (value == "no") {
                    setValue("");
                    if (hasPlanPermission("org_base_goals_with_pillars_ai")) {
                      toggleDrawer();
                    } else {
                      toast.error(
                        "Your current plan has limited features. Upgrade now to access more!"
                      );
                    }
                  }
                  if (
                    isValueStatement === "yes" &&
                    value == "yes" &&
                    savedValue
                  ) {
                    setValue(savedValue);
                    validateValue(savedValue);
                  }
                }}
              >
                <Radio value="yes">Use Existing One</Radio>
                <Radio value="no">
                  Use AI to help create new value statement
                </Radio>
              </RadioGroup>
            </div>
          )}

          {(existingValue === "no" || isValueStatement === "no") && (
            <div className="flex gap-2 items-center text-sm bg-slate-200 rounded-[8px] p-1 px-2 w-[65%]">
              <IconInfoCircle className="mb-[1px] h-5 w-5" />
              Click the{`"AI Help"`} button on the right side to generate a
              value statement using AI or type manually.
            </div>
          )}

          {(isValueStatement === "no" ||
            existingValue === "no" ||
            existingValue === "yes") && (
              <div>
                <Textarea
                  label={
                    <div className="flex items-end justify-between mt-2">
                      <label htmlFor="missionStatement">
                        Value Statement{" "}
                        <span className="text-red-600 text-base ml-1">*</span>
                      </label>
                      {(existingValue === "no" || isValueStatement === "no") &&
                      (hasPlanPermission("org_base_goals_with_pillars_ai") ? (
                          <Button
                            radius="sm"
                            color="primary"
                            className="mt-0 bg-[#39465F]"
                            onClick={toggleDrawer}
                          >
                            <AiHelpIcon />
                            AI Help
                          </Button>
                        ) : (
                          <CustomTooltip
                            tooltipTitle="Upgrade Plan"
                            tooltipContent={
                              currentPlanData?.data?.plan_name == "Enterprise"
                                ? "Your current plan has limited features. Please Contact Admin"
                                : "Your current plan has limited features. Upgrade now to access more!"
                            }
                            buttonText={
                              currentPlanData?.data?.plan_name == "Enterprise"
                                ? null
                                : "Go to Plans"
                            }
                            navigateTo="/settings/account_tab" // The route to navigate
                          />
                        ))}
                    </div>
                  }
                  labelPlacement="outside"
                  placeholder="Enter your value statement"
                  variant="bordered"
                  radius="sm"
                  value={value}
                  onChange={handleValueChange}
                  isInvalid={ValueError ? true : false}
                  errorMessage={ValueError}
                  classNames={{
                    input: "min-h-[150px]",
                    label: "mb-2",
                    inputWrapper: [
                      "group-data-[focus=true]:border-[#0098F5]",
                      "dark:group-data-[focus=true]:border-[#0098F5]",
                    ],
                  }}
                />
              </div>
            )}

          {/* <Drawer
            drawerState={isOpen}
            setDrawerState={setIsOpen}
            title={
              <span className="font-semibold">
                AI Help - <span className="text-[#0098F5]">Create Value</span>
              </span>
            }
            Content={() => (
              <AiDrawer
                businessEssentialData={businessEssentialData}
                getBusinessEssentials={useBusinessEssentials}
                setValue={setValue}
                validate={validateValue}
                type={"value"}
                setDrawerOpen={setIsOpen}
                BELoading={BELoading}
                step={drawerStep}
                setStep={setDrawerStep}
                statements={statements}
                setStatements={setStatements}
                getMoreCount={getMoreCount}
                selectedBusinessEssentials={selectedBusinessEssentials}
                setSelectedBusinessEssentials={setSelectedBusinessEssentials}
              />
            )}
          /> */}

          <AiHelpDrawer
            drawerState={isOpen}
            setDrawerState={setIsOpen}
            title={
              <span className="font-semibold">
                AI Help -{" "}
                <span className="text-[#0098F5]">Create Value Statement</span>
              </span>
            }
            businessEssentialData={businessEssentialData}
            getBusinessEssentials={useBusinessEssentials}
            setValue={setValue}
            validate={validateValue}
            type={"Value"}
            setDrawerOpen={setIsOpen}
            BELoading={BELoading}
            step={drawerStep}
            setStep={setDrawerStep}
            fullStatements={statements}
            setFullStatements={setStatements}
            getMoreCount={getMoreCount}
            selectedBusinessEssentials={selectedBusinessEssentials}
            setSelectedBusinessEssentials={setSelectedBusinessEssentials}
            isEditable={isEditable}
            setIsEditable={setIsEditable}
            handleFullStatementChange={handleFullStatementChange}
            handleIsDirty={handleIsDirty}
          />
        </form>
      </div>
    );
  };

  return <>{renderContent()}</>;
}

export default ValueTab;

import { useState, useEffect } from "react";
import useApi from "../../../../../hooks/useApi";
import { apiList } from "../../../../../services";
import usePermissionsStore from "../../../../../stores/usePermissionStore";
import { Spinner } from "@nextui-org/spinner";
import { mutate } from "swr";
import Swal from "sweetalert2/dist/sweetalert2.js";
import GoalForm from "./GoalForm";
import withReactContent from "sweetalert2-react-content";
import ProstrategyLogo from "../../../../../assets/icons/ProstrategyLogo";
const MySwal = withReactContent(Swal);

export default function GoalsTab() {
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
  const [goals, setGoals] = useState([]);
  const [fullAIResponse, setFullAIResponse] = useState([]);
  const [AIError, setAIError] = useState(null);

  const [isEditing, setIsEditing] = useState(false);

  const {
    data: apiData,
    isLoading,
  } = useApi(
    apiList.admin.strategies.get_saved.key(strategicPlan),
    strategicPlan ? apiList.admin.strategies.get_saved.call(strategicPlan) : null
  );

  const { trigger: genaratedAiHelp, isMutating: AILoading } = useApi(
    null,
    apiList.admin.strategies.genarate.call(),
    { method: "POST" }
  );

  const getAIStatements = async () => {
    try {
      const bodyData = {
        strategic_plan_id: strategicPlan,
      };

      let data = await genaratedAiHelp({ requestBody: bodyData });

      if (data?.data?.length > 0) {
        setFullAIResponse(data?.data);
      }
      setAIError(null);
    } catch (error) {
      console.log(error);
      if (error?.status == "error") {
        if (error?.msg?.includes("SWOT")) {
          setAIError("SWOT");
        } else {
          setAIError("SVA");
        }
      }
    }
  };

  useEffect(() => {


    if (apiData?.data && apiData?.data.length > 0) {
      // Process the API data to map into the desired format
      const processedGoals = apiData.data.map((goalObj) => {
        const [goalId, title] = Object.entries(goalObj)[0];
        return { id: goalId, value: title };
      });

      setGoals(processedGoals);
      setIsEditing(false);

    } else {
      // If no API data, initialize with empty goals
      setGoals([{ id: null, value: "" }]);
      setIsEditing(true);
    }

    // Call the function to get AI statements
    getAIStatements();

  }, [apiData]);

  const addNewGoal = () => {
    if (goals.length < 20) {
      setGoals([...goals, { id: null, value: "" }]);
    }
  };

  const { trigger: SaveStrategies, isMutating } = useApi(
    null,
    apiList.admin?.strategies?.save.call(),
    { method: "POST" }
  );

  const handleSave = async (formData) => {
    try {
      const reqBody = { strategic_plan_id: strategicPlan, goals: formData };
      const { data } = await SaveStrategies({ requestBody: reqBody });
      // setGoals([]);
      setIsEditing(false);
      mutate(apiList.admin.strategies.get_saved.key(strategicPlan)); // Refresh the data after saving
      MySwal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>
            <h2 className="text-xl font-semibold">Success!</h2>
            <p className="mt-2">{data}</p>
          </div>
        ),
        confirmButtonText: "Okay",
        customClass: {
          confirmButton: "my-confirm-button",
        },
      });
    } catch (error) {
      console.error("Error saving strategies:", error);
    }
  };

  if (isLoading || !strategicPlan) {
    return (
      <div className="flex items-center justify-center h-full w-full">
        <Spinner size="md" />
      </div>
    );
  }



  return (
    <div className="">
      <GoalForm
        goals={goals}
        handleSave={handleSave}
        AIError={AIError}
        fullAIResponse={fullAIResponse}
        AILoading={AILoading}
        isMutating={isMutating}
        isEditing={isEditing}
        setIsEditing={setIsEditing}
        addNewGoal={addNewGoal}
        setGoals={setGoals}
      />
    </div>
  );
}

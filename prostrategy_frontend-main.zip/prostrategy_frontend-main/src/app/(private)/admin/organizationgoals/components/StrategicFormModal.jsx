import { Button } from "@nextui-org/button";
import { Input } from "@nextui-org/input";
import {
  Modal,
  ModalBody,
  ModalContent,
  ModalFooter,
  ModalHeader,
} from "@nextui-org/modal";
import { Radio, RadioGroup } from "@nextui-org/radio";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { cn } from "../../../../../utils/twMege";
import { StrategyFormSchema } from "../../../../../../validationSchema/authValidation";
import { apiList } from "../../../../../services";
import useApi from "../../../../../hooks/useApi";
import toast from "react-hot-toast";
import { useEffect } from "react";
import usePermissionsStore from "../../../../../stores/usePermissionStore";
import { mutate } from "swr";

export function StrategicFormModal({
  isOpen,
  onClose,
  strategyIdEntry,
  isFormExist,
}) {
  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    defaultValues: {
      name: "",
      department_choices: "",
      start_date: "",
      production_date: "",
    },
    resolver: yupResolver(StrategyFormSchema),
  });

  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);

  const { data } = useApi(
    strategyIdEntry && isFormExist
      ? apiList.admin.strategies.get_entryFormDetails.key(strategyIdEntry)
      : null,
    apiList.admin.strategies.get_entryFormDetails.call(strategyIdEntry)
  );

  const { trigger, isMutating } = useApi(
    null,
    apiList.admin.strategies.save_entryForm.call(strategyIdEntry),
    { method: "POST" }
  );

  useEffect(() => {
    if (data?.data?.length > 0) {
      const savedData = data.data[0];
      reset({
        name: savedData.name || "",
        department_choices: savedData.department_choices || "",
        start_date: savedData.start_date || "",
        production_date: savedData.production_date || "",
      });
    } else {
      // Handle the case where no data is returned or data is invalid
      reset({
        name: "",
        department_choices: "",
        start_date: "",
        production_date: "",
      });
    }
  }, [data, reset]);

  const onSubmit = async (formData) => {
    const formattedData = {
      ...formData,
      start_date: formData.start_date
        ? new Date(formData.start_date).toISOString().split("T")[0]
        : null,
      production_date: formData.production_date
        ? new Date(formData.production_date).toISOString().split("T")[0]
        : null,
    };

    if (formattedData) {
      try {
        const response = await trigger({ requestBody: formattedData });
        toast.success(response?.message || "Form saved successfully!");
        mutate(apiList.admin.strategies.get_saved.key(strategicPlan));
        onClose();
      } catch (error) {
        console.error(error);
        toast.error("Failed to save the form.");
      }
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="4xl" scrollBehavior="inside">
      <form onSubmit={handleSubmit(onSubmit)} noValidate>
        <ModalContent>
          <ModalHeader>Strategic Form</ModalHeader>
          <ModalBody className="gap-4">
            <Controller
              name="name"
              control={control}
              render={({ field }) => (
                <Input
                  {...field}
                  variant="bordered"
                  labelPlacement="outside"
                  label="1. What is the name of this STRATEGIC INITIATIVE?"
                  placeholder="Enter name"
                  errorMessage={errors.name?.message}
                  isInvalid={errors && !!errors?.name}
                  helperColor="error"
                />
              )}
            />

            <div className="space-y-2">
              <Controller
                name="department_choices"
                control={control}
                render={({ field }) => (
                  <RadioGroup
                    label={
                      <p
                        className={cn(
                          "text-sm",
                          errors && !!errors?.department_choices
                            ? "text-danger"
                            : ""
                        )}
                      >
                        2. What department is submitting this STRATEGIC
                        INITIATIVE?
                      </p>
                    }
                    errorMessage={errors?.department_choices?.message}
                    isInvalid={errors && !!errors?.department_choices}
                    {...field}
                    value={field.value}
                    onValueChange={field.onChange}
                  >
                    <div className="grid grid-cols-2 gap-2">
                      <Radio value="marketing">Marketing</Radio>
                      <Radio value="branch">Branch</Radio>
                      <Radio value="finance">Finance</Radio>
                      <Radio value="landing">Landing</Radio>
                      <Radio value="hr">HR</Radio>
                      <Radio value="organization">Organization</Radio>
                      <Radio value="engineering">Engineering</Radio>
                      <Radio value="other">Other</Radio>
                    </div>
                  </RadioGroup>
                )}
              />
            </div>

            <Controller
              name="start_date"
              control={control}
              render={({ field }) => (
                <Input
                  {...field}
                  variant="bordered"
                  labelPlacement="outside"
                  label="3. What date would you like this project to begin development?"
                  placeholder="mm/dd/yy"
                  type="date"
                  isInvalid={errors && !!errors?.start_date}
                  errorMessage={errors.start_date?.message}
                  helperColor="error"
                />
              )}
            />

            <Controller
              name="production_date"
              control={control}
              render={({ field }) => (
                <Input
                  {...field}
                  variant="bordered"
                  labelPlacement="outside"
                  label="4. What date would you like this project to be moved into production environments?"
                  placeholder="mm/dd/yy"
                  type="date"
                  errorMessage={errors.production_date?.message}
                  isInvalid={errors && !!errors?.production_date}
                  helperColor="error"
                />
              )}
            />
          </ModalBody>
          <ModalFooter>
            <Button color="danger" variant="light" onPress={onClose}>
              Cancel
            </Button>
            <Button color="primary" type="submit" isLoading={isMutating}>
              Save
            </Button>
          </ModalFooter>
        </ModalContent>
      </form>
    </Modal>
  );
}

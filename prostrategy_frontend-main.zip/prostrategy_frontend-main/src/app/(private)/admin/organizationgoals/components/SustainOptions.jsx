import { useState } from "react";
import { Button } from "@nextui-org/button";
import { Checkbox, CheckboxGroup } from "@nextui-org/checkbox";
import { PermissionWrapper } from "../../../../../components";
import { Input } from "@nextui-org/input";
import { DynamicObjectivesSchema } from "../../../../../../validationSchema/authValidation";

function SustainOptions({
  options,
  selectedValues,
  handleCheckboxChange,
  handleNext,
  isMutating,
  dynamic_objective1,
  dynamic_objective2,
  dynamic_objective3,
  dynamic_objective4,
  setDynamic_objective1,
  setDynamic_objective2,
  setDynamic_objective3,
  setDynamic_objective4,
  updateIsDirty
}) {
  const [error, setError] = useState({});

  const handleValueChange = (e) => {
    const { name, value } = e.target;
    updateIsDirty(true)
    if (name === "dynamic_objective1") {
      setDynamic_objective1((prevState) => ({
        ...prevState,
        value: value,
      }));
    } else if (name === "dynamic_objective2") {
      setDynamic_objective2((prevState) => ({
        ...prevState,
        value: value,
      }));
    } else if (name === "dynamic_objective3") {
      setDynamic_objective3((prevState) => ({
        ...prevState,
        value: value,
      }));
    } else if (name === "dynamic_objective4") {
      setDynamic_objective4((prevState) => ({
        ...prevState,
        value: value,
      }));
    }
    DynamicObjectivesSchema.validateAt(name, { [name]: value })
      .then(() => {

        setError((prevErrors) => ({
          ...prevErrors,
          [name]: "", // Set the error message for this field
        }));
      })
      .catch((err) => {
        setError((prevErrors) => ({
          ...prevErrors,
          [name]: err.message, // Set the error message for this field
        }));
      });
  };


  return (
    <div className="col-span-3 ">
      <div className="">
        <div className="flex justify-between gap-5">
          <p className="mb-6">
            Please review the following 15 key areas of your business. Choose 5
            to 9 that you believe are the most critical for ensuring your
            company's long-term success.
          </p>
          <PermissionWrapper
            resource={"org_sustaining_objectives"}
            actions={["edit"]}
          >
            <Button
              isLoading={isMutating}
              type="button"
              radius="sm"
              color="primary"
              className="px-8 bg-[#0098F5]"
              onClick={handleNext}
            //   disabled={selectedValues.length < 5 || selectedValues.length > 9}
            >
              Next
            </Button>
          </PermissionWrapper>
        </div>

        <CheckboxGroup
          orientation="horizontal"
          onChange={handleCheckboxChange}
          value={selectedValues.map((option) => option.id)}
        // className="grid grid-cols-2 gap-4"
        >
          <div className="grid grid-cols-2 gap-6 gap-x-32">
            {options
              .filter(
                (option) =>
                  option.id !== "dynamic_objective1" &&
                  option.id !== "dynamic_objective2" &&
                  option.id !== "dynamic_objective3" &&
                  option.id !== "dynamic_objective4"
              )
              .map((option) => (
                <Checkbox
                  key={option.id}
                  value={option.id}
                  className="flex items-center"
                >
                  {option.name}
                </Checkbox>
              ))}

            <div>
              <Input
                value={dynamic_objective1?.value}
                onChange={handleValueChange}
                name="dynamic_objective1"
                type="text"
                variant="bordered"
                placeholder="User key area"
                radius="sm"
                classNames={{
                  label: "text-black",
                  inputWrapper: [
                    "h-12",
                    "group-data-[focus=true]:border-[#0098F5]",
                    "dark:group-data-[focus=true]:border-[#0098F5]",
                  ],
                }}
                isInvalid={error && !!error?.dynamic_objective1}
              />
              {error?.dynamic_objective1 && (
                <span className="text-tiny text-danger">
                  {error.dynamic_objective1}
                </span>
              )}
            </div>
            <div></div>
            <div className="mb-2">
              <Input
                value={dynamic_objective2?.value}
                onChange={handleValueChange}
                name="dynamic_objective2"
                type="text"
                variant="bordered"
                placeholder="User key area"
                radius="sm"
                classNames={{
                  label: "text-black",
                  inputWrapper: [
                    "h-12",
                    "group-data-[focus=true]:border-[#0098F5]",
                    "dark:group-data-[focus=true]:border-[#0098F5]",
                  ],
                }}
                isInvalid={error && !!error?.dynamic_objective2}
              />
              {error?.dynamic_objective2 && (
                <span className="text-tiny text-danger">
                  {error.dynamic_objective2}
                </span>
              )}
            </div>
            <div></div>
            <div className="mb-2">
              <Input
                value={dynamic_objective3?.value}
                onChange={handleValueChange}
                name="dynamic_objective3"
                type="text"
                variant="bordered"
                placeholder="User key area"
                radius="sm"
                classNames={{
                  label: "text-black",
                  inputWrapper: [
                    "h-12",
                    "group-data-[focus=true]:border-[#0098F5]",
                    "dark:group-data-[focus=true]:border-[#0098F5]",
                  ],
                }}
                isInvalid={error && !!error?.dynamic_objective3}
              />
              {error?.dynamic_objective3 && (
                <span className="text-tiny text-danger">
                  {error.dynamic_objective3}
                </span>
              )}
            </div>
            <div></div>
            <div className="mb-2">
              <Input
                value={dynamic_objective4?.value}
                onChange={handleValueChange}
                name="dynamic_objective4"
                type="text"
                variant="bordered"
                placeholder="User key area"
                radius="sm"
                classNames={{
                  label: "text-black",
                  inputWrapper: [
                    "h-12",
                    "group-data-[focus=true]:border-[#0098F5]",
                    "dark:group-data-[focus=true]:border-[#0098F5]",
                  ],
                }}
                isInvalid={error && !!error?.dynamic_objective4}
              />
              {error?.dynamic_objective4 && (
                <span className="text-tiny text-danger">
                  {error.dynamic_objective4}
                </span>
              )}
            </div>
          </div>
        </CheckboxGroup>
      </div>
      <div className="flex w-full justify-end "></div>
    </div>
  );
}

export default SustainOptions;

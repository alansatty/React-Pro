import { Button } from "@nextui-org/button";
import { Card } from "@nextui-org/card";
import { IconCircleX, IconInfoCircle, IconReload } from "@tabler/icons-react";
import SlidingPane from "react-sliding-pane";
import "react-sliding-pane/dist/react-sliding-pane.css";
import toast from "react-hot-toast";
import { Skeleton } from "@nextui-org/skeleton";

function AiHelpSvaDrawer({
  drawerState,
  setDrawerState,
  title,
  criteriaDetails,
  getCriteriaWithlimitNumber,
  onSaveCriteria,
  getMoreCount,
  criterias,
  BELoading,
  selectedCriteria,
  setSelectedCriteria,
  handleIsDirty,
}) {
  const handleSelectCriteria = (criteria) => {
    if (selectedCriteria.includes(criteria)) {
      // Remove if already selected
      setSelectedCriteria(selectedCriteria.filter((item) => item !== criteria));
    } else if (selectedCriteria.length >= 7) {
      // Error if more than 7 criteria are selected
      toast.error("Only 7 criteria can be selected.");
    } else {
      // Add the new criteria
      setSelectedCriteria([...selectedCriteria, criteria]);
    }
  };

  const useSelectedCriteria = () => {
    if (selectedCriteria.length === 0) {
      toast.error(`Please select at least one criteria`);
      return;
    }

    if (selectedCriteria.length <= 7) {
      if (typeof handleIsDirty === "function") {
        handleIsDirty(true);
      }
      onSaveCriteria(selectedCriteria);
      setDrawerState(false);
    } else {
      toast.error("Please select only up to 7 criteria.");
      if (typeof handleIsDirty === "function") {
        handleIsDirty(false);
      }
    }
  };

  const handleGetMore = () => {
    if (getMoreCount < 2) {
      getCriteriaWithlimitNumber();
    } else {
      toast.error("Maximum focal points reached!");
    }
  };

  return (
    <div>
      <SlidingPane
        closeIcon={
          <div>
            <span className="text-xl">
              <IconCircleX color="#11181C" className="w-12 h-12" />
            </span>
          </div>
        }
        overlayClassName="z-50 "
        width="600px"
        isOpen={drawerState}
        title={title}
        onRequestClose={() => setDrawerState(false)}
      >
        <div>
          <h5 className="text-gray-600 p-1 font-semibold">
            Based on the Organization Name, Organization Type, Organization Description, Organization Business Targets, Web Address, Geographic Market Focus, Client Training, Organization SVA, Organization SVA Dashboard, and Organization Goals, here are the Organization's {criteriaDetails?.sva_option_label}.
          </h5>
          <div className="flex gap-2 items-start text-sm">
            <IconInfoCircle className="mb-1 h-7 w-7" />
            <p>
              You can generate up to 20 criteria and select 7 criteria from the
              list to create Organization's {criteriaDetails?.sva_option_label}.

            </p>
          </div>

          <div className="mt-4 grid grid-cols-1 gap-4 max-h-[calc(78vh-30vh)] overflow-auto p-2">
            {BELoading
              ? Array.from({ length: 4 }).map((_, index) => (
                <Card
                  key={index}
                  bordered
                  shadow="none"
                  radius="md"
                  className={`p-4 border-[#E2E9F0] bg-[#F4F7FA] border`}
                >
                  <Skeleton className="rounded-lg">
                    <div className="h-10 rounded-lg bg-default-300"></div>
                  </Skeleton>
                </Card>
              ))
              : criterias.map((criteria, index) => (
                <Card
                  bordered
                  key={index}
                  shadow="none"
                  isPressable
                  radius="sm"
                  className={`p-2 bg-[#F4F7FA] w-full border text-start min-h-12 flex justify-center ${selectedCriteria.includes(criteria)
                    ? "border-primary border-2"
                    : "border-[#E2E9F0]"
                    }`}
                  onClick={() => handleSelectCriteria(criteria)}
                >
                  {index + 1} : {criteria}
                </Card>
              ))}
          </div>

          <div className="flex justify-between mt-4">
            {getMoreCount < 2 ? (
              <Button
                radius="sm"
                variant="bordered"
                color="primary"
                startContent={!BELoading && <IconReload />}
                auto
                className="bg-white text-black"
                onClick={handleGetMore}
                isLoading={BELoading}
              >
                {BELoading ? "Getting" : "Get 5 more"}
              </Button>
            ) : (
              <div></div>
            )}

            <Button
              color="primary"
              radius="sm"
              className="capitalize"
              onClick={useSelectedCriteria}
              // disabled={selectedCriteria.length === 0}
              isLoading={BELoading}
            >
              Use Criteria
            </Button>
          </div>
        </div>
      </SlidingPane>
    </div>
  );
}

export default AiHelpSvaDrawer;

import { useEffect, useState } from "react";
import { Button } from "@nextui-org/button";
import { Textarea } from "@nextui-org/input";
import { Radio, RadioGroup } from "@nextui-org/radio";
import AiHelpIcon from "../../../../../assets/icons/aihelp-icon";
import { apiList } from "../../../../../services";
import useApi from "../../../../../hooks/useApi";
import { useAuth } from "../../../../../providers/authProviders";
import toast from "react-hot-toast";
import { MissionSchema } from "../../../../../../validationSchema/authValidation";
import { Card } from "@nextui-org/card";
import { IconInfoCircle } from "@tabler/icons-react";
import Swal from "sweetalert2/dist/sweetalert2.js";
import AiHelpDrawer from "./AiHelpDrawer";
import hasPermission from "../../../../../utils/hasPermission";
import { PageSpinner, PermissionWrapper } from "../../../../../components";
import { mutate } from "swr";
import HelpModal from "../../../../../components/Topbar/HelpModal";
import { OrganizationGoalsHelp } from "../../../../../components/Topbar/helpComponents/Helps";
import hasPlanPermission from "../../../../../utils/hasPlanPermission";
import { useNavigate } from "react-router-dom";
import usePermissionsStore from "../../../../../stores/usePermissionStore";
import CustomTooltip from "../../../../../components/CustomTooltip/CustomTooltip";
import ProstrategyLogo from "../../../../../assets/icons/ProstrategyLogo";
import withReactContent from "sweetalert2-react-content";
import UnsavedChangesModal from "../../../../../components/Alert/UnsavedChangesModal";
import useUnsavedChanges from "../../../../../hooks/useUnsavedChanges";
const MySwal = withReactContent(Swal);

function MissionTab() {
  const navigate = useNavigate();
  const [isDirty, setIsDirty] = useState(false);
  const [drawerStep, setDrawerStep] = useState(1);
  const [isOpen, setIsOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [isMissionStatement, setIsMissionStatement] = useState("");
  const [existingMission, setIsExistingMission] = useState("");
  const [fullBusinessEssentials, setFullBusinessEssentials] = useState([]); // Store business essentials data
  const [businessEssentialData, setBusinessEssentialData] = useState([]); // Store business essentials data
  const [mission, setMission] = useState("");
  const [savedMission, setSavedMission] = useState("");
  const [missionError, setMissionError] = useState(null); // Track validation errors for mission
  const [statements, setStatements] = useState([]);
  const [getMoreCount, setGetMoreCount] = useState(0);
  const [isEditable, setIsEditable] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('')
  const [selectedBusinessEssentials, setSelectedBusinessEssentials] = useState(
    []
  );
  const [customLoading, setCustomLoading] = useState(false);

  const auth = useAuth();
  const { showModal, confirmNavigation, cancelNavigation } =
    useUnsavedChanges(isDirty);

  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);

  const {
    data: currentPlanData,

  } = useApi(
    apiList.admin.subscription.current_plan.key(),
    apiList.admin.subscription.current_plan.call()
  );
  const toggleDrawer = () => {
    if (error === "To proceed, please update the business targets in the Settings menu") {
      MySwal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>
            <h2 className="text-xl font-semibold">Warning!</h2>
            <p className="mt-2">Please update the business targets to get AI Help.</p>
          </div>
        ),
        confirmButtonText: "Go to Business Targets",
        customClass: {
          confirmButton:
            "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
        },
      }).then((result) => {
        if (result.isConfirmed) {
          navigate("/organizationgoals/bussiness_target");
        }
      });
      return
    }
    if (getMoreCount == 0) useBusinessEssentials();
    if (fullBusinessEssentials?.length > 0 || BELoading) {

      setIsOpen((prev) => !prev);
    } else {
      // toast.error("Please update the Settings to get AI Help.");
      MySwal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>
            <h2 className="text-xl font-semibold">Warning!</h2>
            <p className="mt-2">Please update the Organization Profile to get AI Help.</p>
          </div>
        ),
        confirmButtonText: "Go to Settings",
        customClass: {
          confirmButton:
            "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
        },
      }).then((result) => {
        if (result.isConfirmed) {
          navigate("/settings/organization_tab"); // Navigate to the settings page
        }
      });
    }
  };

  useEffect(() => {
    if (selectedBusinessEssentials) {
    }
  }, [selectedBusinessEssentials]);


  const getBusinessEssentials = async () => {

    try {

      const bodyData = {
        organization_goal: "mission",
        strategic_plan_id: strategicPlan
        // businessEssentialData: businessEssentialData,
      };

      let response = await businessEssentials({ requestBody: bodyData });
      setFullBusinessEssentials(response?.data);
    } catch (error) {
      console.log("error ==>", error);
      if (error?.msg) {
        setError(error.msg)
      }
      // if (error?.status === 400 && error?.data?.message === "To proceed, please update the business targets in the Settings menu") {


      // }
    } finally {
      // setLoading(false)
    }
  };

  const useBusinessEssentials = () => {
    // Only load if more data is available and count is less than 3

    if (
      getMoreCount < 2 &&
      fullBusinessEssentials?.length > businessEssentialData?.length
    ) {
      const nextDataStart = getMoreCount == 0 ? getMoreCount : 15;
      const nextDataEnd = getMoreCount == 0 ? 15 : 20;

      // Append the next 4 items to the business essentials data
      setBusinessEssentialData((prevData) => [
        ...prevData,
        ...fullBusinessEssentials.slice(nextDataStart, nextDataEnd),
      ]);

      // Increment the count for more data loading
      setGetMoreCount(getMoreCount + 1);
    }
  };

  const { data: Goals, isLoading: loadingState } = useApi(
    apiList.admin.organizationGoals.get_goals.key(auth?.user?.organization_id),
    strategicPlan ? apiList.admin.organizationGoals.get_goals.call(strategicPlan) : null
  );


  useEffect(() => {
    setMission(Goals?.data?.mission);
    setSavedMission(Goals?.data?.mission);
    getBusinessEssentials();
    if (Goals?.data?.mission && Goals?.data?.mission !== "") {
      setEditMode(true);
    } else {
      setEditMode(false);
    }
  }, [Goals]);

  const mutateFn = async () => {
    setCustomLoading(true);
    await mutate(
      apiList.admin.organizationGoals.get_goals.key(auth?.user?.organization_id)
    );
    setCustomLoading(false);
  };

  useEffect(() => {
    mutateFn();
  }, [strategicPlan]);

  const { trigger, isMutating } = useApi(
    null,
    apiList.admin.organizationGoals.create_mission.call(),
    { method: "POST" }
  );

  const { trigger: businessEssentials, isMutating: BELoading } = useApi(
    null,
    apiList.admin.organizationGoals.business_essentials.call(),
    { method: "POST" }
  );

  useEffect(() => {
    if (!loadingState) {
      setLoading(false);
    }
    if (!BELoading) {
      if (getMoreCount == 0) useBusinessEssentials();
    }
  }, [loadingState, BELoading]);

  // Real-time validation on input change
  const handleMissionChange = async (e) => {
    setIsDirty(true);
    const value = e.target.value;
    setMission(value);
    validateMission(value);
  };

  const validateMission = async (value) => {
    try {
      await MissionSchema.validate({ mission: value });
      setMissionError(null); // Clear errors if validation passes
    } catch (error) {
      setMissionError(error.message); // Set validation error
    }
  };

  const onSubmit = async (e) => {
    e.preventDefault();

    // Validate the mission statement using Yup
    try {
      await MissionSchema.validate({ mission });
      setMissionError(""); // Clear errors if validation passes

      const bodyData = {
        content: mission,
        organization: auth?.user?.organization_id,
        strategic_plan_id: strategicPlan,
      };

      let response = await trigger({ requestBody: bodyData });
      // toast.success(response?.data);

      setIsDirty(false);
      mutate(
        apiList.admin.organizationGoals.get_goals.key(
          auth?.user?.organization_id
        )
      );

      MySwal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20">
              <ProstrategyLogo />
            </div>
            <h2 className="text-xl font-semibold ">Success!</h2>
            <p className="mt-2">{response?.data}</p>
          </div>
        ),

        showConfirmButton: true,
        confirmButtonText: "Okay",
        customClass: {
          confirmButton: "my-confirm-button",
        },
      });

      setEditMode(!editMode);
    } catch (error) {
      setMissionError(error?.message); // Set the validation error message
      if (!isMissionStatement || !existingMission) {
        if (error?.message) {
          toast.error(error?.message);
        }
      }
      if (error?.data) {
        if (error?.data?.message) {
          toast.error(error?.data?.message);
        }
      }
    }
  };

  const changeEditMode = () => {
    setIsExistingMission("yes");
    setIsMissionStatement("yes");
    setEditMode(!editMode);
  };

  if (loadingState || loading || customLoading) {
    return <PageSpinner />;
  }

  const renderContent = () => {
    if (
      !hasPermission("org_mission", "read_only") &&
      !hasPermission("org_mission", "edit")
    ) {
      return <div>Mission Not Available for the Organization</div>;
    }

    if (
      hasPermission("org_mission", "read_only") &&
      !hasPermission("org_mission", "edit")
    ) {
      if (!editMode) {
        return <div>Mission Not Available for the Organization</div>;
      }
    }

    if (editMode) {
      return (
        <div className={`my-2 mb-4 w-[80%]`}>
          <h5 className="text-gray-600 p-1">Mission</h5>

          <Card
            bordered
            shadow="none"
            radius="md"
            className={`p-2 bg-[#F4F7FA] border text-start   border-[#E2E9F0]`}
          >
            {mission}
          </Card>
          <PermissionWrapper resource={"org_mission"} actions={["edit"]}>
            <span
              className="mt-2 text-default-500 float-end cursor-pointer"
              onClick={changeEditMode}
            >
              Edit
            </span>
          </PermissionWrapper>
        </div>
      );
    }

    const handleFullStatementChange = (index, value) => {
      const updatedStatements = [...statements];
      updatedStatements[index] = value;
      setStatements(updatedStatements);
    };

    // Runs whenever 'isEditable' changes

    const handleIsDirty = (dirty) => {
      setIsDirty(dirty);
    };
    return (
      <div>
        <form onSubmit={onSubmit} noValidate>
          {showModal && (
            <UnsavedChangesModal
              isCancelNavigation={cancelNavigation}
              isConfirmNavigation={confirmNavigation}
            />
          )}
          <div className="flex">
            <div className="flex justify-between gap-5">
              <div className="flex gap-2 p-1 px-2 w-fit mb-5">
                <span>
                  <IconInfoCircle />
                </span>

                <p>
                  The Organization Goals section, specifically under the Mission
                  tab in ProStrategy.ai, allows you to review or update your
                  Organization's mission statement. Here’s how to interact with
                  this form
                  <HelpModal
                    title={"Organization Goals Mission Help"}
                    ContentComponent={OrganizationGoalsHelp}
                    isReadMore={true}
                  />
                </p>
              </div>
              <PermissionWrapper resource={"org_mission"} actions={["edit"]}>
                <Button
                  type="submit"
                  radius="sm"
                  color="primary"
                  className="mb-2 bg-[#0098F5]"
                  isLoading={isMutating}
                >
                  Save Changes
                </Button>
              </PermissionWrapper>
            </div>
          </div>

          <div>
            <div className="flex justify-between">
              <p className="mb-6">
                Does your Company currently have a mission statement?
              </p>
            </div>
            <RadioGroup
              className="mb-5"
              orientation="horizontal"
              value={isMissionStatement}
              onValueChange={(value) => {
                setIsMissionStatement(value);
                if (value == "no") {
                  setMission("");
                }
                if (
                  existingMission === "yes" &&
                  value == "yes" &&
                  savedMission
                ) {
                  setMission(savedMission);
                  validateMission(savedMission);
                }
              }}
            >
              <Radio value="yes">Yes</Radio>
              <Radio value="no">No</Radio>
            </RadioGroup>
          </div>

          {isMissionStatement === "yes" && (
            <div>
              <p className="mb-6">
                Do you want to continue with the existing mission or create a
                new one?
              </p>
              <RadioGroup
                className="mb-5"
                orientation="horizontal"
                value={existingMission}
                onValueChange={(value) => {
                  setIsExistingMission(value);
                  if (value == "no") {
                    setMission("");
                    if (hasPlanPermission("org_base_goals_with_pillars_ai")) {
                      toggleDrawer();
                    } else {
                      currentPlanData?.data?.plan_name == "Enterprise"
                        ? toast.error(
                          "Your current plan has limited features. Please Contact Admin"
                        )
                        : toast.error(
                          "Your current plan has limited features. Upgrade now to access more!"
                        );
                    }
                  }
                  if (
                    isMissionStatement === "yes" &&
                    value == "yes" &&
                    savedMission
                  ) {
                    setMission(savedMission);
                    validateMission(savedMission);
                  }
                }}
              >
                <Radio value="yes">Use Existing One</Radio>
                <Radio value="no">
                  Use AI to help create new mission statement
                </Radio>
              </RadioGroup>
            </div>
          )}

          {(existingMission === "no" || isMissionStatement === "no") && (
            <div className="flex gap-2 items-center text-sm bg-slate-200 rounded-[8px] p-1 px-2 w-fit">
              <IconInfoCircle className="mb-[1px] h-5 w-5" />
              Click the{`"AI Help"`} button on the right side to generate a
              mission statement using AI or type manually.
            </div>
          )}

          {(isMissionStatement === "no" ||
            existingMission === "no" ||
            existingMission === "yes") && (
              <div>
                <Textarea
                  label={
                    <div className="flex items-end justify-between mt-2">
                      <label htmlFor="missionStatement">
                        Mission Statement{" "}
                        <span className="text-red-600 text-base ml-1">*</span>
                      </label>
                      {(existingMission === "no" ||
                        isMissionStatement === "no") &&
                        (hasPlanPermission("org_base_goals_with_pillars_ai") ? (
                          <Button
                            radius="sm"
                            color="primary"
                            className="mt-0 bg-[#39465F]"
                            onClick={toggleDrawer}
                          >
                            <AiHelpIcon />
                            AI Help
                          </Button>
                        ) : (
                          <CustomTooltip
                            tooltipTitle="Upgrade Plan"
                            tooltipContent={
                              currentPlanData?.data?.plan_name == "Enterprise"
                                ? "Your current plan has limited features. Please Contact Admin"
                                : "Your current plan has limited features. Upgrade now to access more!"
                            }
                            buttonText={
                              currentPlanData?.data?.plan_name == "Enterprise"
                                ? null
                                : "Go to Plans"
                            }
                            navigateTo="/settings/account_tab" // The route to navigate
                          />
                        ))}
                    </div>
                  }
                  labelPlacement="outside"
                  placeholder="Enter your mission statement"
                  variant="bordered"
                  radius="sm"
                  value={mission}
                  onChange={handleMissionChange} // Real-time validation on change
                  isInvalid={missionError ? true : false}
                  errorMessage={missionError}
                  classNames={{
                    input: "min-h-[150px]",
                    label: "mb-2",
                    inputWrapper: [
                      "group-data-[focus=true]:border-[#0098F5]",
                      "dark:group-data-[focus=true]:border-[#0098F5]",
                    ],
                  }}
                />
              </div>
            )}
        </form>

        <AiHelpDrawer
          drawerState={isOpen}
          setDrawerState={setIsOpen}
          title={
            <span className="font-semibold">
              AI Help -{" "}
              <span className="text-[#0098F5]">Create Mission Statement</span>
            </span>
          }
          businessEssentialData={businessEssentialData}
          getBusinessEssentials={useBusinessEssentials}
          setValue={setMission}
          validate={validateMission}
          type={"Mission"}
          setDrawerOpen={setIsOpen}
          BELoading={BELoading}
          step={drawerStep}
          setStep={setDrawerStep}
          fullStatements={statements}
          setFullStatements={setStatements}
          getMoreCount={getMoreCount}
          selectedBusinessEssentials={selectedBusinessEssentials}
          setSelectedBusinessEssentials={setSelectedBusinessEssentials}
          isEditable={isEditable}
          setIsEditable={setIsEditable}
          handleFullStatementChange={handleFullStatementChange}
          handleIsDirty={handleIsDirty}
        />
      </div>
    );
  };

  return <>{renderContent()}</>;
}

export default MissionTab;

import { useState, useEffect } from "react";
import { Button } from "@nextui-org/button";
import { Textarea } from "@nextui-org/input";
import hasPlanPermission from "../../../../../utils/hasPlanPermission";
import AiHelpIcon from "../../../../../assets/icons/aihelp-icon";
import CustomTooltip from "../../../../../components/CustomTooltip/CustomTooltip";
import useApi from "../../../../../hooks/useApi";
import { apiList } from "../../../../../services";
import { IconPlus, IconTrash } from "@tabler/icons-react";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { Controller, useForm } from "react-hook-form";
import toast from "react-hot-toast";
import { Card } from "@nextui-org/card";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2/dist/sweetalert2.js";
import { PermissionWrapper } from "../../../../../components";
import hasPermission from "../../../../../utils/hasPermission";
import AiHelpGoalsDrawer from "./goalsDrawer";
import withReactContent from "sweetalert2-react-content";
import ProstrategyLogo from "../../../../../assets/icons/ProstrategyLogo";
import useUnsavedChanges from "../../../../../hooks/useUnsavedChanges";
import UnsavedChangesModal from "../../../../../components/Alert/UnsavedChangesModal";

const MySwal = withReactContent(Swal);

const schema = yup.object({
  goals: yup.array().of(
    yup
      .string()
      .test(
        "min-length-or-empty",
        "Goals needs at least 4 characters",
        (value) => !value || value.trim().length >= 4 // Allow empty values or enforce minimum length
      )
      .max(1054, "Goals max characters are 1054")
  ),
});

function GoalForm({
  goals,
  handleSave,
  AIError,
  fullAIResponse,
  AILoading,
  isMutating,
  isEditing,
  setIsEditing,
  addNewGoal,
  setGoals,
}) {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [AIUsedCount, setAIUsedCount] = useState(0);
  const [AIGoalData, setAIGoalData] = useState([]);
  const [selectedGoal, setSelectedGoal] = useState([]);
  const [aiDirty, setAiIsDirty] = useState(false);
  const [isFormDirty, setIsFormDirty] = useState(false);

  const navigate = useNavigate();

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    defaultValues: {
      goals: goals.map((goal) =>
        typeof goal === "string" ? goal : goal.value
      ),
    },
    resolver: yupResolver(schema),
    mode: "onChange",
  });

  useEffect(() => {
    reset({
      goals: goals.map((goal) =>
        typeof goal === "string" ? goal : goal.value
      ),
    });
  }, [goals, reset]);

  const { showModal, confirmNavigation, cancelNavigation } =
    useUnsavedChanges(isFormDirty);

  const onSubmit = async (data) => {
    const nonEmptyGoals = data.goals.filter(
      (goal) => goal && goal.trim().length > 0
    );

    if (nonEmptyGoals.length === 0) {
      toast.error("At least one goal must be provided!");
      return;
    }

    const transformGoals = (goals, formData) => {
      return goals
        .map((goal, index) => {
          const formValue = formData[index]?.trim() || "";

          if (goal.id) {
            return { [goal.id]: formValue };
          }

          return formValue ? formValue : null;
        })
        .filter((goal) => goal !== null);
    };

    const transformedGoals = transformGoals(goals, data.goals);

    handleSave(transformedGoals);
    setIsFormDirty(false);
  };

  const toggleDrawer = () => {

    if (AIError) {

      MySwal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>
            <h2 className="text-xl font-semibold">Warning!</h2>
            <p className="mt-2">{`Please update the ${AIError} Form to get AI Help.`}</p>
          </div>
        ),
        confirmButtonText: `Go to ${AIError} Form`,
        customClass: {
          confirmButton:
            "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
        },
      }).then((result) => {
        if (result.isConfirmed) {
          if (AIError === "SVA") {
            navigate("/organizationgoals/svaform");
          } else {
            navigate("/organizationgoals/swot_tab");
          }
        }
      });
    } else {
      if (AIUsedCount == 0) getGoalsWithlimitNumber();
      if (fullAIResponse.length > 0 || AILoading) {
        setDrawerOpen((prev) => !prev);
      }
    }
  };

  const getGoalsWithlimitNumber = () => {
    // Only load if more data is available and count is less than 3
    if (AIUsedCount < 2 && fullAIResponse?.length > AIGoalData.length) {
      // Slice the AI response into chunks of 4 based on AIUsedCount
      const nextDataStart = AIUsedCount == 0 ? AIUsedCount : 15;
      const nextDataEnd = AIUsedCount == 0 ? 15 : 20;

      setAIGoalData((prevData) => [
        ...prevData,
        ...fullAIResponse.slice(nextDataStart, nextDataEnd),
      ]);

      setAIUsedCount(AIUsedCount + 1);
    } else {
      // toast.error("You have reached the maximum limit for AI help.");
    }
  };

  useEffect(() => {
    if (!AILoading) {
      if (AIUsedCount == 0) getGoalsWithlimitNumber();
    }
  }, [AILoading]);

  useEffect(() => {
    if (aiDirty) {
      setIsFormDirty(aiDirty);
    }
  }, [aiDirty]);

  const handleSaveGoals = (selectedGoals) => {
    setGoals((prevGoals) => {
      return selectedGoals
        .map((goalValue, index) => {
          if (index < prevGoals.length) {
            // Update existing goal value, keeping the same ID
            return { ...prevGoals[index], value: goalValue };
          } else {
            // Add new goal if the index exceeds prevGoals length
            return { id: null, value: goalValue };
          }
        })
        .concat(prevGoals.slice(selectedGoals.length)); // Keep remaining goals unchanged
    });
  };

  const handleIsDirty = (dirty) => {
    setAiIsDirty(dirty);
  };

  const CardView = () => {
    return (
      <div>
        <PermissionWrapper resource={"org_strategic_goals"} actions={["edit"]}>
          <div className="flex justify-end">
            <Button
              className="mt-6"
              onClick={() => setIsEditing(true)}
              color="primary"
            >
              Edit
            </Button>
          </div>
        </PermissionWrapper>
        <div className="flex flex-col gap-3">
          {goals?.map(
            (goal, index) =>
              goal?.value &&
              goal?.value?.trim() !== "" && (
                <div key={index}>
                  <label className="text-sm text-gray-600">
                    Goal {index + 1}
                  </label>
                  <br />
                  <Card
                    bordered
                    shadow="none"
                    radius="sm"
                    className="p-2 bg-[#F4F7FA] border text-start border-[#E2E9F0]"
                  >
                    {goal?.value}
                  </Card>
                </div>
              )
          )}
        </div>
      </div>
    );
  };

  const {
    data: currentPlanData,
  } = useApi(
    apiList.admin.subscription.current_plan.key(),
    apiList.admin.subscription.current_plan.call()
  );

  const removeGoal = (goalIndex) => {
    setGoals((prevGoals) =>
      prevGoals.filter((_, index) => index !== goalIndex)
    );
  };

  if (hasPermission("org_strategic_goals", "read_only") && isEditing) {
    return <>Goals Not Available for This Organization</>;
  }

  return !isEditing ? (
    CardView()
  ) : (
    <>
      {showModal && (
        <UnsavedChangesModal
          isConfirmNavigation={confirmNavigation}
          isCancelNavigation={cancelNavigation}
        />
      )}
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6 p-4">
        <div className={`flex ${goals.length < 10 ? "justify-between" : "justify-end"} items-center`}>
          {goals.length < 10 && (
            <Button
              size="sm"
              onClick={addNewGoal}
              type="button"
              color="primary"
              radius="sm"
              className="mt-4 w-fit p-2 px-5"
            >
              <IconPlus size={15} />
              <div>Add New Goal</div>
            </Button>
          )}
          <div className="flex gap-5">
            <Button
              type="submit"
              color="primary"
              radius="sm"
              isLoading={isMutating}
            >
              Save Changes
            </Button>
            {hasPlanPermission("org_sva_swot_goals_ai") ? (
              <Button
                radius="sm"
                color="primary"
                className="mt-0 bg-[#39465F]"
                onPress={() => toggleDrawer()}
              >
                <AiHelpIcon />
                AI Help
              </Button>
            ) : (
              <CustomTooltip
                tooltipTitle="Upgrade Plan"
                tooltipContent={
                  currentPlanData?.data?.plan_name === "Enterprise"
                    ? "Your current plan has limited features. Please Contact Admin"
                    : "Your current plan has limited features. Upgrade now to access more!"
                }
                buttonText={
                  currentPlanData?.data?.plan_name === "Enterprise"
                    ? null
                    : "Go to Plans"
                }
                navigateTo="/settings/account_tab"
              />
            )}
          </div>
        </div>

        {goals.map((goal, index) => (
          <div key={index}>
            <Controller
              name={`goals[${index}]`}
              control={control}
              render={({ field }) => (
                <Textarea
                  {...field}
                  label={
                    <div className="flex justify-between items-start w-full">
                      <label htmlFor={`goals[${index}]`}>
                        Goals {index + 1}
                      </label>
                      <button
                        type="button"
                        disabled={goals.length == 1}
                        onClick={() => removeGoal(index)}
                        className={`${goals.length == 1 ? "text-danger-100" : "text-danger-500"}`}
                      >
                        <IconTrash />
                      </button>
                    </div>
                  }
                  labelPlacement="outside"
                  placeholder="Enter Goal here..."
                  className="w-full"
                  radius="sm"
                  variant="bordered"
                  errorMessage={errors?.goals?.[index]?.message}
                  isInvalid={!!errors?.goals?.[index]}
                  onChange={(e) => {
                    const newValue = e.target.value;
                    field.onChange(newValue);
                    setIsFormDirty(true);
                    // Update form state
                    setGoals((prevGoals) =>
                      prevGoals.map((g, i) =>
                        i === index ? { ...g, value: newValue } : g
                      )
                    );
                  }}
                  classNames={{
                    inputWrapper: [
                      "group-data-[focus=true]:border-[#0098F5]",
                      "dark:group-data-[focus=true]:border-[#0098F5]",
                    ],
                  }}
                />
              )}
            />
          </div>
        ))}
      </form >

      <AiHelpGoalsDrawer
        drawerState={drawerOpen}
        setDrawerState={setDrawerOpen}
        title={
          <span className="font-semibold">
            AI Help - <span className="text-[#0098F5]">Create Goals</span>
          </span>
        }
        getGoalsWithlimitNumber={getGoalsWithlimitNumber}
        onSaveGoals={handleSaveGoals}
        AIGoalData={AIGoalData}
        AIUsedCount={AIUsedCount}
        AILoading={AILoading}
        selectedGoal={selectedGoal}
        setSelectedGoal={setSelectedGoal}
        handleIsDirty={handleIsDirty}
      />
    </>
  );
}

export default GoalForm;

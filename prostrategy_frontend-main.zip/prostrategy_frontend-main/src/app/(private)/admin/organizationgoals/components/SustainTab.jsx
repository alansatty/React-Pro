import { useEffect, useState } from "react";
import useApi from "../../../../../hooks/useApi";
import { apiList } from "../../../../../services";
import toast from "react-hot-toast";
import SustainOptions from "./SustainOptions";
import SustainObjectives from "./SustainObjectives";
import hasPermission from "../../../../../utils/hasPermission";
import { Spinner } from "@nextui-org/spinner";
import { useAuth } from "../../../../../providers/authProviders";
import { mutate } from "swr";
import usePermissionsStore from "../../../../../stores/usePermissionStore";
import UnsavedChangesModal from "../../../../../components/Alert/UnsavedChangesModal";
import useUnsavedChanges from "../../../../../hooks/useUnsavedChanges";

function SustainTab() {
  const [selectedValues, setSelectedValues] = useState([]);
  const [currentStep, setCurrentStep] = useState(1);
  const [activeItem, setActiveItem] = useState(null);
  const [objectives, setObjectives] = useState({});
  const [options, setOptions] = useState([]);
  const [loading, setLoading] = useState(true);

  const [dynamic_objective1, setDynamic_objective1] = useState({
    id: "",
    value: "",
  });

  const [dynamic_objective2, setDynamic_objective2] = useState({
    id: "",
    value: "",
  });

  const [dynamic_objective3, setDynamic_objective3] = useState({
    id: "",
    value: "",
  });


  const [dynamic_objective4, setDynamic_objective4] = useState({
    id: "",
    value: "",
  });


  const [customLoading, setCustomLoading] = useState(false)
  const [isDirty, setIsDirty] = useState(false)

  const {
    showModal: showRouteChangeModal,
    confirmNavigation,
    cancelNavigation
  } = useUnsavedChanges(isDirty);

  const auth = useAuth();
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);

  const { data: SustainingOptions, isLoading: isLoadingOptions } = useApi(
    strategicPlan ? apiList.admin.organizationGoals.sutaining_options.key : null,
    strategicPlan ? apiList.admin.organizationGoals.sutaining_options.call(strategicPlan) : null
  );

  const { data: SavedSustainingOptions, isLoading: isLoadingSavedOptions } =
    useApi(
      apiList.admin.organizationGoals.saved_sutaining_options.key(
        auth?.user?.organization_id
      ),
      apiList.admin.organizationGoals.saved_sutaining_options.call(
        strategicPlan
      )
    );

  const { data: SustainingDetails, isLoading: loadingState } = useApi(
    apiList.admin.organizationGoals.sustaining_objective_details,
    apiList.admin.organizationGoals.sustaining_objective_details.call(
      strategicPlan
    )
  );


  const { trigger, isMutating } = useApi(
    null,
    apiList.admin.organizationGoals.update_sustaining_options.call(),
    { method: "POST" }
  );

  useEffect(() => {
    if (SustainingOptions?.data && SustainingOptions?.data.length > 0) {
      const mappedOptions = SustainingOptions.data.map((optionObj) => {
        const [id, name] = Object.entries(optionObj)[0];
        return { id, name };
      });
      setOptions(mappedOptions);
    }
  }, [SustainingOptions]);

  useEffect(() => {
    if (!isLoadingSavedOptions) {
      setLoading(false);
    }
  }, [isLoadingSavedOptions]);

  useEffect(() => {
    if (
      SavedSustainingOptions?.data &&
      SavedSustainingOptions?.data.length > 0
    ) {
      const parsedSavedOptions = SavedSustainingOptions.data.map((savedObj) => {
        const [id, name] = Object.entries(savedObj)[0];

        if (id === "dynamic_objective" && typeof name === "object") {
          Object.entries(name).map(([dynamicId, dynamicValue]) => {
            return { id: dynamicId, name: dynamicValue };
          });
        }

        return { id, name };
      });


      parsedSavedOptions.forEach((option) => {
        if (
          option.id === "dynamic_objective" &&
          typeof option.name === "object"
        ) {
          const dynamicEntries = Object.entries(option.name);

          // Set the first dynamic objective with id and value
          if (dynamicEntries[0]) {
            setDynamic_objective1({
              id: dynamicEntries[0][0], // Use the first entry's key as id
              value: dynamicEntries[0][1], // Use the first entry's value as value
            });
          } else {
            setDynamic_objective1({
              id: "", // Use the first entry's key as id
              value: "", // Use the first entry's value as value
            });
          }

          // Set the second dynamic objective with id and value
          if (dynamicEntries[1]) {
            setDynamic_objective2({
              id: dynamicEntries[1][0], // Use the second entry's key as id
              value: dynamicEntries[1][1], // Use the second entry's value as value
            });
          } else {
            setDynamic_objective2({ id: "", value: "" });
          }

          if (dynamicEntries[2]) {
            setDynamic_objective3({
              id: dynamicEntries[2][0], // Use the second entry's key as id
              value: dynamicEntries[2][1], // Use the second entry's value as value
            });
          } else {
            setDynamic_objective3({ id: "", value: "" });
          }

          if (dynamicEntries[3]) {
            setDynamic_objective4({
              id: dynamicEntries[3][0], // Use the second entry's key as id
              value: dynamicEntries[3][1], // Use the second entry's value as value
            });
          } else {
            setDynamic_objective4({ id: "", value: "" });
          }
        }
      });

      setActiveItem(parsedSavedOptions[0]);
      setSelectedValues(parsedSavedOptions);
      setCurrentStep(2);
    } else {
      setCurrentStep(1);
      setActiveItem(null);
      setSelectedValues([]);
      setDynamic_objective1({ id: "", value: "" });
      setDynamic_objective2({ id: "", value: "" });
      setDynamic_objective3({ id: "", value: "" });
      setDynamic_objective4({ id: "", value: "" });
    }
  }, [SavedSustainingOptions]);

  const mutateFn = async () => {
    setCustomLoading(true);
    await mutate(
      apiList.admin.organizationGoals.saved_sutaining_options.key(
        auth?.user?.organization_id
      )
    );
    setCustomLoading(false);
  };

  useEffect(() => {
    mutateFn();
  }, [strategicPlan]);

  const handleUpdateIsDirty = (dirty) => {
    setIsDirty(dirty)
  }

  const handleCheckboxChange = (values) => {
    const selectedOptions = options?.filter((option) =>
      values?.includes(option?.id)
    );
    setSelectedValues(selectedOptions);
    setIsDirty(true)

    if (!selectedOptions.find((option) => option.id === activeItem?.id)) {
      setActiveItem(null);
    }
  };

  const handleNext = async () => {
    const filteredSelectedValues = selectedValues.filter(
      (objective) => objective.id !== "dynamic_objective"
    );

    const totalSelectedCount =
      filteredSelectedValues.length +
      (dynamic_objective1.value.trim().length !== 0 ? 1 : 0) +
      (dynamic_objective2.value.trim().length !== 0 ? 1 : 0) +
      (dynamic_objective3.value.trim().length !== 0 ? 1 : 0) +
      (dynamic_objective4.value.trim().length !== 0 ? 1 : 0);

    // Check if the total count meets the range condition (5 to 9)
    if (totalSelectedCount >= 5 && totalSelectedCount <= 9) {
      try {
        // const data = selectedValues.reduce((acc, item, index) => {
        //   acc[`sus_objectives[${index}]`] = item.id;
        //   return acc;
        // }, {});
        const data = selectedValues
          .filter((option) => option.id !== "dynamic_objective")
          .map((item) => item.id);

        await trigger({
          requestBody: {
            sus_objectives: data,
            strategic_plan_id: strategicPlan,
            dynamic_objective1:
              dynamic_objective1.value.trim().length !== 0
                ? dynamic_objective1.value
                : "",
            dynamic_objective2:
              dynamic_objective2.value.trim().length !== 0
                ? dynamic_objective2.value
                : "",
            dynamic_objective3:
              dynamic_objective3.value.trim().length !== 0
                ? dynamic_objective3.value
                : "",
            dynamic_objective4:
              dynamic_objective4.value.trim().length !== 0
                ? dynamic_objective4.value
                : "",
          },
        });
        setCurrentStep(2);
        setActiveItem(selectedValues[0]);

        mutate(
          apiList.admin.organizationGoals.saved_sutaining_options.key(
            auth?.user?.organization_id
          )
        );
      } catch (error) {
        console.error(error);
        toast.error("Something Went Wrong. Please Try Again.");
      }
    } else {
      // toast.error("Please Select 5 to 9 Values")
      toast.error(
        "Please select a total of 5 to 9 values, including dynamic pillars."
      );
    }
  };

  const handlePrevious = () => {
    setCurrentStep(1);
  };

  const handleSave = (newObjectives) => {
    setObjectives(newObjectives);

  };
  const activeDetails = SustainingDetails?.data?.find(
    (detail) => detail.id === activeItem?.id
  );

  const isLoading =
    isLoadingOptions || isLoadingSavedOptions || loadingState || loading;

  if (isLoading || customLoading) {
    return <Spinner />;
  }

  if (
    !hasPermission("org_sustaining_objectives", "read_only") &&
    !hasPermission("org_sustaining_objectives", "edit")
  ) {
    return <div>Organization Pillars Not Available for the Organization</div>;
  }

  if (
    hasPermission("org_sustaining_objectives", "read_only") &&
    !hasPermission("org_sustaining_objectives", "edit")
  ) {
    if (SustainingDetails?.data.length == 0) {
      return (
        <div>Organization Pillars Not Available for the Organization</div>
      );
    }
  }


  return (
    <div className="grid grid-cols-3 gap-4">
      {showRouteChangeModal && (
        <UnsavedChangesModal
          isConfirmNavigation={confirmNavigation}
          isCancelNavigation={cancelNavigation}
        />
      )}

      {currentStep === 1 && (
        <SustainOptions
          options={options}
          selectedValues={selectedValues}
          handleCheckboxChange={handleCheckboxChange}
          handleNext={handleNext}
          isMutating={isMutating}
          dynamic_objective1={dynamic_objective1}
          dynamic_objective2={dynamic_objective2}
          dynamic_objective3={dynamic_objective3}
          dynamic_objective4={dynamic_objective4}
          setDynamic_objective1={setDynamic_objective1}
          setDynamic_objective2={setDynamic_objective2}
          setDynamic_objective3={setDynamic_objective3}
          setDynamic_objective4={setDynamic_objective4}
          updateIsDirty={handleUpdateIsDirty}
        />
      )}

      {currentStep === 2 && (
        <SustainObjectives
          selectedValues={selectedValues}
          activeItem={activeItem}
          details={activeDetails}
          setActiveItem={setActiveItem}
          objectives={objectives}
          handleSaveLocal={handleSave}
          handlePrevious={handlePrevious}
          loadingState={loadingState}

        />
      )}
    </div>
  );
}

export default SustainTab;

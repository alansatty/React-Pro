import { Button } from "@nextui-org/button";
import { Textarea } from "@nextui-org/input";
import { Radio, RadioGroup } from "@nextui-org/radio";
import { useEffect, useState } from "react";
import AiHelpIcon from "../../../../../assets/icons/aihelp-icon";
import { VisionSchema } from "../../../../../../validationSchema/authValidation";
import useApi from "../../../../../hooks/useApi";
import { apiList } from "../../../../../services";
import { useAuth } from "../../../../../providers/authProviders";
import toast from "react-hot-toast";
import { Card } from "@nextui-org/card";
import { IconInfoCircle } from "@tabler/icons-react";
import AiHelpDrawer from "./AiHelpDrawer";
import Swal from "sweetalert2/dist/sweetalert2.js";
import hasPermission from "../../../../../utils/hasPermission";
import { PageSpinner, PermissionWrapper } from "../../../../../components";
import { mutate } from "swr";
import HelpModal from "../../../../../components/Topbar/HelpModal";
import { OrganizationVisionHelp } from "../../../../../components/Topbar/helpComponents/Helps";
import hasPlanPermission from "../../../../../utils/hasPlanPermission";
import usePermissionsStore from "../../../../../stores/usePermissionStore";
import { useNavigate } from "react-router-dom";
import CustomTooltip from "../../../../../components/CustomTooltip/CustomTooltip";
import withReactContent from "sweetalert2-react-content";
import ProstrategyLogo from "../../../../../assets/icons/ProstrategyLogo";
import useUnsavedChanges from "../../../../../hooks/useUnsavedChanges";
import UnsavedChangesModal from "../../../../../components/Alert/UnsavedChangesModal";
const MySwal = withReactContent(Swal);

function VisionTab() {
  const navigate = useNavigate();
  const [isDirty, setIsDirty] = useState(false);
  const [drawerStep, setDrawerStep] = useState(1);
  const [statements, setStatements] = useState([]);
  const [error, setError] = useState('')
  const [isOpen, setIsOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [isVisionStatement, setIsVisionStatement] = useState("");
  const [existingVision, setIsExistingVision] = useState("");
  const [fullBusinessEssentials, setFullBusinessEssentials] = useState([]); // Store business essentials data
  const [businessEssentialData, setBusinessEssentialData] = useState([]); // Store business essentials data
  const [vision, setVision] = useState("");
  const [savedVision, setSavedVision] = useState("");
  const [VisionError, setVisionError] = useState(null); // Track validation errors for mission
  const [getMoreCount, setGetMoreCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [selectedBusinessEssentials, setSelectedBusinessEssentials] = useState(
    []
  );

  const {
    data: currentPlanData,
  } = useApi(
    apiList.admin.subscription.current_plan.key(),
    apiList.admin.subscription.current_plan.call()
  );
  const [isEditable, setIsEditable] = useState(null);
  const [customLoading, setCustomLoading] = useState(false);

  const auth = useAuth();
  const { showModal, confirmNavigation, cancelNavigation } =
    useUnsavedChanges(isDirty);
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);

  const toggleDrawer = () => {
    if (error === "To proceed, please update the business targets in the Settings menu") {
      MySwal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>
            <h2 className="text-xl font-semibold">Warning!</h2>
            <p className="mt-2">Please update the business targets to get AI Help.</p>
          </div>
        ),
        confirmButtonText: "Go to Business Targets",
        customClass: {
          confirmButton:
            "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
        },
      }).then((result) => {
        if (result.isConfirmed) {
          navigate("/organizationgoals/bussiness_target");
        }
      });
      return
    }
    if (getMoreCount == 0) useBusinessEssentials();
    if (fullBusinessEssentials?.length > 0 || BELoading) {

      setIsOpen((prev) => !prev);
    } else {
      // toast.error("Please update the Settings to get AI Help.");
      MySwal.fire({
        // Combine warning messages and additional text
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>
            <h2 className="text-xl font-semibold">Warning!</h2>
            <p className="mt-2">Please update the Settings to get AI Help.</p>
          </div>
        ),
        confirmButtonText: "Go to Settings",
        customClass: {
          confirmButton:
            "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
        },
      }).then((result) => {
        if (result.isConfirmed) {
          navigate("/settings/organization_tab"); // Navigate to the settings page
        }
      });
    }
  };



  const getBusinessEssentials = async () => {
    try {
      const bodyData = {
        organization_goal: "vision",
        strategic_plan_id: strategicPlan
        // businessEssentialData: businessEssentialData,
      };

      let response = await businessEssentials({ requestBody: bodyData });
      setFullBusinessEssentials(response?.data);
    } catch (error) {
      console.log(error);
      if (error?.msg) {
        setError(error?.msg)
      }
      // setIsOpen((prev) => !prev);
      // toast.error(error.data.message);
    } finally {
      // setLoading(false)
    }
  };

  const useBusinessEssentials = () => {
    // Only load if more data is available and count is less than 3

    if (
      getMoreCount < 2 &&
      fullBusinessEssentials?.length > businessEssentialData?.length
    ) {
      const nextDataStart = getMoreCount == 0 ? getMoreCount : 15;
      const nextDataEnd = getMoreCount == 0 ? 15 : 20;

      // Append the next 4 items to the business essentials data
      setBusinessEssentialData((prevData) => [
        ...prevData,
        ...fullBusinessEssentials.slice(nextDataStart, nextDataEnd),
      ]);

      // Increment the count for more data loading
      setGetMoreCount(getMoreCount + 1);
    }
  };

  const { data: Goals, isLoading: loadingState } = useApi(
    apiList.admin.organizationGoals.get_goals.key(auth?.user?.organization_id),
    strategicPlan ? apiList.admin.organizationGoals.get_goals.call(strategicPlan) : null
  );

  useEffect(() => {
    setVision(Goals?.data?.vision);
    setSavedVision(Goals?.data?.vision);
    getBusinessEssentials();
    if (Goals?.data?.vision) {
      setEditMode(true);
    } else {
      setEditMode(false);
    }
  }, [Goals]);

  const mutateFn = async () => {
    setCustomLoading(true);
    await mutate(
      apiList.admin.organizationGoals.get_goals.key(auth?.user?.organization_id)
    );
    setCustomLoading(false);
  };

  useEffect(() => {
    mutateFn();
  }, [strategicPlan]);

  const { trigger, isMutating } = useApi(
    null,
    apiList.admin.organizationGoals.create_vision.call(),
    { method: "POST" }
  );

  const { trigger: businessEssentials, isMutating: BELoading } = useApi(
    null,
    apiList.admin.organizationGoals.business_essentials.call(),
    { method: "POST" }
  );

  useEffect(() => {
    if (!loadingState) {
      setLoading(false);
    }
    if (!BELoading) {
      if (getMoreCount == 0) useBusinessEssentials();
    }
  }, [loadingState, BELoading]);

  const handleIsDirty = (dirty) => {
    setIsDirty(dirty);
  };

  // Real-time validation on input change
  const handleVisionChange = async (e) => {
    setIsDirty(true);
    const value = e.target.value;
    setVision(value);
    validateVision(value);
  };

  const handleFullStatementChange = (index, value) => {
    const updatedStatements = [...statements];
    updatedStatements[index] = value;
    setStatements(updatedStatements);
  };

  const validateVision = async (value) => {
    try {
      await VisionSchema.validate({ vision: value });
      setVisionError(null); // Clear errors if validation passes
    } catch (error) {
      setVisionError(error.message); // Set validation error
    }
  };

  const onSubmit = async (e) => {
    e.preventDefault();

    // Validate the mission statement using Yup
    try {
      await VisionSchema.validate({ vision });
      setVisionError(""); // Clear errors if validation passes

      const bodyData = {
        content: vision,
        organization: auth?.user?.organization_id,
        strategic_plan_id: strategicPlan,
      };

      let response = await trigger({ requestBody: bodyData });
      // toast.success(response?.data);
      setIsDirty(false);
      mutate(
        apiList.admin.organizationGoals.get_goals.key(
          auth?.user?.organization_id
        )
      );

      MySwal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>
            <h2 className="text-xl font-semibold">Success!</h2>
            <p className="mt-2">{response?.data}</p>
          </div>
        ),
        confirmButtonText: "Okay",
        customClass: {
          confirmButton: "my-confirm-button",
        },
      });

      setEditMode(!editMode);
    } catch (error) {
      setVisionError(error?.message); // Set the validation error message
      if (!isVisionStatement || !existingVision) {
        if (error?.message) {
          toast.error(error?.message);
        }
      }
      if (error?.data) {
        if (error?.data?.message) {
          toast.error(error?.data?.message);
        }
      }
    }
  };

  const changeEditMode = () => {
    setIsExistingVision("yes");
    setIsVisionStatement("yes");
    setEditMode(!editMode);
  };
  if (loadingState || loading || customLoading) {
    return <PageSpinner />;
  }

  const renderContent = () => {
    if (
      !hasPermission("org_vision", "read_only") &&
      !hasPermission("org_vision", "edit")
    ) {
      return <div>Vision Not Available for the Organization</div>;
    }

    if (
      hasPermission("org_vision", "read_only") &&
      !hasPermission("org_vision", "edit")
    ) {
      if (!editMode) {
        return (
          <div className="">Vision Not Available for the Organization</div>
        );
      }
    }
    if (editMode) {
      return (
        <div className={`my-2 mb-4 w-[80%]`}>
          <h5 className="text-gray-600 p-1">Vision</h5>

          <Card
            bordered
            shadow="none"
            radius="md"
            className={`p-2 bg-[#F4F7FA] border text-start   border-[#E2E9F0]`}
          >
            {vision}
          </Card>
          <PermissionWrapper resource={"org_vision"} actions={["edit"]}>
            <span
              className="mt-1 text-default-500 float-end cursor-pointer"
              onClick={changeEditMode}
            >
              Edit
            </span>
          </PermissionWrapper>
        </div>
      );
    }
    return (
      <div>
        <form onSubmit={onSubmit} noValidate>
          {showModal && (
            <UnsavedChangesModal
              isCancelNavigation={cancelNavigation}
              isConfirmNavigation={confirmNavigation}
            />
          )}
          <div className="flex justify-between gap-5 ">
            <div className="flex gap-2  p-1 px-2 w-fit mb-5">
              <span>
                <IconInfoCircle />
              </span>
              <p>
                The "Organization Goals" section, specifically under the Vision
                tab in ProStrategy.ai, helps you manage your company's vision
                statement. Here's how to interact with this form
                <HelpModal
                  title={"Organization Goals Vision Help"}
                  ContentComponent={OrganizationVisionHelp}
                  isReadMore={true}
                />
              </p>
            </div>
            <PermissionWrapper resource={"org_vision"} actions={["edit"]}>
              <Button
                radius="sm"
                color="primary"
                className="mb-2 bg-[#0098F5]"
                type="submit"
                isLoading={isMutating}
              >
                Save Changes
              </Button>
            </PermissionWrapper>
          </div>
          <div>
            <p className="mb-6">
              Does your Company currently have a vision statement?
            </p>
            <RadioGroup
              className="mb-5"
              orientation="horizontal"
              value={isVisionStatement}
              onValueChange={(value) => {
                setIsVisionStatement(value);
                if (value == "no") {
                  setVision("");
                }
                if (existingVision === "yes" && value == "yes" && savedVision) {
                  setVision(savedVision);
                  validateVision(savedVision);
                }
              }}
            >
              <Radio value="yes">Yes</Radio>
              <Radio value="no">No</Radio>
            </RadioGroup>
          </div>
          {isVisionStatement == "yes" && (
            <div>
              <p className="mb-6">
                Do you want to continue with the existing vision or create a new
                one?
              </p>
              <RadioGroup
                className="mb-5"
                orientation="horizontal"
                value={existingVision}
                onValueChange={(value) => {
                  setIsExistingVision(value);
                  if (value == "no") {
                    setVision("");
                    if (hasPlanPermission("org_base_goals_with_pillars_ai")) {
                      toggleDrawer();
                    } else {
                      toast.error(
                        "Your current plan has limited features. Upgrade now to access more!"
                      );
                    }
                  }
                  if (
                    isVisionStatement === "yes" &&
                    value == "yes" &&
                    savedVision
                  ) {
                    setVision(savedVision);
                    validateVision(savedVision);
                  }
                }}
              >
                <Radio value="yes">Use Existing One</Radio>
                <Radio value="no">
                  Use AI to help create new vision statement
                </Radio>
              </RadioGroup>
            </div>
          )}
          {(existingVision === "no" || isVisionStatement === "no") && (
            <div className="flex gap-2 items-center text-sm bg-slate-200 rounded-[8px] p-1 px-2 w-fit">
              <IconInfoCircle className="mb-[1px] h-5 w-5" />
              Click the{`"AI Help"`} button on the right side to generate a
              vision statement using AI or type manually.
            </div>
          )}
          {(isVisionStatement === "no" ||
            existingVision === "no" ||
            existingVision === "yes") && (
              <div>
                <Textarea
                  label={
                    <div className="flex items-end justify-between mt-2">
                      <label htmlFor="missionStatement">
                        Vision Statement{" "}
                        <span className="text-red-600 text-base ml-1">*</span>
                      </label>
                      {(existingVision === "no" || isVisionStatement === "no") &&
                      (hasPlanPermission("org_base_goals_with_pillars_ai") ? (
                          <Button
                            radius="sm"
                            color="primary"
                            className="mt-0 bg-[#39465F]"
                            onClick={toggleDrawer}
                          >
                            <AiHelpIcon />
                            AI Help
                          </Button>
                        ) : (
                          <CustomTooltip
                            tooltipTitle="Upgrade Plan"
                            tooltipContent={
                              currentPlanData?.data?.plan_name == "Enterprise"
                                ? "Your current plan has limited features. Please Contact Admin"
                                : "Your current plan has limited features. Upgrade now to access more!"
                            }
                            buttonText={
                              currentPlanData?.data?.plan_name == "Enterprise"
                                ? null
                                : "Go to Plans"
                            }
                            navigateTo="/settings/account_tab" // The route to navigate
                          />
                        ))}
                    </div>
                  }
                  labelPlacement="outside"
                  placeholder="Enter your vision statement"
                  variant="bordered"
                  radius="sm"
                  value={vision}
                  onChange={handleVisionChange}
                  isInvalid={VisionError ? true : false}
                  errorMessage={VisionError}
                  classNames={{
                    input: "min-h-[150px]",
                    label: "mb-2",
                    inputWrapper: [
                      "group-data-[focus=true]:border-[#0098F5]",
                      "dark:group-data-[focus=true]:border-[#0098F5]",
                    ],
                  }}
                />
              </div>
            )}
    
          <AiHelpDrawer
            drawerState={isOpen}
            setDrawerState={setIsOpen}
            title={
              <span className="font-semibold">
                AI Help -{" "}
                <span className="text-[#0098F5]">Create Vision Statement</span>
              </span>
            }
            businessEssentialData={businessEssentialData}
            getBusinessEssentials={useBusinessEssentials}
            setValue={setVision}
            validate={validateVision}
            type={"Vision"}
            setDrawerOpen={setIsOpen}
            BELoading={BELoading}
            step={drawerStep}
            setStep={setDrawerStep}
            fullStatements={statements}
            setFullStatements={setStatements}
            getMoreCount={getMoreCount}
            selectedBusinessEssentials={selectedBusinessEssentials}
            setSelectedBusinessEssentials={setSelectedBusinessEssentials}
            isEditable={isEditable}
            setIsEditable={setIsEditable}
            handleFullStatementChange={handleFullStatementChange}
            handleIsDirty={handleIsDirty}
          />
        </form>
      </div>
    );
  };

  return <>{renderContent()}</>;
}

export default VisionTab;

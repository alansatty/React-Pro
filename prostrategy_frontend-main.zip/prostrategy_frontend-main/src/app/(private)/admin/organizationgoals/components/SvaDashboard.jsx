import React, { useEffect, useState } from "react";
import { Spinner } from "@nextui-org/spinner";
import toast from "react-hot-toast";
import { mutate } from "swr";
import usePermissionsStore from "../../../../../stores/usePermissionStore";
import { apiList } from "../../../../../services";
import useApi from "../../../../../hooks/useApi";
import hasPermission from "../../../../../utils/hasPermission";

const SvaDashboard = () => {
  const [svaData, setSvaData] = useState([])
  const [customLoading, setCustomLoading] = useState(false)

  const strategicPlan = usePermissionsStore((state) => state.strategicPlan)

  const { data, isLoading } = useApi(
    apiList.admin.organizationGoals.get_sva_dashboard.key(),
    strategicPlan ? apiList.admin.organizationGoals.get_sva_dashboard.call(strategicPlan) : null,
  )

  const [years, setYears] = useState([])

  useEffect(() => {
    if (data?.data) {
      setSvaData(data.data)
      // Extract unique years from data
      const extractedYears = [
        ...new Set(data.data.flatMap((row) => row.subCriteria.flatMap((subRow) => Object.keys(subRow.delivery)))),
      ]
      setYears(extractedYears)
    }
  }, [data])


  const mutateFn = async () => {
    setCustomLoading(true)
    await mutate(apiList.admin.organizationGoals.get_sva_dashboard.key())
    setCustomLoading(false)
  }

  useEffect(() => {
    mutateFn()
  }, [strategicPlan])

  const { trigger } = useApi(null, apiList.admin.organizationGoals.save_sva_dashboard.call(), { method: "POST" })

  // Handler to toggle the value in the `delivery` object when a dot is clicked
  const handleDotClick = async (mainIdx, subId, year, quarterIdx) => {
    setSvaData((prevData) =>
      prevData.map((mainRow, mainRowIdx) =>
        mainRowIdx === mainIdx
          ? {
            ...mainRow,
            subCriteria: mainRow.subCriteria.map((subRow) =>
              subRow.criteria.id === subId
                ? {
                  ...subRow,
                  // Reset all years and quarters, then set the clicked one to 1
                  delivery: Object.fromEntries(
                    Object.entries(subRow.delivery).map(([yr, quarters]) => [
                      yr,
                      quarters.map((_, qtrIdx) => (yr === year && qtrIdx === quarterIdx ? 1 : 0)),
                    ]),
                  ),
                }
                : subRow,
            ),
          }
          : mainRow,
      ),
    )

    try {
      const bodyData = {
        criteria_id: subId,
        year: year,
        quarter: `q${quarterIdx + 1}`,
        strategic_plan_id: strategicPlan,
        is_selected: true
      }

      await trigger({ requestBody: bodyData })

      toast.success("SVA Dashboard Updated")

      mutate(apiList.admin.organizationGoals.get_sva_dashboard.key())
    } catch (error) {
      console.log(error)
    }
  }

  function hasValidCriteria(data) {
    return data.some((entry) => entry.subCriteria.some((sub) => sub.criteria.id))
  }


  // Render a loading message while data is being fetched
  if (isLoading || customLoading) {
    return (
      <div className="flex items-center justify-center h-full w-full">
        <Spinner size="md" />
      </div>
    )
  }

  return (
    <div className="">
      {hasValidCriteria(svaData) ? (
        <>
          <div className="w-100 flex justify-end items-center mb-2">
            <div className="flex gap-2 items-center">
              <span className="block relative w-4 h-4 mb-1 mx-auto border-2 border-[#0098F5] border-opacity-[60%] rounded-full">
                <span className="block absolute top-[2px] left-[2px] w-2 h-2 bg-[#00aaff] rounded-full mx-auto"></span>
              </span>
              Refers Expected Delivery
            </div>
          </div>

          {/* Main container with fixed width and overflow handling */}
          <div className="relative border border-gray-200 rounded">
            {/* Table with sticky headers and first column */}
            <div className="overflow-auto max-h-[600px]">
              <table className="min-w-full bg-white border-collapse">
                <thead>
                  {/* Year row - sticky top */}
                  <tr className="bg-[#02205F] text-white sticky top-0 z-20">
                    {/* First cell - sticky top-left corner */}
                    <th className="px-4 py-2 text-left font-semibold sticky left-0 z-30 bg-[#02205F]">Criteria</th>
                    {/* Year headers - sticky top */}
                    {years.map((year, i) => (
                      <th
                        key={year}
                        colSpan={4}
                        className={`px-4 py-2 text-center border-l border-[#0098F5]/50 font-semibold ${i === years.length - 1 && "border-r"
                          }`}
                      >
                        {year}
                      </th>
                    ))}
                  </tr>

                  {/* Quarter row - sticky below year row */}
                  <tr className="sticky top-[41px] bg-white z-20">
                    {/* Empty cell in top-left corner below "Criteria" */}
                    <th className="sticky left-0 z-30 bg-white"></th>

                    {/* Quarter headers */}
                    {years.map((year, yearIdx) =>
                      ["Q1", "Q2", "Q3", "Q4"].map((quarter, qIdx) => (
                        <th
                          key={`${year}-${quarter}`}
                          className={`px-2 py-2 text-center border-l font-semibold ${qIdx === 0 ? "border-[#0098F5]/50" : ""
                            } ${qIdx === 3 && yearIdx === years.length - 1 ? "border-r border-r-[#0098F5]/50" : ""}`}
                        >
                          {quarter}
                        </th>
                      )),
                    )}
                  </tr>
                </thead>

                <tbody>
                  {svaData?.map((row, idx) => (
                    <React.Fragment key={idx}>
                      {/* Main Title Row */}
                      <tr className="bg-slate-100">
                        <td className="border px-4 py-2 font-semibold text-blue-600 sticky left-0 z-10 bg-slate-100">
                          {row.mainTitle}
                        </td>
                        {/* Span the title across all quarter columns */}
                        <td
                          colSpan={years.length * 4}
                          className="border px-4 py-2 font-semibold text-blue-600 bg-slate-100"
                        ></td>
                      </tr>

                      {/* Sub-Criteria Rows */}
                      {row.subCriteria.map(
                        (subRow, subIdx) =>
                          subRow.criteria.id &&
                          subRow.criteria.title.trim() !== "" && (
                            <tr key={subIdx} className={subIdx % 2 === 0 ? "bg-white" : "bg-[#EEEEEE]"}>
                              {/* Sticky first column */}
                              <td
                                className="border px-4 py-2 border-r-[#0098F5]/50 min-w-[360px] sticky left-0 z-10"
                                style={{ backgroundColor: subIdx % 2 === 0 ? "white" : "#EEEEEE" }}
                              >
                                {subRow.criteria.title}
                              </td>

                              {/* Data cells */}
                              {years.map((year) =>
                                subRow.delivery[year]?.map((qtr, i) => (
                                  <td
                                    key={`${year}-qtr${i}`}
                                    className={`border text-center ${hasPermission("dept_expected_delivery", ["edit"]) && "cursor-pointer"
                                      } ${i === subRow.delivery[year].length - 1 ? "border-r-[#0098F5]/50" : ""}`}
                                    onClick={() =>
                                      hasPermission("dept_expected_delivery", ["edit"]) &&
                                      handleDotClick(idx, subRow.criteria.id, year, i)
                                    }
                                  >
                                    {qtr === 1 ? (
                                      <span className="block relative w-4 h-4 mx-auto border-2 border-[#0098F5] border-opacity-[60%] rounded-full">
                                        <span className="block absolute top-[2px] left-[2px] w-2 h-2 bg-[#00aaff] rounded-full mx-auto"></span>
                                      </span>
                                    ) : (
                                      ""
                                    )}
                                  </td>
                                )),
                              )}
                            </tr>
                          ),
                      )}
                    </React.Fragment>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : (
        <p className="text-center text-gray-500 mt-4">Please submit SVA Form for getting dashboard data.</p>
      )}
    </div>
  )
}

export default SvaDashboard


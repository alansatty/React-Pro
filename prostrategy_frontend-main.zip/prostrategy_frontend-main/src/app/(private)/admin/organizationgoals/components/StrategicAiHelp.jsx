import { IconCheck, IconCircleX, IconReload } from "@tabler/icons-react";
import SlidingPane from "react-sliding-pane";
import "react-sliding-pane/dist/react-sliding-pane.css";
import toast from "react-hot-toast";
import { Button } from "@nextui-org/button";

function StrategicAiHelp({
  drawerState,
  setDrawerState,
  title,
  getCriteriaWithlimitNumber,
  onSaveCriteria,
  getMoreCount,
  criterias,
  BELoading,
  selectedCriteria,
  setSelectedCriteria,
}) {
  const handleSelectGoal = (goal) => {
    const alreadySelected = selectedCriteria.find(
      (item) => item.goal === goal.goal
    );

    if (alreadySelected) {
      setSelectedCriteria([]);
    } else {
      setSelectedCriteria([goal]);
    }
  };

  const handleGetMore = () => {
    if (getMoreCount < 3) {
      getCriteriaWithlimitNumber();
    } else {
      toast.error("Maximum focal points reached!");
    }
  };

  const handleSave = () => {
    if (selectedCriteria.length === 1) {
      onSaveCriteria(selectedCriteria);
      setDrawerState(false);
      toast.success("Criteria saved successfully!");
    } else {
      toast.error("Please select a goal.");
    }
  };

  return (
    <SlidingPane
      closeIcon={
        <div>
          <span className="text-xl">
            <IconCircleX color="#11181C" className="w-12 h-12" />
          </span>
        </div>
      }
      overlayClassName="z-50"
      width="600px"
      isOpen={drawerState}
      title={title}
      onRequestClose={() => setDrawerState(false)}
    >
      <div className="p-4 space-y-4">
        <h3 className="text-xl font-semibold">Select a Goal</h3>

        {BELoading ? (
          <div className="space-y-2">
            {[...Array(5)].map((_, index) => (
              <div
                key={index}
                className="bg-gray-200 h-6 rounded-md animate-pulse"
              ></div>
            ))}
          </div>
        ) : (
          <ul className="space-y-4">
            {criterias.map((criteria, index) => (
              <li
                key={`goal-${index}`}
                className={`border p-3 rounded-md cursor-pointer ${selectedCriteria.find(
                  (item) => item.goal === criteria[`goal_${index + 1}`]
                )
                  ? "border-green-500 bg-green-50"
                  : "border-gray-200"
                  }`}
                onClick={() =>
                  handleSelectGoal({
                    goal: criteria[`goal_${index + 1}`],
                    strategies: criteria.strategies,
                  })
                }
              >
                <div className="flex justify-between items-center">
                  <span className="text-lg font-medium">
                    {criteria[`goal_${index + 1}`]}
                  </span>
                  {selectedCriteria?.find(
                    (item) => item.goal === criteria[`goal_${index + 1}`]
                  ) && <IconCheck className="text-green-500 w-5 h-5" />}
                </div>
                <ul className="mt-2 pl-5 text-sm text-gray-600 list-disc">
                  {criteria.strategies.map((strategy, i) => (
                    <li key={i}>{strategy}</li>
                  ))}
                </ul>
              </li>
            ))}
          </ul>
        )}

        <div className="flex justify-between mt-4">
          {getMoreCount < 3 ? (
            <Button
              radius="sm"
              variant="bordered"
              color="primary"
              startContent={!BELoading && <IconReload />}
              auto
              className="bg-white text-black"
              onClick={handleGetMore}
              isLoading={BELoading}
            >
              {BELoading ? "Getting" : "Get 5 more"}
            </Button>
          ) : (
            <div></div>
          )}

          <Button
            color="primary"
            radius="sm"
            className="capitalize"
            onClick={handleSave}
            disabled={selectedCriteria.length === 0}
            isLoading={BELoading}
          >
            Use Criteria
          </Button>
        </div>
      </div>
    </SlidingPane>
  );
}

export default StrategicAiHelp;


import { useEffect, useRef, useState } from "react";
import usePermissionsStore from "../../../../../stores/usePermissionStore";
import useApi from "../../../../../hooks/useApi";
import { apiList } from "../../../../../services";
import { mutate } from "swr";
import { Spinner } from "@nextui-org/spinner";
import { cn } from "../../../../../utils/twMege";
import { SvaCriterias } from "./SvaCriterias";
import useTabNavigation from "../../../../../hooks/useTabNavigation";

const SvaForm = () => {
  const [customLoading, setCustomLoading] = useState(false);
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
  const [formIsDirty, setFormIsDirty] = useState(false); // Track form dirty state at parent level
  const hasFetchedRef = useRef(false);

  // Fetching SVA options
  const { data, isLoading } = useApi(
    apiList.admin.organizationGoals.get_sva_options.key,
    apiList.admin.organizationGoals.get_sva_options.call()
  );

  // Fetching saved criteria
  const { data: DetailsCriteria, isLoading: isLoadingDetailsCriteria } = useApi(
    apiList.admin.organizationGoals.get_saved_criterea.key(),
    strategicPlan ? apiList.admin.organizationGoals.get_saved_criterea.call(strategicPlan) : null
  );

  const [selectedValues, setSelectedValues] = useState([]);
  const [activeItem, setActiveItem] = useState(null);

  // Use our new tab navigation hook
  const {
    showModal,
    targetTab,
    isNavigating,
    handleTabClick,
    confirmTabChange,
    cancelTabChange,
  } = useTabNavigation(formIsDirty);

  // Update selectedValues from API response when data is fetched
  useEffect(() => {
    if (data?.status === "success" && data?.data?.length > 0) {
      setSelectedValues(data.data);
      setActiveItem(data.data[0]); // Set the first option as the default active item
    }
  }, [data]);

  const mutateFn = async () => {
    setCustomLoading(true);
    await mutate(apiList.admin.organizationGoals.get_saved_criterea.key());
    setCustomLoading(false);
  };

  useEffect(() => {
    mutateFn();
  }, [strategicPlan]);

  // Update active tab when navigation is confirmed
  useEffect(() => {
    if (isNavigating && targetTab) {
      setActiveItem(targetTab);
      setFormIsDirty(false); // Reset dirty state after navigation
    }
  }, [isNavigating, targetTab]);

  // Callback to update form dirty state from child
  const updateFormDirtyState = (isDirty) => {
    setFormIsDirty(isDirty);
  };

  // Handler for tab click
  const handleTabNavigation = (item) => {
    if (activeItem?.sva_option_id !== item.sva_option_id) {
      hasFetchedRef.current = false
      handleTabClick(item);
    }
  };

  // Render the form content dynamically based on the active item
  const renderContent = () => {
    if (!activeItem || isLoadingDetailsCriteria || customLoading)
      return (
        <div className="flex items-center justify-center h-full w-full">
          <Spinner size="md" />
        </div>
      );

    // Find the criteria data for the active item
    const criteria = DetailsCriteria?.data?.find(
      (item) => item.sva_option_id === activeItem.sva_option_id
    );

    return (
      <SvaCriterias
        criteria={criteria}
        updateFormDirty={updateFormDirtyState}
        showTabChangeModal={showModal}
        confirmTabChange={confirmTabChange}
        cancelTabChange={cancelTabChange}
        hasFetchedRef={hasFetchedRef}
      />
    );
  };

  // Render a loading message while data is being fetched
  if (isLoading || isLoadingDetailsCriteria || !strategicPlan) {
    return (
      <div className="flex items-center justify-center h-full w-full">
        <Spinner size="md" />
      </div>
    );
  }

  return (
    <div className="grid grid-cols-3 gap-4">
      <div className="col-span-1">
        <div className="bg-white p-4 border-e h-full rounded-none">
          <ul className="space-y-4">
            {selectedValues.map((item) => (
              <li
                key={item.sva_option_id}
                className={cn(
                  "text-gray-700 cursor-pointer py-2 px-2 rounded-lg",
                  activeItem?.sva_option_id === item.sva_option_id
                    ? "bg-[#EBF7FF] text-appSecondary"
                    : ""
                )}
                onClick={() => handleTabNavigation(item)}
              >
                {item.sva_option_label}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="col-span-2">{renderContent()}</div>
    </div>
  );
};

export default SvaForm;

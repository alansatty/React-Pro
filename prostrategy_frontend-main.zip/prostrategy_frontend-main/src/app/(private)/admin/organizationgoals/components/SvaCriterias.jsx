import { useState, useEffect } from "react";
import { Button } from "@nextui-org/button";
import { useNavigate } from "react-router-dom";
import * as yup from "yup";
import { Input } from "@nextui-org/input";
import { mutate } from "swr";
import Swal from "sweetalert2/dist/sweetalert2.js";
import { Card } from "@nextui-org/card";
import { IconInfoCircle } from "@tabler/icons-react";
import usePermissionsStore from "../../../../../stores/usePermissionStore";
import AiHelpIcon from "../../../../../assets/icons/aihelp-icon";
import HelpModal from "../../../../../components/Topbar/HelpModal";
import { DepartmentSVAFormHelp } from "../../../../../components/Topbar/helpComponents/Helps";
import hasPlanPermission from "../../../../../utils/hasPlanPermission";
import { CriteriaSchema } from "../../../../../../validationSchema/authValidation";
import { apiList } from "../../../../../services";
import useApi from "../../../../../hooks/useApi";
import CustomTooltip from "../../../../../components/CustomTooltip/CustomTooltip";
import AiHelpSvaDrawer from "./SvaFormDrawer";
import withReactContent from "sweetalert2-react-content";
import ProstrategyLogo from "../../../../../assets/icons/ProstrategyLogo";
import useUnsavedChanges from "../../../../../hooks/useUnsavedChanges";
import UnsavedChangesModal from "../../../../../components/Alert/UnsavedChangesModal";
const Myswal = withReactContent(Swal);

export function SvaCriterias({
  criteria,
  updateFormDirty,
  showTabChangeModal,
  confirmTabChange,
  cancelTabChange,
  hasFetchedRef,
}) {
  const navigate = useNavigate();
  const [getMoreCount, setGetMoreCount] = useState(0);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [fullCriterias, setFullCriterias] = useState([]);
  const [criteriaData, setCriteriaData] = useState([]);
  const [selectedCriteria, setSelectedCriteria] = useState([]);
  const [refresh, setRefresh] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [formData, setFormData] = useState({
    criteria1: "",
    criteria2: "",
    criteria3: "",
    criteria4: "",
    criteria5: "",
    criteria6: "",
    criteria7: "",
  });
  const [errors, setErrors] = useState({});
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
  const [isEditing, setIsEditing] = useState(false);
  const [isDirty, setIsDirty] = useState(false);

  const {
    showModal: showRouteChangeModal,
    confirmNavigation,
    cancelNavigation,
  } = useUnsavedChanges(isDirty);

  useEffect(() => {
    updateFormDirty(isDirty);
  }, [isDirty, updateFormDirty]);

  useEffect(() => {
    setCriteriaData([]);
    setGetMoreCount(0);
    setSelectedCriteria([]);
    setErrorMsg("");

    if (criteria && !hasFetchedRef.current) {
      setFormData({
        criteria1: criteria?.criteria?.criteria1?.criteria || "",
        criteria2: criteria?.criteria?.criteria2?.criteria || "",
        criteria3: criteria?.criteria?.criteria3?.criteria || "",
        criteria4: criteria?.criteria?.criteria4?.criteria || "",
        criteria5: criteria?.criteria?.criteria5?.criteria || "",
        criteria6: criteria?.criteria?.criteria6?.criteria || "",
        criteria7: criteria?.criteria?.criteria7?.criteria || "",

        criteria1_id: criteria?.criteria?.criteria1?.id || "",
        criteria2_id: criteria?.criteria?.criteria2?.id || "",
        criteria3_id: criteria?.criteria?.criteria3?.id || "",
        criteria4_id: criteria?.criteria?.criteria4?.id || "",
        criteria5_id: criteria?.criteria?.criteria5?.id || "",
        criteria6_id: criteria?.criteria?.criteria6?.id || "",
        criteria7_id: criteria?.criteria?.criteria7?.id || "",
      });
      setErrors({});
      setIsEditing(false);
      setIsDirty(false);

      getCriteria();
      hasFetchedRef.current = true
    }
  }, [criteria]);

  const getCriteria = async () => {
    try {
      const bodyData = {
        sva_option: criteria?.sva_option_label,
      };

      let response = await genaratedAicriterias({ requestBody: bodyData });
      setFullCriterias(response?.data);

      if (response?.data?.length > 0) {
        setCriteriaData(response.data.slice(0, 15));
        setGetMoreCount(1);
      }
    } catch (error) {
      console.log('error', error);
      setErrorMsg(error?.msg);
    } finally {
      //   setLoading(false)
    }
  };

  const toggleDrawer = () => {
    if (errorMsg) {
      Myswal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>
            <h2 className="text-xl font-semibold">Warning!</h2>

            {errorMsg.includes("business targets") ? (
              <p className="mt-2">
                Please update your Business Targets to get AI Help.
              </p>
            ) : (
              <p className="mt-2">
                Please update your Organization Profile to get AI Help.
              </p>
            )}
          </div>
        ),
        confirmButtonText: "Go to Settings",
        customClass: {
          confirmButton:
            "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
        },
      }).then((result) => {
        if (result.isConfirmed) {
          if (errorMsg.includes("business targets")) {
            navigate(`/organizationgoals/bussiness_target`);
          } else {
            navigate("/settings/organization_tab");
          }
        }
      });

      return;
    }
    if (criteriaData.length === 0 && fullCriterias?.length > 0) {
      getCriteriaWithlimitNumber();
    }
    setDrawerOpen((prev) => !prev);
    // if (getMoreCount == 0) {
    //   getCriteriaWithlimitNumber();
    // }
    // if (fullCriterias?.length > 0 || BELoading) {
    //   setDrawerOpen((prev) => !prev);
    // } else {
    //   // toast.error("Please update the Settings to get AI Help.");
    //   Myswal.fire({
    //     // Combine warning messages and additional text
    //     html: (
    //       <div className="flex flex-col items-center">
    //         <div className="w-18 h-20 mb-2">
    //           <ProstrategyLogo />
    //         </div>
    //         <h2 className="text-xl font-semibold">Warning!</h2>
    //         <p className="mt-2">Please update the Settings to get AI Help.</p>
    //       </div>
    //     ),
    //     confirmButtonText: "Go to Settings",
    //     customClass: {
    //       confirmButton:
    //         "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
    //     },
    //   }).then((result) => {
    //     if (result.isConfirmed) {
    //       navigate("/settings/organization_tab"); // Navigate to the settings page
    //     }
    //   });
    // }
  };

  const getCriteriaWithlimitNumber = () => {
    if (getMoreCount < 2 && fullCriterias?.length > criteriaData.length) {
      const nextDataStart = criteriaData.length;
      const nextDataEnd = nextDataStart + (getMoreCount === 0 ? 15 : 5);

      setCriteriaData((prevData) => [
        ...prevData,
        ...fullCriterias.slice(nextDataStart, nextDataEnd),
      ]);
      setGetMoreCount(getMoreCount + 1);
    }
  };
  // const getCriteriaWithlimitNumber = () => {
  //   // Only load if more data is available and count is less than 3

  //   if (getMoreCount < 2 && fullCriterias?.length > criteriaData.length) {
  //     const nextDataStart = getMoreCount == 0 ? getMoreCount : 15;
  //     const nextDataEnd = getMoreCount == 0 ? 15 : 20;
  //     // Append the next 4 items to the business essentials data
  //     setCriteriaData((prevData) => [
  //       ...prevData,
  //       ...fullCriterias.slice(nextDataStart, nextDataEnd),
  //     ]);
  //     // Increment the count for more data loading
  //     setGetMoreCount(getMoreCount + 1);
  //   }
  // };

  // API call for submitting form
  const { trigger, isMutating } = useApi(
    null,
    apiList.admin.organizationGoals.save_criterea_form.call(),
    { method: "POST" }
  );

  const { trigger: genaratedAicriterias, isMutating: BELoading } = useApi(
    null,
    strategicPlan ? apiList.admin.organizationGoals.genarate_sva_criterea.call(strategicPlan) : null,
    { method: "POST" }
  );

  // useEffect(() => {
  //   if (!BELoading) {
  //     if (getMoreCount == 0) getCriteriaWithlimitNumber();
  //   }
  // }, [BELoading]);

  // Handle form input changes with real-time validation

  const onSubmit = async (e) => {
    e.preventDefault();
    const validationErrorObject = {};
    const filteredFormData = Object.fromEntries(
      Object.entries(formData).filter(([key]) => !key.includes("_id"))
    );
    try {
      // Validate each field individually using yup.reach
      for (const [name, value] of Object.entries(filteredFormData)) {
        try {
          await yup.reach(CriteriaSchema, name).validate(value);
        } catch (error) {
          validationErrorObject[name] = error.message;
        }
      }

      // If there are errors, set them and return early
      if (Object.keys(validationErrorObject).length > 0) {
        setErrors(validationErrorObject);
        return;
      }

      // Clear errors and proceed if validation passes
      setErrors({});
      const payload = {
        ...Object.fromEntries(
          Object.entries(formData).map(([key, value]) => [
            key,
            typeof value === "string" && value.trim() === "" ? "" : value,
          ])
        ),
        sva_option: criteria?.sva_option_id || "",
        strategic_plan_id: strategicPlan,
      };

      // Trigger API request
      const response = await trigger({ requestBody: payload });
      getCriteria()
      setIsDirty(false);
      await mutate(apiList.admin.organizationGoals.get_saved_criterea.key());
      // setRefresh((prev) => !prev);

      Myswal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>
            <h2 className="text-xl font-semibold">Success!</h2>
            <p className="mt-2">{response?.data}</p>
          </div>
        ),
        confirmButtonText: "Okay",
        customClass: {
          confirmButton: "my-confirm-button",
        },
      });
      setIsEditing(false);
    } catch (error) {
      console.error("Unexpected error:", error);
    }
  };

  const handleSaveCriteria = (selectedCriteria) => {
    setFormData((prevData) => {
      const updatedData = { ...prevData };
      selectedCriteria.forEach((criteria, index) => {
        updatedData[`criteria${index + 1}`] = criteria;
      });
      return updatedData;
    });
  };

  const handleChange = async (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    setIsDirty(true);
    try {
      await yup.reach(CriteriaSchema, name).validate(value);
      setErrors((prevErrors) => ({ ...prevErrors, [name]: "" }));
    } catch (error) {
      setErrors((prevErrors) => ({ ...prevErrors, [name]: error.message }));
    }
  };

  useEffect(() => {
    if (selectedCriteria.length > 0) {
      setIsDirty(true);
    } else {
      setIsDirty(false);
    }
  }, [selectedCriteria]);


  const { data: currentPlanData } = useApi(
    apiList.admin.subscription.current_plan.key(),
    apiList.admin.subscription.current_plan.call()
  );

  const CardView = () => {
    return (
      <div>
        <div className="flex flex-col gap-3">
          <div className="flex justify-end">
            <Button
              className="mt-2"
              onClick={() => setIsEditing(true)}
              color="primary"
            >
              Edit
            </Button>
          </div>
          {Object.keys(formData).map(
            (key, index) =>
              !key.includes("_id") &&
              formData[key].trim() !== "" && (
                <div key={index}>
                  <label className="text-sm text-gray-600">
                    Criteria {index + 1}
                  </label>{" "}
                  <br />
                  <Card
                    bordered
                    shadow="none"
                    radius="sm"
                    className="p-2 bg-[#F4F7FA] border text-start border-[#E2E9F0]"
                  >
                    {formData[key]}
                  </Card>
                </div>
              )
          )}
        </div>
        {/* {hasPermission(permissionKey, "edit") && ( */}
        {/* )} */}
      </div>
    );
  };

  const handleIsDirty = (dirty) => {
    setIsDirty(dirty);
  };

  return (
    <div>
      <AiHelpSvaDrawer
        drawerState={drawerOpen}
        setDrawerState={setDrawerOpen}
        title={
          <span className="font-semibold">
            AI Help -{" "}
            <span className="text-[#0098F5]">
              Create {criteria?.sva_option_label}
            </span>
          </span>
        }
        criteriaDetails={criteria}
        getCriteriaWithlimitNumber={getCriteriaWithlimitNumber}
        onSaveCriteria={handleSaveCriteria}
        criterias={criteriaData}
        getMoreCount={getMoreCount}
        BELoading={BELoading}
        selectedCriteria={selectedCriteria}
        setSelectedCriteria={setSelectedCriteria}
        handleIsDirty={handleIsDirty}
      />
      {showTabChangeModal && (
        <UnsavedChangesModal
          isConfirmNavigation={confirmTabChange}
          isCancelNavigation={cancelTabChange}
        />
      )}

      {/* Modal for Route Changes */}
      {showRouteChangeModal && (
        <UnsavedChangesModal
          isConfirmNavigation={confirmNavigation}
          isCancelNavigation={cancelNavigation}
        />
      )}

      {criteria?.criteria?.criteria1?.criteria ? (
        // hasPermission(permissionKey, "read_only") ||
        !isEditing ? (
          <CardView />
        ) : (
          <form onSubmit={onSubmit} noValidate>
            <div className="flex justify-between gap-5">
              <div className="flex gap-2 p-1 px-2 w-fit mb-3">
                <IconInfoCircle className="h-12 w-12" />
                <p>
                  This form helps define the {criteria?.sva_option_label} for
                  your Organization, ensuring that the Organization meets the
                  baseline needs of the market and remains competitive.
                  <HelpModal
                    title={"Organization Sva Form Help"}
                    ContentComponent={() => (
                      <DepartmentSVAFormHelp
                        option={criteria?.sva_option_label}
                      />
                    )}
                    isReadMore={true}
                  />
                </p>
              </div>
              <Button
                isLoading={isMutating}
                radius="sm"
                color="primary"
                type="submit"
                className="mb-2 min-w-fit"
              >
                Save Changes
              </Button>
            </div>
            <div className="flex justify-between">
              <p className="mb-2">{`What are the ${criteria?.sva_option_label} for Organization?`}</p>
              {hasPlanPermission("org_sva_swot_goals_ai") ? (
                <Button
                  onPress={toggleDrawer}
                  radius="sm"
                  color="primary"
                  className="mt-0 bg-[#39465F]"
                >
                  <AiHelpIcon />
                  AI Help
                </Button>
              ) : (
                <CustomTooltip
                  tooltipTitle="Upgrade Plan"
                  tooltipContent={
                    currentPlanData?.data?.plan_name == "Enterprise"
                      ? "Your current plan has limited features. Please Contact Admin"
                      : "Your current plan has limited features. Upgrade now to access more!"
                  }
                  buttonText={
                    currentPlanData?.data?.plan_name == "Enterprise"
                      ? null
                      : "Go to Plans"
                  }
                  navigateTo="/settings/account_tab" // The route to navigate
                />
              )}
            </div>

            <div className="flex flex-col space-y-4">
              <div>
                {/* {showModal && (
                  <UnsavedChangesModal
                    isConfirmNavigation={confirmNavigation}
                    isCancelNavigation={cancelNavigation}
                  />
                )} */}
                <Input
                  // readOnly={hasPermission(permissionKey, "read_only")}
                  labelPlacement="outside"
                  radius="sm"
                  variant="bordered"
                  id="criteria1"
                  name="criteria1"
                  value={formData.criteria1}
                  onChange={handleChange}
                  placeholder="Enter your Criteria"
                  label="Criteria 1"
                  isRequired
                  isInvalid={!!errors.criteria1}
                  errorMessage={errors.criteria1}
                  classNames={{
                    inputWrapper: [
                      "group-data-[focus=true]:border-[#0098F5]",
                      "dark:group-data-[focus=true]:border-[#0098F5]",
                    ],
                  }}
                />
              </div>
              <div>
                <Input
                  // readOnly={hasPermission(permissionKey, "read_only")}
                  labelPlacement="outside"
                  radius="sm"
                  variant="bordered"
                  id="criteria2"
                  name="criteria2"
                  value={formData.criteria2}
                  onChange={handleChange}
                  placeholder="Enter your Criteria"
                  label="Criteria 2"
                  isRequired
                  isInvalid={!!errors.criteria2}
                  errorMessage={errors.criteria2}
                  classNames={{
                    inputWrapper: [
                      "group-data-[focus=true]:border-[#0098F5]",
                      "dark:group-data-[focus=true]:border-[#0098F5]",
                    ],
                  }}
                />
              </div>
              <div>
                <Input
                  // readOnly={hasPermission(permissionKey, "read_only")}
                  labelPlacement="outside"
                  radius="sm"
                  variant="bordered"
                  id="criteria3"
                  name="criteria3"
                  value={formData.criteria3}
                  onChange={handleChange}
                  placeholder="Enter your Criteria"
                  label="Criteria 3"
                  isRequired
                  isInvalid={!!errors.criteria3}
                  errorMessage={errors.criteria3}
                  classNames={{
                    inputWrapper: [
                      "group-data-[focus=true]:border-[#0098F5]",
                      "dark:group-data-[focus=true]:border-[#0098F5]",
                    ],
                  }}
                />
              </div>
              <div>
                <Input
                  // readOnly={hasPermission(permissionKey, "read_only")}
                  labelPlacement="outside"
                  radius="sm"
                  variant="bordered"
                  id="criteria4"
                  name="criteria4"
                  value={formData.criteria4}
                  onChange={handleChange}
                  placeholder="Enter your Criteria"
                  label="Criteria 4"
                  isRequired
                  isInvalid={!!errors.criteria4}
                  errorMessage={errors.criteria4}
                  classNames={{
                    inputWrapper: [
                      "group-data-[focus=true]:border-[#0098F5]",
                      "dark:group-data-[focus=true]:border-[#0098F5]",
                    ],
                  }}
                />
              </div>
              <div>
                <Input
                  // readOnly={hasPermission(permissionKey, "read_only")}
                  labelPlacement="outside"
                  radius="sm"
                  variant="bordered"
                  id="criteria5"
                  name="criteria5"
                  value={formData.criteria5}
                  onChange={handleChange}
                  placeholder="Enter your Criteria"
                  label="Criteria 5"
                  isRequired
                  isInvalid={!!errors.criteria5}
                  errorMessage={errors.criteria5}
                  classNames={{
                    inputWrapper: [
                      "group-data-[focus=true]:border-[#0098F5]",
                      "dark:group-data-[focus=true]:border-[#0098F5]",
                    ],
                  }}
                />
              </div>

              <div>
                <Input
                  // readOnly={hasPermission(permissionKey, "read_only")}
                  labelPlacement="outside"
                  radius="sm"
                  variant="bordered"
                  id="criteria6"
                  name="criteria6"
                  value={formData.criteria6}
                  onChange={handleChange}
                  placeholder="Enter your Criteria"
                  label="Criteria 6"
                  // isRequired
                  isInvalid={!!errors.criteria6}
                  errorMessage={errors.criteria6}
                  classNames={{
                    inputWrapper: [
                      "group-data-[focus=true]:border-[#0098F5]",
                      "dark:group-data-[focus=true]:border-[#0098F5]",
                    ],
                  }}
                />
              </div>

              <div>
                <Input
                  // readOnly={hasPermission(permissionKey, "read_only")}
                  labelPlacement="outside"
                  radius="sm"
                  variant="bordered"
                  id="criteria7"
                  name="criteria7"
                  value={formData.criteria7}
                  onChange={handleChange}
                  placeholder="Enter your Criteria"
                  label="Criteria 7"
                  // isRequired
                  isInvalid={!!errors.criteria7}
                  errorMessage={errors.criteria7}
                  classNames={{
                    inputWrapper: [
                      "group-data-[focus=true]:border-[#0098F5]",
                      "dark:group-data-[focus=true]:border-[#0098F5]",
                    ],
                  }}
                />
              </div>
            </div>
          </form>
        )
      ) : (
        //  hasPermission(permissionKey, "read_only") ? (
        //   <div>{criteria.sva_option_label} Not Available for This Department</div>
        // ) :
        <form onSubmit={onSubmit} noValidate>
          <div className="flex gap-2  p-1 px-2 w-fit mb-5">
            <IconInfoCircle className="h-12 w-12" />
            <p>
              This form helps define the {criteria?.sva_option_label} for your{" "}
              Organization, ensuring that the Organization meets the baseline
              needs of the market and remains competitive.
              <HelpModal
                title={"Organization Sva Form Help"}
                // ContentComponent={DepartmentSVAFormHelp}
                ContentComponent={() => (
                  <DepartmentSVAFormHelp option={criteria?.sva_option_label} />
                )}
                isReadMore={true}
              />
            </p>

            <Button
              isLoading={isMutating}
              radius="sm"
              color="primary"
              type="submit"
              className="mb-2 min-w-fit"
            >
              Save Changes
            </Button>
          </div>
          <div className="flex justify-between">
            <p className="mb-2">{`What are the ${criteria?.sva_option_label} for Organization?`}</p>

            {hasPlanPermission("org_sva_swot_goals_ai") ? (
              <Button
                onPress={toggleDrawer}
                radius="sm"
                color="primary"
                className="mt-0 bg-[#39465F]"
              >
                <AiHelpIcon />
                AI Help
              </Button>
            ) : (
              <CustomTooltip
                tooltipTitle="Upgrade Plan"
                tooltipContent={
                  currentPlanData?.data?.plan_name == "Enterprise"
                    ? "Your current plan has limited features. Please Contact Admin"
                    : "Your current plan has limited features. Upgrade now to access more!"
                }
                buttonText={
                  currentPlanData?.data?.plan_name == "Enterprise"
                    ? null
                    : "Go to Plans"
                }
                navigateTo="/settings/account_tab" // The route to navigate
              />
            )}
          </div>

          <div className="flex flex-col space-y-4">
            <div>
              <Input
                // readOnly={hasPermission(permissionKey, "read_only")}
                labelPlacement="outside"
                radius="sm"
                variant="bordered"
                id="criteria1"
                name="criteria1"
                value={formData.criteria1}
                onChange={handleChange}
                placeholder="Enter your Criteria"
                label="Criteria 1"
                isRequired
                isInvalid={!!errors.criteria1}
                errorMessage={errors.criteria1}
                classNames={{
                  inputWrapper: [
                    "group-data-[focus=true]:border-[#0098F5]",
                    "dark:group-data-[focus=true]:border-[#0098F5]",
                  ],
                }}
              />
            </div>
            <div>
              <Input
                // readOnly={hasPermission(permissionKey, "read_only")}
                labelPlacement="outside"
                radius="sm"
                variant="bordered"
                id="criteria2"
                name="criteria2"
                value={formData.criteria2}
                onChange={handleChange}
                placeholder="Enter your Criteria"
                label="Criteria 2"
                isRequired
                isInvalid={!!errors.criteria2}
                errorMessage={errors.criteria2}
                classNames={{
                  inputWrapper: [
                    "group-data-[focus=true]:border-[#0098F5]",
                    "dark:group-data-[focus=true]:border-[#0098F5]",
                  ],
                }}
              />
            </div>
            <div>
              <Input
                // readOnly={hasPermission(permissionKey, "read_only")}
                labelPlacement="outside"
                radius="sm"
                variant="bordered"
                id="criteria3"
                name="criteria3"
                value={formData.criteria3}
                onChange={handleChange}
                placeholder="Enter your Criteria"
                label="Criteria 3"
                isRequired
                isInvalid={!!errors.criteria3}
                errorMessage={errors.criteria3}
                classNames={{
                  inputWrapper: [
                    "group-data-[focus=true]:border-[#0098F5]",
                    "dark:group-data-[focus=true]:border-[#0098F5]",
                  ],
                }}
              />
            </div>
            <div>
              <Input
                // readOnly={hasPermission(permissionKey, "read_only")}
                labelPlacement="outside"
                radius="sm"
                variant="bordered"
                id="criteria4"
                name="criteria4"
                value={formData.criteria4}
                onChange={handleChange}
                placeholder="Enter your Criteria"
                label="Criteria 4"
                isRequired
                isInvalid={!!errors.criteria4}
                errorMessage={errors.criteria4}
                classNames={{
                  inputWrapper: [
                    "group-data-[focus=true]:border-[#0098F5]",
                    "dark:group-data-[focus=true]:border-[#0098F5]",
                  ],
                }}
              />
            </div>
            <div>
              <Input
                // readOnly={hasPermission(permissionKey, "read_only")}
                labelPlacement="outside"
                radius="sm"
                variant="bordered"
                id="criteria5"
                name="criteria5"
                value={formData.criteria5}
                onChange={handleChange}
                placeholder="Enter your Criteria"
                label="Criteria 5"
                isRequired
                isInvalid={!!errors.criteria5}
                errorMessage={errors.criteria5}
                classNames={{
                  inputWrapper: [
                    "group-data-[focus=true]:border-[#0098F5]",
                    "dark:group-data-[focus=true]:border-[#0098F5]",
                  ],
                }}
              />
            </div>

            <div>
              <Input
                // readOnly={hasPermission(permissionKey, "read_only")}
                labelPlacement="outside"
                radius="sm"
                variant="bordered"
                id="criteria6"
                name="criteria6"
                value={formData.criteria6}
                onChange={handleChange}
                placeholder="Enter your Criteria"
                label="Criteria 6"
                // isRequired
                isInvalid={!!errors.criteria6}
                errorMessage={errors.criteria6}
                classNames={{
                  inputWrapper: [
                    "group-data-[focus=true]:border-[#0098F5]",
                    "dark:group-data-[focus=true]:border-[#0098F5]",
                  ],
                }}
              />
            </div>

            <div>
              <Input
                // readOnly={hasPermission(permissionKey, "read_only")}
                labelPlacement="outside"
                radius="sm"
                variant="bordered"
                id="criteria7"
                name="criteria7"
                value={formData.criteria7}
                onChange={handleChange}
                placeholder="Enter your Criteria"
                label="Criteria 7"
                // isRequired
                isInvalid={!!errors.criteria7}
                errorMessage={errors.criteria7}
                classNames={{
                  inputWrapper: [
                    "group-data-[focus=true]:border-[#0098F5]",
                    "dark:group-data-[focus=true]:border-[#0098F5]",
                  ],
                }}
              />
            </div>
          </div>
        </form>
      )}
    </div>
  );
}

import { Button } from "@nextui-org/button";
import { Input } from "@nextui-org/input";
import { Card } from "@nextui-org/card"; // Assuming you're using a Card component from your library
import { useEffect, useMemo, useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { SwotFormSchema } from "../../../../../../validationSchema/authValidation";
import useApi from "../../../../../hooks/useApi";
import { apiList } from "../../../../../services";
import Swal from "sweetalert2/dist/sweetalert2.js";
import { mutate } from "swr";
import { useAuth } from "../../../../../providers/authProviders";
import { PermissionWrapper } from "../../../../../components";
import hasPermission from "../../../../../utils/hasPermission";
import withReactContent from "sweetalert2-react-content";
import ProstrategyLogo from "../../../../../assets/icons/ProstrategyLogo";
import useUnsavedChanges from "../../../../../hooks/useUnsavedChanges";
import UnsavedChangesModal from "../../../../../components/Alert/UnsavedChangesModal";
import AiHelpIcon from "../../../../../assets/icons/aihelp-icon";
import AiHelpSwotDrawer from "./AiHelpSwotDrawer";
import usePermissionsStore from "../../../../../stores/usePermissionStore";
import { useNavigate } from "react-router-dom";
import CustomTooltip from "../../../../../components/CustomTooltip/CustomTooltip";
import hasPlanPermission from "../../../../../utils/hasPlanPermission";
import toast from "react-hot-toast";
const MySwal = withReactContent(Swal);

// Function to get singular form for the label
const getSingularForm = (label) => {
  const exceptions = {
    Weaknesses: "Weakness",
    Opportunities: "Opportunity",
    Threats: "Threat",
    Strengths: "Strength",
  };

  return exceptions[label] || label.replace(/s$/, "");
};

const Swotkeys = ({
  strategicPlanId,
  swotValues,
  isItemSelected,
  updateFormDirty,
  showTabChangeModal,
  confirmTabChange,
  cancelTabChange,
  hasFetchedRef
}) => {
  const auth = useAuth();
  const navigate = useNavigate();
  const singularLabel = getSingularForm(swotValues?.swot_option_label);

  const fieldCount = 10; // Number of fields
  const validationSchema = SwotFormSchema(fieldCount, singularLabel);

  // Determine if editing mode should be enabled
  const [isEditing, setIsEditing] = useState(false);
  const [getMoreCount, setGetMoreCount] = useState(0);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [fullCriterias, setFullCriterias] = useState([]);
  const [criteriaData, setCriteriaData] = useState([]);
  const [selectedCriteria, setSelectedCriteria] = useState([]);
  const [refresh, setRefresh] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  // const [formData, setFormData] = useState({
  //   criteria1: "",
  //   criteria2: "",
  //   criteria3: "",
  //   criteria4: "",
  //   criteria5: "",
  //   criteria6: "",
  //   criteria7: "",
  // });
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
  const defaultValues = useMemo(() => {
    return swotValues?.criteria
      ? Object.keys(swotValues.criteria).reduce((acc, key) => {
        const criterion = swotValues.criteria[key];
        acc[`${singularLabel}-criteria${key.match(/\d+/)?.[0]}`] =
          criterion.criteria || "";
        return acc;
      }, {})
      : {};
  }, [swotValues, singularLabel]);

  const {
    control,
    handleSubmit,
    setValue,
    getValues,
    reset,
    // Used to set form field values
    formState: { errors, isDirty },
  } = useForm({
    resolver: yupResolver(validationSchema),
    mode: "onChange",
    defaultValues,
  });

  const { trigger, isMutating } = useApi(
    null,
    apiList.admin.organizationGoals.swot_save.call(),
    { method: "POST" }
  );

  const { trigger: genaratedAicriterias, isMutating: BELoading, mutationError } = useApi(
    null,
    apiList.admin.organizationGoals.genarate_swot_criterea.call(
      swotValues.swot_option_id
    ),
    { method: "POST" }
  );

  const { data: currentPlanData } = useApi(
    apiList.admin.subscription.current_plan.key(),
    apiList.admin.subscription.current_plan.call()
  );

  const {
    showModal: showRouteChangeModal,
    confirmNavigation,
    cancelNavigation,
  } = useUnsavedChanges(isDirty);

  useEffect(() => {
    updateFormDirty(isDirty);
  }, [isDirty, updateFormDirty]);

  useEffect(() => {
    if (isItemSelected) {
      reset(defaultValues, {
        keepDefaultValues: false,
        keepDirty: false
      });
    }
  }, [isItemSelected, reset, defaultValues]);

  // useEffect(() => {
  //   if (!BELoading) {
  //     if (getMoreCount == 0) getCriteriaWithlimitNumber();
  //   }
  // }, [BELoading]);


  useEffect(() => {
    if (mutationError?.status === 'error') {
      setErrorMsg(mutationError?.msg);
    }
  }, [mutationError]);

  const onSubmit = async (data) => {
    if (data) {
      try {
        const singularLabel = getSingularForm(swotValues?.swot_option_label);

        const filteredData = Object.keys(data).reduce((acc, key) => {
          if (key.startsWith(`${singularLabel}-criteria`)) {
            const match = key.match(/criteria(\d+)/);
            if (match) {
              const criteriaNumber = match[1];
              const criterionKey = `criteria${criteriaNumber}`;
              const criterionIdKey = `${criterionKey}_id`;
              const criterionValue = data[key];
              const criterionId = swotValues.criteria[criterionKey]?.id || null;
              acc[criterionKey] = criterionValue;
              if (criterionId) {
                acc[criterionIdKey] = criterionId;
              }
            }
          }
          return acc;
        }, {});

        const bodyData = {
          strategic_plan_id: strategicPlanId,
          swot_option: swotValues?.swot_option_id,
          ...filteredData,
        };

        const response = await trigger({ requestBody: bodyData });
        // after submit success
        getCriteria()
        reset(getValues());
        updateFormDirty(false);
        // Refresh data using mutate

        mutate(
          apiList.admin.organizationGoals.get_swotValues.key(
            auth?.user?.organization_id
          )
        );
        setIsEditing(false);
        MySwal.fire({
          html: (
            <div className="flex flex-col items-center">
              <div className="w-18 h-20 mb-2">
                <ProstrategyLogo />
              </div>
              <h2 className="text-xl font-semibold">Success!</h2>
              <p className="mt-2">{response?.data}</p>
            </div>
          ),
          confirmButtonText: "Okay",
          customClass: {
            confirmButton: "my-confirm-button",
          },
        });

      } catch (error) {
        console.error("Error during submission:", error);
      }
    }
  };

  useEffect(() => {
    const hasEmptyCriteria = Object.values(swotValues?.criteria || {}).every(
      (item) => !item.criteria
    );

    if (hasEmptyCriteria) {
      setIsEditing(true);
    } else {
      setIsEditing(false);

      // Reset form values when `swotValues` changes
      const updatedValues = swotValues?.criteria
        ? Object.keys(swotValues.criteria).reduce((acc, key) => {
          const criterion = swotValues.criteria[key];
          acc[`${singularLabel}-criteria${key.match(/\d+/)?.[0]}`] =
            criterion.criteria || ""; // Use existing values or empty strings
          return acc;
        }, {})
        : {};

      // Update form values in react-hook-form
      Object.entries(updatedValues).forEach(([key, value]) => {
        setValue(key, value);
      });
    }
  }, [swotValues, setValue, singularLabel]);

  useEffect(() => {
    setCriteriaData([]);
    setGetMoreCount(0);
    setSelectedCriteria([]);
    const hasEmptyCriteria = Object.values(swotValues?.criteria || {}).every(
      (item) => !item.criteria
    );
    if (swotValues.criteria && !hasFetchedRef.current) {
      getCriteria();
      hasFetchedRef.current = true

    }
  }, [swotValues.criteria, refresh]);

  const getCriteria = async () => {
    try {
      const bodyData = {
        strategic_plan_id: strategicPlan,
        swot_option: swotValues?.swot_option_label
      };
      let response = await genaratedAicriterias({ requestBody: bodyData });
      setFullCriterias(response?.data);
      if (response?.data?.length > 0) {
        setCriteriaData(response.data.slice(0, 15));
        setGetMoreCount(1);
      }
    } catch (error) {
      console.log(error);
      setErrorMsg(error?.msg)
      // toast.error(error?.msg || error?.message || error?.data.msg || 'failed to generate');
      // setIsOpen((prev) => !prev);
      // toast.error(error.data.message);
    } finally {
      //   setLoading(false)
    }
  };

  const CardView = () => {

    return (
      <div>
        <div className="flex flex-col gap-3">
          <PermissionWrapper resource={"org_swot_form"} actions={["edit"]}>
            <div className="flex justify-end">
              <Button
                className="mt-6"
                onPress={() => setIsEditing(true)}
                color="primary"
              >
                Edit
              </Button>
            </div>
          </PermissionWrapper>
          {Object.entries(swotValues.criteria).map(
            ([key, value], index) =>
              value.criteria && (
                <div key={value.id || key}>
                  <label className="text-sm text-gray-600">
                    {`${singularLabel} ${index + 1}`}
                  </label>{" "}
                  <br />
                  <Card
                    bordered
                    shadow="none"
                    radius="sm"
                    className="p-2 bg-[#F4F7FA] border text-start border-[#E2E9F0]"
                  >
                    {value.criteria}
                  </Card>
                </div>
              )
          )}
        </div>
      </div>
    );
  };

  if (hasPermission("org_swot_form", "read_only") && isEditing) {
    return (
      <>{swotValues?.swot_option_label} Not Available for This Organization</>
    );
  }

  const toggleDrawer = () => {

    if (errorMsg) {
      MySwal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>
            <h2 className="text-xl font-semibold">Warning!</h2>

            {errorMsg.includes("business targets") ? (
              <p className="mt-2">
                Please update your Business Targets to get AI Help.
              </p>
            ) : errorMsg.includes("SVA") ? (
              <p className="mt-2">
                Please update your SVA to get AI Help.
              </p>
            ) : (
              <p className="mt-2">
                Please update your Organization Profile to get AI Help.
              </p>
            )}
          </div>
        ),
        confirmButtonText: `Go to ${errorMsg.includes("business targets") ? 'Bussiness Targets' : errorMsg.includes("SVA") ? "SVA FORM" : "Organization Profile"
          } `,
        customClass: {
          confirmButton:
            "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
        },
      }).then((result) => {
        if (result.isConfirmed) {
          if (errorMsg.includes("business targets")) {
            navigate(`/organizationgoals/bussiness_target`);
          } else if (errorMsg.includes("SVA")) {
            navigate("/organizationgoals/svaform");
          } else {
            navigate("/settings/organization_tab");
          }
        }
      });

      return;
    }
    if (criteriaData.length === 0 && fullCriterias?.length > 0) {
      getCriteriaWithlimitNumber();
    }
    setDrawerOpen((prev) => !prev);

    // if (getMoreCount == 0) {
    //   getCriteriaWithlimitNumber();
    // }
    // if (Object.keys(swotValues.criteria)?.length > 0 || BELoading) {
    //   setDrawerOpen((prev) => !prev);
    // } else {
    //   // toast.error("Please update the Settings to get AI Help.");
    //   MySwal.fire({
    //     // Combine warning messages and additional text
    //     html: (
    //       <div className="flex flex-col items-center">
    //         <div className="w-18 h-20 mb-2">
    //           <ProstrategyLogo />
    //         </div>
    //         <h2 className="text-xl font-semibold">Warning!</h2>
    //         <p className="mt-2">Please update the Settings to get AI Help.</p>
    //       </div>
    //     ),
    //     confirmButtonText: "Go to Settings",
    //     customClass: {
    //       confirmButton:
    //         "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
    //     },
    //   }).then((result) => {
    //     if (result.isConfirmed) {
    //       navigate("/settings/organization_tab"); // Navigate to the settings page
    //     }
    //   });
    // }
  };

  const getCriteriaWithlimitNumber = () => {
    if (getMoreCount < 2 && fullCriterias?.length > criteriaData.length) {
      const nextDataStart = criteriaData.length;
      const nextDataEnd = nextDataStart + (getMoreCount === 0 ? 15 : 5);

      setCriteriaData((prevData) => [
        ...prevData,
        ...fullCriterias.slice(nextDataStart, nextDataEnd),
      ]);
      setGetMoreCount(getMoreCount + 1);
    }
  };

  // const getCriteriaWithlimitNumber = () => {
  //   // Only load if more data is available and count is less than 3

  //   if (getMoreCount < 2 && fullCriterias?.length > criteriaData.length) {
  //     const nextDataStart = getMoreCount == 0 ? getMoreCount : 15;
  //     const nextDataEnd = getMoreCount == 0 ? 15 : 20;
  //     // Append the next 4 items to the business essentials data
  //     setCriteriaData((prevData) => [
  //       ...prevData,
  //       ...fullCriterias.slice(nextDataStart, nextDataEnd),
  //     ]);
  //     // Increment the count for more data loading
  //     setGetMoreCount(getMoreCount + 1);
  //   }
  // };
  const handleSaveCriteria = (selectedCriteria) => {
    setSelectedCriteria(selectedCriteria); // still update local state if needed

    selectedCriteria.forEach((item, index) => {
      const fieldName = `${singularLabel}-criteria${index + 1}`;
      setValue(fieldName, item || "");
    });
  };

  return (
    <>
      <AiHelpSwotDrawer
        swotname={swotValues}
        drawerState={drawerOpen}
        setDrawerState={setDrawerOpen}
        title={
          <span className="font-semibold">
            AI Help -{" "}
            <span className="text-[#0098F5]">
              Create {swotValues?.swot_option_label}
            </span>
          </span>
        }
        criteriaDetails={swotValues.criteria}
        getCriteriaWithlimitNumber={getCriteriaWithlimitNumber}
        onSaveCriteria={handleSaveCriteria}
        criterias={criteriaData}
        getMoreCount={getMoreCount}
        BELoading={BELoading}
        selectedCriteria={selectedCriteria}
        setSelectedCriteria={setSelectedCriteria}
        type={"Organization_Foundations"}
      />
      {swotValues?.criteria && !isEditing ? (
        <CardView />
      ) : (
        <form onSubmit={handleSubmit(onSubmit)} noValidate>
          <div className="flex justify-between">
            <p className="mb-2">{`What are the Company's key ${swotValues?.swot_option_label}?`}</p>
            <Button
              radius="sm"
              color="primary"
              type="submit"
              className="mb-2"
              isLoading={isMutating}
            >
              Save Changes
            </Button>
            {hasPlanPermission("org_sva_swot_goals_ai") ? (
              <Button
                onPress={toggleDrawer}
                radius="sm"
                color="primary"
                className="mt-0 bg-[#39465F]"
              >
                <AiHelpIcon />
                AI Help
              </Button>
            ) : (
              <CustomTooltip
                tooltipTitle="Upgrade Plan"
                tooltipContent={
                  currentPlanData?.data?.plan_name == "Enterprise"
                    ? "Your current plan has limited features. Please Contact Admin"
                    : "Your current plan has limited features. Upgrade now to access more!"
                }
                buttonText={
                  currentPlanData?.data?.plan_name == "Enterprise"
                    ? null
                    : "Go to Plans"
                }
                navigateTo="/settings/account_tab" // The route to navigate
              />
            )}
          </div>

          <div className="flex flex-col space-y-4">
            {Array.from({ length: fieldCount }).map((_, index) => {
              const fieldName = `${singularLabel}-criteria${index + 1}`;
              return (
                <div key={fieldName}>
                  <Controller
                    name={fieldName}
                    control={control}
                    render={({ field }) => (
                      <Input
                        {...field}
                        labelPlacement="outside"
                        radius="sm"
                        variant="bordered"
                        placeholder={`Enter your ${singularLabel}`}
                        label={`${singularLabel} ${index + 1}`}
                        isRequired={index < 5} // Make the first 5 required
                        // className="capitalize"
                        isInvalid={!!errors[fieldName]}
                        errorMessage={errors[fieldName]?.message}
                        classNames={{
                          inputWrapper: [
                            "group-data-[focus=true]:border-[#0098F5]",
                            "dark:group-data-[focus=true]:border-[#0098F5]",
                          ],
                        }}
                      />
                    )}
                  />
                </div>
              );
            })}
          </div>
        </form>
      )}
      {showTabChangeModal && (
        <UnsavedChangesModal
          isConfirmNavigation={confirmTabChange}
          isCancelNavigation={cancelTabChange}
        />
      )}

      {showRouteChangeModal && (
        <UnsavedChangesModal
          isConfirmNavigation={confirmNavigation}
          isCancelNavigation={cancelNavigation}
        />
      )}
    </>
  );
};

export default Swotkeys;

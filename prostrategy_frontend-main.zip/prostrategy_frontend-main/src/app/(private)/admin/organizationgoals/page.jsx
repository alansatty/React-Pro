import { Card, CardBody } from "@nextui-org/card";
import { Tab, Tabs } from "@nextui-org/tabs";
import { useEffect, useState, useRef, useMemo } from "react";
import MissionTab from "./components/MissionTab";
import MissionIcon from "../../../../assets/icons/mission-icon";
import VisionIcon from "../../../../assets/icons/vision-icon";
import VisionTab from "./components/VisionTab";
import ValueIcon from "../../../../assets/icons/value-icon";
import SustainIcon from "../../../../assets/icons/sustain-icon";
import ValueTab from "./components/ValueTab";
import SustainTab from "./components/SustainTab";
import { useNavigate, useParams } from "react-router-dom";
import hasPlanPermission from "../../../../utils/hasPlanPermission";
import SwotIcon from "../../../../assets/icons/SwotIcon";
import SwotFormTab from "./components/SwotFormTab";
import AnalysisIcon from "../../../../assets/icons/analysis-icon";
import SwotAnalysisTab from "./components/swotAnalysisTab";
import GoalsAndStrategiesIcon from "../../../../assets/icons/goalsAndStrategies-icon";
import hasPermission from "../../../../utils/hasPermission";
import FileSearchIcon from "../../../../assets/icons/FileSearchIcon";
import SvaForm from "./components/SvaForm";
import SvaDashboard from "./components/SvaDashboard";
import DashboardIcon from "../../../../assets/icons/Sva-DashIcon";
import GoalsTab from "./components/GoalsTab";
import usePermissionsStore from "../../../../stores/usePermissionStore";
import { PageSpinner } from "../../../../components";
import BusinessTargetTab from "../settings/components/businessTargetTab";
import { useAuth } from "../../../../providers/authProviders";
import useApi from "../../../../hooks/useApi";
import { mutate } from "swr";
import { apiList } from "../../../../services";
import { IconTarget } from "@tabler/icons-react";
function CreateTitle({ title, Icon }) {
  return (
    <div className="flex items-center space-x-2">
      <Icon />
      <span>{title}</span>
    </div>
  );
}

function OrganizationGoals() {
  const auth = useAuth();
  const navigate = useNavigate();
  const { tabId } = useParams();
  const PlanPermissions = usePermissionsStore((state) => state.planPermissions);
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);

  const [customLoading, setCustomLoading] = useState(false);
  const tabRefs = useRef({});

  const { data, error, isLoading } = useApi(
    apiList.admin.settings.index.key(auth?.user?.organization_id),
    strategicPlan ? apiList.admin.settings.index.call(strategicPlan) : null,
  );

  const {
    data: ratingData,
    error: ratingError,
    isLoading: ratingLoading,
  } = useApi(
    apiList.admin.settings.get_rating.key(auth?.user?.organization_id),
    strategicPlan ? apiList.admin.settings.get_rating.call(strategicPlan) : null
  );

  const mutateFn = async () => {
    setCustomLoading(true);
    await mutate(
      apiList.admin.settings.get_rating.key(auth?.user?.organization_id)
    );
    setCustomLoading(false);
  };

  useEffect(() => {
    mutateFn();
  }, [strategicPlan]);

  const tabs = useMemo(() => {
    if (!PlanPermissions) return [];
    return [
      ...(hasPlanPermission("organization_business_targets")
        ? [
          {
            id: "bussiness_target",
            label: (<CreateTitle title="Business Targets" Icon={IconTarget} />),
            content: (
              <BusinessTargetTab
                key={strategicPlan}
                initialData={ratingData?.data}
              />
            ),
          },
        ]
        : []),

      ...(hasPlanPermission("mission_vision_value")
        ? [
          {
            id: "mission_tab",
            label: <CreateTitle title="Mission" Icon={MissionIcon} />,
            content: <MissionTab />,
          },
          {
            id: "vision_tab",
            label: <CreateTitle title="Vision" Icon={VisionIcon} />,
            content: <VisionTab />,
          },
          {
            id: "value_tab",
            label: <CreateTitle title="Value" Icon={ValueIcon} />,
            content: <ValueTab />,
          },
        ]
        : []),
      ...(hasPlanPermission("sustainable_objectives")
        ? [
          {
            id: "sustaining_tab",
            label: (
              <CreateTitle title="Organization Pillars" Icon={SustainIcon} />
            ),
            content: <SustainTab />,
          },
        ]
        : []),

      {
        id: "svaform",
        label: <CreateTitle title="SVA Form" Icon={FileSearchIcon} />,
        content: <SvaForm />,
      },

      ...(hasPlanPermission("sva_dashboard_allowed")
        ? [
          {
            id: "sva_dashboard",
            label: (<CreateTitle title="SVA Dashboard" Icon={DashboardIcon} />),
            content: <SvaDashboard />,
          },
        ]
        : []),

      {
        id: "swot_tab",
        label: <CreateTitle title="SWOT Form" Icon={SwotIcon} />,
        content: <SwotFormTab />,
      },

      ...(hasPlanPermission("swot_analysis")
        ? [
          {
            id: "analysis_tab",
            label: (<CreateTitle title="SWOT Dashboard" Icon={AnalysisIcon} />),
            content: <SwotAnalysisTab />,
          },
        ]
        : []),

      ...(hasPlanPermission("goal_strategic")
        ? [
          {
            id: "goals_tab",
            label: (
              <CreateTitle title="Goals" Icon={GoalsAndStrategiesIcon} />
            ),
            content: <GoalsTab />,
          },
        ]
        : []),
    ];
  }, [PlanPermissions, data?.data, ratingData?.data, strategicPlan]);

  // useEffect(() => {
  //   // If no tab is selected in the URL, default to "Sent"
  //   if (!tabId) {
  //     navigate("/organizationgoals/bussiness_target"); // Redirect to default tab
  //   }
  // }, [tabId, navigate]);
  useEffect(() => {
    if (!tabId && tabs?.length > 0) {
      navigate("/organizationgoals/bussiness_target");
    }
  }, [tabId, navigate, tabs]);

  useEffect(() => {
    if (tabId && tabRefs.current[tabId]) {
      tabRefs.current[tabId].scrollIntoView({
        behavior: "smooth",
        inline: "center",
        block: "nearest",
      });
    }
  }, [tabId]);

  if (!tabs || ratingLoading) {
    return <PageSpinner />;
  }

  return (
    <Card shadow="sm" radius="md" className="p-2">
      <CardBody>
        <h2 className="text-gray-700 font-semibold text-xl mt-2 ">
          Organization Foundations
        </h2>
        <div className="flex w-full flex-col mt-3">
          <Tabs
            key={tabId}
            selectedKey={tabId}
            aria-label="Dynamic tabs"
            color="primary"
            items={tabs}
            size="md"
            radius="sm"
            variant="underlined"
            classNames={{
              tabList:
                "gap-8 w-full relative rounded-none p-0 border-b border-divider !overflow-scroll  ",
              cursor: "w-full bg-[#0098F5]",
              tab: "max-w-fit px-2 h-12",

              tabContent: "group-data-[selected=true]:text-[#0098F5]",
            }}
            onSelectionChange={(key) => {
              navigate(`/organizationgoals/${key}`);
              setTimeout(() => {
                tabRefs.current[key]?.scrollIntoView({
                  behavior: "smooth",
                  inline: "center",
                  block: "nearest",
                });
              }, 0);
            }}
          >
            {(item) => (
              <Tab
                key={item.id}
                title={
                  <div ref={(el) => (tabRefs.current[item.id] = el)}>
                    {item.label}
                  </div>
                }
              >
                <Card shadow="none" radius="sm">
                  <CardBody>{item.content}</CardBody>
                </Card>
              </Tab>
            )}
          </Tabs>
        </div>
      </CardBody>
    </Card>
  );
}

export default OrganizationGoals;

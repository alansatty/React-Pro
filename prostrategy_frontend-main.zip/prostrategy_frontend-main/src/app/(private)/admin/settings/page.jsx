import React, { useEffect, useMemo, useState } from "react";
import OrganizationTab from "./components/organizationTab";
import { Tab, Tabs } from "@nextui-org/tabs";
import { Card, CardBody } from "@nextui-org/card";
import OrganizationIcon from "../../../../assets/icons/organization-icon";
import useApi from "../../../../hooks/useApi";
import { apiList } from "../../../../services";
import { PageSpinner } from "../../../../components";
import BusinessTargetTab from "./components/businessTargetTab";
import BusinessTargetIcon from "../../../../assets/icons/businessTarget-icon";
import { useAuth } from "../../../../providers/authProviders";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import hasPlanPermission from "../../../../utils/hasPlanPermission";
import usePermissionsStore from "../../../../stores/usePermissionStore";
import { mutate } from "swr";
import Strategicdata from "./components/strategicdata";
import AccountTab from "./components/AccountTab";
import { GeneralTab } from "../profile/components/GeneralTab";
import UsersIcon from "../../../../assets/icons/users";
// import { profile } from "../../../../services/admin/profile";

import InitialStrategicData from "../../../../assets/icons/Setup";
import AccountIcon from "../../../../assets/icons/Account";
import ProfileIcon from "../../../../assets/icons/Profile";
import TeamManagementTab from "./components/TeamManagementDropdown";
import StrategicPlans from "../strategicPlans/page";
import StrategicPlansIcon from "../../../../assets/icons/strategicPlans-icon";
import ProtectedRoute from "../../../../middleware/ProtectedRoute";
import ClientTrining from "./components/ClientTrining";
function CreateTitle({ title, Icon }) {
  return (
    <div className="flex items-center space-x-2">
      <Icon />
      <span>{title}</span>
    </div>
  );
}

const Settings = () => {
  const auth = useAuth();
  const { tabId } = useParams();
  const navigate = useNavigate();
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);

  const [customLoading, setCustomLoading] = useState(false);

  const { data, error, isLoading } = useApi(
    apiList.admin.settings.index.key(auth?.user?.organization_id, strategicPlan),
    strategicPlan ? apiList.admin.settings.index.call(strategicPlan) : null
  );

  const {
    data: ratingData,
    error: ratingError,
    isLoading: ratingLoading,
  } = useApi(
    apiList.admin.settings.get_rating.key(auth?.user?.organization_id, strategicPlan),
    strategicPlan ? apiList.admin.settings.get_rating.call(strategicPlan) : null
  );

  const mutateFn = async () => {
    setCustomLoading(true);
    await mutate(
      apiList.admin.settings.get_rating.key(auth?.user?.organization_id)
    );
    setCustomLoading(false);
  };

  useEffect(() => {
    mutateFn();
  }, [strategicPlan]);

  const tabs = useMemo(() => {
    const baseTabs = [
      {
        id: "general",
        label: <CreateTitle title="My Profile" Icon={ProfileIcon} />,
        content: <GeneralTab />,
      },

      {
        id: "organization_tab",
        label: (
          <CreateTitle title="Organization Profile" Icon={OrganizationIcon} />
        ),
        content: <OrganizationTab initialData={data?.data} />,
      },
      ...(hasPlanPermission("ai_organization_training") ? [
        {
          id: "client_training _tab",
          label: (
            <CreateTitle title="Client Training " Icon={OrganizationIcon} />
          ),
          content: <ClientTrining />,
        },
      ] : []),
      {
        id: "strategic_data_tab",
        label: (
          <CreateTitle
            title="Initial Strategic Data"
            Icon={InitialStrategicData}
          />
        ),
        content: <Strategicdata />,
      },
      {
        id: "team_management_tab",
        label: <CreateTitle title="Team Management" Icon={UsersIcon} />,
        content: <TeamManagementTab />,
      },
    ];


    // if (hasPlanPermission("organization_business_targets")) {
    //   baseTabs.push({
    //     id: "bussiness_target",
    //     label: (
    //       <CreateTitle
    //         title="Organization Business Targets"
    //         Icon={BusinessTargetIcon}
    //       />
    //     ),
    //     content: (
    //       <BusinessTargetTab
    //         key={strategicPlan}
    //         initialData={ratingData?.data}
    //       />
    //     ),
    //   });
    // }

    baseTabs.push({
      id: "account_tab",
      label: <CreateTitle title="Account" Icon={AccountIcon} />,
      content: <AccountTab />,
    }, {
      id: "strategic_plans",
      label: <CreateTitle title="Strategic Plans" Icon={StrategicPlansIcon} />,
      content: (
        <ProtectedRoute
          page={"strategic_plans"}
          action={"list"}
          planPermission={"strategy_plans_allowed_count"}
        >
          <StrategicPlans />
        </ProtectedRoute>
      ),
    });

    return baseTabs;
  }, [data?.data, ratingData?.data, hasPlanPermission, strategicPlan]);
  useEffect(() => {
    // If no tab is selected in the URL, default to "Sent"
    if (!tabId) {
      navigate("/settings/general"); // Redirect to default tab
    }
  }, [tabId, navigate]);

  if (isLoading || ratingLoading || customLoading) return <PageSpinner />;

  return (
    <Card shadow="sm" radius="md" className="p-2">
      <CardBody>
        <h2 className=" text-gray-700 font-semibold text-xl mt-2">Settings</h2>
        <div className="flex w-full flex-col mt-3">
          <Tabs
            key={tabId}
            selectedKey={tabId}
            aria-label="Dynamic tabs"
            color="primary"
            items={tabs}
            size="md"
            radius="sm"
            variant="underlined"
            classNames={{
              tabList:
                "gap-8 w-full relative rounded-none p-0 border-b border-divider",
              cursor: "w-full bg-[#0098F5]",
              tab: "max-w-fit px-2 h-12",
              tabContent: "group-data-[selected=true]:text-[#0098F5]",
            }}
            onSelectionChange={(key) => {
              // if (selectedItem) setSelectedItem(null)
              navigate(`/settings/${key}`);
            }}
          >
            {(item) => (
              <Tab key={item.id} title={item.label} activ>
                <Card shadow="none" radius="sm">
                  <CardBody>{item.content}</CardBody>
                </Card>
              </Tab>
            )}
          </Tabs>
        </div>
      </CardBody>
    </Card>
  );
};

export default Settings;

import useApi from "../../../../../hooks/useApi";
import { apiList } from "../../../../../services";
import { BillingHistoryTab } from "../../profile/components/BillingHistoryTab";
import { SubscriptionPlanTab } from "../../profile/components/SubscriptionPlanTab";

const AccountTab = () => {
  const { data, isLoading } = useApi(
    apiList.admin.subscription.current_plan.key(),
    apiList.admin.subscription.current_plan.call()
  );
  console.log('data', data);


  return (
    <>
      <div>
        <SubscriptionPlanTab data={data} />
        <div className="mt-20">
          <BillingHistoryTab />
        </div>
      </div>
    </>
  );
};

export default AccountTab;

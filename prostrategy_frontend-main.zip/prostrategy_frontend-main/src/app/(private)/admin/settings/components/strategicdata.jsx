
import { yupResolver } from "@hookform/resolvers/yup";
import { useEffect, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import hasPermission from "../../../../../utils/hasPermission";
import { Button } from "@nextui-org/button";
import useApi from "../../../../../hooks/useApi";
import { apiList } from "../../../../../services";
import usePermissionsStore from "../../../../../stores/usePermissionStore";
import { Input } from "@nextui-org/input";
import { Textarea } from "@nextui-org/input";
import { ChevronDown, ChevronRight } from "lucide-react";
import { Checkbox } from "@nextui-org/checkbox";
import { Select, SelectItem } from "@nextui-org/select";
import { mutate } from "swr";
import toast from "react-hot-toast";
import { cn } from "@nextui-org/theme";
import { Tooltip } from "@nextui-org/tooltip";
import { strategicdataFormSchema } from "../../../../../../validationSchema/authValidation"
import useUnsavedChanges from "../../../../../hooks/useUnsavedChanges";
import UnsavedChangesModal from "../../../../../components/Alert/UnsavedChangesModal";
import { IconInfoCircle } from "@tabler/icons-react";
import { Switch } from "@nextui-org/switch";

const FORMAT_OPTIONS = [
  { value: "dollar", label: "Dollar($)" },
  { value: "number", label: "Number" },
];

const generateYearOptions = () => {
  const currentYear = new Date().getFullYear();
  return Array.from({ length: 7 }, (_, i) => (currentYear - 1) + i);
};

const DEFAULT_METRIC = {
  include: false,
  metric: "",
  metric_format: "",
  data_form_question: "",
  help_text: "",
  calculation_type: "static",
  calculation_static_status: "beginning_of_development",
  percentage_of_growth: false,
  value: ""
};

const generateDefaultMetrics = (initialMetrics = []) => {


  return Array.from({ length: 8 }, (_, i) => ({
    id: i + 1,
    ...DEFAULT_METRIC,
    ...(initialMetrics[i] || {})
  }));
};

export default function StrategicData() {
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
  const [isLoading, setIsLoading] = useState(false);
  const [isUserMadeChanges, setIsUserMadeChange] = useState(false);
  const [expandedMetrics, setExpandedMetrics] = useState(
    Array.from({ length: 8 }, (_, i) => i + 1).reduce((acc, id) => {
      acc[id] = false;
      return acc;
    }, {})
  );

  // API hooks
  const { data: initialStrategyData, error } = useApi(
    strategicPlan ? apiList.admin.settings.get_startegyData.key(strategicPlan, false) : null,
    strategicPlan ? apiList.admin.settings.get_startegyData.call(strategicPlan, false) : null
  );

  const { trigger: saveStrategyData, isMutating } = useApi(
    null,
    strategicPlan ? apiList.admin.settings.strategydata_create.call(strategicPlan) : null,
    { method: "POST" }
  );

  // Form setup
  const {
    control,
    handleSubmit,
    formState: { errors, isDirty },
    reset,
    trigger: triggerValidation,
    watch,
    setValue,
  } = useForm({
    mode: "onChange",
    reValidateMode: "onChange",
    resolver: yupResolver(strategicdataFormSchema),
    defaultValues: {
      start_year: initialStrategyData?.data?.start_year || "",
      metrics: generateDefaultMetrics(initialStrategyData?.data?.metrics)
    }
  });

  const { showModal, confirmNavigation, cancelNavigation } = useUnsavedChanges(isUserMadeChanges);

  // Helper functions

  console.log('error', error);
  useEffect(() => {
    if (initialStrategyData?.data) {
      // Success case - reset with API data
      reset({
        start_year: initialStrategyData.data.start_year || "",
        metrics: generateDefaultMetrics(initialStrategyData.data.metrics)
      });
    } else if (error?.error_key === "initial_strategy_settings") {

      reset({
        start_year: "",
        metrics: generateDefaultMetrics()
      });
    }
  }, [initialStrategyData, error, reset]);

  const parseNumberValue = (value) => {
    if (!value && value !== 0) return "";
    if (typeof value === 'number') return value;
    if (typeof value === 'string') {
      return value.replace(/,/g, '').split('.')[0] || "";
    }
    return "";
  };

  const formatNumberWithCommas = (value) => {
    if (!value && value !== 0) return "";
    if (typeof value === 'string' && value.includes(',')) return value;
    const numValue = Number(value);
    return isNaN(numValue) ? "" : new Intl.NumberFormat('en-US').format(numValue);
  };

  const toggleMetricExpansion = (metricId) => {
    setExpandedMetrics(prev => ({
      ...prev,
      [metricId]: !prev[metricId]
    }));
  };

  // Effects
  //   useEffect(() => {
  //   if (initialStrategyData?.data) {
  //     const resetData = {
  //       start_year: initialStrategyData.data.start_year || "",
  //       metrics: generateDefaultMetrics(initialStrategyData.data.metrics)
  //     };
  //     reset(resetData);
  //   }
  // }, [initialStrategyData, reset]);
  useEffect(() => {
    if (initialStrategyData?.data) {
      reset({
        start_year: initialStrategyData.data.start_year || "",
        metrics: generateDefaultMetrics(initialStrategyData.data.metrics)
      });
    }
  }, [initialStrategyData, reset]);

  // Add this effect to trigger validation when include changes
  useEffect(() => {
    const subscription = watch((value, { name }) => {
      if (name?.startsWith('metrics') && name?.includes('include')) {
        triggerValidation();
      }
    });
    return () => subscription.unsubscribe();
  }, [watch, triggerValidation]);

  // Handlers
  const handleSave = () => {
    if (errors.metrics) {
      const erroredMetricIndex = watch("metrics").findIndex((_, index) =>
        errors.metrics?.[index]
      );

      if (erroredMetricIndex !== -1) {
        const metricId = watch("metrics")[erroredMetricIndex].id;
        setExpandedMetrics(prev => ({ ...prev, [metricId]: true }));
      }
    }
  };

  const onSubmit = async (data) => {
    console.log("data", data);

    // removing values from static metrics and removing static status from dynamic metrics
    const submissionData = {
      ...data,
      metrics: data.metrics.map(metric => metric.calculation_type === 'static' ? {
        ...metric,
        value: ''
      } : metric
      )
    }
    console.log('submissionData', submissionData);


    try {
      const isValid = await triggerValidation();
      if (!isValid) return;
      setIsLoading(true);

      const formData = new FormData();
      Object.entries(submissionData).forEach(([key, value]) => {
        if (key === 'metrics' || key === 'data_values') {
          formData.append(key, JSON.stringify(value));
        } else {
          formData.append(key, String(value));
        }
      });

      const res = await saveStrategyData({ requestBody: formData });

      if (res.error) {
        toast.error(res.error);
        return;
      }

      if (res) {
        // Fixed: Use the correct structure that matches your form defaultValues
        // const resetData = {
        //   start_year: res.start_year || "",
        //   metrics: generateDefaultMetrics(res.metrics) // This ensures proper structure
        // };

        // reset(resetData);

        // Mutate the SWR cache to refresh data
        mutate(apiList.admin.strategicPlanWithIntialData.list.key(strategicPlan));
        mutate(apiList.admin.departmentStrategies.get_metricQuestions.key(strategicPlan));
        mutate(apiList.admin.settings.get_startegyData.key(strategicPlan, false));

        toast.success("Strategic Data Settings saved successfully");
        setIsUserMadeChange(false);
      }
    } catch (error) {
      console.error("API Error:", error);
      toast.error(error.message || "Failed to save changes.");
    } finally {
      setIsLoading(false);
    }
  };
  // Render helpers
  const renderYearSelect = ({ field }) => (
    <div className="space-y-2 relative">
      <label htmlFor="start_year" className="text-sm font-medium text-gray-900">
        As of year end <span className="text-red-500">*</span>
      </label>
      <div className="relative">
        <select
          {...field}
          id="start_year"
          className={cn(
            "border-2 rounded-md px-3 py-2 w-full h-12 appearance-none cursor-pointer pr-8",
            "focus:ring-2 focus:ring-blue-500 focus:border-blue-500",
            errors?.start_year ? "border-red-500" : "border-gray-300"
          )}
          aria-invalid={!!errors?.start_year}
          onChange={(e) => {
            setIsUserMadeChange(true)
            field.onChange(e)
          }
          }
        >
          <option value="" disabled hidden>Select Year</option>
          {generateYearOptions().map((year) => (
            <option key={year} value={year}>{year}</option>
          ))}
        </select>
        <div className="pointer-events-none absolute right-0 inset-y-0 flex items-center pr-3">
          <svg className="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
          </svg>
        </div>
      </div>
      {errors?.start_year && (
        <p className="mt-1 text-sm text-red-600">{errors.start_year.message}</p>
      )}
    </div>
  );

  const renderMetricItem = (metric, index) => {
    const isExpanded = expandedMetrics[metric.id];
    return (
      <div key={metric.id}>
        <div className="flex items-center justify-between mb-4">
          <button
            type="button"
            onClick={() => toggleMetricExpansion(metric.id)}
            className="flex items-center gap-2 text-md font-semibold text-gray-900 transition-colors"
          >
            {isExpanded ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
            <p className="text-black">{metric?.metric || `User Chosen Metric #${index + 1}`}</p>
          </button>
          <div className="flex items-center gap-3">
            <Controller
              name={`metrics.${index}.include`}
              control={control}
              render={({ field }) => (
                <div className="flex items-center ">
                  <Checkbox
                    {...field}
                    id={`include-${metric.id}`}
                    isSelected={field.value}
                    onValueChange={(isChecked) => {
                      setIsUserMadeChange(true)
                      field.onChange(isChecked);
                      if (isChecked) {
                        setExpandedMetrics(prev => ({ ...prev, [metric.id]: true }));
                      }
                    }}
                    className="data-[state=checked]:bg-[#0098F5]] data-[state=checked]:border-blue-600"
                  />
                  <label htmlFor={`include-${metric.id}`} className="text-sm font-medium text-[#0098F5]"
                  >
                    Include
                  </label>
                </div>
              )}
            />
          </div>
        </div>

        {isExpanded && (
          <div className="space-y-4 pl-7 border-l-2 border-gray-100">
            {/* Metric Name */}
            <Controller
              name={`metrics.${index}.metric`}
              control={control}
              render={({ field }) => {

                const hasError = !!errors?.metrics?.[index]?.metric;
                const lengthValidationMsg = errors?.metrics?.[index]?.metric?.message

                return (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <label htmlFor={`metric-${metric.id}`} className="text-sm font-medium text-gray-700">
                        Metric {metric.include && <span className="text-red-500">*</span>}
                      </label>
                      <Tooltip content="This value remains constant across all Strategic plans.">
                        <span><InfoIcon /></span>
                      </Tooltip>
                    </div>
                    <Input
                      {...field}
                      id={`metric-${metric.id}`}
                      placeholder="Enter metric name"
                      className="h-12"
                      isInvalid={hasError}
                      errorMessage={errors?.metrics?.[index]?.metric?.message}
                      onChange={(e) => {
                        field.onChange(e)
                        setIsUserMadeChange(true)
                      }
                      }
                      // here presisting typing if we got characters length error
                      onKeyDown={(e) => {
                        if (lengthValidationMsg === 'Metric must be 20 characters or less' && e.key !== 'Backspace' && e.key !== 'Delete') {
                          e.preventDefault();
                        }
                      }}
                    />
                  </div>
                );
              }}
            />

            {/* Metric Format */}
            <Controller
              name={`metrics.${index}.metric_format`}
              control={control}
              render={({ field }) => (
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <label htmlFor={`format-${metric.id}`} className="text-sm font-medium text-gray-700">
                      Metric Format
                    </label>
                    <Tooltip content="This value remains constant across all Strategic plans.">
                      <span><InfoIcon /></span>
                    </Tooltip>
                    {metric.include && <span className="text-red-500">*</span>}
                  </div>
                  <Select
                    {...field}
                    aria-label="Select format"
                    selectedKeys={field.value ? [field.value] : []}
                    onChange={(e) => {
                      setIsUserMadeChange(true)
                      field.onChange(e)
                    }
                    }
                    className="w-full"
                    isInvalid={!!errors?.metrics?.[index]?.metric_format}
                    errorMessage={errors?.metrics?.[index]?.metric_format?.message}
                    placeholder="Select a format"
                  >
                    {FORMAT_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </Select>
                </div>
              )}
            />

            {/* Data Form Question */}
            <Controller
              name={`metrics.${index}.data_form_question`}
              control={control}
              render={({ field }) => (
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <label htmlFor={`question-${metric.id}`} className="text-sm font-medium text-gray-700">
                      Data Form Question {metric.include && <span className="text-red-500">*</span>}
                    </label>
                    <Tooltip content="This value remains constant across all Strategic plans.">
                      <span><InfoIcon /></span>
                    </Tooltip>
                  </div>
                  <Textarea
                    {...field}
                    id={`question-${metric.id}`}
                    placeholder="Enter the question for data collection"
                    onChange={(e) => {
                      field.onChange(e)
                      setIsUserMadeChange(true)
                    }
                    }
                    className="min-h-[100px] resize-none"
                    isInvalid={!!errors?.metrics?.[index]?.data_form_question}
                    errorMessage={errors?.metrics?.[index]?.data_form_question?.message}
                  />
                </div>
              )}
            />

            {/* Help Text */}
            <Controller
              name={`metrics.${index}.help_text`}
              control={control}
              render={({ field }) => (
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <label htmlFor={`help-${metric.id}`} className="text-sm font-medium text-gray-700">
                      Help Text {metric.include && <span className="text-red-500">*</span>}
                    </label>
                    <Tooltip content="This value remains constant across all Strategic plans.">
                      <span><InfoIcon /></span>
                    </Tooltip>
                  </div>
                  <Textarea
                    {...field}
                    id={`help-${metric.id}`}
                    placeholder="Enter the help text for data collection"
                    onChange={(e) => {
                      field.onChange(e)
                      setIsUserMadeChange(true)
                    }}
                    className="min-h-[100px] resize-none"
                    isInvalid={!!errors?.metrics?.[index]?.help_text}
                    errorMessage={errors?.metrics?.[index]?.help_text?.message}
                  />
                </div>
              )}
            />

            {/* Calculation Type */}
            <Controller
              name={`metrics.${index}.calculation_type`}
              control={control}
              render={({ field }) => (
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <label htmlFor={`calculation-${metric.id}`} className="text-sm font-medium text-gray-700">
                      Calculation Type {metric.include && <span className="text-red-500">*</span>}
                    </label>
                    <Tooltip content={
                      <div>
                        <p>Static: Value will be taken from the strategic form data.</p>
                        <p> Dynamic: Value will be calculated based on the input value you provide below.</p>
                      </div>
                    }>
                      <span><InfoIcon /></span>
                    </Tooltip>
                  </div>

                  <div className="flex items-center gap-4 mt-1">
                    <RadioOption
                      id={`static-${metric.id}`}
                      name={`calculation-type-${metric.id}`}
                      checked={field.value === "static"}
                      onChange={() => {
                        field.onChange("static")
                        setIsUserMadeChange(true)

                      }
                      }
                      label="Static"
                    />
                    <RadioOption
                      id={`dynamic-${metric.id}`}
                      name={`calculation-type-${metric.id}`}
                      checked={field.value === "dynamic"}
                      onChange={() => {
                        setIsUserMadeChange(true)
                        field.onChange("dynamic")
                      }
                      }
                      label="Dynamic"
                    />
                  </div>
                  {errors?.metrics?.[index]?.calculation_type && (
                    <p className="mt-1 text-sm text-red-600">
                      {errors.metrics[index].calculation_type.message}
                    </p>
                  )}
                </div>
              )}
            />


            {watch(`metrics.${index}.calculation_type`) === "static" && (
              <div className="space-y-2">
                <Controller
                  name={`metrics.${index}.calculation_static_status`}
                  control={control}
                  render={({ field }) => (
                    <>
                      <div className="flex items-center gap-2">
                        <label htmlFor={`static-status-${metric.id}`} className="text-sm font-medium text-gray-700">
                          Static Status {metric.include && <span className="text-red-500">*</span>}
                        </label>
                        <Tooltip
                          content={
                            <div className="space-y-1">
                              <p>Beginning of Development: The metric is in the early stages of development.</p>
                              <p>Beginning of Production: The metric is in the early stages of production.</p>
                            </div>
                          }
                        >
                          <span className="cursor-pointer">
                            <InfoIcon className="w-4 h-4 text-gray-500" />
                          </span>
                        </Tooltip>
                      </div>

                      <div className="flex items-center gap-4 mt-1">
                        <RadioOption
                          id={`static-${metric.id}-development`}
                          name={`static-status-${metric.id}`}
                          checked={field.value === "beginning_of_development"}
                          onChange={() => {
                            field.onChange("beginning_of_development")
                            setIsUserMadeChange(true)
                          }
                          }
                          label="Beginning of Development"
                        />
                        <RadioOption
                          id={`static-${metric.id}-production`}
                          name={`static-status-${metric.id}`}
                          checked={field.value === "beginning_of_production"}
                          onChange={() => {
                            field.onChange("beginning_of_production")
                            setIsUserMadeChange(true)

                          }
                          }
                          label="Beginning of Production"
                        />
                      </div>
                    </>
                  )}
                />

                {errors?.metrics?.[index]?.calculation_static_status && (
                  <p className="mt-1 text-sm text-red-600">
                    {errors.metrics[index].calculation_static_status.message}
                  </p>
                )}
              </div>
            )}

            {/* Dynamic Value Input */}
            {watch(`metrics.${index}.calculation_type`) === "dynamic" && (
              <Controller
                name={`metrics.${index}.value`}
                control={control}
                render={({ field }) => {
                  const displayValue = formatNumberWithCommas(field.value);
                  return (
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <label htmlFor={`value-${metric.id}`} className="text-sm font-medium text-gray-700">
                          Value as of year ({watch("start_year") || "selected"}) end {metric.include && <span className="text-red-500">*</span>}
                        </label>
                        <Tooltip content="This value adjusts dynamically for each strategic plan">
                          <span><InfoIcon /></span>
                        </Tooltip>
                      </div>
                      <Input
                        {...field}
                        id={`value-${metric.id}`}
                        value={displayValue}
                        onChange={(e) => {
                          const rawValue = e.target.value.replace(/\D/g, "");
                          field.onChange(rawValue);
                          setIsUserMadeChange(true)
                        }}
                        placeholder="Enter value"
                        className="h-12"
                        isInvalid={!!errors?.metrics?.[index]?.value}
                        errorMessage={errors?.metrics?.[index]?.value?.message}
                      />
                    </div>
                  );
                }}
              />
            )}

            {/* Percentage of Growth Section - Fixed Version */}
            <div className="space-y-2 pt-4">
              <Controller
                name={`metrics.${index}.percentage_of_growth`}
                control={control}
                render={({ field }) => (
                  <>
                    <div className="flex items-center gap-2">
                      <label htmlFor={`percentage-of-growth-${metric.id}`} className="text-sm font-medium text-gray-700">
                        Percentage of Growth
                      </label>
                      <Tooltip
                        content="Display percentage growth compared to previous period"
                      >
                        <span className="cursor-pointer">
                          <InfoIcon className="w-4 h-4 text-gray-500" />
                        </span>
                      </Tooltip>
                    </div>

                    <div className="flex items-center gap-2 mt-1">
                      <Switch
                        id={`percentage-of-growth-${metric.id}`}
                        isSelected={field.value}
                        onValueChange={(isSelected) => {
                          field.onChange(isSelected);
                          setIsUserMadeChange(true);
                        }}
                      />
                      <span className="text-sm font-medium text-gray-700">
                        {field.value ? "Yes" : "No  "}
                      </span>
                    </div>
                  </>
                )}
              />

              {/* Show correct error message */}
              {/* {errors?.metrics?.[index]?.percentage_of_growth && (
                <p className="mt-1 text-sm text-red-600">
                  {errors.metrics[index].percentage_of_growth.message}
                </p>
              )} */}
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="">
      {showModal && (
        <UnsavedChangesModal
          isConfirmNavigation={confirmNavigation}
          isCancelNavigation={cancelNavigation}
        />
      )}
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
        <Controller
          name="start_year"
          control={control}
          render={renderYearSelect}
        />

        <div className="space-y-6">
          {watch("metrics").map((metric, index) => renderMetricItem(metric, index))}
        </div>
        <div className="flex text-gray">
          <div>
            <IconInfoCircle className="w-5" />
          </div>
          <span className="ms-2 text-sm mt-1 font-medium">
            Only included metrics will appear in the data form.
          </span>
        </div>
        {hasPermission("org_settings", "edit") && (
          <div className="mt-2">
            <Button
              radius="sm"
              isLoading={isMutating || isLoading}
              color="primary"
              className="text-sm font-medium bg-[#0098F5]"
              isDisabled={isMutating}
              type="submit"
              onPress={handleSave}
            >
              {isMutating || isLoading ? "Saving..." : "Save Changes"}
            </Button>
          </div>
        )}
      </form>
    </div>
  );
}

// Helper components
const InfoIcon = () => (
  <div className="mb-1 cursor-pointer">
    <svg
      xmlns="http://www.w3.org/2000/svg"
      className="h-4 w-4 text-gray-400"
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
      />
    </svg>
  </div>
);

const RadioOption = ({ id, name, checked, onChange, label }) => (
  <div className="flex items-center gap-2">
    <input
      type="radio"
      id={id}
      name={name}
      checked={checked}
      onChange={onChange}
      className="h-4 w-4 border-gray-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
    />
    <label
      htmlFor={id}
      className="text-sm text-gray-700 cursor-pointer select-none font-medium"
    >
      {label}
    </label>
  </div>
);

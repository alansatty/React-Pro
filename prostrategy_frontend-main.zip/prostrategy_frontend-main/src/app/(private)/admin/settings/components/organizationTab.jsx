import { Button } from "@nextui-org/button";
import { Input, Textarea } from "@nextui-org/input";
import { FormInput } from "../../../../../components";
import useApi from "../../../../../hooks/useApi";
import { apiList } from "../../../../../services";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import toast from "react-hot-toast";
import { organizationSchema } from "../../../../../../validationSchema/authValidation";
import { useEffect, useMemo, useState } from "react";
import AlerModal from "../../../../../components/Alert/AlertModal";
import Swal from "sweetalert2/dist/sweetalert2.js";
import hasPermission from "../../../../../utils/hasPermission";
import { mutate } from "swr";
import { useAuth } from "../../../../../providers/authProviders";
import ProstrategyLogo from "../../../../../assets/icons/ProstrategyLogo";
import withReactContent from "sweetalert2-react-content";
import UnsavedChangesModal from "../../../../../components/Alert/UnsavedChangesModal";
import useUnsavedChanges from "../../../../../hooks/useUnsavedChanges";
import { IconTrash } from "@tabler/icons-react";
import AiHelpIcon from "../../../../../assets/icons/aihelp-icon";
import AiHelpDescriptionDrawer from "./AiHelpDescription";
import usePermissionsStore from "../../../../../stores/usePermissionStore";

const Myswal = withReactContent(Swal);

function OrganizationTab({ initialData }) {
  const auth = useAuth();
  const [isAlert, setIsAlert] = useState(false);
  const [load, setIsLoad] = useState(false);
  const [userMadeChanges, setUserMadeChanges] = useState(false);
  const [imageSrc, setImageSrc] = useState(null);
  const [imageWasDeleted, setImageWasDeleted] = useState(false);
  const [originalImageFile, setOriginalImageFile] = useState(null);

  const [imageSrcAgent, setImageSrcAgent] = useState(null);
  const [imageWasDeletedAgent, setImageWasDeletedAgent] = useState(false);
  const [originalImageFileAgent, setOriginalImageFileAgent] = useState(null);

  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
  const [orgType, setOrgType] = useState(initialData?.organization_type || "");
  const [orgName, setOrgName] = useState(initialData?.organization_name || "");
  const [orgAgentLink, setOrgAgentLink] = useState(
    initialData?.organization_agent_link || ""
  );
  const [agentName, setagentName] = useState(
    initialData?.organization_agent_name || ""
  );
  const [market, setAgentmarket] = useState(
    initialData?.organization_geographical_market_focus || ""
  );


  // AI Help state management
  const [aiHelpState, setAiHelpState] = useState({
    drawerOpen: false,
    descriptions: [],
    selectedDescription: "",
    loading: false,
    getMoreCount: 0,
    fullDescriptions: [],
  });

  const {
    data: currentPlanData,
    error: planError,
    isLoading: currentPlanDataLoading,
  } = useApi(
    apiList.admin.subscription.current_plan.key(),
    apiList.admin.subscription.current_plan.call()
  );


  const { trigger, isMutating } = useApi(
    null,
    strategicPlan ? apiList.admin.settings.update.call(strategicPlan) : null,
    { method: "POST" }
  );

  const { trigger: triggerGenerateDescription, isMutating: BELoading } = useApi(
    null,
    apiList.admin.settings.generate_organization_description.call(strategicPlan),
    { method: "POST" }
  );

  useEffect(() => {
    if (initialData?.organization_type) {
      setOrgType(initialData.organization_type);
    } else {
      setOrgType("");
    }

    if (initialData?.organization_name) {
      setOrgName(initialData.organization_name);
    } else {
      setOrgName("");
    }
    if (initialData?.organization_agent_link) {
      setOrgAgentLink(initialData.organization_agent_link);
    } else {
      setOrgAgentLink("");
    }
    if (initialData?.organization_agent_name) {
      setagentName(initialData.organization_agent_name);
    } else {
      setagentName("");
    }
    if (initialData?.organization_geographical_market_focus) {
      setAgentmarket(initialData.organization_geographical_market_focus);
    } else {
      setAgentmarket("");
    }

    if (initialData?.organization_agent_logo) {
      setOriginalImageFileAgent(initialData.organization_agent_logo);
    } else {
      setOriginalImageFileAgent(null);
    }

  }, [initialData]);

  const defaultValues = useMemo(() => {
    return {
      organization_description:
        initialData?.organization_description === "null"
          ? ""
          : initialData?.organization_description || "",
      organization_web_address:
        initialData?.organization_web_address === "null"
          ? ""
          : initialData?.organization_web_address || "",
      organization_logo: initialData?.organization_logo || null,
      organization_agent_logo: initialData?.organization_agent_logo || null,

    };
  }, [initialData]);

  const {
    register,
    handleSubmit,
    formState: { errors, isDirty },
    reset,
    clearErrors,
    setValue,
    getValues,
    watch,
    setError,
  } = useForm({
    mode: "onChange",
    resolver: yupResolver(organizationSchema),
    defaultValues,
  });

  const orgDescription = watch("organization_description");

  const { showModal, confirmNavigation, cancelNavigation } = useUnsavedChanges(
    isDirty || userMadeChanges
  );

  const handleFileChange = (event) => {
    event.preventDefault();
    setUserMadeChanges(true);

    const file = event.target.files?.[0];
    clearErrors("organization_logo");

    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => setImageSrc(e.target.result);
    reader.readAsDataURL(file);
    setValue("organization_logo", file, { shouldValidate: true });
    setOriginalImageFile(file);
  };

  // const handleFileChangeAgent = (event) => {
  //   event.preventDefault();
  //   setUserMadeChanges(true);

  //   const file = event.target.files?.[0];
  //   clearErrors("organization_agent_logo");

  //   if (!file) return;

  //   const reader = new FileReader();
  //   reader.onload = (e) => setImageSrcAgent(e.target.result);
  //   reader.readAsDataURL(file);
  //   setValue("organization_agent_logo", file, { shouldValidate: true });
  //   setOriginalImageFileAgent(file);
  // };

  useEffect(() => {
    if (initialData?.organization_logo) {
      setImageSrc(initialData.organization_logo);
      setValue("organization_logo", initialData.organization_logo, {
        shouldValidate: false,
      });
    } else {
      reset((prevValues) => ({
        ...prevValues,
        organization_logo: null,
      }));
      setImageSrc(null); // Clear image preview if you're using this for preview
    }

    if (initialData?.organization_agent_logo) {
      setImageSrcAgent(initialData.organization_agent_logo);
      setValue("organization_agent_logo", initialData.organization_agent_logo);
    } else {
      reset((prevValues) => ({
        ...prevValues,
        organization_agent_logo: null,
      }));
      setImageSrcAgent(null); // Clear image preview if you're using this for preview
    }

    if (initialData?.organization_description) {
      setValue(
        "organization_description",
        initialData.organization_description,
        {
          shouldValidate: false,
        }
      );
    } else {
      reset((prevValues) => ({
        ...prevValues,
        organization_description: "",
      }));
    }

    if (initialData?.organization_web_address) {
      setValue(
        "organization_web_address",
        initialData.organization_web_address,
        {
          shouldValidate: false,
        }
      );
    } else {
      reset((prevValues) => ({
        ...prevValues,
        organization_web_address: "",
      }));
    }
  }, [initialData, setValue, reset, strategicPlan]);

  const generateDescription = async () => {
    try {
      setAiHelpState((prev) => ({ ...prev, loading: true }));

      const formData = new FormData();
      formData.append("organization_name", orgName);
      formData.append("organization_type", orgType);
      formData.append("organization_web_address", getValues().organization_web_address);
      formData.append("organization_geographical_market_focus", market);

      const response = await triggerGenerateDescription({
        requestBody: formData,
      });

      setAiHelpState((prev) => ({
        ...prev,
        descriptions: response?.data?.slice(0, 15) || [],
        fullDescriptions: response?.data || [],
        loading: false,
        getMoreCount: 0,
      }));
    } catch (error) {
      console.error("Error generating description:", error);
      setAiHelpState((prev) => ({ ...prev, loading: false }));
      toast.error("Failed to generate descriptions");
    }
  };

  const toggleDrawer = () => {
    if (aiHelpState.drawerOpen) {
      // Closing drawer - reset selection
      setAiHelpState((prev) => ({
        ...prev,
        drawerOpen: false,
        selectedDescription: "",
      }));
    } else {
      const newErrors = {};

      if (!orgName.trim()) {
        newErrors.organization_name = {
          type: "required",
          message: "Organization Name is required",
        };
      }

      if (!orgType.trim()) {
        newErrors.organization_type = {
          type: "required",
          message: "Organization type is required",
        };
      }

      if (Object.keys(newErrors).length > 0) {
        // Set errors for missing fields
        Object.entries(newErrors).forEach(([name, error]) => {
          setError(name, error);
        });

        // Show error toast
        toast.error("Please fill in required fields to generate descriptions");
        return;
      }

      // Only generate descriptions if we don't have them already
      if (aiHelpState.fullDescriptions.length === 0) {
        generateDescription();
      }
      setAiHelpState((prev) => ({ ...prev, drawerOpen: true }));
    }
  };

  const handleGetMoreDescriptions = () => {
    if (aiHelpState.getMoreCount < 2) {
      const nextDataStart = aiHelpState.getMoreCount === 0 ? 15 : 20;
      const nextDataEnd = nextDataStart + 5; // Get next 5 descriptions

      setAiHelpState((prev) => ({
        ...prev,
        descriptions: [
          ...prev.descriptions,
          ...(prev.fullDescriptions?.slice(nextDataStart, nextDataEnd) || []),
        ],
        getMoreCount: prev.getMoreCount + 1,
      }));
    }
  };

  const handleSelectDescription = (description) => {
    setAiHelpState((prev) => ({ ...prev, selectedDescription: description }));
  };

  const handleUseDescription = () => {
    if (!aiHelpState.selectedDescription) {
      toast.error("Please select a description first");
      return;
    }

    setValue("organization_description", aiHelpState.selectedDescription, {
      shouldValidate: true,
      shouldDirty: true,
      shouldTouch: true,
    });

    setUserMadeChanges(true);

    // Close drawer and reset AI state
    setAiHelpState({
      drawerOpen: false,
      descriptions: [],
      selectedDescription: "",
      loading: false,
      getMoreCount: 0,
      fullDescriptions: [],
    });
  };

  const validateField = (fieldName, value) => {
    // Create a mapping of field names to display names
    const fieldDisplayNames = {
      organization_name: "Organization name",
      organization_type: "Organization type",
      organization_agent_name: "Agent name",
      organization_agent_link: "Agent link",
      organization_geographical_market_focus: " Market area",
    };

    // Get the display name, defaulting to the fieldName if not found in the mapping
    const displayName = fieldDisplayNames[fieldName] || fieldName.replace(/_/g, ' ');

    if (fieldName === "organization_agent_link") {
      // If empty, it's valid (assuming it's optional)
      if (!value.trim()) {
        clearErrors(fieldName);
        return true;
      }

      // URL validation using regex
      const urlPattern =
        /^(https?:\/\/)?(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&//=]*)$/;
      if (!urlPattern.test(value)) {
        setError(fieldName, {
          type: "format",
          message: "Please enter a valid URL",
        });
        return false;
      } else {
        clearErrors(fieldName);
        return true;
      }
    }

    if (!value.trim()) {
      setError(fieldName, {
        type: "required",
        message: `${displayName} is required`,
      });
      return false;
    } else if (value.trim().length < 3) {
      setError(fieldName, {
        type: "min",
        message: `${displayName} must be at least 3 characters`,
      });
      return false;
    } else if (value.trim().length > 200) {
      setError(fieldName, {
        type: "max",
        message: `${displayName} cannot exceed 200 characters`,
      });
      return false;
    } else {
      clearErrors(fieldName);
      return true;
    }
  };

  const validateURL = (url) => {
    // Allow empty values (if the field is not required)
    if (!url) return true;

    // Basic URL validation regex
    const urlPattern =
      /^(https?:\/\/)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)$/;
    return urlPattern.test(url);
  };
  // Input change handlers
  const handleNameChange = (e) => {
    const value = e.target.value;
    setOrgName(value);
    setUserMadeChanges(true);
    validateField("organization_name", value);
  };

  const handleTypeChange = (e) => {
    const value = e.target.value;
    setOrgType(value);
    setUserMadeChanges(true);
    validateField("organization_type", value);
  };


  const handleMarketChange = (e) => {
    const value = e.target.value;
    setAgentmarket(value);
    setUserMadeChanges(true);
    validateField("organization_geographical_market_focus", value);
  };




  const onSubmit = async (data) => {

    try {
      // Validate form
      const isNameValid = validateField("organization_name", orgName);
      const isTypeValid = validateField("organization_type", orgType);
      // const isAgentNameValid = validateField(
      //   "organization_agent_name",
      //   agentName
      // );
      const isMarketValid = validateField(
        "organization_geographical_market_focus",
        market
      );

      // const isAgentValid = validateField(
      //   "organization_agent_link",
      //   orgAgentLink
      // );

      if (!isNameValid || !isTypeValid || !isMarketValid) {
        return;
      }

      setIsLoad(true);
      const formData = new FormData();

      formData.append("organization_name", orgName || "");
      formData.append("organization_type", orgType || "");
      formData.append("organization_geographical_market_focus", market || "");
      if (initialData?.agent) {
        formData.append("organization_agent_name", agentName || "");
        formData.append("organization_agent_link", orgAgentLink || "");
        formData.append("organization_agent_logo", originalImageFileAgent);
      }

      formData.append(
        "organization_description",
        data.organization_description || ""
      );
      formData.append(
        "organization_web_address",
        data.organization_web_address || ""
      );

      if (originalImageFile) {
        formData.append("organization_logo", originalImageFile);
      } else if (imageWasDeleted) {
        formData.append("organization_logo", "");
      }

      // Handle agent logo
      // if (originalImageFileAgent) {
      //   formData.append("organization_agent_logo", originalImageFileAgent);
      // } else if (imageWasDeletedAgent) {
      //   formData.append("organization_agent_logo", "");
      // }


      const res = await trigger({ requestBody: formData });

      if (res?.data) {
        reset(data);
        setUserMadeChanges(false);
        setImageWasDeleted(false);
        setImageWasDeletedAgent(false);

        mutate(
          apiList.admin.settings.index.key(
            auth?.user?.organization_id,
            strategicPlan
          )
        );
        mutate(apiList.admin.profile.details.key(auth?.user?.user_id, strategicPlan));

        Myswal.fire({
          html: (
            <div className="flex flex-col items-center">
              <div className="w-18 h-20 mb-2">
                <ProstrategyLogo />
              </div>
              <h2 className="text-xl font-semibold">Success!</h2>
              <p className="mt-2">{res?.data}</p>
            </div>
          ),
          confirmButtonText: "Okay",
          customClass: {
            confirmButton: "my-confirm-button",
          },
        });
      }
      mutate(
        apiList.admin.settings.index.key(
          auth?.user?.organization_id,
          strategicPlan
        )
      );
      mutate(
        apiList.auth.getPermissions.key(auth?.user?.id)
      );
    } catch (error) {
      console.error(error);
      toast.error("Failed to save changes.");
    } finally {
      setIsLoad(false);
    }


  };

  const handleDeleteImage = (e) => {
    e.preventDefault();
    e.stopPropagation();

    setImageSrc(null);
    setValue("organization_logo", "", {
      shouldValidate: true,
      shouldDirty: true,
      shouldTouch: true,
    });
    setImageWasDeleted(true);
    clearErrors("organization_logo");
    setUserMadeChanges(true);
    setOriginalImageFile(null);
  };

  const handleDeleteImageAgent = (e) => {
    e.preventDefault();
    e.stopPropagation();

    setImageSrcAgent(null);
    setValue("organization_agent_logo", "", {
      shouldValidate: true,
      shouldDirty: true,
      shouldTouch: true,
    });
    setImageWasDeletedAgent(true);
    clearErrors("organization_agent_logo");
    setUserMadeChanges(true);
    setOriginalImageFileAgent(null);
  };
  if (
    !hasPermission("org_settings", "read_only") &&
    !hasPermission("org_settings", "edit")
  ) {
    return <div>You have no permission to read and edit</div>;
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      {showModal && (
        <UnsavedChangesModal
          isConfirmNavigation={confirmNavigation}
          isCancelNavigation={cancelNavigation}
        />
      )}

      <AiHelpDescriptionDrawer
        drawerState={aiHelpState.drawerOpen}
        setDrawerState={(open) =>
          setAiHelpState((prev) => ({ ...prev, drawerOpen: open }))
        }
        title="AI Help - Organization Description"
        getDescriptionWithlimitNumber={handleGetMoreDescriptions}
        onSaveDescription={handleUseDescription}
        descriptions={aiHelpState.descriptions}
        getMoreCount={aiHelpState.getMoreCount}
        BELoading={aiHelpState.loading}
        selectedDescription={aiHelpState.selectedDescription}
        setSelectedDescription={handleSelectDescription}
      />

      <AlerModal
        isOpen={isAlert}
        onOpenChange={setIsAlert}
        title="Organization Settings updated successfully"
        clickFunction={() => null}
      />

      <div className="flex justify-between gap-10">
        <div className="w-[100%]">
          <div className="mb-12 w-full">
            <div className="flex items-end justify-between mb-2">
              <label
                htmlFor="organization_name"
                className="text-sm text-black "
              >
                Organization Name{" "}
                <span className="text-red-600 text-base ml-1">*</span>
              </label>
            </div>

            <input
              id="organization_name"
              name="organization_name"
              type="text"
              placeholder="Organization Name"
              value={orgName}
              onChange={handleNameChange}
              readOnly={hasPermission("org_settings", "read_only")}
              maxLength={100}
              className={`block w-full rounded-md border border-gray-300 px-4 py-2 text-sm shadow-sm focus:border-[#0098F5] focus:outline-none focus:ring-1 focus:ring-[#0098F5] ${errors.organization_name ? "border-red-500" : ""
                }`}
            />
            {errors.organization_name && (
              <p className="mt-1 text-sm text-red-600">
                {errors.organization_name.message}
              </p>
            )}
          </div>

          <div className="mb-12 w-full">
            <div className="flex items-end justify-between mb-2">
              <label
                htmlFor="organization_type"
                className="text-sm text-black "
              >
                Organization Type{" "}
                <span className="text-red-600 text-base ml-1">*</span>
              </label>
            </div>

            <input
              id="organization_type"
              name="organization_type"
              type="text"
              placeholder="Eg. Educational, Manufacturing,..."
              value={orgType}
              onChange={handleTypeChange}
              readOnly={hasPermission("org_settings", "read_only")}
              maxLength={100}
              className={`block w-full rounded-md border border-gray-300 px-4 py-2 text-sm shadow-sm focus:border-[#0098F5] focus:outline-none focus:ring-1 focus:ring-[#0098F5] ${errors.organization_type ? "border-red-500" : ""
                }`}
            />
            {errors.organization_type && (
              <p className="mt-1 text-sm text-red-600">
                {errors.organization_type.message}
              </p>
            )}
          </div>
          {
            initialData?.agent && (
              <>
                <div className="mb-12 w-full">
                  <div className="flex items-end justify-between mb-2">
                    <label
                      htmlFor="organization_agent_name"
                      className="text-sm text-black"
                    >
                      Agent Name{" "}
                    </label>
                  </div>

                  <input
                    id="organization_agent_name"
                    name="organization_agent_name"
                    type="text"
                    value={agentName}
                    readOnly={true}
                    className={`block w-full rounded-md border border-gray-300 bg-slate-200 px-4 py-2 text-sm shadow-sm focus:outline-none`}
                  />
                </div>
                <div className="mb-12 w-full">
                  <div className="flex items-end justify-between mb-2">
                    <label
                      htmlFor="organization_agent_link"
                      className="text-sm text-black"
                    >
                      Agent Link
                    </label>
                  </div>

                  <input
                    id="organization_agent_link"
                    name="organization_agent_link"
                    type="url"
                    value={orgAgentLink}
                    readOnly={true}
                    className={`block w-full rounded-md border border-gray-300 bg-slate-200 px-4 py-2 text-sm shadow-sm focus:outline-none`}
                  />
                </div>
              </>
            )
          }

          <div className="mb-12 w-full">
            <div className="flex items-end justify-between mb-2">
              <label
                htmlFor="organization_geographical_market_focus"
                className="text-sm text-black "
              >
                Geographic Market Focus{" "}
                <span className="text-red-600 text-base ml-1">*</span>
              </label>
            </div>

            <input
              id="organization_geographical_market_focus"
              name="organization_geographical_market_focus"
              type="text"
              placeholder="Enter Your Market Focus"
              value={market}
              onChange={handleMarketChange}
              readOnly={hasPermission("org_agent_name", "read_only")}
              maxLength={100}
              className={`block w-full rounded-md border border-gray-300 px-4 py-2 text-sm shadow-sm focus:border-[#0098F5] focus:outline-none focus:ring-1 focus:ring-[#0098F5] ${errors.organization_geographical_market_focus ? "border-red-500" : ""
                }`}
            />
            {errors.organization_geographical_market_focus && (
              <p className="mt-1 text-sm text-red-600">
                {errors.organization_geographical_market_focus.message}
              </p>
            )}
          </div>

        </div>
        <div>
          <label
            htmlFor="upload"
            className={`w-[300px] h-[250px] inline-block mb-2 p-6 bg-gray-100 border-dashed border-2 ${errors?.organization_logo ? "border-red-500" : "border-gray-400"} rounded-lg items-center mx-auto text-center cursor-pointer`}
          >
            <Input
              id="upload"
              type="file"
              className="hidden"
              accept="image/jpeg,image/jpg,image/png,image/webp"
              {...register("organization_logo")}
              onChange={handleFileChange}
              disabled={hasPermission("org_settings", "read_only")}
            />
            {imageSrc && !errors?.organization_logo ? (
              <>
                <img
                  src={imageSrc}
                  className="max-h-40 mb-1 m-auto"
                  alt="Image preview"
                />
                {!hasPermission("org_settings", "read_only") && (
                  <div className="flex justify-center gap-3">
                    <span className="text-gray-500 ">Organization logo Click here to change</span>
                    <div
                      onClick={handleDeleteImage}
                      className="cursor-pointer flex justify-end"
                    >
                      <IconTrash className="text-red-500 hover:text-red-700" />
                    </div>
                  </div>
                )}
              </>
            ) : (
              <>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth="1.5"
                  stroke="currentColor"
                  className="w-8 h-8 text-gray-700 mx-auto mb-4"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5"
                  />
                </svg>
                <h5 className="mb-2 text-xl font-bold tracking-tight text-gray-700">
                  Upload Organization logo (optional)
                </h5>
                {errors?.organization_logo ? (
                  <p className="text-red-500 text-sm">
                    {errors?.organization_logo?.message}
                  </p>
                ) : (
                  <>
                    <p className="font-normal text-sm text-gray-400 md:px-6">
                      Choose photo size should be less than{" "}
                      <b className="text-gray-600">10mb</b>
                    </p>
                    <p className="font-normal text-sm text-gray-400 md:px-6">
                      and should be in{" "}
                      <b className="text-gray-600">JPEG, JPG, PNG or WebP</b>{" "}
                      format.
                    </p>
                  </>
                )}
              </>
            )}
          </label>
          {/* /// Agent logo */}
          <div className="cursor-default">
            {initialData?.agent && (
              <label
                htmlFor="agent_logo_upload"
                className={`w-[300px] h-[250px] inline-block mt-4 p-6 bg-gray-100 border-dashed border-2 ${errors?.organization_agent_logo ? "border-red-500" : "border-gray-400"
                  } rounded-lg items-center mx-auto text-center cursor-default`}  // 👈 changed here
              >
                <Input
                  id="agent_logo_upload"
                  className="hidden cursor-default" // 👈 added
                  {...register("organization_agent_logo")}
                  readOnly={true}
                />
                {imageSrcAgent ? (
                  <>
                    <img
                      src={imageSrcAgent}
                      className="max-h-40 mb-1 m-auto cursor-default" // 👈 added
                      alt="Image preview"
                    />
                    <span className="text-gray-700 cursor-default">Agent Logo</span>
                  </>
                ) : (
                  <>
                    <img
                      src={"/default-agent-logo.png"}
                      alt="Avatar"
                      className="w-full h-full text-gray-700 mx-auto mb-4 cursor-default" // 👈 added
                      onError={(e) => {
                        e.target.onerror = null;
                        e.target.src =
                          "data:image/svg+xml,%3Csvg ... %3E%3C/svg%3E";
                      }}
                    />
                  </>
                )}
              </label>
            )}
          </div>

        </div>
      </div>

      <Textarea
        label={
          <div className="flex items-center justify-start gap-3 w-full mt-2">
            <label htmlFor="organization_description" className="text-sm">
              {" "}
              Web Address
            </label>
          </div>
        }
        value={watch("organization_web_address") || ""}
        {...register("organization_web_address")}
        id="organization_web_address"
        placeholder="Web Address"
        variant="bordered"
        labelPlacement="outside"
        type="text"
        radius="sm"
        className="mb-3"
        classNames={{
          input: "min-h-[150px]",
          label: "mb-2",
          inputWrapper: [
            "group-data-[focus=true]:border-[#0098F5]",
            "dark:group-data-[focus=true]:border-[#0098F5]",
          ],
        }}
        maxLength={500}
        isInvalid={!!errors.organization_web_address}
        errorMessage={errors.organization_web_address?.message || ""}
        isReadOnly={hasPermission("org_settings", "read_only")}
      />

      <Textarea
        label={
          <div className="flex items-center justify-start gap-3 w-full mt-2">
            <label htmlFor="organization_description">
              Organization Description{" "}
              <span className="text-red-600 text-base ml-1">*</span>
            </label>
            <Button
              radius="sm"
              color="primary"
              className="mt-0 bg-[#39465F]"
              onPress={toggleDrawer}
            >
              <AiHelpIcon />
              AI Help
            </Button>
            {/* <CustomTooltip
                tooltipTitle="Upgrade Plan"
                tooltipContent={
                  currentPlanData?.data?.plan_name === "Enterprise"
                    ? "Your current plan has limited features. Please Contact Admin"
                    : "Your current plan has limited features. Upgrade now to access more!"
                }
                buttonText={
                  currentPlanData?.data?.plan_name === "Enterprise"
                    ? null
                    : "Go to Plans"
                }
                navigateTo="/settings/account_tab"
              /> */}
          </div>
        }
        value={orgDescription}
        {...register("organization_description")}
        id="organization_description"
        placeholder="Organization Description"
        variant="bordered"
        labelPlacement="outside"
        type="text"
        radius="sm"
        className="mb-3"
        classNames={{
          input: "min-h-[150px]",
          label: "mb-2",
          inputWrapper: [
            "group-data-[focus=true]:border-[#0098F5]",
            "dark:group-data-[focus=true]:border-[#0098F5]",
          ],
        }}
        maxLength={500}
        isInvalid={!!errors.organization_description}
        errorMessage={errors.organization_description?.message || ""}
        isReadOnly={hasPermission("org_settings", "read_only")}
      />

      {hasPermission("org_settings", "edit") && (
        <Button
          radius="sm"
          isLoading={isMutating || load}
          color="primary"
          className="mt-5 bg-[#0098F5]"
          isDisabled={isMutating}
          type="submit"
        >
          {isMutating ? "Saving..." : "Save Changes"}
        </Button>
      )}
    </form>
  );
}

export default OrganizationTab;

import { Button } from "@nextui-org/button";
import { Card } from "@nextui-org/card";
import { IconCircleX, IconInfoCircle, IconReload } from "@tabler/icons-react";
import SlidingPane from "react-sliding-pane";
import "react-sliding-pane/dist/react-sliding-pane.css";
import toast from "react-hot-toast";
import { Skeleton } from "@nextui-org/skeleton";
import { useState } from "react";

function AiHelpDescriptionDrawer({
    drawerState,
    setDrawerState,
    title,
    getDescriptionWithlimitNumber,
    onSaveDescription,
    getMoreCount,
    descriptions,
    BELoading,
    selectedDescription,
    setSelectedDescription,
}) {
    const handleSelectDescription = (description) => {
        setSelectedDescription(description);
    };

    const handleUseDescription = () => {
        if (!selectedDescription) {
            toast.error("Please select a description first");
            return;
        }
        onSaveDescription(selectedDescription);
    };

    const handleGetMore = () => {
        if (getMoreCount < 1) {
            getDescriptionWithlimitNumber();

        } else {
            toast.error("Maximum descriptions reached!");
        }
    };


    return (
        <div>
            <SlidingPane
                closeIcon={
                    <div>
                        <span className="text-xl">
                            <IconCircleX color="#11181C" className="w-12 h-12" />
                        </span>
                    </div>
                }
                overlayClassName="z-50"
                width="600px"
                isOpen={drawerState}
                title={title}
                onRequestClose={() => setDrawerState(false)}
            >
                <div>
                    <h5 className="text-gray-600 p-1 font-semibold">

                        Based on the Organization Name, Organization Type, Organization Business Targets, Web Address, Geographic Market Focus, and Client Training provided, here are suggested descriptions for your organization.
                    </h5>
                    <div className="flex gap-2 items-start text-sm">
                        <IconInfoCircle className="mb-1 h-7 w-7" />
                        <p>
                            You can generate up to 20 descriptions and select 1 description from the
                            list to use as your organization's description.
                        </p>
                    </div>

                    <div className="mt-4 grid grid-cols-1 gap-4 max-h-[calc(69vh-30vh)] overflow-auto p-2">
                        {BELoading
                            ? Array.from({ length: 4 }).map((_, index) => (
                                <Card
                                    key={index}
                                    bordered
                                    shadow="none"
                                    radius="md"
                                    className={`p-4 border-[#E2E9F0] bg-[#F4F7FA] border`}
                                >
                                    <Skeleton className="rounded-lg">
                                        <div className="h-10 rounded-lg bg-default-300"></div>
                                    </Skeleton>
                                </Card>
                            ))
                            : descriptions.map((description, index) => (
                                <Card
                                    key={index}
                                    bordered
                                    shadow="none"
                                    isPressable
                                    radius="sm"
                                    className={`p-2 bg-[#F4F7FA] w-full border text-start min-h-12 flex justify-center ${selectedDescription === description
                                        ? "border-primary border-2"
                                        : "border-[#E2E9F0]"
                                        }`}
                                    onClick={() => handleSelectDescription(description)}
                                >
                                    {index + 1} : {description}
                                </Card>
                            ))}
                    </div>

                    <div className="flex justify-between mt-4">
                        {getMoreCount < 1 ? (
                            <Button
                                radius="sm"
                                variant="bordered"
                                color="primary"
                                startContent={!BELoading && <IconReload />}
                                auto
                                className="bg-white text-black"
                                onClick={handleGetMore}
                                isLoading={BELoading}

                            >
                                {BELoading ? "Getting" : "Get 5 more"}
                            </Button>
                        ) : (
                            <div></div>
                        )}

                        <Button
                            color="primary"
                            radius="sm"
                            className="capitalize"
                            onClick={handleUseDescription}
                            isLoading={BELoading}
                        >
                            Use Description
                        </Button>
                    </div>
                </div>
            </SlidingPane>
        </div>
    );
}

export default AiHelpDescriptionDrawer;
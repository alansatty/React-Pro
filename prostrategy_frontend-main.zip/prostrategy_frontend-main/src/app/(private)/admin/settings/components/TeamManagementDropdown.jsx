
import { useEffect } from "react"
import { Tab, Tabs } from "@nextui-org/tabs"
import { Card, CardBody } from "@nextui-org/card"
import { useNavigate, useParams } from "react-router-dom"
import UserManagement from "../../userManagement/page"
import RoleManagement from "../../roleManagement/page"
import UsersIcon from "../../../../../assets/icons/users"
import { IconUsers, IconUserCog, IconShieldLock, IconShieldFilled } from "@tabler/icons-react"
import ProtectedRoute from "../../../../../middleware/ProtectedRoute"

function CreateSubTitle({ title, Icon }) {
    return (
        <div className="flex items-center space-x-2">
            <Icon />
            <span>{title}</span>
        </div>
    );
}

const TeamManagementTab = () => {
    const { tabId, subTabId } = useParams()
    const navigate = useNavigate()

    useEffect(() => {
        // If team_management_tab is selected but no subTabId, default to user_management
        if (tabId === "team_management_tab" && !subTabId) {
            navigate("/settings/team_management_tab/user_management")
        }
    }, [tabId, subTabId, navigate])

    const selectedKey = subTabId || "user_management"

    const tabs = [
        {
            id: "user_management",
            label: <CreateSubTitle title={"User Management"} Icon={IconUserCog} />,
            content: <UserManagement />,
        },
        {
            id: "role_management",
            label: <CreateSubTitle title={"Role Management"} Icon={IconShieldLock} />,
            content:
                <ProtectedRoute
                    page="roles"
                    action="list"
                    planPermission="custom_roles_allowed"
                >
                    <RoleManagement />
                </ProtectedRoute>,
        },
    ]

    return (
        <div className="flex w-full flex-col">
            <Tabs
                selectedKey={selectedKey}
                aria-label="Team Management Tabs"
                color="primary"
                size="md"
                radius="sm"
                variant="underlined"
                classNames={{
                    tabList: "gap-6 w-full relative rounded-none p-0 border-b border-divider",
                    cursor: "w-full bg-[#0098F5]",
                    tab: "max-w-fit px-2 h-10",
                    tabContent: "group-data-[selected=true]:text-[#0098F5]",
                }}
                onSelectionChange={(key) => {
                    navigate(`/settings/team_management_tab/${key}`)
                }}
            >
                {tabs.map((item) => (
                    <Tab key={item.id} title={item.label}>
                        <Card shadow="none" radius="sm">
                            <CardBody>{item.content}</CardBody>
                        </Card>
                    </Tab>
                ))}
            </Tabs>
        </div>
    )
}

export default TeamManagementTab

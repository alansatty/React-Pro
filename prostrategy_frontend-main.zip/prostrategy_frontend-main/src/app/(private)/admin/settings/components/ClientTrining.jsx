
import { Button } from "@nextui-org/button"
import { Textarea } from "@nextui-org/input"
import { IconFileAnalytics, IconTrash, IconEdit, IconChevronDown, IconChevronRight, IconDownload, IconX, IconFile, IconVideo, IconPhoto, IconFileText, IconEye } from "@tabler/icons-react"
import { useEffect, useState, useRef } from "react"
import usePermissionsStore from "../../../../../stores/usePermissionStore"
import { useAuth } from "../../../../../providers/authProviders"
import axios from "axios"
import toast from "react-hot-toast"
import useUnsavedChanges from "../../../../../hooks/useUnsavedChanges"
import UnsavedChangesModal from "../../../../../components/Alert/UnsavedChangesModal"
import ReactShowMoreText from "react-show-more-text"
import { Spinner } from "@nextui-org/spinner"

const ClientTraining = () => {
  const [activeTab, setActiveTab] = useState("textContent")
  const tabs = [
    { name: "textContent", label: "Text content" },
    { name: "Link", label: "Link" },
    { name: "Files", label: "Files" },
  ]

  // Store and auth
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan)
  const auth = useAuth()
  const authToken = auth?.user?.token

  const [isLoading, setIsLoading] = useState(false)
  const [textContents, setTextContents] = useState([])
  const [textContentsLength, setTextContentsLength] = useState(0)
  const [linksLength, setLinksLength] = useState(0)
  const [filesLength, setFilesLength] = useState(0)
  const [clientTrainingIds, setClientTrainingIds] = useState([])

  const [links, setLinks] = useState([])
  const [files, setFiles] = useState([])
  const [expandedItems, setExpandedItems] = useState({})
  const [isAddingMode, setIsAddingMode] = useState(false)

  const [selectedFile, setSelectedFile] = useState(null)
  const [fileViewerOpen, setFileViewerOpen] = useState(false)

  const [showLinkContentFields, setShowLinkContentFields] = useState(false)
  const [showAddForm, setShowAddForm] = useState(false)
  const [editingItem, setEditingItem] = useState(null)
  const [formData, setFormData] = useState({
    title: "",
    content: "",
    url: "",
    file: null,
    linkContent: "", // Added for scraped content
  })

  const [errors, setErrors] = useState({
    title: "",
    content: "",
    url: "",
    file: "",
    linkContent: "",
  })

  // Refs
  const fileInputRef = useRef()

  // Unsaved changes management
  const [isDirty, setIsDirty] = useState(false)
  const [selectedItem, setSelectedItem] = useState(null)
  const [pendingNavigation, setPendingNavigation] = useState(false)

  // Loading states
  const [loading, setLoading] = useState({
    textcontent: false,
    link: false,
    files: false,
    scraping: false,
  })

  // Initialize data on component mount and strategic plan change
  useEffect(() => {
    if (strategicPlan) {
      fetchData()
    }
  }, [strategicPlan])

  // Reset states when tab changes
  useEffect(() => {
    setShowAddForm(false)
    setEditingItem(null)
    resetForm()
    setShowLinkContentFields(false)
    clearErrors()
  }, [activeTab])

  // Unsaved changes modal logic
  const { showModal, confirmNavigation, cancelNavigation } = useUnsavedChanges(
    isDirty,
    pendingNavigation,
    handleNavigationConfirm,
  )

  const resetForm = () => {
    setFormData({
      title: "",
      content: "",
      url: "",
      file: null,
      linkContent: "",
    })
  }

  const clearErrors = () => {
    setErrors({
      title: "",
      content: "",
      url: "",
      file: "",
      linkContent: "",
    })
  }

  const setError = (field, message) => {
    setErrors(prev => ({ ...prev, [field]: message }))
  }

  const setLoadingState = (key, value) => {
    setLoading((prev) => ({ ...prev, [key.toLowerCase()]: value }))
  }

  const countWords = (text) => {
    return text
      .trim()
      .split(/\s+/)
      .filter((word) => word.length > 0).length
  }

  const isValidUrl = (url) => {
    try {
      // Check if URL has a valid protocol
      const urlObj = new URL(url);
      const validProtocols = ['http:', 'https:', 'ftp:', 'ftps:'];
      if (!validProtocols.includes(urlObj.protocol)) {
        return false;
      }

      // Check if domain has a valid TLD (at least 2 characters after the last dot)
      const domainParts = urlObj.hostname.split('.');
      if (domainParts.length < 2 || domainParts[domainParts.length - 1].length < 2) {
        return false;
      }

      return true;
    } catch {
      return false;
    }
  }
  // Navigation handlers
  function handleNavigationConfirm(shouldNavigate) {
    if (shouldNavigate) {
      setActiveTab(selectedItem)
      setIsDirty(false)
    }
    setPendingNavigation(false)
  }

  const handleTabClick = (tab) => {
    if (isDirty) {
      setSelectedItem(tab.name)
      setPendingNavigation(true)
    } else {
      setActiveTab(tab.name)
    }
  }

  const fetchData = async () => {
    try {
      setIsLoading(true)
      const response = await axios.get(
        `organization/client_training/?strategic_plan_id=${strategicPlan}`,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: authToken ? `Bearer ${authToken}` : undefined,
          },
        }
      );

      const data = response?.data?.data || {};
      setTextContents(data.text_contents || []);
      setLinks(data.links || []);
      setFiles(data.files || []);

      setTextContentsLength(data.text_contents?.length || 0);
      setLinksLength(data.links?.length || 0);
      setFilesLength(data.files?.length || 0);

      setClientTrainingIds(data.ids || []);

    } catch (error) {
      console.error("Error fetching data:", error);
      toast.error("Failed to load data.");
    } finally {
      setIsLoading(false)
    }
  };
  const toggleExpanded = (type, id) => {
    setExpandedItems((prev) => ({
      ...prev,
      [`${type}-${id}`]: !prev[`${type}-${id}`],
    }))
  }

  const handleAddNew = () => {
    setShowAddForm(true)
    setEditingItem(null)
    resetForm()
    setShowLinkContentFields(false)
    clearErrors()
  }

  useEffect(() => {
    if (formData.url && isDirty) {
      if (!isValidUrl(formData.url)) {
        setError("url", "Please enter a valid URL with protocol (http, https, ftp) and domain (e.g., .com, .org)")
      } else {
        setError("url", "")
      }
    }
  }, [formData.url, isDirty])

  const handleEdit = (item, type) => {
    setShowLinkContentFields(true)
    setEditingItem({ ...item, type })
    setFormData({
      title: item.title || item.text_title || "",
      content: item.content || item.text_content || "",
      url: item.url || item.link || "",
      file: null,
      linkContent: item.link_content || "",
    })

    if (item.link || item.url) {
      const existingUrl = item.link || item.url
      if (!isValidUrl(existingUrl)) {
        setError("url", "Please enter a valid URL with protocol (http, https, ftp) and domain (e.g., .com, .org)")
      } else {
        setError("url", "")
      }
    }

    setShowAddForm(true)
    if (type === "link") {
      setShowLinkContentFields(true)
    }
    setIsDirty(false)
  }

  const handleDelete = async (id, slug, index) => {
    try {
      const res = await axios.patch(`organization/client_training/${id}/?slug=${slug}&strategic_plan_id=${strategicPlan}`,
        null,
        {
          headers: {
            Authorization: authToken ? `Bearer ${authToken}` : undefined,
          },
        })
      if (res.data?.status === "Success") {
        toast.success(`${res?.data?.msg}`)
      }

      fetchData()
    } catch (error) {
      console.error("Error deleting item:", error)
      toast.error("Failed to delete item.")
    }
  }

  const scrapeUrlContent = async (url) => {
    setLoadingState("scraping", true)
    const formDataToSend = new FormData()
    formDataToSend.append("url", url)

    try {
      const response = await axios.post(
        `/organization/scrap_content_from_url/`,
        formDataToSend,
        {
          headers: {
            "Content-Type": "multipart/form-data",
            Authorization: authToken ? `Bearer ${authToken}` : undefined,
          },
        }
      )

      setFormData(prev => ({
        ...prev,
        linkContent: response.data?.content || "",
        title: formData.title || response.data?.title || "Scraped Content"
      }))
      setShowLinkContentFields(true)
      setError("url", "")

      toast.success("Content generated successfully!")
    } catch (error) {
      console.error("Error during URL scraping:", error)
      setError("url", "Failed to generate content from this URL")
      toast.error("Failed to generate content from this URL.")
    } finally {
      setLoadingState("scraping", false)
    }
  }

  const handleUrlChange = (e) => {
    const url = e.target.value
    setFormData(prev => ({ ...prev, url }))
    setIsDirty(true)
    setShowLinkContentFields(false)
    // Validate URL as user types
    if (url) {
      if (!isValidUrl(url)) {
        setError("url", "Please enter a valid URL with protocol (http, https, ftp) and domain (e.g., .com, .org)")
      } else {
        setError("url", "")
      }
    } else {
      setError("url", "")
    }
  }

  const handleViewFile = (file) => {
    setSelectedFile(file)
    setFileViewerOpen(true)
  }

  const handleSave = async () => {
    const currentTab = activeTab
    let hasErrors = false

    // Clear previous errors
    clearErrors()

    if (currentTab === "textContent") {
      if (!formData.title.trim()) {
        setError("title", "Title is required")
        hasErrors = true
      }

      if (!formData.content.trim()) {
        setError("content", "Content is required")
        hasErrors = true
      }

      const wordCount = countWords(formData.content)
      if (wordCount > 5000) {
        setError("content", "Content exceeds 5000 words limit")
        hasErrors = true
      }

      if (formData.title.trim().length > 50) {
        setError("title", "Title exceeds 50 characters limit");
        hasErrors = true
      }

    } else if (currentTab === "Link") {
      if (!formData.url.trim()) {
        setError("url", "URL is required")
        hasErrors = true
      } else if (!isValidUrl(formData.url)) {
        setError("url", "Please enter a valid URL")
        hasErrors = true
      }

      // For links, we need either scraped content or manually entered content
      const linkContent = formData.linkContent || formData.content
      if (!linkContent.trim()) {
        setError("linkContent", "Content is required. Please generate.")
        hasErrors = true
      } else {
        const wordCount = countWords(linkContent)
        if (wordCount > 5000) {
          setError("linkContent", "Content exceeds 5000 words limit")
          hasErrors = true
        }
      }
    } else if (currentTab === "Files") {
      if (!formData.file && !editingItem) {
        setError("file", "Please select a file")
        hasErrors = true
      }
    }

    if (hasErrors) {
      return
    }

    try {
      setLoadingState(currentTab, true)
      const formDataToSend = new FormData()

      if (currentTab === "textContent") {
        formDataToSend.append("text_title", formData.title)
        formDataToSend.append("text_content", formData.content)
      } else if (currentTab === "Link") {
        formDataToSend.append("link", formData.url)
        formDataToSend.append("link_content", formData.linkContent || formData.content)
        // If we have a title, include it
      } else if (currentTab === "Files") {
        if (formData.file) {
          formDataToSend.append("file", formData.file)
        }
      }

      if (editingItem) {
        formDataToSend.append("id", editingItem.id)
      }

      let id;

      if (activeTab === "textContent") {
        id = clientTrainingIds[textContentsLength] || null
      }
      else if (activeTab === "Link") {
        id = clientTrainingIds[linksLength] || null
      }
      else if (activeTab === "Files") {
        id = clientTrainingIds[filesLength] || null
      }

      const slug = activeTab === 'textContent' ? 'text_content' : activeTab === 'Link' ? 'link' : activeTab === 'Files' ? 'file' : null

      const url = editingItem || id
        ? `organization/client_training/${editingItem?.id || id}/?slug=${slug}&strategic_plan_id=${strategicPlan}`
        : `organization/client_training/?slug=${slug}&strategic_plan_id=${strategicPlan}`

      const method = id || editingItem ? "put" : "post"

      const response = await axios[method](url, formDataToSend, {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: authToken ? `Bearer ${authToken}` : undefined,
        },
      });
      console.log('response', response);

      toast.success(response?.data?.msg)
      setShowAddForm(false)
      setEditingItem(null)
      resetForm()
      setShowLinkContentFields(false)
      fetchData()
      setIsDirty(false)
    } catch (error) {
      console.error("Error saving:", error)

      if (error.response && error.response.data?.data.file) {
        toast.error(error.response?.data?.data.file[0] || "Failed to save changes.")
      }
      else if (error.response && error.response.data?.data.link) {
        toast.error(error.response?.data?.data.link[0] || "Failed to save changes.")
      } else {
        toast.error(error?.response?.data?.msg)
      }
    } finally {
      setLoadingState(currentTab, false)
    }
  }

  const handleFileChange = (e) => {
    const file = e.target.files[0]
    if (!file) return

    const allowedTypes = [
      "application/pdf",
      "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "text/plain",
    ]

    if (allowedTypes.includes(file.type) && file.size <= 1 * 1024 * 1024) {
      setFormData((prev) => ({ ...prev, file }))
      setError("file", "")
      setIsDirty(true)
    } else {
      setError("file", "Please upload a valid file (PDF, DOCX, DOC, TXT under 1MB)")
      toast.error("Please upload a valid file (PDF, DOCX, DOC, TXT under 1MB)")
    }
  }

  // Add this component inside your ClientTraining component
  const FileViewerModal = () => {
    if (!selectedFile) return null

    const getFileIcon = () => {
      const extension = selectedFile.file_name?.split('.').pop()?.toLowerCase()

      switch (extension) {
        case 'pdf':
          return <IconFileText className="text-red-500" size={28} />
        case 'jpg':
        case 'jpeg':
        case 'png':
        case 'gif':
        case 'webp':
          return <IconPhoto className="text-green-500" size={28} />
        case 'mp4':
        case 'mov':
        case 'avi':
        case 'webm':
          return <IconVideo className="text-purple-500" size={28} />
        default:
          return <IconFile className="text-blue-500" size={28} />
      }
    }

    const renderFilePreview = () => {
      const extension = selectedFile.file_name?.split('.').pop()?.toLowerCase()
      const fileUrl = selectedFile.file

      if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(extension)) {
        return (
          <div className="flex justify-center items-center h-full">
            <img
              src={fileUrl}
              alt={selectedFile.file_name}
              className="max-h-full max-w-full object-contain"
            />
          </div>
        )
      } else if (['mp4', 'mov', 'avi', 'webm'].includes(extension)) {
        return (
          <div className="flex justify-center items-center h-full">
            <video controls className="max-h-full max-w-full">
              <source src={fileUrl} type={`video/${extension}`} />
              Your browser does not support the video tag.
            </video>
          </div>
        )
      } else if (extension === 'pdf') {
        return (
          <div className="w-full h-full">
            <iframe
              src={fileUrl}
              className="w-full h-full"
              title={selectedFile.file_name}
            />
          </div>
        )
      } else if (['doc', 'docx', 'ppt', 'pptx', 'xls', 'xlsx', 'txt'].includes(extension)) {
        // Use Google Docs Viewer for Office files, direct iframe for txt
        const viewerUrl =
          extension === 'txt'
            ? fileUrl
            : `https://docs.google.com/gview?url=${encodeURIComponent(fileUrl)}&embedded=true`

        return (
          <div className="w-full h-full">
            <iframe
              src={viewerUrl}
              className="w-full h-full"
              title={selectedFile.file_name}
            />
          </div>
        )
      } else {
        return (
          <div className="flex flex-col items-center justify-center h-full text-center p-4">
            <div className="text-gray-400 mb-4">
              {getFileIcon()}
            </div>
            <h3 className="text-xl font-semibold mb-2">No Preview Available</h3>
            <p className="text-gray-500 mb-4">
              This file type doesn't support inline preview.
            </p>
            <a
              href={fileUrl}
              download
              className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
            >
              <IconDownload size={16} />
              Download File
            </a>
          </div>
        )
      }
    }


    return (
      <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl h-full overflow-hidden flex flex-col">
          <div className="flex items-center justify-between p-4 border-b border-gray-200">
            <div className="flex items-center gap-3">
              {getFileIcon()}
              <h2 className="text-sm font-semibold">{selectedFile.file_name}</h2>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setFileViewerOpen(false)}
                className="p-2 rounded-full hover:bg-gray-100 transition-colors"
              >
                <IconX size={20} />
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-auto p-6 h-full">
            {renderFilePreview()}
          </div>

          <div className="p-4 border-t border-gray-200 bg-gray-50">
            <div className="flex justify-between gap-4 text-sm">
              <div>
                <span className="text-gray-500">File Name:</span>
                <span className="ml-2 font-medium">{selectedFile.file_name}</span>
              </div>
              <div>
                <span className="text-gray-500">Type:</span>
                <span className="ml-2 font-medium">{selectedFile.file_name?.split('.').pop()?.toUpperCase()}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  const renderTextContentItem = (item, index) => {
    const isExpanded = expandedItems[`textContent-${item.id}`]

    return (
      <div key={item.id} className="border border-gray-200 rounded-lg mb-3">
        <div
          className="flex items-center justify-between p-4 cursor-pointer"
          onClick={() => toggleExpanded("textContent", item.id)}
        >
          <div className="flex items-center gap-3">
            {isExpanded ? <IconChevronDown size={20} /> : <IconChevronRight size={20} />}
            <span className="font-medium">{item.text_title}</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={(e) => {
                e.stopPropagation()
                handleEdit(item, "textContent")
              }}
              className="text-blue-500 hover:text-blue-700 flex items-center gap-1"
            >
              <IconEdit size={18} />
              {/* Edit */}
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation()
                handleDelete(item.id, "text_content", index)
              }}
              className="text-red-500 hover:text-red-700 flex items-center gap-1"
            >
              <IconTrash size={18} />
              {/* Delete */}
            </button>
          </div>
        </div>

        {isExpanded && (
          <div className="px-4 pb-4 border-t border-gray-100">
            {/* <h4 className="font-medium mb-2 mt-3">{item.text_title || item.title}</h4> */}
            <ReactShowMoreText
              lines={2}
              className="mt-3"
              more="..."
              less="Show less"
              anchorClass="text-blue-500 hover:text-blue-700 text-xs font-medium"
              expanded={false}
              truncatedEndingComponent=""
            >
              {item.text_content || item.content}
            </ReactShowMoreText>
          </div>
        )}
      </div>
    )
  }

  const renderLinkItem = (item, index) => {
    const isExpanded = expandedItems[`link-${item.id}`]

    return (
      <div key={item.id} className="border border-gray-200 rounded-lg mb-3">
        <div
          className="flex items-center justify-between p-4 cursor-pointer"
          onClick={() => toggleExpanded("link", item.id)}
        >
          <div className="flex items-center gap-3">
            {isExpanded ? <IconChevronDown size={20} /> : <IconChevronRight size={20} />}
            {item.link.length > 50 ? (
              <ReactShowMoreText
                lines={1}
                className="mt-3 font-medium"
                more="..."
                anchorClass="text-blue-500 hover:text-blue-700 text-xs font-medium"
                expanded={false}
                truncatedEndingComponent=""
              >
                {item.link}
              </ReactShowMoreText>
            ) : (
              <span className="mt-3 font-medium">{item.link}</span>
            )}

          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={(e) => {
                e.stopPropagation()
                handleEdit(item, "link")
              }}
              className="text-blue-500 hover:text-blue-700 flex items-center gap-1"
            >
              <IconEdit size={18} />

            </button>
            <button
              onClick={(e) => {
                e.stopPropagation()
                handleDelete(item.id, "link", index)
              }}
              className="text-red-500 hover:text-red-700 flex items-center gap-1"
            >
              <IconTrash size={18} />

            </button>
          </div>
        </div>

        {isExpanded && (
          <div className="px-4 pb-4 border-t border-gray-100">
            {/* <p className="text-gray-600 text-sm mb-2 break-all mt-3">{item.link || item.url}</p> */}
            {/* {item.title && <h4 className="font-medium mb-2">{item.title}</h4>} */}
            <ReactShowMoreText
              lines={2}
              className="mt-3"
              more="..."
              less="Show less"
              anchorClass="text-blue-500 hover:text-blue-700 text-xs font-medium"
              expanded={false}
              truncatedEndingComponent=""
            >
              {item.link_content || item.content}
            </ReactShowMoreText>
          </div>
        )}
      </div>
    )
  }

  const renderFileItem = (item, index) => {
    const isExpanded = expandedItems[`file-${item.id}`]

    const truncateFileName = (fileName, maxLength = 50) => {
      if (fileName.length <= maxLength) return fileName;

      // Extract file extension
      const lastDotIndex = fileName.lastIndexOf('.');
      const extension = fileName.slice(lastDotIndex);
      const nameWithoutExtension = fileName.slice(0, lastDotIndex);

      // Calculate how much of the name we can show
      const availableLength = maxLength - extension.length - 3; // 3 for the ellipsis

      if (availableLength <= 0) {
        // If even the extension is too long, just truncate the whole string
        return fileName.slice(0, maxLength - 1) + '…';
      }

      // Show the beginning and end of the filename (excluding extension)
      const beginning = nameWithoutExtension.slice(0, availableLength / 2);
      const end = nameWithoutExtension.slice(-availableLength / 2);

      return `${beginning}…${end}${extension}`;
    };

    return (
      <div key={item.id} className="border border-gray-200 rounded-lg mb-3">
        <div
          className="flex items-center justify-between p-4 cursor-pointer"
          onClick={() => handleViewFile(item)}
        >
          <div className="flex items-center gap-3 group cursor-pointer">
            <IconFileAnalytics size={18} className="group-hover:text-blue-500" />
            <span
              className="font-medium group-hover:text-blue-500"
              onClick={(e) => {
                e.stopPropagation();
                handleViewFile(item);
              }}
            >
              {truncateFileName(item.file_name || item.file_name)}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <IconEye size={22} className="text-gray-500 hover:text-blue-500" />
            <button
              onClick={(e) => {
                e.stopPropagation()
                handleEdit(item, "file")
              }}
              className="text-blue-500 hover:text-blue-700 flex items-center gap-1"
            >
              <IconEdit size={18} />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation()
                handleDelete(item.id, "file", index)
              }}
              className="text-red-500 hover:text-red-700 flex items-center gap-1"
            >
              <IconTrash size={18} />

            </button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-3 gap-4">
      {showModal && (
        <UnsavedChangesModal isConfirmNavigation={confirmNavigation} isCancelNavigation={cancelNavigation} />
      )}


      {fileViewerOpen && <FileViewerModal />}

      {/* Sidebar Navigation */}
      <div className="col-span-1">
        <div className="bg-white p-4 border-e h-full rounded-none">
          <ul className="space-y-4">
            {tabs.map((tab) => (
              <li
                key={tab.name}
                onClick={() => handleTabClick(tab)}
                className={`cursor-pointer py-2 px-2 rounded-lg transition-colors ${activeTab === tab.name ? "bg-[#EBF7FF] text-appSecondary" : "text-gray-700 hover:bg-gray-50"
                  }`}
              >
                {tab.label}
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Main Content */}
      <div className="col-span-2">
        {
          isLoading ? (
            <div className="flex justify-center items-center h-[500px]">
              <Spinner />
            </div>
          ) : (
            <>

              {/* Text Content Tab */}
              {activeTab === "textContent" && (
                <>
                  <div className={`flex items-center ${showAddForm ? 'justify-between' : 'justify-end'} mb-6`}>
                    {
                      showAddForm && (
                        <Button
                          size="sm"
                          className="cursor-pointer "
                          onPress={() => {
                            setShowLinkContentFields(false)
                            setEditingItem(null)
                            setShowAddForm(false)
                          }}
                        >
                          Back
                        </Button>

                      )
                    }
                    <div className="flex items-center gap-4">
                      <span className="text-sm text-gray-600">Text Content Added: {textContents.length}/5</span>
                      {textContents.length < 5 && (
                        <Button
                          radius="sm"
                          color="primary"
                          variant="bordered"
                          className="border-[#0098F5] text-[#0098F5]"
                          onPress={handleAddNew}
                        >
                          Add Text Content
                        </Button>
                      )}
                    </div>
                  </div>

                  {/* Add/Edit Form */}
                  {showAddForm && (
                    <div className=" p-4 rounded-lg mb-6">

                      <h3 className="font-medium mb-4">{editingItem ? "Edit Text Content" : "Add New Text Content"}</h3>

                      <div className="mb-4">
                        <label className="block text-sm font-medium mb-2">Title</label>
                        <input
                          type="text"
                          value={formData.title}
                          onChange={(e) => {
                            setFormData((prev) => ({ ...prev, title: e.target.value }))
                            setIsDirty(true)
                            if (e.target.value.trim()) {
                              setError("title", "")
                            }
                          }}
                          placeholder="Enter Title"
                          className={`w-full px-3 py-2 border ${errors.title ? 'border-red-500' : 'border-gray-300'} rounded-md focus:outline-none focus:ring-1 focus:ring-[#0098F5] focus:border-[#0098F5]`}
                        />
                        {errors.title && <p className="text-red-500 text-xs mt-1">{errors.title}</p>}
                      </div>

                      <div className="mb-4">
                        <label className="block text-sm font-medium mb-2">Content</label>
                        <div className="flex justify-end mb-1">
                          <span className="text-xs text-gray-500">{countWords(formData.content)}/5000 words</span>
                        </div>
                        <Textarea
                          value={formData.content}
                          onChange={(e) => {
                            setFormData((prev) => ({ ...prev, content: e.target.value }))
                            setIsDirty(true)
                            if (e.target.value.trim()) {
                              setError("content", "")
                            }
                          }}
                          placeholder="Enter Content"
                          variant="bordered"
                          radius="sm"
                          classNames={{
                            input: "min-h-[150px]",
                            inputWrapper: [
                              errors.content ? "border-red-500" : "",
                              "group-data-[focus=true]:border-[#0098F5]",
                              "dark:group-data-[focus=true]:border-[#0098F5]",
                            ],
                          }}
                        />
                        {errors.content && <p className="text-red-500 text-xs mt-1">{errors.content}</p>}
                      </div>

                      <div className="flex gap-2 justify-end">
                        <Button
                          radius="sm"
                          color="primary"
                          className="bg-[#0098F5]"
                          onPress={handleSave}
                          isLoading={loading.textcontent}
                        >
                          Save Changes
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* Text Content List */}
                  {!showAddForm && (
                    <div>
                      {textContents.map((item, index) => renderTextContentItem(item, index))}
                      {textContents.length === 0 && !showAddForm && (
                        <p className="text-gray-500 text-center py-8">No text content added yet</p>
                      )}
                    </div>
                  )}

                </>
              )}

              {/* Link Tab */}
              {activeTab === "Link" && (
                <>
                  <div className={`flex items-center ${showAddForm ? 'justify-between' : 'justify-end'} mb-6`}>
                    {
                      showAddForm && (
                        <Button
                          size="sm"
                          className="cursor-pointer"
                          onPress={() => {
                            setShowLinkContentFields(false)
                            setEditingItem(null)
                            setShowAddForm(false)
                          }}
                        >Back</Button>
                      )
                    }
                    <div className="flex items-center gap-4">
                      <span className="text-sm text-gray-600">Link Added: {links.length}/5</span>
                      {links.length < 5 && (
                        <Button
                          radius="sm"
                          color="primary"
                          variant="bordered"
                          className="border-[#0098F5] text-[#0098F5]"
                          onPress={handleAddNew}
                        >
                          Add Link
                        </Button>
                      )}
                    </div>
                  </div>

                  {/* Add/Edit Form */}
                  {showAddForm && (
                    <div className="p-4 rounded-lg mb-6">
                      <h3 className="font-medium mb-4">{editingItem ? "Edit Link" : "Add New Link"}</h3>
                      <div className="mb-4">
                        <label className="block text-sm font-medium mb-2">Link URL</label>
                        <input
                          type="url"
                          value={formData.url}
                          onChange={handleUrlChange}
                          placeholder="Enter URL (e.g., https://example.com)"
                          className={`w-full px-3 py-2 border ${errors.url ? 'border-red-500' : 'border-gray-300'} rounded-md focus:outline-none focus:ring-1 focus:ring-[#0098F5] focus:border-[#0098F5]`}
                        />
                        {errors.url && <p className="text-red-500 text-xs mt-1">{errors.url}</p>}
                      </div>

                      {formData.url && isValidUrl(formData.url) && !showLinkContentFields && (
                        <div className="mb-4">
                          <Button
                            radius="sm"
                            color="primary"
                            className="bg-[#0098F5]"
                            onPress={() => scrapeUrlContent(formData.url)}
                            isLoading={loading.scraping}
                          >
                            Generate Content
                          </Button>
                        </div>
                      )}

                      {(showLinkContentFields || editingItem) && (
                        <>

                          <div className="mb-4">
                            <label className="block text-sm font-medium mb-2">Content</label>
                            <div className="flex justify-end mb-1">
                              <span className="text-xs text-gray-500">{
                                (() => {
                                  const wordCount = countWords(formData.linkContent || formData.content);
                                  return `${wordCount}/5000 words ${wordCount > 5000 ? `(exceeds limit)` : "allowed"}`;
                                })()}
                              </span>
                            </div>
                            <Textarea
                              value={formData.linkContent || formData.content}
                              onChange={(e) => {
                                setFormData(prev => ({
                                  ...prev,
                                  linkContent: e.target.value,
                                  content: e.target.value
                                }))
                                setIsDirty(true)
                                if (e.target.value.trim()) {
                                  setError("linkContent", "")
                                }
                              }}
                              placeholder="Content will be generated from the URL"
                              variant="bordered"
                              radius="sm"
                              classNames={{
                                input: "min-h-[150px]",
                                inputWrapper: [
                                  errors.linkContent ? "border-red-500" : "",
                                  "group-data-[focus=true]:border-[#0098F5]",
                                  "dark:group-data-[focus=true]:border-[#0098F5]",
                                ],
                              }}
                            />
                            {errors.linkContent && <p className="text-red-500 text-xs mt-1">{errors.linkContent}</p>}
                          </div>
                        </>
                      )}

                      {
                        (showLinkContentFields || editingItem) && (
                          <div className="flex gap-2 justify-end">
                            <Button
                              radius="sm"
                              color="primary"
                              className="bg-[#0098F5] cursor-pointer"
                              onPress={handleSave}
                              isLoading={loading.link}
                              disabled={!formData.url || !isValidUrl(formData.url) ||
                                !(formData.linkContent || formData.content) ||
                                countWords(formData.linkContent || formData.content) > 200}
                            >
                              Save Changes
                            </Button>
                          </div>
                        )
                      }

                    </div>
                  )}

                  {/* Links List */}
                  {!showAddForm && (
                    <div>
                      {links.map((item, index) => renderLinkItem(item, index))}
                      {links.length === 0 && !showAddForm && (
                        <p className="text-gray-500 text-center py-8">No links added yet</p>
                      )}
                    </div>
                  )}

                </>
              )}

              {/* Files Tab */}
              {activeTab === "Files" && (
                <>
                  <div className={`flex items-center ${showAddForm ? 'justify-between' : 'justify-end'} mb-6`}>
                    {
                      showAddForm && (
                        <Button
                          size="sm"

                          className="cursor-pointer"
                          onPress={() => {
                            setShowLinkContentFields(false)
                            setEditingItem(null)
                            setShowAddForm(false)
                          }}
                        >Back</Button>
                      )
                    }
                    <div className="flex items-center gap-4">
                      <span className="text-sm text-gray-600">File Added: {files.length}/5</span>
                      {files.length < 5 && (
                        <Button

                          radius="sm"
                          color="primary"
                          variant="bordered"
                          className="border-[#0098F5] text-[#0098F5] cursor-pointer"
                          onPress={handleAddNew}
                        >
                          Add File
                        </Button>
                      )}
                    </div>
                  </div>

                  {/* Add/Edit Form */}
                  {showAddForm && (
                    <div className=" p-4 rounded-lg mb-6">
                      <h3 className="font-medium mb-4">{editingItem ? "Edit File" : "Add New File"}</h3>

                      <label
                        htmlFor="upload"
                        className="w-full h-[180px] inline-block mb-4 pb-9 pt-4 bg-white border-dashed border-2 border-gray-400 rounded-lg items-center text-center cursor-pointer hover:border-gray-500 transition-colors"
                      >
                        <input
                          id="upload"
                          ref={fileInputRef}
                          type="file"
                          className="hidden"
                          accept=".pdf,.doc,.docx,.txt"
                          onChange={handleFileChange}
                        />

                        <div className="flex flex-col items-center">
                          <h5 className="mb-2 text-xl font-bold tracking-tight text-gray-700">Upload Document</h5>
                          <p className="font-normal text-sm text-gray-500 mb-2">Drop your file here or click to browse</p>
                          <p className="font-normal text-sm text-gray-400">
                            File size must be less than <b className="text-gray-600">1MB</b>
                          </p>
                          <p className="font-normal text-sm text-gray-400">
                            Format: <b className="text-gray-600">PDF, DOCX or TXT</b>
                          </p>

                          {formData.file && (
                            <p className="text-sm text-green-600 font-medium mt-2">Selected: {formData.file.name}</p>
                          )}
                          {errors.file && <p className="text-red-500 text-xs mt-2 mb-2">{errors.file}</p>}
                        </div>
                      </label>

                      <div className="flex gap-2 justify-end">
                        <Button
                          radius="sm"
                          color="primary"
                          className="bg-[#0098F5] cursor-pointer"
                          onPress={handleSave}
                          isLoading={loading.files}
                          disabled={!formData.file && !editingItem}
                        >
                          Save Changes
                        </Button>
                      </div>
                    </div>
                  )}

                  {
                    !showAddForm && (
                      <div>
                        {files.map((item, index) => renderFileItem(item, index))}
                        {files.length === 0 && !showAddForm && (
                          <p className="text-gray-500 text-center py-8">No files added yet</p>
                        )}
                      </div>
                    )}

                </>
              )}
            </>
          )
        }

      </div>
    </div>
  )
}

export default ClientTraining
import { Select, SelectItem } from "@nextui-org/select";
import { IconChevronDown } from "@tabler/icons-react";
export const YearPicker = ({ setFilterStartYear, startYear, errorMessage="",register,id,isInvalid }) => {
    const MIN_YEAR = 2025;
    const MAX_YEAR = 2030;

    return (
        <Select
            selectedKeys={startYear ? [String(startYear)] : []}
            onChange={(e) => setFilterStartYear(Number(e.target.value))}
            selectorIcon={<IconChevronDown color="gray" className="text-2xl" size="4em" />}
            variant="bordered"
            size="sm"
            label=" "
            id="start_year" 
            fieldName="start_year"
            placeholder="Select Year"
            errorMessage={errorMessage}
            className="min-w-40"
            {...(register && register(id))}
            isInvalid={isInvalid}
            classNames={{
                listbox: "remove-truncate",
                trigger: [
                    "data-[open=true]:border-2 data-[open=true]:border-[#0098F5]",
                    "data-[focus=true]:border-2 data-[focus=true]:border-[#0098F5]",
                    "dark:data-[open=true]:border-2 dark:data-[open=true]:border-[#0098F5]",
                    "dark:data-[focus=true]:border-2 dark:data-[focus=true]:border-[#0098F5]",
                ],
            }}
            renderValue={(items) => {
                if (!items || items.length === 0) return startYear || "Select year";
                return items.map((item) => item.textValue).join(", ");
            }}
        >
            {Array.from({ length: MAX_YEAR - MIN_YEAR + 1 }, (_, i) => MIN_YEAR + i).map((year) => (
                <SelectItem key={String(year)} value={String(year)} textValue={String(year)}>
                    {year}
                </SelectItem>
            ))}
        </Select>
    );
}
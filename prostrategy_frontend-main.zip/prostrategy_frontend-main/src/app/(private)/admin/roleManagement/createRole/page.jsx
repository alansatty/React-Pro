import AddRoleForm from "./_components/AddRoleForm";

function CreateRolePage() {
  return (
    <div>
      <AddRoleForm />
    </div>
  );
}

export default CreateRolePage;

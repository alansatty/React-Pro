import React, { useEffect, useMemo, useState } from "react";
import { FormInput } from "../../../../../../components";
import { useNavigate } from "react-router-dom";
import { Controller, useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { Button } from "@nextui-org/button";
import { Divider } from "@nextui-org/divider";
import { Radio, RadioGroup } from "@nextui-org/radio";
import { Checkbox } from "@nextui-org/checkbox";
import PermissionTable from "./permissionTable";
import { PermissionIcon } from "../../../../../../assets/icons/permission-icon";
import { OrganizationGoalIcon } from "../../../../../../assets/icons/organizationGoal-icon";
import { Card, CardBody, CardFooter, CardHeader } from "@nextui-org/card";
import { apiList } from "../../../../../../services";
import useApi from "../../../../../../hooks/useApi";
import DepartmentsIcon from "../../../../../../assets/icons/departments";
import { RoleSchema } from "../../../../../../../validationSchema/authValidation";
import toast from "react-hot-toast";
import axios from "axios";
import { useAuth } from "../../../../../../providers/authProviders";
import Swal from "sweetalert2/dist/sweetalert2.js";
import { IconSettings } from "@tabler/icons-react";
import hasPermission from "../../../../../../utils/hasPermission";
import DeptGoalsIcon from "../../../../../../assets/icons/deptGoals-icon";
import FileSearchIcon from "../../../../../../assets/icons/FileSearchIcon";
import SvaDashIcon from "../../../../../../assets/icons/Sva-DashIcon";
import AnalysisIcon from "../../../../../../assets/icons/analysis-icon";
import StrategicPlansIcon from "../../../../../../assets/icons/strategicPlans-icon";
import withReactContent from "sweetalert2-react-content";
import ProstrategyLogo from "../../../../../../assets/icons/ProstrategyLogo";
import useUnsavedChanges from "../../../../../../hooks/useUnsavedChanges";
import UnsavedChangesModal from "../../../../../../components/Alert/UnsavedChangesModal";
const MySwal = withReactContent(Swal);

function AddRoleForm({ roleId }) {
  const navigate = useNavigate();

  const [roleType, setRoleType] = useState("organization_admin");
  const [selectAll, setSelectAll] = useState(false);
  const [permissions, setPermissions] = useState({});
  const [isUserMadeChanges, setIsUserMadeChanges] = useState(false);

  const auth = useAuth();
  const authToken = useMemo(() => auth?.user?.token, [auth?.user?.token]);
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    control,
  } = useForm({
    resolver: yupResolver(RoleSchema),
  });
  // only will true showmodal value if both conditions are met
  const { showModal, confirmNavigation, cancelNavigation } = useUnsavedChanges(isUserMadeChanges);

  const {
    data: role_permission,
    isLoading,
    error,
  } = useApi(
    apiList.admin.roles.role_permission.key,
    apiList.admin.roles.role_permission.call()
  );

  const getEditIds = (permissions) => {
    const EditIds = [];

    permissions.forEach((item) => {
      if (
        item.resource !== "Department" &&
        item.resource !== "Role Management" &&
        item.resource !== "User Management" &&
        item.resource !== "Strategic Plan Management"
      ) {
        item.action.forEach((action) => {
          if (action.label === "Edit") {
            EditIds.push(action.id);
          }
        });
      }
    });

    return EditIds;
  };

  const getReadOnlyIds = (permissions) => {
    const readOnlyIds = [];

    permissions.forEach((item) => {
      if (
        item.resource !== "Department" &&
        item.resource !== "Role Management" &&
        item.resource !== "User Management" &&
        item.resource !== "Strategic Plan Management"
      ) {
        item.action.forEach((action) => {
          if (action.label === "Read Only") {
            readOnlyIds.push(action.id);
          }
        });
      }
    });

    return readOnlyIds;
  };
  const transformRolePermissionData = (rolePermissionData) => {
    const categories = {
      permission: {
        headers: ["Permission", "List", "Create", "Edit", "Delete"],
        data: [],
        icon: <PermissionIcon />,
      },
      organizationGoals: {
        headers: ["Organization Goals", "Read Only", "", "Edit", ""], // Ensure headers match
        data: [],
        icon: <OrganizationGoalIcon />,
      },
      department: {
        headers: ["Department Management", "List", "Create", "Edit", "Delete"],
        data: [],
        icon: <DepartmentsIcon className="text-[#1E86FF]" />,
      },
      strategyManagement: {
        headers: [
          "Strategic Plan Management",
          "List",
          "Create",
          "Edit",
          "Delete",
        ],
        data: [],
        icon: <StrategicPlansIcon className="text-[#1E86FF]" />,
      },

      strategicPlans: {
        headers: ["Strategic Plans", "Has Access", "", "", ""], // Ensure headers match
        data: [],
        icon: <StrategicPlansIcon className="text-[#1E86FF]" />,
      },

      departmentGoals: {
        headers: ["Department Goals", "Read Only", "", "Edit", ""], // Ensure headers match
        data: [],
        icon: <DeptGoalsIcon className="text-[#1E86FF]" />,
      },
      departmentStrategicSupport: {
        headers: ["Department Strategic Support", "Read Only", "", "Edit", ""], // Ensure headers match
        data: [],
        icon: <DepartmentsIcon className="text-[#1E86FF]" />,
      },

      departmentStrategicSupportMonitor: {
        headers: ["Department Strategic Support Monitor", "Has Access", "", "", ""], // Ensure headers match
        data: [],
        icon: <StrategicPlansIcon className="text-[#1E86FF]" />,
      },
      strategyData: {
        headers: ["Strategy Data", "Has Access", "", "", ""], // Ensure headers match
        data: [],
        icon: <DepartmentsIcon className="text-[#1E86FF]" />,
      },

      // swotAnalysis: {
      //   headers: ["SWOT Analysis", "Has Access", "", "", ""], // Ensure headers match
      //   data: [],
      //   icon: <AnalysisIcon className="text-[#1E86FF]" />,
      // },

      departmentSettings: {
        headers: ["Department Settings", "Read Only", "", "Edit", ""],
        data: [],
        icon: <IconSettings className="text-[#1E86FF]" />,
      },
      departmentSvaForm: {
        headers: ["Department SVA Form", "Read Only", "", "Edit", ""], // Ensure headers match
        data: [],
        icon: <FileSearchIcon className="text-[#1E86FF]" />,
      },
      departmentSvaDash: {
        headers: ["Department SVA Dashboard", "Read Only", "", "Edit", ""], // Ensure headers match
        data: [],
        icon: <SvaDashIcon className="text-[#1E86FF]" />,
      },

      settings: {
        headers: ["Settings", "Read Only", "", "Edit", ""], // Ensure headers match
        data: [],
        icon: <IconSettings className="text-[#1E86FF]" />,
      },

      subscription: {
        headers: ["Subscription Plans", "Has Access", "", "", ""], // Ensure headers match
        data: [],
        icon: <IconSettings className="text-[#1E86FF]" />,
      },
    };

    rolePermissionData?.forEach((item) => {
      const rowData = ["", "", "", "", ""]; // Initialize with empty strings for all columns
      rowData[0] = item.resource; // First column for the resource

      item?.action?.forEach((action) => {
        switch (action.label) {
          case "List":
            rowData[1] = { id: action.id, is_checked: action.is_checked };
            break;
          case "Read Only":
            rowData[1] = { id: action.id, is_checked: action.is_checked };
            break;
          case "Create":
            rowData[2] = { id: action.id, is_checked: action.is_checked };
            break;
          case "Edit":
            rowData[3] = { id: action.id, is_checked: action.is_checked };
            break;
          case "Delete":
            // if (item.resource === "Department") {
            rowData[4] = { id: action.id, is_checked: action.is_checked };
            // }
            break;
          case "Has Access":
            // if (item.resource === "Department") {
            rowData[1] = { id: action.id, is_checked: action.is_checked };
            // }
            break;
          default:
            break;
        }
      });

      if (item.resource == "Department Settings Business Targets") {
        let modifiedData = rowData[0]?.replace("Settings ", "");
        rowData[0] = modifiedData;
        categories.departmentSettings.data.push(rowData);
      } else if (
        item.resource == "Organization Settings" ||
        item.resource == "Organization Business Targets" ||
        item.resource == "Organization Agent Name" ||
        item.resource == "Organization Agent Link"
      ) {
        let modifiedData = rowData[0]?.replace("settings_", "");
        rowData[0] = modifiedData;
        categories.settings.data.push(rowData);
      } else if (item.resource == "Department") {
        categories.department.data.push(rowData);
      } else if (item.resource == "Strategic Plan Management") {
        categories.strategyManagement.data.push(rowData);
      } else if (
        item.resource == "Department Mission" ||
        item.resource == "Department Vision" ||
        item.resource == "Department Value" ||
        item.resource == "Department Sustaining Objectives" ||
        item.resource == "Department SWOT Form" ||
        item.resource == "Department Strategic Goals"
      ) {
        categories.departmentGoals.data.push(rowData);
      } else if (
        item.resource == "Organization Goal Alignment" ||
        item.resource == "Organization Pillars" ||
        item.resource == "Goal Deliverable Summary" ||
        item.resource == "Strategy Summary" ||
        item.resource == "Core Purpose/Vision Trajectory" ||
        item.resource == "History and Strategic Foundation" ||
        item.resource == "Benefit  Analysis/Strategic Outcome" ||
        item.resource == "Potential Risk/Contegencies" ||
        item.resource == "Strategy Phasing/Timing" ||
        item.resource == "Cost Benefit/Model" ||
        item.resource == "Strategic Implementation Group(SIG)"
      ) {
        categories.departmentStrategicSupport.data.push(rowData);
      } else if (item.resource == 'Strategic Binder Monitor') {
        categories.departmentStrategicSupportMonitor.data.push(rowData)
      } else if (
        item.resource == "Department Strategic Form" ||
        item.resource == "Department Strategic Data" ||
        item.resource == "Department Strategic Gantt Chart"
      ) {
        categories.strategyData.data.push(rowData);
      }
      // else if (
      //   item.resource == "Department SWOT Analysis" ||
      //   item.resource == "Organization SWOT Analysis"
      // ) {
      //   categories.swotAnalysis.data.push(rowData);
      // }
      else if (item.resource == "Expected Delivery") {
        // let modifiedData = rowData[0]?.replace("Department Year Of", "");
        // rowData[0] = modifiedData;
        categories.departmentSvaDash.data.push(rowData);
      } else if (
        item.resource == "Department Minimum Requirements" ||
        item.resource == "Department Market Competitive" ||
        item.resource == "Department Leadership" ||
        item.resource == "Department Elite"
      ) {
        let modifiedData = rowData[0]?.replace("Department ", "");
        rowData[0] = modifiedData;
        categories?.departmentSvaForm?.data?.push(rowData);
      } else if (
        item.resource.includes("Organization") &&
        !item.resource.includes("SWOT Analysis")
      ) {
        categories.organizationGoals.data.push(rowData);
      } else if (
        item.resource === "User Management" ||
        item.resource === "Role Management"
      ) {
        categories.permission.data.push(rowData);
      } else if (
        item.resource === "Upgrade/Downgrade Plan" ||
        item.resource === "Billing History"
      ) {
        categories.subscription.data.push(rowData);
      } else if (item.resource.startsWith("Others_")) {
        categories?.strategicPlans.data.push(rowData);
      }
    });

    const permissionTableData = Object.values(categories);

    return permissionTableData;
  };

  const handleCancel = () => {
    setTimeout(() => {
      navigate("/settings/team_management_tab/role-management")
    }, 1)

  }

  const permissionTableData = transformRolePermissionData(
    role_permission?.data
  );

  const handlePermissionChange = (id, checked, rowData) => {

    const stringsToCheck = [
      "Organization Mission",
      "Organization Vision",
      "Organization Value",
      "Organization Pillars",
      "Organization Goal Alignment",
      "Organization Sustaining Objectives",
      "Organization SWOT Form",
      "Organization Strategic Goals",
      "Department Mission",
      "Department Vision",
      "Department Value",
      "Department Sustaining Objectives",
      "Department SWOT Form",
      "Department Strategic Goals",
      "Department Business Targets",
      "Minimum Requirements",
      "Market Competitive",
      "Leadership",
      "Elite",
      "Expected Delivery",
      "Organization Settings",
      "Organization Business Targets",
      "Organization Agent Link",
      "Organization Agent Name",
      "Goal Deliverable Summary",
      "Strategy Summary",
      "Core Purpose/Vision Trajectory",
      "History and Strategic Foundation",

      "Benefit  Analysis/Strategic Outcome",
      "Potential Risk/Contegencies",
      "Strategy Phasing/Timing",
      "Cost Benefit/Model",
      "Strategic Implementation Group(SIG)",
      "Strategic Binder Monitor"
    ]; // Add all strings you want to check

    setPermissions((prevPermissions) => {
      const newPermissions = { ...prevPermissions, [id]: checked };

      // Check if rowData[0] contains any of the strings in stringsToCheck

      if (rowData && stringsToCheck.some((str) => rowData[0]?.includes(str))) {
        // Locate the "Read Only" and "Edit" cells in the same row
        // const readOnlyCell = rowData.find(
        //   (cell) => cell?.id && rowData[1]?.id === cell.id
        // ); // Assuming Read Only is in index 1
        // const editCell = rowData.find(
        //   (cell) => cell?.id && rowData[3]?.id === cell.id
        // ); // Assuming Edit is in index 3
        const readOnlyCell = rowData[1] && typeof rowData[1] === 'object' ? rowData[1] : null;
        const editCell = rowData[3] && typeof rowData[3] === 'object' ? rowData[3] : null;

        if (readOnlyCell?.id === id && checked) {
          if (editCell?.id) newPermissions[editCell.id] = false;
        } else if (editCell?.id === id && checked) {
          if (readOnlyCell?.id) newPermissions[readOnlyCell.id] = false;
        }
      }
      //   if (readOnlyCell?.id === id && checked) {
      //     // If "Read Only" is checked, uncheck "Edit"
      //     newPermissions[editCell.id] = false;
      //   } else if (editCell?.id === id && checked) {
      //     // If "Edit" is checked, uncheck "Read Only"
      //     newPermissions[readOnlyCell.id] = false;
      //   } else {
      //     newPermissions[id] = true;
      //   }
      // }

      if (
        rowData &&
        (rowData[0] === "User Management" ||
          rowData[0] === "Role Management" ||
          rowData[0] === "Department" ||
          rowData[0] === "Strategic Plan Management")
      ) {
        const listCell = rowData[1] && typeof rowData[1] === 'object' ? rowData[1] : null;

        if (listCell?.id === id && !checked) {
          if (rowData[2]?.id) newPermissions[rowData[2].id] = false;
          if (rowData[3]?.id) newPermissions[rowData[3].id] = false;
          if (rowData[4]?.id) newPermissions[rowData[4].id] = false;
        }
      }
      // if (
      //   rowData &&
      //   (rowData[0] === "User Management" ||
      //     rowData[0] === "Role Management" ||
      //     rowData[0] === "Department" ||
      //     rowData[0] === "Strategic Plan Management")
      // ) {
      //   const listCell = rowData.find(
      //     (cell) => cell?.id && rowData[1]?.id === cell.id
      //   );

      //   if (listCell?.id === id && !checked) {
      //     newPermissions[rowData[2]?.id] = false;
      //     newPermissions[rowData[3]?.id] = false;
      //     newPermissions[rowData[4]?.id] = false;
      //   }
      // }

      return newPermissions;
    });
  };

  useEffect(() => {
    if (roleId) {
      axios
        .get(`/organization/roles/permission_dropdown/${roleId}`, {
          headers: { Authorization: `Bearer ${authToken}` },
        })
        .then((response) => {
          populateForm(response);
        })
        .catch((error) => {
          console.log("Failed to fetch role data", error);
        });
    } else {
      defaultFormPopulate();
    }
  }, [role_permission]);

  const defaultFormPopulate = () => {
    const updatedPermissions = {};

    // Ensure role_permission is defined and has data
    if (role_permission?.data) {
      // Extract Read Only IDs
      const readOnlyIds = getReadOnlyIds(role_permission.data);

      // Mark all permissions as checked or unchecked based on the selectAll state
      role_permission.data.forEach((category) => {
        category.action.forEach((cellData) => {
          if (typeof cellData === "object" && cellData !== null) {
            const readOnly = readOnlyIds.includes(cellData.id);

            // Only update the permission if it's not a "Read Only" checkbox
            if (readOnly) {
              updatedPermissions[cellData.id] = true;
            }
          }
        });
      });
    }

    setPermissions((prevPermissions) => ({
      ...prevPermissions,
      ...updatedPermissions,
    }));
  };

  const populateForm = (roleData) => {
    setRoleType(roleData.data?.role_type);
    const permissionMap = {};
    roleData.data?.data?.forEach((item) => {
      item.action.forEach((action) => {
        permissionMap[action.id] = action.is_checked;
      });
    });

    setPermissions(permissionMap);
    // setValue("name", roleData.data?.role_name)
    reset({ name: roleData?.data?.role_name });
  };

  const { trigger: updateRoleTrigger, isMutating: isMutateUpdate } = useApi(
    null,
    apiList.admin.roles.update.call(roleId),
    { method: "PUT" }
  );

  const { trigger, isMutating } = useApi(
    null,
    apiList.admin.roles.create.call(),
    { method: "POST" } // Use PUT for editing, POST for creating
  );

  const deselectAll = () => {
    const updatedPermissions = {};
    role_permission.data.forEach((category) => {
      category.action.forEach((cellData) => {
        if (typeof cellData === "object" && cellData !== null) {
          updatedPermissions[cellData.id] = false;
        }
      });
    });

    setPermissions((prevPermissions) => ({
      ...prevPermissions,
      ...updatedPermissions,
    }));
  };
  const handleSelectAll = (checked) => {
    setSelectAll(checked);
    deselectAll();
    const updatedPermissions = {};

    // Ensure role_permission is defined and has data
    if (role_permission?.data) {
      // Extract Read Only IDs
      const EditIds = getEditIds(role_permission.data);

      // Mark all permissions as checked or unchecked based on the selectAll state
      role_permission.data.forEach((category) => {
        category.action.forEach((cellData) => {
          if (typeof cellData === "object" && cellData !== null) {
            const isEdit = EditIds.includes(cellData.id);

            // Only update the permission if it's not a "Read Only" checkbox
            if (!isEdit) {
              updatedPermissions[cellData.id] = checked;
            }
          }
        });
      });
    }

    setPermissions((prevPermissions) => ({
      ...prevPermissions,
      ...updatedPermissions,
    }));
  };

  const CreateRole = async (data) => {
    if (data) {
      try {
        const selectedPermissionIds = Object.keys(permissions).filter(
          (id) => permissions[id] === true // Only include the IDs with true values
        );

        data.role_type = roleType;

        data.permissions = selectedPermissionIds;

        if (roleId) {
          let response = await updateRoleTrigger({ requestBody: data });
          MySwal.fire({
            html: (
              <div className="flex flex-col items-center">
                <div className="w-18 h-20 mb-2">
                  <ProstrategyLogo />
                </div>
                <h2 className="text-xl font-semibold">Success!</h2>
                <p className="mt-2">Role Updated Successfully</p>
              </div>
            ),
            allowOutsideClick: false,
            confirmButtonText: "Okay",
            customClass: {
              confirmButton: "my-confirm-button",
            },
          }).then((result) => {
            if (result.isConfirmed) {
              navigate("/settings/team_management_tab/role_management"); // Perform navigation after clicking "Okay"
            }
          });
        } else {
          let response = await trigger({ requestBody: data });
          MySwal.fire({
            html: (
              <div className="flex flex-col items-center">
                <div className="w-18 h-20 mb-2">
                  <ProstrategyLogo />
                </div>
                <h2 className="text-xl font-semibold">Success!</h2>
                <p className="mt-2">Role Created Successfully</p>
              </div>
            ),
            allowOutsideClick: false,
            confirmButtonText: "Okay",
            customClass: {
              confirmButton: "my-confirm-button",
            },
          }).then((result) => {
            if (result.isConfirmed) {
              if (!hasPermission("roles", "list")) {
                navigate("/role-management/create");
              } else {
                navigate("/settings/team_management_tab/role_management");
              }
            }
          });
        }
      } catch (error) {
        if (error?.status == 400) {
          if (error?.data?.msg) {
            toast.error(error?.data?.msg);
          }
          if (error?.permissions[0]) {
            toast.error(error?.permissions[0]);
          }
        }

        if (error?.permissions) {
          if (error?.permissions[0]) {
            toast.error(error?.permissions[0]);
          }
        }
        // toast.error("Failed to create role");
      } finally {
        setIsUserMadeChanges(false)
      }
    }
  };

  return (
    <Card shadow="sm" className="p-5">
      {showModal && (
        <UnsavedChangesModal
          isConfirmNavigation={confirmNavigation}
          isCancelNavigation={cancelNavigation}
        />
      )}
      <form onSubmit={handleSubmit(CreateRole)}>
        <CardHeader>
          <h3 className="font-semibold text-xl mb-6 text-gray-700">
            {roleId ? "Edit Role" : "Create New Role"}
          </h3>
        </CardHeader>
        <CardBody className="">
          <div className="">
            <div className="flex  gap-20 mb-5">
              <Controller
                name="name"
                control={control}
                render={({ field }) => (
                  <FormInput
                    {...field}
                    onChange={(e) => {
                      setIsUserMadeChanges(true)
                      field.onChange(e)
                    }}
                    radius="sm"
                    label="Role Name"
                    fieldName="name"
                    register={register}
                    errors={errors}
                    placeholder="Enter role name"
                    className="w-1/2"
                    isRequired={true}
                  />
                )}
              />

              <RadioGroup
                label="Role Type"
                orientation="horizontal"
                value={roleType}
                onValueChange={setRoleType}
                defaultValue="organization_admin"
                isRequired={true}
                onChange={() => {
                  setIsUserMadeChanges(true)
                }}
              >
                <Radio value="organization_admin">Admin Role</Radio>
                <Radio value="organization_department">Department Role</Radio>
                <Radio value="organization_guest">Guest User Role</Radio>
                {errors.role_type && (
                  <span className="text-red-500 text-sm">
                    {errors.role_type.message}
                  </span>
                )}
              </RadioGroup>
            </div>

            <Checkbox
              checked={selectAll}
              onChange={(e) => {
                handleSelectAll(e.target.checked)
                setIsUserMadeChanges(true)
              }
              }
            >
              Select all
            </Checkbox>

            {permissionTableData?.map((item, index) => (
              <PermissionTable
                key={index}
                headers={item.headers}
                data={item.data}
                icon={item.icon}
                register={register}
                handlePermissionChange={handlePermissionChange}
                permissions={permissions}
                setIsUserMadeChanges={setIsUserMadeChanges}
              />
            ))}
          </div>
        </CardBody>
        <CardFooter>
          <div className="w-full">
            <Divider className="mb-3" />
            <div className="flex justify-end gap-3">
              <Button
                variant="bordered"
                onPress={() => {
                  setIsUserMadeChanges(false)
                  handleCancel()
                }
                }
                type="button"
                className="border-appSecondary text-center"
                radius="sm"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="bg-appSecondary text-white"
                radius="sm"
                isLoading={roleId ? isMutateUpdate : isMutating}
              >
                {roleId ? "Update" : "Create"}
              </Button>
            </div>
          </div>
        </CardFooter>
      </form>
    </Card>
  );
}

export default AddRoleForm;

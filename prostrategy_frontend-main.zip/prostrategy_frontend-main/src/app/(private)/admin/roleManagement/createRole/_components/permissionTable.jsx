import React from "react";
import { Checkbox } from "@nextui-org/checkbox";

const PermissionTable = ({
  headers,
  data,
  icon,
  handlePermissionChange,
  permissions,
  setIsUserMadeChanges
}) => {
  const formatCellData = (data) => {
    return data
      .replace(/_/g, " ") // Replace underscores with spaces
      .toLowerCase() // Convert to lowercase
      .replace(/^\w|\s\w/g, (match) => match.toUpperCase()); // Capitalize first letter of each word
  };

  return (
    <table
      aria-label="Permissions Table"
      className="mt-5 w-full border-collapse"
    >
      <thead>
        <tr className="bg-gray-200">
          {headers.map((header, index) => (
            <th
              key={index}
              className={`text-base text-gray-700 text-start w-[650px] h-10 ml-2 ${index === 0 ? "flex gap-2 items-center" : ""
                }`}
            >
              {index === 0 && icon} {/* Optional icon for the first column */}
              {header}
            </th>
          ))}
        </tr>
      </thead>

      <tbody>
        {data?.map((rowData, rowIndex) => {
          return (
            <tr key={rowIndex} className="hover:bg-gray-100">
              {rowData?.map((cellData, cellIndex) => {
                // Render checkbox for object-type cellData
                if (typeof cellData === "object" && cellData !== null) {
                  return (
                    <td key={cellIndex} className="w-[150px] h-12">
                      <div className="flex items-center justify-start">
                        <Checkbox
                          isDisabled={
                            (rowData[0] === "User Management" ||
                              rowData[0] === "Department" ||
                              rowData[0] === "Role Management" ||
                              rowData[0] === "Strategic Plan Management") &&
                            (!permissions[rowData[1]?.id] ||
                              permissions[rowData[1]?.id] === false) &&
                            cellData.id !== rowData[1]?.id
                          }
                          isSelected={permissions[cellData.id] || false}
                          onChange={(e) => {
                            handlePermissionChange(
                              cellData.id,
                              e.target.checked,
                              rowData
                            )
                            setIsUserMadeChanges(true)
                          }

                          }
                        />
                      </div>
                    </td>
                  );
                }

                // Render normal text cell
                return (
                  <td key={cellIndex} className="w-[150px] h-12">
                    <div className="flex items-center justify-start">
                      {cellData === "Others_default_strategic_plan"
                        ? formatCellData(cellData.replace("Others_", ""))
                        : cellData.startsWith("Others_")
                          ? cellData.replace("Others_", "")
                          : cellData.includes("Sustaining Objectives")
                            ? cellData.replace(" Sustaining Objectives", " Pillars")
                            : cellData}
                    </div>
                  </td>
                );
              })}

              {/* Add empty cells if rowData length is less than headers length */}
              {headers.length > rowData.length &&
                Array.from({ length: headers.length - rowData.length }).map(
                  (_, idx) => (
                    <td
                      key={`empty-${rowIndex}-${idx}`}
                      className="w-[150px] h-12"
                    ></td>
                  )
                )}
            </tr>
          );
        })}
      </tbody>
    </table>
  );
};

export default PermissionTable;

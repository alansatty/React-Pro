import { Select, SelectItem } from "@nextui-org/select";
import CustomTable from "../../../../components/Table/CustomTable";
// import UserManagementTable from './components/UserManagementTable'
import { Button } from "@nextui-org/button";
import {
  IconEdit,
  IconEye,
  IconPlus,
  IconSearch,
  IconTrash,
} from "@tabler/icons-react";
import { Tooltip } from "@nextui-org/tooltip";
import { useLocation, useNavigate } from "react-router-dom";
import React, { useCallback, useMemo, useState } from "react";
import { apiList } from "../../../../services";
import useApi from "../../../../hooks/useApi";
import { Card } from "@nextui-org/card";
import { PageSpinner, PermissionWrapper } from "../../../../components";
import ConfirmationModal from "../../../../components/ConfirmationModal/ConfirmationModal";
import toast from "react-hot-toast";
import { mutate } from "swr";
import { Input } from "@nextui-org/input";
import SearchInput from "../../../../components/searchInput/SearchInput";
import { useAuth } from "../../../../providers/authProviders";
import { IconRotate } from "@tabler/icons-react";
function RoleManagement() {
  const navigate = useNavigate();
  const [page, setPage] = useState(1);
  const [role, setRole] = useState("");
  const [selectedItem, setSelectedItem] = useState(null);
  const [confirmation, setConfirmation] = useState(false);
  const [search, setSearch] = useState("");
  const [searchval, setSearchVal] = useState("");
  const [perPage, setPerPage] = useState(10);

  const {
    data: roleList,
    isLoading,
    isValidating,
  } = useApi(
    apiList.admin.roles.index.key(perPage, page, null, {
      role: role,
      search: search,
    }),
    apiList.admin.roles.index.call(perPage, page, null, {
      role: role,
      search: search,
    })
  );

  const auth = useAuth();

  const { trigger: deleteRole, isMutating } = useApi(
    null,
    apiList.admin.roles.delete.call(),
    { method: "DELETE" }
  );

  const columns = [
    { name: "#", uid: "sl" },
    { name: "Name", uid: "name" },
    { name: "Role Type", uid: "role_type" },
    { name: "", uid: "actions" },
  ];

  const deleteRoles = (item) => {
    setSelectedItem(item);
    setConfirmation(true);
  };

  const handlePageChange = (newPage) => {
    setPage(newPage);
    // navigate(pathname + "?" + createQueryString("page", newPage));
  };

  const confirmDeleteRole = async () => {
    try {
      const res = await deleteRole({
        dynamicPath: selectedItem.id + "/delete",
      });
      if (res.status == "success") {
        mutate(apiList.admin.roles.index.key(perPage, 1));
        toast.success(res?.msg);
      }
    } catch (error) {
      console.log(error);
      if (error?.status == 400) {
        toast.error(error?.data?.msg);
      }
      // toast.error("Something went wrong!");
    } finally {
      setConfirmation(false);
    }
  };

  // const { data, error, isLoading } = useApi(apiList.admin.user.rolesDropdown.key, apiList.admin.user.rolesDropdown.call());
  const data = [
    { id: "organization_admin", name: "Admin Role" },
    { id: "organization_department", name: "Department Role" },
    { id: "organization_guest", name: "Guest User Role" },
  ];

  const resetFields = () => {
    setRole("");
    setSearch("");
    setSearchVal("");
  };

  const renderCell = React.useCallback((roles, columnKey, pagef, rowIndex) => {
    let cellValue = roles[columnKey];
    if (!cellValue) {
      cellValue = "-";
    }
    const queryPage = pagef ? pagef : 1;

    const rowsPerPage = 10;
    const slNumber = (queryPage - 1) * rowsPerPage + (rowIndex + 1);

    switch (columnKey) {
      case "sl":
        return <>{slNumber}</>;
      case "actions":
        return (
          <>
            {!roles.is_predefined_role && (
              <div className="relative flex items-center gap-2">
                <PermissionWrapper resource={"roles"} actions={["edit"]}>
                  <Tooltip content="Edit Role">
                    <span
                      className="text-lg
                       text-gray-500
                        cursor-pointer active:opacity-50"
                      onClick={() =>
                        navigate(`/role-management/edit/${roles.id}`)
                      }
                    >
                      <IconEdit />
                    </span>
                  </Tooltip>
                </PermissionWrapper>
                <PermissionWrapper resource={"roles"} actions={["delete"]}>
                  <Tooltip color="danger" content="Delete Role">
                    <span className=" text-lg text-danger cursor-pointer active:opacity-50">
                      <IconTrash
                        onClick={() => deleteRoles(roles)}
                      />
                    </span>
                  </Tooltip>
                </PermissionWrapper>
              </div>
            )}
          </>
        );
      default:
        return cellValue;
    }
  }, []);

  // const topContent = useMemo(() => {
  //   return (

  //   );
  // }, [role, search, searchval]);

  const onSearchChange = (value) => {
    const trimmedValue = value?.trim();
    if (trimmedValue) {
      // debouncedSearch(value);
      setSearch(trimmedValue);
      setPage(1);
    } else {
      setSearch(""); // Clear the search value
    }
  };

  const onClear = () => {
    setSearch("");
    setSearchVal("");
  };

  return (
    <Card className=" bg-white " shadow="none">
      <ConfirmationModal
        isLoading={false}
        isOpen={confirmation}
        onClose={setConfirmation}
        onConfirm={confirmDeleteRole}
      />

      <div className="flex flex-col gap-4">
        <div className="flex justify-between">
          <h2 className="pl-2 text-gray-700 font-semibold text-xl mt-2">
            Role Management
          </h2>
          <PermissionWrapper resource={"roles"} actions={["create"]}>
            <Button
              // isDisabled={true}
              size="md"
              color="primary"
              startContent={<IconPlus className="mb-1" />}
              radius="sm"
              className="font-medium py-[23px] disabled:bg-gray-100 disabled:text-gray-300 min-w-32"
              onPress={() => navigate("/settings/role-management/create")}
            >
              Add Role
            </Button>
          </PermissionWrapper>
        </div>
        <div className="flex justify-between items-center gap-3 w-full">
          {/* Left-aligned search input */}
          <div className="flex items-center justify-start w-full sm:max-w-[44%]">
            {/* <Input
              isClearable
              variant="bordered"
              className="w-full min-w-52"
              classNames={{
                inputWrapper: "h-[46px]",
              }}
              onClear={() => {
                setSearch("");
                setSearchVal("");
              }}
              placeholder="Search..."
              startContent={<IconSearch className="text-gray-400" size={18} />}
              onChange={(e) => {
                debouncedSearch(e.target.value);
                setSearchVal(e.target.value);
              }}
              value={searchval}
              radius="sm"
            /> */}
            <SearchInput
              onSearch={onSearchChange}
              onClear={onClear}
              placeholder="Search name"
              setSearch={setSearchVal}
              value={searchval}
            />
          </div>

          {/* Right-aligned select and button */}

          <div className="flex items-center gap-3">
            {auth?.user?.user_type === "organization_admin" && (
              <Select
                classNames={{
                  trigger: [
                    "data-[open=true]:border-2 data-[open=true]:border-[#0098F5]",
                    "data-[focus=true]:border-2 data-[focus=true]:border-[#0098F5]",
                    "dark:data-[open=true]:border-2 dark:data-[open=true]:border-[#0098F5]",
                    "dark:data-[focus=true]:border-2 dark:data-[focus=true]:border-[#0098F5]",
                  ],
                }}
                items={data || []}
                variant="bordered"
                size="sm"
                label="Select Role Type"
                className="min-w-60"
                onChange={(e) => {
                  setRole(e.target.value);
                }}
                selectedKeys={[role]}
              >
                {(item) => (
                  <SelectItem key={item?.id} value={item?.id}>
                    {item?.name}
                  </SelectItem>
                )}
              </Select>
            )}
          </div>
        </div>
        {(role || search) && (
          <div className="flex justify-end">
            <Button
              color="default"
              variant="flat"
              size="sm"
              radius="sm"
              onPress={resetFields}
            >
              <IconRotate size={18} />
              Reset Filters
            </Button>
          </div>
        )}
      </div>
      <CustomTable
        columns={columns}
        renderCell={renderCell}
        // fetchUrl={apiList.admin.user.roles.call}
        // fetchKey={apiList.admin.user.roles.key}
        responceData={roleList}
        handlePageChange={handlePageChange}
        isLoading={isLoading || isValidating}
        page={page}
        setPage={setPage}
        setPerPage={setPerPage}
        perPage={perPage}
      // rowsPerPage={10}
      // topContent={topContent}
      // filters={{
      //   role:
      //     auth?.user?.user_type !== "organization_admin"
      //       ? auth?.user?.user_type
      //       : role,
      //   search: search,
      // }}
      />
    </Card>
  );
}

export default RoleManagement;

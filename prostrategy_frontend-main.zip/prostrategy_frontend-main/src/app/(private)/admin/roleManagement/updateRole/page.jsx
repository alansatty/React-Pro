import { useNavigate, useParams } from "react-router-dom";
import AddRoleForm from "../createRole/_components/AddRoleForm";
import hasPermission from "../../../../../utils/hasPermission";
import toast from "react-hot-toast";
import { useEffect, useRef } from "react";

function UpdateRole() {
  const { id } = useParams();

  return (
    <div>
      <AddRoleForm roleId={id} />
    </div>
  );
}

export default UpdateRole;

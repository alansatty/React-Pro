import React, { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { toast } from "react-hot-toast";
import { mutate } from "swr";
import useApi from "../../../../hooks/useApi";
import { apiList } from "../../../../services";
import { PermissionWrapper } from "../../../../components";
import hasPlanPermission from "../../../../utils/hasPlanPermission";
import ProstrategyLogo from "../../../../assets/icons/ProstrategyLogo";
import ConfirmationModal from "../../../../components/ConfirmationModal/ConfirmationModal";
import usePermissionsStore from "../../../../stores/usePermissionStore";
import CustomTable from "../../../../components/Table/CustomTable";
import { useAuth } from "../../../../providers/authProviders";
import { useDisclosure } from "@nextui-org/modal";
import { Tooltip } from "@nextui-org/tooltip";
import { IconEdit, IconGripVertical, IconPlus, IconTrash } from "@tabler/icons-react";
import { Card } from "@nextui-org/card";
import Swal from 'sweetalert2/dist/sweetalert2.js'
import { Button } from "@nextui-org/button";
import StrategicPlanDrawer from "./components/StrategicPlanDrawer";
import withReactContent from "sweetalert2-react-content";
const MySwal = withReactContent(Swal)

const StrategicPlans = () => {
  const navigate = useNavigate();
  const auth = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const { isOpen, onOpen, onOpenChange } = useDisclosure();
  const [page, setPage] = useState(1);
  const [confirmation, setConfirmation] = useState(false);
  const [selectedId, setSelectedId] = useState(null);
  const { setStrategicPlan } = usePermissionsStore();
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
  const [perPage, setPerPage] = useState(10);

  const handleEditMode = () => {
    onOpenChange(true);
    setSearchParams({ edit: "true" });
  };

  useEffect(() => {
    if (!isOpen) {
      setSearchParams({});
    }
  }, [isOpen]);

  const [columns, setColumns] = useState([
    { name: "#", uid: "sl" },
    { name: "Plan Name", uid: "name" },
    { name: "Strategic Plan Information", uid: "description" },
    { name: "Applicable Date", uid: "applicable_date" },
    { name: "Modifier Name", uid: "modifier_name" },
    { name: "Modified Date", uid: "updated_at" },
    { name: "Status", uid: "status" },
    { name: "", uid: "actions" },
  ]);

  const { data, isLoading, error } = useApi(
    apiList.admin.strategicPlans.list.key(page, perPage, auth?.user?.id),
    apiList.admin.strategicPlans.list.call(page, perPage),
  );

  const handleMutation = () => {
    mutate(
      apiList.admin.strategicPlans.list.key(page, perPage, auth?.user?.id)
    );
  };

  const { trigger: strategicPlanDelete, isMutating: loadingDelete, mutationError } = useApi(
    null,
    apiList.admin.strategicPlans.delete.call(selectedId),
    { method: "DELETE" }
  );

  useEffect(() => {
    if (mutationError?.data?.["Strategic Plan"]?.[0]) {
      toast.error(mutationError?.data?.["Strategic Plan"]?.[0]);
    }
  }, [mutationError?.data]);


  // API for reordering - note we'll call this directly from the table
  const { trigger: reorderPlan, isMutating: isReordering } = useApi(
    null,
    apiList.admin.strategicPlans.reorder.call(),
    { method: "POST" }
  );

  const {
    data: currentPlanData,
  } = useApi(
    apiList.admin.subscription.current_plan.key(),
    apiList.admin.subscription.current_plan.call()
  );

  const confirmDeleteDepartment = (id) => {
    setSelectedId(id);
    setConfirmation(true);
  };

  // This function will be called immediately when a row is dropped in a new position
  const handleRowReorder = async (strategyPlanId, newPosition) => {
    try {
      const formData = new FormData()
      formData.append('strategic_plan_id', strategyPlanId)
      formData.append('new_position', newPosition)

      await reorderPlan({ requestBody: formData })
      handleMutation();
    } catch (error) {
      console.error("Failed to reorder plan", error);
      toast.error("Failed to reorder plan");
      handleMutation();
    }
  };

  const renderCell = React.useCallback((plans, columnKey, pagef, rowIndex) => {
    let cellValue = plans[columnKey];
    if (!cellValue) {
      cellValue = "-";
    }
    const queryPage = pagef ? pagef : 1;
    const rowsPerPage = 10;
    const slNumber = (queryPage - 1) * rowsPerPage + (rowIndex + 1);

    switch (columnKey) {
      case "sl":
        return <>{slNumber}</>;
      case "actions":
        return (
          <>
            <div className="relative flex items-center gap-2">
              <PermissionWrapper
                resource={"strategic_plans"}
                actions={["edit"]}
              >
                <Tooltip content="Edit plan">
                  <span className="text-lg text-default-500 cursor-pointer active:opacity-50">
                    <IconEdit
                      onClick={() => {
                        setSelectedId(plans?.id);
                        handleEditMode();
                      }}
                    />
                  </span>
                </Tooltip>
              </PermissionWrapper>
              <PermissionWrapper
                resource={"strategic_plans"}
                actions={["delete"]}
              >
                <Tooltip color="danger" content="Delete plan">
                  <span className="text-lg text-danger cursor-pointer active:opacity-50">
                    <IconTrash
                      onClick={() => confirmDeleteDepartment(plans.id)}
                    />
                  </span>
                </Tooltip>
              </PermissionWrapper>
            </div>
          </>
        );
      default:
        return cellValue;
    }
  }, []);

  const deleteDepartment = async () => {
    try {
      let response = await strategicPlanDelete();
      toast.success(response?.data);

      if (strategicPlan === selectedId) {
        const newActivePlan = data.data.find(plan => plan.id !== selectedId)?.id;
        if (newActivePlan) {
          setStrategicPlan(newActivePlan);
        } else {
          setStrategicPlan(null);
        }
      }

      // Refetch the list
      await mutate(apiList.admin.strategicPlans.list.key(page, perPage, auth?.user?.id));
    } catch (error) {
      console.log(error);
      if (error?.data?.status == "validation_errors") {
        const errorMessage = error?.data?.data?.["Strategic Plan"]?.[0];
        toast.error(errorMessage);
      }
    } finally {
      setConfirmation(false);
    }
  };

  useEffect(() => {
    // if (!strategicPlan && isDeletedSuccess) {
    if (!strategicPlan) {
      setStrategicPlan(data.data[0].id);
    }
  }, [strategicPlan, setStrategicPlan])

  const checkPlanPermission = () => {
    if (hasPlanPermission("strategy_plans_allowed_count", data?.data?.length)) {
      setSelectedId(null);
      onOpenChange(true);
    } else {
      if (
        ["Free", "Essential", "Plus"].includes(currentPlanData?.data?.plan_name)
      ) {
        MySwal.fire({
          html: (
            <div className="flex flex-col items-center">
              <div className="w-18 h-20 mb-2">
                <ProstrategyLogo />
              </div>
              <h2 className="text-xl font-semibold">Warning!</h2>
              <p className="mt-2">
                Strategic plan creation on this plan is exceeded. Please update
                your plan
              </p>
            </div>
          ),
          confirmButtonText: "Go to plans",
          customClass: {
            confirmButton:
              "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
          },
        }).then((result) => {
          if (result.isConfirmed) {
            navigate("/settings/account_tab");
          }
        });
      } else {
        MySwal.fire({
          html: (
            <div className="flex flex-col items-center">
              <div className="w-18 h-20 mb-2">
                <ProstrategyLogo />
              </div>
              <h2 className="text-xl font-semibold">Warning!</h2>
              <p className="mt-2">
                Strategic plan creation on this plan is exceeded.
              </p>
            </div>
          ),
          confirmButtonText: "Okay",
          customClass: {
            confirmButton:
              "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
          },
        });
      }
    }
  };

  return (
    <Card className=" bg-white" shadow="none">
      <ConfirmationModal
        isLoading={loadingDelete}
        isOpen={confirmation}
        onClose={setConfirmation}
        onConfirm={deleteDepartment}
      />
      <StrategicPlanDrawer
        selectedId={selectedId}
        title={selectedId ? "Edit Strategic Plan" : "Create New Strategic Plan"}
        drawerState={isOpen}
        setDrawerState={onOpenChange}
        handleMutation={handleMutation}
        page={page}
        perPage={perPage}
      />
      <div className="flex flex-col gap-4">
        <div className="flex justify-between">
          <h2 className="pl-2 text-gray-700 font-semibold text-xl mt-2">
            Strategic Plans
          </h2>
          <div className="flex gap-2">
            <PermissionWrapper resource={"strategic_plans"} actions={["create"]}>
              <Button
                size="md"
                color="primary"
                startContent={<IconPlus className="mb-1" />}
                radius="sm"
                className="font-medium py-[23px]"
                onClick={() => {
                  checkPlanPermission();
                }}
              >
                Add Strategic Plan
              </Button>
            </PermissionWrapper>
          </div>
        </div>
      </div>
      <CustomTable
        columns={columns}
        renderCell={renderCell}
        responceData={data}
        isLoading={isLoading}
        page={page}
        isDraggable={true}
        onRowReorder={handleRowReorder}
        setPage={setPage}
        setPerPage={setPerPage}
        perPage={perPage}
      />
    </Card>
  );
};

export default StrategicPlans;
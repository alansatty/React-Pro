import { Textarea } from "@nextui-org/input";
import { useEffect } from "react";
import { FormInput } from "../../../../../components";
import { Button } from "@nextui-org/button";
import { hoverEff } from "../../../../../stores/constants";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { StrategicPLanSchema } from "../../../../../../validationSchema/authValidation";
import useApi from "../../../../../hooks/useApi";
import { apiList } from "../../../../../services";
import toast from "react-hot-toast";
import { mutate } from "swr";
import {
  formatDateForBackend,
  parseBackendDate,
} from "../../../../../utils/helpers";
import { useAuth } from "../../../../../providers/authProviders";

const StrategicForm = ({
  setDrawerState,
  initialData,
  selectedId = null,
  handleMutation,
  page,
  perPage, }) => {
  const auth = useAuth();
  const {
    register,
    handleSubmit,
    setError,
    reset,
    formState: { errors: formErrors },
  } = useForm({
    resolver: yupResolver(StrategicPLanSchema),
    mode: "onChange",
    defaultValues: {
      strategic_plan_name: initialData?.strategic_plan_name || "",
      strategicInformation: initialData?.description || "",
      applicable_date: initialData?.applicable_date
        ? parseBackendDate(initialData.applicable_date, "/")
        : null,
    },
  });

  // This effect ensures form is updated when initialData changes
  useEffect(() => {
    if (initialData) {
      reset({
        strategic_plan_name: initialData.strategic_plan_name || "",
        strategicInformation: initialData.description || "",
        applicable_date: initialData.applicable_date
          ? parseBackendDate(initialData.applicable_date, "/")
          : null,
      });
    }
  }, [initialData, reset]);

  const { trigger, isMutating } = useApi(
    null,
    apiList.admin.strategicPlans.create.call(),
    { method: "POST" }
  );

  const { trigger: strategicUpdate, isMutating: StrategicMutating } = useApi(
    null,
    apiList.admin.strategicPlans.update.call(selectedId),
    { method: "PUT" }
  );

  const onSubmit = async (data) => {

    try {
      const formData = {
        strategic_plan_name: data.strategic_plan_name,
        description: data.strategicInformation,
        applicable_date: formatDateForBackend(new Date(data.applicable_date)),
      };

      if (selectedId) {
        const response = await strategicUpdate({ requestBody: formData });

        // First mutate both list and detail endpoints to refresh data
        await Promise.all([
          mutate(apiList.admin.strategicPlans.list.key(page, perPage, auth?.user?.user_id)),
          mutate(apiList.admin.strategicPlans.detail.key(selectedId))
        ]);
        handleMutation()

        toast.success(response.data);
      } else {
        const response = await trigger({ requestBody: formData });

        await mutate(apiList.admin.strategicPlans.list.key(page, perPage, auth?.user?.user_id));
        handleMutation()
        toast.success(response.data);
      }
      setDrawerState(false);

    } catch (error) {
      console.log(error);

      if (error?.data?.status === "validation_error" && error?.data?.data) {
        const validationErrors = error.data.data;

        for (const [field, messages] of Object.entries(validationErrors)) {
          setError(field, { type: "manual", message: messages[0] });
        }
        return;
      }
      if (error?.status == 400) {
        toast.error(error?.data?.msg);
      }
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate>
      <div className="mb-12">
        <FormInput
          id="strategic_plan_name"
          fieldName="strategic_plan_name"
          label="Strategic Plan Name"
          type="text"
          register={register}
          isRequired={true}
          errors={formErrors}
          placeholder="Enter strategic plan name"
        />
      </div>

      <Textarea
        classNames={hoverEff}
        radius="sm"
        className="mt-[-20px]"
        variant="bordered"
        labelPlacement="outside"
        label={<span className="text-black">Strategic Plan Information</span>}
        placeholder="Enter strategic plan information"
        {...register("strategicInformation")}
        isRequired={true}
        errorMessage={formErrors && formErrors?.strategicInformation?.message}
        color={formErrors && formErrors.strategicInformation ? "danger" : ""}
        isInvalid={formErrors && !!formErrors["strategicInformation"]}
      />

      <div className="mt-6">
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Applicable Date
          <span className="text-red-500 ml-1">*</span>
        </label>
        <input
          type="date"
          {...register("applicable_date")}
          className={`w-full px-3 py-2 border-2 rounded-md shadow-sm ${formErrors.applicable_date ? "border-danger" : "border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500"}  `}
        />
        {formErrors.applicable_date && (
          <p className="text-tiny text-danger mt-1">
            {formErrors.applicable_date.message}
          </p>
        )}
      </div>

      <Button
        radius="sm"
        type="submit"
        color="primary"
        className="mt-9 px-8"
        isLoading={isMutating || StrategicMutating}
      >
        {selectedId ? "Update" : "Create"}
      </Button>
    </form>
  );
};

export default StrategicForm;
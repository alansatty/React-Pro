import { IconSquareRoundedX } from "@tabler/icons-react";
import SlidingPane from "react-sliding-pane";
import { PageSpinner } from "../../../../../components";
import StrategicForm from "./StrategicForm";
import useApi from "../../../../../hooks/useApi";
import { apiList } from "../../../../../services";
import HelpModal from "../../../../../components/Topbar/HelpModal";
import { StrategyPlanForm } from "../../../../../components/Topbar/helpComponents/Helps";

const StrategicPlanDrawer = ({
  drawerState,
  setDrawerState,
  title,
  subTitle = "",
  selectedId = null,
  handleMutation,
  page = 1,
  perPage = 10,
}) => {
  const { data, isLoading } = useApi(
    selectedId ? apiList.admin.strategicPlans.detail.key(selectedId) : null,
    apiList.admin.strategicPlans.detail.call(selectedId)
  );

  const handleClose = () => {
    setDrawerState(false)
  }


  return (
    <div>

      <SlidingPane
        overlayClassName="z-50 "
        width="600px"
        isOpen={drawerState}
        title={
          <>
            <div className="flex items-center relative">
              <span className="font-semibold text-black">{title}</span>

            </div>
          </>}
        subtitle={subTitle}
        closeIcon={
          <div className="flex items-center gap-2">
            <HelpModal ContentComponent={StrategyPlanForm} />
            <IconSquareRoundedX color="#11181C" className="w-8 h-8" onClick={handleClose} />

          </div>
        }
        onRequestClose={handleClose}
      >
        {isLoading ? (
          <PageSpinner />
        ) : (<>

          <StrategicForm
            setDrawerState={setDrawerState}
            initialData={data?.data}
            selectedId={selectedId}
            handleMutation={handleMutation}
            page={page}
            perPage={perPage}
          />
        </>
        )}
        {/* here contnent  */}
      </SlidingPane>
    </div>
  );
};

export default StrategicPlanDrawer;

import { Button } from "@nextui-org/button";
import { Card } from "@nextui-org/card";
import { Checkbox } from "@nextui-org/checkbox";
import { useEffect, useState } from "react";
import { apiList } from "../../../../services";
import useApi from "../../../../hooks/useApi";
import usePermissionsStore from "../../../../stores/usePermissionStore";
import ViewImageModal from "./ViewImageModal";
import Swal from "sweetalert2/dist/sweetalert2.js";
import withReactContent from 'sweetalert2-react-content';
import ProstrategyLogo from "../../../../assets/icons/ProstrategyLogo";
import { PageSpinner } from "../../../../components";
const MySwal = withReactContent(Swal);

function BinderStepOne({ setStep, content }) {
  const [uploadedImages, setUploadedImages] = useState({});
  const [imageLinks, setImageLinks] = useState({});
  const [selectedItems, setSelectedItems] = useState({});
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
  const { trigger, isMutating } = useApi(
    null,
    apiList.admin.binder_template.save_tableof_content.call(),
    { method: "POST" }
  );

  // Initialize selectedItems and imageLinks based on content
  useEffect(() => {
    const initialSelectedItems = {};
    const initialImageLinks = {};

    content?.forEach((item) => {
      const section = item.section;
      if (section.is_selected !== undefined) {
        initialSelectedItems[section.text] = section.is_selected;
      }

      section.sub_heading?.forEach((sub) => {
        if (sub.is_selected !== undefined) {
          initialSelectedItems[sub.text] = sub.is_selected;
        }

        if (sub.image) {
          initialImageLinks[sub.text] = sub.image;
        }

        if (section.text === "Department Analysis" && sub.sub_heading2) {
          // Check if all sub_heading2 items are selected
          const allSubItemsSelected = sub.sub_heading2.every(
            (sub2) => sub2.is_selected === true
          );

          // If all sub-items are selected, mark the department name as selected
          if (allSubItemsSelected) {
            initialSelectedItems[sub.department_name] = true;
          }

          // Set the sub-heading2's selected state and image links
          sub.sub_heading2.forEach((sub2) => {
            const key = getDepartmentSubKey(sub.department_id, sub2.text);
            initialSelectedItems[key] = sub2.is_selected;

            // Set the image link if it exists
            if (sub2.image) {
              initialImageLinks[key] = sub2.image;
            }
          });
        }
      });

      // For non-department sections, check if all sub-items are selected
      if (section.text !== "Department Analysis" && section.sub_heading) {
        const allSubItemsSelected = section.sub_heading.every((sub) => {
          if (sub.sub_heading2) {
            return sub.sub_heading2.every((sub2) => sub2.is_selected === true);
          } else {
            return sub.is_selected === true;
          }
        });

        if (allSubItemsSelected) {
          initialSelectedItems[section.text] = true;
        }
      }
    });

    setSelectedItems(initialSelectedItems);
    setImageLinks(initialImageLinks);
  }, [content]); // Run this effect when content changes

  const getDepartmentSubKey = (departmentId, subText) => {
    return `${departmentId}-${subText}`;
  };
  const handleFileChange = (e, sectionKey) => {
    const file = e.target.files[0];

    if (file) {
      // Check if file type is an image
      if (!file.type.startsWith("image/")) {
        MySwal.fire({

          html: (
            <div className="flex flex-col items-center">
              <div className="w-18 h-20 mb-2">
                <ProstrategyLogo />
              </div>

              <h2 className="text-xl font-semibold">Invalid File</h2>
              <p className="mt-2">Please upload a valid image file!</p>
            </div>
          ),
        });
        return;
      }

      setUploadedImages({
        ...uploadedImages,
        [sectionKey]: file,
      });
    }
  };

  const handleMainCheckboxChange = (sectionKey, isChecked, subSections) => {
    const updatedSelections = { ...selectedItems };

    // Toggle all sub-sections based on main section selection
    subSections.forEach((sub) => {
      updatedSelections[sub.text] = isChecked;

      // If sub has sub-sections (sub_heading2), toggle them as well
      if (sub.sub_heading2) {
        sub.sub_heading2.forEach((sub2) => {
          const key = sub.department_id
            ? getDepartmentSubKey(sub.department_id, sub2.text)
            : sub2.text;
          updatedSelections[key] = isChecked;
        });
      }
    });

    // Update the main section itself
    updatedSelections[sectionKey] = isChecked;
    setSelectedItems(updatedSelections);
  };

  const handleSubCheckboxChange = (
    subKey,
    isChecked,
    sectionKey,
    subSections
  ) => {
    const updatedSelections = { ...selectedItems, [subKey]: isChecked };

    // Check if all sub-sections are selected
    const allSelected = subSections.every((sub) => updatedSelections[sub.text]);

    // If all sub-sections are selected, mark the main section as selected
    updatedSelections[sectionKey] = allSelected;

    setSelectedItems(updatedSelections);
  };

  const handleDepartmentCheckboxChange = (department, isChecked) => {
    const updatedSelections = { ...selectedItems };

    // Select/Deselect all sub_heading2 items
    department.sub_heading2.forEach((sub) => {
      const subKey = getDepartmentSubKey(department.department_id, sub.text);
      updatedSelections[subKey] = isChecked;
    });

    // Also update the department name
    updatedSelections[department.department_name] = isChecked;

    setSelectedItems(updatedSelections);
  };

  const handleDepartmentSubCheckboxChange = (subKey, isChecked, department) => {
    const updatedSelections = { ...selectedItems, [subKey]: isChecked };

    // Check if all sub_heading2 items are selected
    const allSelected = department.sub_heading2.every(
      (sub) =>
        updatedSelections[
        getDepartmentSubKey(department.department_id, sub.text)
        ]
    );

    // Update the department title based on allSelected status
    updatedSelections[department.department_name] = allSelected;

    setSelectedItems(updatedSelections);
  };



  const handleNextClick = async () => {
    const organizationData = [];
    const departmentData = [];
    const formData = new FormData(); // FormData to append images

    content.forEach((item) => {
      const section = item.section;

      if (section.text !== "Department Analysis") {
        // Organization data
        section.sub_heading?.forEach((sub) => {
          const key = sub.text.toLowerCase().replace(/ /g, "_");
          const is_selected = selectedItems[sub.text] ? "True" : "False";

          if (is_selected === "True") {
            const image = uploadedImages[sub.text]; // Newly uploaded image
            const imageLink = imageLinks[sub.text]; // Existing image link

            const data = { key, is_selected };

            // Prioritize newly uploaded images over existing links
            if (image) {
              const imageKey = `image_${key}`;
              formData.append(imageKey, image); // Append new image
            }

            organizationData.push(data);
          }
        });
      } else {
        // Department data
        section.sub_heading?.forEach((department) => {
          department.sub_heading2.forEach((sub) => {
            const key = sub.text.toLowerCase().replace(/ /g, "_");
            const is_selected = selectedItems[getDepartmentSubKey(department.department_id, sub.text)]
              ? "True"
              : "False";

            if (is_selected === "True") {
              const image = uploadedImages[getDepartmentSubKey(department.department_id, sub.text)];
              const imageLink = imageLinks[getDepartmentSubKey(department.department_id, sub.text)];

              const data = {
                department: department.department_id,
                key,
                is_selected,
              };

              // Prioritize newly uploaded images
              if (image) {
                const imageKey = `image_${key}_${department.department_id}`;
                formData.append(imageKey, image); // Append new image
              }

              departmentData.push(data);
            }
          });
        });
      }
    });

    // Combine organization and department data
    const requestData = {
      strategic_plan_id: strategicPlan,
      entry: JSON.stringify([...organizationData, ...departmentData]),
    };

    // Append non-image data as JSON
    formData.append("strategic_plan_id", strategicPlan);
    formData.append("entry", requestData?.entry);

    // Send data to backend
    try {
      await trigger({ requestBody: formData });
      setStep("2"); // Move to the next step
    } catch (error) {
      console.error("Error sending data to backend:", error);
    }
  };


  if (isMutating) {
    return <PageSpinner text="Please wait it will take some time" className="bg-white" />
  }

  return (
    <Card className="p-6 bg-white min-h-screen">
      <div className="flex mb-6">
        <h1 className="text-2xl font-bold ">Table of Contents</h1>
        <Button
          color="primary"
          className="px-12 py-3  text-white rounded  ml-auto"
          onPress={handleNextClick}
        >
          Next
        </Button>

      </div>
      {content?.map((item, index) => {
        const section = item.section;
        return (
          <div key={index} className="mb-6">
            {section.text !== "Department Analysis" && (
              <div className="flex items-center justify-between">
                <Checkbox
                  isSelected={selectedItems[section.text] || false} // Fallback to false if undefined
                  onChange={(e) =>
                    handleMainCheckboxChange(
                      section.text,
                      e.target.checked,
                      section.sub_heading
                    )
                  }
                >
                  <h2 className="text-xl font-semibold">{section.text}</h2>
                </Checkbox>
              </div>
            )}
            {(section.text === "Department Analysis" && section.sub_heading[0]) && (
              <h2 className="text-xl font-semibold">{section.text}</h2>
            )}
            <div className="space-y-4 pl-6 mt-2">
              {section.sub_heading?.map((subsection) => (
                <div
                  key={subsection.text || subsection.department_id}
                  className="ml-4"
                >
                  {subsection.department_name && (
                    <div className="flex items-center justify-between bg-gray-100 p-3 rounded">
                      <Checkbox
                        isSelected={
                          selectedItems[subsection.department_name] || false
                        } // Fallback to false if undefined
                        onChange={(e) =>
                          handleDepartmentCheckboxChange(
                            subsection,
                            e.target.checked
                          )
                        }
                      >
                        <h3 className="text-lg font-semibold">
                          {subsection.department_name}
                        </h3>
                      </Checkbox>
                    </div>
                  )}
                  {(subsection.sub_heading2 || [subsection]).map((sub) => {
                    const subKey = subsection.department_id
                      ? getDepartmentSubKey(subsection.department_id, sub.text)
                      : sub.text;
                    const imageLink = imageLinks[subKey]; // Image link from backend
                    const uploadedImage = uploadedImages[subKey]; // Locally uploaded image

                    return (
                      <div
                        key={subKey}
                        className="flex items-center justify-between bg-white p-4 rounded shadow"
                      >
                        <Checkbox
                          isSelected={selectedItems[subKey] || false}
                          onChange={(e) => {
                            if (section.text === "Department Analysis") {
                              handleDepartmentSubCheckboxChange(
                                subKey,
                                e.target.checked,
                                subsection
                              );
                            } else {
                              handleSubCheckboxChange(
                                subKey,
                                e.target.checked,
                                section.text,
                                section.sub_heading
                              );
                            }
                          }}
                        >
                          {sub.text}
                        </Checkbox>

                        <div className="flex items-center">
                          <label className="relative cursor-pointer">
                            <input
                              type="file"
                              accept="image/*"
                              className="absolute inset-0 opacity-0 cursor-pointer"
                              onChange={(e) => handleFileChange(e, subKey)}
                            />
                            <span className="px-4 py-2 text-primary rounded cursor-pointer">
                              {uploadedImage || imageLink
                                ? "Change Image"
                                : "Upload Image"}
                            </span>
                          </label>
                          {(uploadedImage || imageLink) && (
                            <ViewImageModal
                              imageUrl={
                                uploadedImage
                                  ? URL.createObjectURL(uploadedImage) // Create URL for local file
                                  : imageLink // Use backend image link directly
                              }
                            />
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>
        );
      })}

    </Card>
  );
}

export default BinderStepOne;




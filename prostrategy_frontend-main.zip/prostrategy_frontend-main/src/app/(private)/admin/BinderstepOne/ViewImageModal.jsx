
import { IconEye } from "@tabler/icons-react";
import {
    Modal,
    ModalBody,
    ModalContent,
    ModalFooter,
    ModalHeader,
    useDisclosure,
} from "@nextui-org/modal";
import { Button } from "@nextui-org/button";
import { useEffect, useState } from "react";
import { Spinner } from "@nextui-org/spinner";

function ViewImageModal({ imageUrl }) {
    const { isOpen, onOpen, onOpenChange } = useDisclosure();
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        return () => {
            if (imageUrl && imageUrl.startsWith("blob:")) {
                URL.revokeObjectURL(imageUrl);
            }
        };
    }, [imageUrl]);

    const handleImageLoad = () => {
        setIsLoading(false);
    };

    return (
        <>
            {imageUrl && (
                <span
                    onClick={onOpen}
                    className="ml-3 text-gray-700 flex cursor-pointer"
                >
                    <IconEye />
                    <span>View</span>
                </span>
            )}

            <Modal isOpen={isOpen} onOpenChange={onOpenChange}>
                <ModalContent>
                    {(onClose) => (
                        <>
                            <ModalHeader className="flex flex-col gap-1">
                                Image Preview
                            </ModalHeader>
                            <ModalBody>
                                {isLoading && (
                                    <div className="flex justify-center items-center h-[500px]">
                                        <Spinner />
                                    </div>
                                )}
                                <img
                                    src={imageUrl}
                                    height="500"
                                    width="500"
                                    alt="Preview"
                                    className={`w-full h-[500px] ${isLoading ? 'hidden' : 'block'}`}
                                    onLoad={handleImageLoad}
                                />
                            </ModalBody>
                            <ModalFooter>
                                <Button color="danger" variant="light" onPress={onClose}>
                                    Close
                                </Button>
                            </ModalFooter>
                        </>
                    )}
                </ModalContent>
            </Modal>
        </>
    );
}

export default ViewImageModal;
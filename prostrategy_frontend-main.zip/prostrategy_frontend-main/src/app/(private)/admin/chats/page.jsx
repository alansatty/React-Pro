import { useCallback, useEffect, useState } from "react";
import UserList from "./_components/UserList";
import ChatBox from "./_components/ChatBox";
import UserListDrawer from "./_components/UserListDrawer";
import { apiList } from "../../../../services";
import { useAuth } from "../../../../providers/authProviders";
import useApi from "../../../../hooks/useApi";
import Pusher from "pusher-js";

// const pusherInstance = new Pusher(import.meta.env.VITE_PUSHER_ENV, {
//   cluster: "ap2",
// });
const Chats = () => {
  const [pusherInstance, setPusherInstance] = useState(null);
  const [isOpen, setIsOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [page, setPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [userList, setUserList] = useState([]);
  const auth = useAuth();
  const [networkStatus, setNetworkStatus] = useState(navigator.onLine);
  const authUserId = auth?.user?.user_id;
  const { data: userLists, isLoading: userListLoading } = useApi(
    apiList.admin.chat.userList.key(auth?.user?.user_id),
    apiList.admin.chat.userList.call()
  );

  const {
    data: myChats,
    isLoading: myChatLoading,
    isValidating,
  } = useApi(
    apiList.admin.chat.myChats.key(page, searchQuery, authUserId),
    apiList.admin.chat.myChats.call(page, searchQuery)
  );

  // useEffect(() => {
  //   if (myChats?.data) {
  //     setUserList((prevList) => {
  //       // Combine old data and new data
  //       const combinedList = [...prevList, ...myChats.data];

  //       // Ensure unique conversations by their `conversation_id`
  //       const uniqueChats = combinedList.reduce((acc, chat) => {
  //         if (!acc.some((existingChat) => existingChat.conversation_id === chat.conversation_id)) {
  //           acc.push(chat);
  //         }
  //         return acc;
  //       }, []);

  //       return uniqueChats;
  //     });
  //     setIsLoadingMore(false); // Stop loading state
  //   }
  // }, [myChats]);

  useEffect(() => {
    const handleOnline = () => {
      setNetworkStatus(true);
      setPage(1); // Reset to first page on reconnection
      // setUserList([]); // Clear existing list
    };

    const handleOffline = () => {
      setNetworkStatus(false);
    };

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  // useEffect(() => {
  //   if (myChats?.data) {
  //     setUserList((prevList) => {
  //       // Create a map of existing conversations for quick lookup
  //       const existingConversations = new Map(
  //         prevList.map((chat) => [chat.conversation_id, chat])
  //       );

  //       // Update or add conversations from the new data
  //       myChats.data.forEach((chat) => {
  //         existingConversations.set(chat.conversation_id, chat);
  //       });

  //       // Convert the map back to an array
  //       return Array.from(existingConversations.values());
  //     });

  //     setIsLoadingMore(false); // Stop loading state
  //   }
  // }, [myChats]);

  useEffect(() => {
    if (myChats?.data) {
      setUserList((prevList) => {
        // Create a map of existing conversations for quick lookup
        const existingConversations = new Map(
          prevList.map((chat) => [chat.conversation_id, chat])
        );

        // Update or add conversations from the new data
        myChats.data.forEach((chat) => {
          // Only update if the new chat is more recent or doesn't exist
          const existingChat = existingConversations.get(chat.conversation_id);
          if (!existingChat || new Date(chat.timestamp) > new Date(existingChat.timestamp)) {
            existingConversations.set(chat.conversation_id, chat);
          }
        });

        // Convert the map back to an array and sort by timestamp
        const sortedChats = Array.from(existingConversations.values()).sort((a, b) => {
          const dateA = new Date(a.timestamp);
          const dateB = new Date(b.timestamp);
          return dateB - dateA; // Sort in descending order (newest first)
        });

        return sortedChats;
      });

      setIsLoadingMore(false);
    }
  }, [myChats]);

  useEffect(() => {
    const pusher = new Pusher(import.meta.env.VITE_PUSHER_ENV, {
      cluster: "mt1",
    });

    setPusherInstance(pusher);

    // Cleanup
    return () => {
      pusher.disconnect();
    };
  }, []);

  const handleScrollPagination = useCallback(() => {
    if (
      !isLoadingMore &&
      !myChatLoading &&
      !isValidating &&
      myChats?.page < myChats?.total_pages
    ) {
      setPage((prevPage) => prevPage + 1);
      setIsLoadingMore(true);
    }
  }, [networkStatus, isLoadingMore, userLists]);

  const handleSearch = (query) => {
    setSearchQuery(query);
    setPage(1);
    setUserList([]); // Clear the user list for new search results
  };

  if (!pusherInstance) return null;
  return (
    <div className="flex h-[calc(100vh-12vh)] overflow-auto m-[-13px] mx-[-25px] ">

      <UserList
        networkStatus={networkStatus}
        isLoading={userListLoading}
        pusherInstance={pusherInstance}
        drawerState={isOpen}
        setDrawerState={setIsOpen}
        userLists={myChats?.data}
        selectedUser={selectedUser}
        onSelectUser={setSelectedUser}
        authUserId={authUserId}
        onScrollEnd={handleScrollPagination} // Trigger pagination on scroll end
        onSearch={handleSearch} // Pass search handler
        userList={userList}
        setUserList={setUserList}
      />

      <ChatBox
        pusherInstance={pusherInstance}
        selectedUser={selectedUser}
        userList={userList}
        setUserList={setUserList}
        onSelectUser={setSelectedUser}
        page={page}
      />

      <UserListDrawer
        userLists={userLists?.data}
        isLoading={userListLoading}
        drawerState={isOpen}
        setDrawerState={setIsOpen}
        onSelectUser={(user) => setSelectedUser(user)}
      />
    </div>
  );
};

export default Chats;

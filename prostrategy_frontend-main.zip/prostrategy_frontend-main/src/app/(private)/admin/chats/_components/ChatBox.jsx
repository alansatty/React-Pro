import { useState, useRef, useEffect } from "react";
import EmptyChatIcon from "../../../../../assets/icons/emptyChatIcon";
import Message from "./components_chatbox/Message";
import ChatHeader from "./components_chatbox/ChatHeader";
import EmptyChat from "./components_chatbox/EmptyChat";
import MessageInput from "./components_chatbox/MessageInput";
import { apiList } from "../../../../../services";
import useApi from "../../../../../hooks/useApi";
import toast from "react-hot-toast";
import { useAuth } from "../../../../../providers/authProviders";
import { Spinner } from "@nextui-org/spinner";
import { formatTimestamp } from "../../../../../utils/helpers";

function ChatBox({
  selectedUser,
  pusherInstance,
  userList,
  setUserList,
  onSelectUser,
  page
}) {
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState([]);
  const [pageNum, setPageNum] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const auth = useAuth();
  const messageEndRef = useRef(null);
  const scrollHeightRef = useRef(0);
  const isInitialLoad = useRef(true);
  const { data: Conversations, isLoading: isLoadingConversation } = useApi(
    apiList.admin.chat.conversation.key(
      selectedUser?.conversation_id || null,
      pageNum
    ),
    apiList.admin.chat.conversation.call(selectedUser?.conversation_id, pageNum)
  );

  const playNotificationSound = () => {
    const audio = new Audio("/sounds/notification.mp3"); // Replace with the actual path to your sound file
    audio.play().catch((err) => {
      console.error("Notification sound failed to play:", err);
    });
  };

  const { trigger } = useApi(null, apiList.admin.chat.sendMessage.call(), {
    method: "POST",
  });

  useEffect(() => {
    if (messageEndRef.current && !isInitialLoad.current) {
      scrollHeightRef.current = messageEndRef.current.scrollHeight;
    }
  }, [isLoadingMore]);
  // Fetch existing conversation
  useEffect(() => {
    if (Conversations?.data?.length) {
      const loadedMessages = Conversations.data.map((msg) => ({
        text: msg.message,
        time: msg.timestamp,
        isSentByUser: msg.is_sent_by_log_in_user,
      }));

      if (pageNum === 1) {
        setMessages(loadedMessages);
        isInitialLoad.current = true;
      } else {
        setMessages((prev) => [...prev, ...loadedMessages]);

        requestAnimationFrame(() => {
          if (messageEndRef.current) {
            const newScrollHeight = messageEndRef.current.scrollHeight;
            const scrollDiff = newScrollHeight - scrollHeightRef.current;
            messageEndRef.current.scrollTop += scrollDiff;
          }
        });
      }

      // Update hasMore based on response
      setHasMore(Conversations.data.length === 20); // Assuming 20 is your page size
    } else if (pageNum === 1) {
      setMessages([]);
    }

    setIsLoadingMore(false);
    isInitialLoad.current = false;
  }, [selectedUser, Conversations, pageNum]);

  const handleScroll = (e) => {
    const { scrollTop, scrollHeight, clientHeight } = e.target;
    // When user scrolls to bottom (considering a buffer of 100px)
    if (scrollHeight - Math.abs(scrollTop) - clientHeight < 100) {
      if (hasMore && !isLoadingMore && !isLoadingConversation) {
        setIsLoadingMore(true);
        setPageNum((prev) => prev + 1);
      }
    }
  };

  // Set up Pusher for real-time updates
  useEffect(() => {
    if (selectedUser?.conversation_id) {
      // pusherInstance.unsubscribe()
      const channel = pusherInstance.subscribe(selectedUser.conversation_id);
      channel.bind("new-message", (data) => {
        const newMessage = {
          text: data.message,
          time: data?.timestamp,
          message_id: data?.message_id,
          chat_id: data?.chat_id,
          isSentByUser: data?.user_id == auth?.user?.user_id ? true : false,
        };
        setMessages((prevMessages) => [newMessage, ...prevMessages]);
        if (data?.user_id != auth?.user?.user_id) {
          playNotificationSound()
        }

      });

      return () => {
        channel.unbind_all();
        channel.unsubscribe();
      };
    }
  }, [pusherInstance, selectedUser]);

  // Reset pagination when selected user changes
  useEffect(() => {
    setPageNum(1);
    setHasMore(true);
    setInput("");
  }, [selectedUser?.id]);
  // Scroll to the latest message on update
  // useEffect(() => {
  //   if (messageEndRef.current) {
  //     messageEndRef.current.scrollTop = 0;
  //   }
  // }, [messages]);

  // const updateUserListOrder = (updatedUser) => {
  //   setUserList((prevList) => {
  //     // Remove the user from their current position
  //     const filteredList = prevList.filter(
  //       (user) => user.receiver !== updatedUser.receiver
  //     );

  //     // Add the updated user at the beginning
  //     return [updatedUser, ...filteredList];
  //   });
  // };

  const updateUserListOrder = (updatedUser) => {
    setUserList((prevList) => {
      // Check if the user already exists in the list
      const userExists = prevList.some(
        (user) => user.receiver === updatedUser.receiver
      );

      if (userExists) {
        // Remove the user from their current position
        const filteredList = prevList.filter(
          (user) => user.receiver !== updatedUser.receiver
        );

        // Add the updated user at the beginning
        return [updatedUser, ...filteredList];
      } else {
        // Add the new user to the list
        return [updatedUser, ...prevList];
      }
    });
  };

  const renderLoadingSpinner = () => {
    if (isLoadingConversation && pageNum === 1) {
      return (
        <div className="flex justify-center items-center h-full">
          <Spinner size="lg" />
        </div>
      );
    } else if (isLoadingMore) {
      return (
        <div className="flex justify-center items-center py-2">
          <Spinner size="sm" />
        </div>
      );
    }
    return null;
  };



  const handleSend = async () => {

    if (isSubmitting) return;

    if (input.trim()) {
      try {
        setIsSubmitting(true)
        const formData = {
          receiver: selectedUser.id,
          message: input,
        };
        const { data } = await trigger({ requestBody: formData });
        setInput("");

        const updatedUser = {
          ...selectedUser,
          conversation_id: data,
          name: selectedUser.name,
          receiver_name: selectedUser?.name,
          id: selectedUser?.id,
          receiver: selectedUser?.id,
          message: formData?.message,
          timestamp: formatTimestamp(new Date())
        };
        // Update user list order

        if (messageEndRef.current) {
          messageEndRef.current.scrollTop = 0;
        }

        onSelectUser((prev) => {
          if (!prev?.conversation_id) {
            return {
              ...prev,
              conversation_id: data,
              name: selectedUser?.name,
              id: selectedUser?.id,
            };
          } else {
            return prev;
          }
        });
        updateUserListOrder(updatedUser);
        // mutate(apiList.admin.chat.myChats.key(1,"",auth?.user?.user_id));
        // mutate(apiList.admin.chat.myChats.key); // Update recent chats
      } catch (error) {
        console.error("Failed to send message:", error);
        toast.error("Failed to send message. Please try again.");
      } finally {
        setIsSubmitting(false)
      }
    }
  };

  const sendHi = async () => {
    const formData = {
      receiver: selectedUser.id,
      message: "Hi 👋",
    };
    try {
      const { data } = await trigger({ requestBody: formData });
      setInput("");
      const sentHiMessage = {
        text: formData.message,
        time: new Date().toLocaleTimeString(),
        isSentByUser: true,
      };

      const updatedUser = {
        ...selectedUser,
        conversation_id: data,
        name: selectedUser.name,
        receiver_name: selectedUser?.name,
        id: selectedUser?.id,
        receiver: selectedUser?.id,
        message: formData?.message,
        timestamp: formatTimestamp(new Date()),
      };


      if (messageEndRef.current) {
        messageEndRef.current.scrollTop = 0;
      }


      // setMessages((prevMessages) => [sentHiMessage, ...prevMessages]);
      onSelectUser((prev) => {
        if (!prev?.conversation_id) {
          return {
            ...prev,
            conversation_id: data,
            name: selectedUser?.name,
            id: selectedUser?.id,
          };
        } else {
          return prev;
        }
      });

      updateUserListOrder(updatedUser);

      // mutate(apiList.admin.chat.myChats.key);
    } catch (error) {
      console.error("Failed to send 'Hi' message:", error);
      toast.error("Failed to send message. Please try again.");
    }
  };

  if (!selectedUser) {
    return (
      <div className="flex flex-col w-2/3 md:w-3/4">
        <div className="flex flex-col justify-center items-center h-[calc(100vh-30vh)]">
          <EmptyChatIcon className="h-36 w-36" />
          <p className="mt-2 text-sm text-gray-500">
            You have not selected a user yet.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col w-2/3 md:w-3/4">
      <ChatHeader user={selectedUser} />
      {/* Chat Messages */}
      <div
        className="flex-1 p-4 overflow-y-auto flex flex-col-reverse"
        ref={messageEndRef}
        onScroll={handleScroll}
      >
        {renderLoadingSpinner()}
        {!isLoadingConversation || pageNum > 1 ? (
          messages?.length === 0 ? (
            <EmptyChat sendHi={sendHi} user={selectedUser} />
          ) : (
            messages?.map((msg, index) => <Message key={index} message={msg} />)
          )
        ) : null}
      </div>
      <MessageInput disabled={isSubmitting} input={input} setInput={setInput} handleSend={handleSend} />
    </div>
  );
}

export default ChatBox;

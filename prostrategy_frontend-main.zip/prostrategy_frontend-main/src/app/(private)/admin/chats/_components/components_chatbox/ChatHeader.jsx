function ChatHeader({ user }) {
    return (
      <div className="flex items-center p-4 bg-white border-b border-gray-200">
        <div className="flex items-center">
          <div className="flex items-center justify-center w-10 h-10 pt-1 capitalize text-[#0098F5] font-semibold border-[1px] border-[#0098F5] bg-[#007AFF]/15 rounded-full">
            {user?.name?.charAt(0)}
          </div>
          <div className="ml-3">
            <p className="font-medium">{user?.name}</p>
            <p className="text-xs text-gray-500">{user?.role}</p>
          </div>
        </div>
      </div>
    );
  }

  export default ChatHeader;
  
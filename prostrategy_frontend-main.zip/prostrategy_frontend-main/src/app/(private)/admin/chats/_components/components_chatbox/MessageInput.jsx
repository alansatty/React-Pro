import { Button } from "@nextui-org/button";
import { Input } from "@nextui-org/input";
import { IconSend } from "@tabler/icons-react";
import clsx from "clsx";

function MessageInput({ input, setInput, handleSend, disabled }) {
    return (
      <div className="p-4 border-t border-gray-200 bg-white flex items-center">
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type a message"
          type="text"
          radius="full"
          className="text-[#929292]"
          onKeyDown={(e) => {
            if (e.key === "Enter" && !disabled ) {
              handleSend();
            }
          }}
        />
        <Button
          onClick={handleSend}
          isIconOnly
          color="default"
          radius="full"
          disabled={disabled}
          aria-label="Send message"
          className={clsx("bg-[#EBF7FF]", "font-medium py-[20px] px-3 w-full md:w-auto ml-3")}
        >
          <IconSend color="#0098F5" />
        </Button>
      </div>
    );
  }

  export default MessageInput;
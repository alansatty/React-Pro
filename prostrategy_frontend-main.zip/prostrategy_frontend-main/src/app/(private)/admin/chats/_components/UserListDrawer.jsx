import { IconCircleX, IconSearch } from "@tabler/icons-react";
import SlidingPane from "react-sliding-pane";
import { Spinner } from "@nextui-org/spinner";
import { useState } from "react";
import { Input } from "@nextui-org/input";
import ChatUserEmptyIcon from "../../../../../assets/icons/chatEmptyIcon";

const UserListDrawer = ({
  drawerState,
  setDrawerState,
  isLoading,
  userLists,
  onSelectUser,
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const filteredUserLists = userLists?.filter((contact) =>
    contact.name.toLowerCase().includes(searchQuery.toLowerCase())
  );


  return (
    <div>
      <SlidingPane
        closeIcon={
          <div>
            <span className="text-xl">
              {" "}
              <IconCircleX color="#11181C" className="w-12 h-12" />
            </span>
          </div>
        }
        overlayClassName="z-50 "
        width="500px"
        isOpen={drawerState}
        title={<span className="font-semibold">New Chat</span>}
        // subtitle={'Add new user to chat'}
        onRequestClose={() => {
          // triggered on "<" on left top click or on outside click
          setDrawerState(false);
        }}
      >
        <>
          <Input
            isClearable
            variant="bordered"
            placeholder="Search name"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            classNames={{
              inputWrapper: [
                "h-[46px]",
                "group-data-[focus=true]:border-[#0098F5]",
                "dark:group-data-[focus=true]:border-[#0098F5]",
              ],
            }}
            className={`w-full`}
            startContent={<IconSearch className="text-gray-400" size={18} />}
            onClear={() => setSearchQuery("")}
            radius={"sm"}
          />

          <div className="space-y-3 mt-5 ">
            {isLoading ? (
              <div className="flex justify-center items-center h-24">
                <Spinner color="primary" size="lg" />
              </div>
            ) : filteredUserLists?.length === 0 ? (
              <div className="flex flex-col justify-center items-center h-32">
                <ChatUserEmptyIcon className="h-32" />
                <p className="text-sm text-center mt-2 text-gray-600">
                  No users found
                </p>
              </div>
            ) : (
              filteredUserLists?.map((contact, index) => (
                <div
                  onClick={() => {
                    onSelectUser({...contact,conversation_id:contact?.chat_id});
                    setDrawerState(false);
                  }}
                  key={index}
                  className="flex items-center p-2 cursor-pointer hover:bg-gray-100  border-b"
                >
                  <div className="flex items-center justify-center pt-1 w-10 h-10 capitalize text-[#0098F5] font-semibold border-[1px] border-[#0098F5] bg-[#007AFF]/15 rounded-full">
                    {contact.name.charAt(0)}
                  </div>
                  <div className="ml-3">
                    <p className="font-medium text-sm">{contact.name}</p>
                    <p className="text-xs text-gray-500">{contact.role}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </>
      </SlidingPane>
    </div>
  );
};

export default UserListDrawer;

import { formatDistanceToNow, isValid, parse, parseISO } from 'date-fns';
import { fromZonedTime, toZonedTime } from 'date-fns-tz';
function Message({ message }) {
    let timeAgo = message?.time;

    if (message?.time) {
        const date = parse(message?.time, "dd MMM yyyy HH:mm", new Date());
        if (isValid(date)) {
            const utcDate = fromZonedTime(date, 'America/New_York');
            timeAgo = formatDistanceToNow(utcDate, { addSuffix: true });
        }
    }

    return (
        <>
            {message?.isSentByUser ? (
                <div className="flex flex-col mt-2 items-end">
                    <div className="text-sm text-white bg-[#0098F5] shadow-sm p-3 rounded-[8px_8px_0px_8px] w-fit max-w-[75%] break-words overflow-hidden">
                        {message.text}
                    </div>
                    <span className="text-xs text-gray-400 mt-1">{timeAgo}</span>
                </div>
            ) : (
                <div className="flex flex-col mt-2">
                    <div className="text-sm text-gray-700 bg-white shadow-sm p-3 w-fit rounded-[8px_8px_8px_0px] max-w-[75%] break-words overflow-hidden">
                        {message.text}
                    </div>
                    <span className="text-xs text-gray-400 mt-1">{timeAgo}</span>
                </div>
            )}
        </>
    );
}

export default Message;

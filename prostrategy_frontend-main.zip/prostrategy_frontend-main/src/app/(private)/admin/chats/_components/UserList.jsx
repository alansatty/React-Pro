import { Button } from "@nextui-org/button";
import clsx from "clsx";
import AddUserIcon from "../../../../../assets/icons/addUser-icon";
import ChatUserEmptyIcon from "../../../../../assets/icons/chatEmptyIcon";
import { useCallback, useEffect, useRef, useState } from "react";
import { Input } from "@nextui-org/input";
import debounce from "lodash.debounce";
const UserList = ({
  setDrawerState,
  userLists,
  selectedUser,
  onSelectUser,
  authUserId,
  pusherInstance,
  isLoading,
  onScrollEnd,
  onSearch,
  userList,
  setUserList,
  networkStatus,
}) => {
  const [searchTerm, setSearchTerm] = useState("");

  const [hasMoreData, setHasMoreData] = useState(true);
  const scrollRef = useRef(null);
  // Update userList when userLists prop changes

  // Toggle drawer
  const toggleDrawer = () => {
    setDrawerState((prev) => !prev);
  };

  const handleScroll = () => {
    if (
      scrollRef.current &&
      scrollRef.current.scrollTop + scrollRef.current.clientHeight >=
      scrollRef.current.scrollHeight - 10 &&
      networkStatus && // Add network status check
      hasMoreData &&
      !isLoading
    ) {
      onScrollEnd();
    }
  };

  const debouncedSearch = useCallback(
    debounce((query) => {
      onSearch(query);
      setHasMoreData(true); // Reset hasMoreData on new search
    }, 500),
    [onSearch]
  );
  const handleSearchChange = (e) => {
    const value = e.target.value;
    setSearchTerm(value);
    debouncedSearch(value);
  };

  useEffect(() => {
    if (userLists) {
      // Check if the response indicates no more data
      const noMoreData =
        userLists?.data?.length === 0 ||
        userLists?.page >= userLists?.total_pages;

      setHasMoreData(!noMoreData);
    }
  }, [userLists]);

  useEffect(() => {
    // Check initial scroll and trigger pagination if needed
    const checkInitialScroll = () => {
      if (
        scrollRef.current &&
        scrollRef?.current?.scrollHeight <= scrollRef?.current?.clientHeight &&
        hasMoreData &&
        searchTerm?.trim() === ""
      ) {
        onScrollEnd();
      }
    };

    checkInitialScroll();
  }, [userList, scrollRef, searchTerm, hasMoreData]);

  useEffect(() => {
    if (pusherInstance && authUserId) {
      let channel;

      try {
        channel = pusherInstance.subscribe(authUserId);

        channel.bind("recent-chats", (data) => {
      
          try {
            setUserList((prevUserList) => {
              // Remove the conversation if it exists (to be added at the top)
              const filteredList = prevUserList.filter(
                (chat) => chat.conversation_id !== data.conversation_id
              );

              // Prepare the new chat data
              const newChat = {
                ...data,
                receiver:
                  data.sender !== authUserId ? data.sender : data.receiver,
                receiver_name:
                  data.sender !== authUserId
                    ? data.sender_name
                    : data.receiver_name,
                name:
                  data.sender !== authUserId
                    ? data.sender_name
                    : data.receiver_name,
                timestamp: data?.timestamp,
              };

              // Add the new/updated chat at the beginning of the list
              return [newChat, ...filteredList];
            });
          } catch (error) {
            console.error("Error updating user list:", error);
          }
        });
      } catch (error) {
        console.error("Error subscribing to Pusher channel:", error);
      }

      return () => {
        if (channel) {
          try {
            channel.unsubscribe();
          } catch (error) {
            console.error("Error unsubscribing from Pusher channel:", error);
          }
        }
      };
    }
  }, [authUserId, pusherInstance]);

  // authUserId, pusherInstance

  if (isLoading) {
    return (
      <div className="w-1/3 bg-white border-r border-gray-200 p-4">
        <div className="flex justify-center items-center h-full">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={scrollRef}
      onScroll={handleScroll}
      className="w-1/3 bg-white border-r border-gray-200 p-4 overflow-auto"
    >
      <div className="mb-4 flex gap-3 items-center">
        <Input
          placeholder="Search name"
          value={searchTerm}
          onChange={handleSearchChange}
        />
        <Button
          onClick={toggleDrawer}
          isIconOnly
          color="default"
          variant="bordered"
          radius="sm"
          aria-label="List view"
          className={clsx(
            "bg-[#E9ECF2]",
            "font-medium py-[20px] px-3 w-full md:w-auto "
          )}
        >
          <AddUserIcon color="#39465F" />
        </Button>
      </div>

      {!networkStatus && (
        <div className="bg-red-500 sticky top-0 z-30 text-white text-center p-2 animate-shake">
          No internet connection
        </div>
      )}

      <div className="space-y-3">
        {userList?.length === 0 ? (
          <div className="flex flex-col justify-center items-center h-32">
            <ChatUserEmptyIcon className="h-32" />
            <p className="text-sm text-center mt-2 text-gray-600">
              {searchTerm ? "No matching users found" : "No users found"}
            </p>
          </div>
        ) : (
          userList?.map((contact, index) => (
            <div
              key={index}
              className={clsx(
                "flex items-center p-2 cursor-pointer hover:bg-gray-100 rounded-lg",
                selectedUser?.id === contact?.receiver &&
                "bg-gray-100 border-l-4 border-blue-500"
              )}
              onClick={() =>
                onSelectUser({
                  ...contact,
                  id: contact?.receiver,
                  name: contact?.receiver_name,
                })
              }
            >
              <div className="flex items-center justify-center pt-1 w-10 h-10 capitalize text-[#0098F5] font-semibold border-[1px] border-[#0098F5] bg-[#007AFF]/15 rounded-full">
                {contact?.receiver_name?.charAt(0)}
              </div>
              <div className="ml-3">
                <p className="font-medium text-sm">{contact?.receiver_name}</p>
                <p className="text-xs text-gray-500">
                  {contact?.message?.length > 20
                    ? `${contact?.message?.substring(0, 20)}...`
                    : contact?.message}
                </p>
              </div>
              <div className="ml-auto text-xs text-gray-400">
                {contact?.timestamp}
              </div>
            </div>
          ))
        )}

        {isLoading && hasMoreData && (
          <div className="text-center py-2">
            <div className="animate-spin inline-block w-5 h-5 border-[3px] border-current border-t-transparent text-gray-400 rounded-full"></div>
          </div>
        )}
      </div>
    </div>
  );
};

export default UserList;

import { Button } from "@nextui-org/button";
import { Card } from "@nextui-org/card";

function EmptyChat({ sendHi, user }) {
    return (
      <div className="flex flex-col justify-center items-center h-full">
        <Card className="flex flex-col bg-gray-100 justify-center items-center p-6">
          <div
            className="text-4xl mb-4 animate-wave"
            style={{ animation: "wave 1.5s ease-in-out infinite" }}
          >
            👋
          </div>
          <p className="text-gray-600 text-lg mb-4">Say hi to {user?.name} with a wave.</p>
          <Button
            onClick={sendHi}
            className="bg-[#0098F5] hover:bg-[#007ACC] text-white font-semibold py-2 px-6 rounded-full"
          >
            Say hi
          </Button>
        </Card>
      </div>
    );
  }

  export default EmptyChat;
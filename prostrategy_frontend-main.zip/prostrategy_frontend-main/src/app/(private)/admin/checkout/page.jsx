import PaymentDetails from "./components/PaymentDetails";
import ContactInfo from "./components/ContactInfo";
import useApi from "../../../../hooks/useApi";
import { apiList } from "../../../../services";
import { useParams, useSearchParams } from "react-router-dom";
import { PageSpinner } from "../../../../components";
import { useEffect, useState } from "react";

const Checkout = () => {
  const { planId } = useParams();
  const [periodState, setPeriodState] = useState(null);
  const [searchParams] = useSearchParams();

  // Get the page from URL params, default to 1 if not present
  const period = searchParams.get("period");

  const { data, error, isLoading } = useApi(
    apiList.admin.subscription.get_planDetails.key(planId),
    apiList.admin.subscription.get_planDetails.call(planId)
  );

  useEffect(() => {
    setPeriodState(period);
  }, [period]);

  if (isLoading) {
    return <PageSpinner />;
  }


  return (
    <div className="flex flex-col md:flex-row items-start gap-3">
      {/* Payment Details Section */}
      <PaymentDetails
        planData={data.data}
        period={periodState}
        setPeriodState={setPeriodState}
      />

      {/* Contact Information Section */}
      <ContactInfo
        planId={planId}
        period={periodState}
      />
    </div>
  );
};

export default Checkout;

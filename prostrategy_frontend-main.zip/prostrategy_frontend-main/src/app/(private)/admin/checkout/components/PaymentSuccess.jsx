import { Button } from "@nextui-org/button";
import { CheckboxIcon } from "@nextui-org/checkbox";
import { IconCircleCheck } from "@tabler/icons-react";
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { mutate } from "swr";
import { apiList } from "../../../../../services";
import ProstrategyLogo from "../../../../../assets/icons/ProstrategyLogo";
const PaymentSuccess = () => {
  const [countdown, setCountdown] = useState(10);
  const [showCheckmark, setShowCheckmark] = useState(false);
  const navigate = useNavigate();
  useEffect(() => {
    // Start animation after component mount
    setShowCheckmark(true);

    // Countdown timer
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          mutate(apiList.admin.subscription.current_plan.key());
          navigate("/settings/account_tab");
          clearInterval(timer);
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleGoBack = () => {
    mutate(apiList.admin.subscription.current_plan.key());
    navigate("/settings/account_tab");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b py-12 text-center rounded-md bg-white  p-4">
      {/* Success Icon with Animation */}
      {/* <div
        className={`mb-6 transform transition-all duration-1000 ${
          showCheckmark ? "scale-100 opacity-100" : "scale-0 opacity-0"
        }`}
      >
        <IconCircleCheck
          className="mx-auto text-primary animate-bounce"
          size={80}
        />
      </div> */}

      <div className="mb-6 flex justify-center">
        <ProstrategyLogo />
      </div>

      {/* Success Message */}
      <h1 className="text-3xl font-bold text-gray-800 mb-4">
        Payment Successful!
      </h1>
      <p className="text-gray-600 mb-8">
        Thank you for your payment. Your transaction has been completed
        successfully.
      </p>

      {/* Countdown Message */}
      <p className="text-sm text-gray-500 mb-6">
        Redirecting to subscription plan page in {countdown} seconds...
      </p>

      {/* Back Button */}
      <Button
        onClick={handleGoBack}
        className="bg-primary hover:bg-green-600 text-white font-semibold py-3 px-8 rounded-lg transform transition-all duration-200 hover:scale-105 active:scale-95 shadow-md hover:shadow-lg"
      >
        Go Back
      </Button>
    </div>
  );
};

export default PaymentSuccess;

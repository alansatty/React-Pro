import { Switch } from "@nextui-org/switch";
import React, { useState } from "react";

const PaymentDetails = ({ planData, period, setPeriodState }) => {
  const [changeToYearly, setChangeToYearly] = useState(false);

  const handleChangePeriod = () => {
    // setPeriodState("yearly")

    if (!changeToYearly) {
      setPeriodState("yearly");
    } else {
      setPeriodState("monthly");
    }
  };

  return (
    <div className="bg-white shadow-sm rounded-lg p-6 w-full md:w-1/2">
      <h2 className="text-2xl font-bold">Payment Details</h2>
      <p className="text-gray-600 capitalize">
        Subscribe to {planData.name} Plan
      </p>
      <div className="text-3xl font-bold mt-4">
        $
        {period == "monthly" && !changeToYearly
          ? planData.price_month_dollar
          : planData.price_year_dollar}{" "}
        <span className="text-lg font-medium">
          {period == "monthly" && !changeToYearly ? "/monthly" : "/yearly"}
        </span>
      </div>

      <div className="bg-blue-50 p-4 rounded-sm mt-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-semibold text-gray-800 capitalize">
              {planData.name} Plan
            </h3>
            <p className="text-gray-500 capitalize">Billed {period}</p>
          </div>
          <span className="text-gray-800 ">
            ${" "}
            {period == "monthly" && !changeToYearly
              ? planData.price_month_dollar
              : planData.price_year_dollar}{" "}
          </span>
        </div>

        {(period === "monthly" || changeToYearly) && (
          <div className="flex items-center justify-between mt-4">
            <div className="flex items-center">
              <Switch
                value={changeToYearly}
                onChange={() => {
                  setChangeToYearly((prev) => !prev);
                  handleChangePeriod();
                }}
                aria-label="Change to yearly plan"
              />
              <span className="ml-3 bg-[#02205F] text-white font-medium text-sm p-2 rounded-md">
                {changeToYearly ? "Saved" : "Save"} $
                {(
                  planData.price_month_dollar * 12 -
                  planData.price_year_dollar
                ).toFixed(2)}
              </span>

              <span className="ml-3 text-gray-600">with annual billing</span>
            </div>

            <span className="text-gray-800 ">
              ${planData.price_year_dollar}
            </span>
          </div>
        )}
      </div>

      <div className="mt-6 space-y-2">
        {/* <div className="flex justify-between pb-4 border-b mr-4">
          <span>Sub Total</span>
          <span>
            $
            {period == "monthly" && !changeToYearly
              ? planData.price_month_dollar
              : planData.price_year_dollar}{" "}
          </span>
        </div> */}
        {/* <div className="flex justify-between pb-4 border-b pt-2 mr-4">
          <span>Tax</span>
          <span>$34.00</span>
        </div> */}
        <div className="flex justify-between font-bold pb-4 pt-2 mr-4">
          <span>Total</span>
          <span>
            $
            {period == "monthly" && !changeToYearly
              ? planData.price_month_dollar
              : planData.price_year_dollar}{" "}
          </span>
        </div>
      </div>
    </div>
  );
};

export default PaymentDetails;

// import { Button } from "@nextui-org/button";
// import { FormInput } from "../../../../../components";
// import { Controller, useForm } from "react-hook-form";
// import { yupResolver } from "@hookform/resolvers/yup";
// import { PaymentInfoSchema } from "../../../../../../validationSchema/authValidation";
// import useApi from "../../../../../hooks/useApi";
// import { apiList } from "../../../../../services";
// import { useEffect, useState } from "react";
// import { loadStripe } from "@stripe/stripe-js";
// import { Elements } from "@stripe/react-stripe-js";
// import StripeForm from "./StripeForm";
// import Swal from "sweetalert2/dist/sweetalert2.js";
// import withReactContent from "sweetalert2-react-content";
// import ProstrategyLogo from "../../../../../assets/icons/ProstrategyLogo";
// import Select from "react-select";
// import { Country, State, City } from "country-state-city";
// import { cn } from "../../../../../utils/twMege";

// const MySwal = withReactContent(Swal);

// const ContactInfo = ({ planId, period }) => {
//   const [stripePromise, setStripePromise] = useState(null);
//   const [clientSecret, setClientSecret] = useState(null);
//   const [countries, setCountries] = useState([]);
//   const [states, setStates] = useState([]);
//   const [cities, setCities] = useState([]);
//   const [isUserMadeChanges, setIsUserMadeChanges] = useState(false)

//   const {
//     register,
//     handleSubmit,
//     control,
//     watch,
//     setValue,
//     formState: { errors },
//   } = useForm({
//     resolver: yupResolver(PaymentInfoSchema),
//     defaultValues: {
//       country: { value: "US", label: "United States" },
//     },
//   });

//   const { trigger, isMutating } = useApi(
//     null,
//     apiList.admin.subscription.proceed_checkout.call(),
//     { method: "POST" }
//   );

//   useEffect(() => {
//     // Set states for United States
//     const stateOptions = State.getStatesOfCountry("US").map((state) => ({
//       value: state.isoCode,
//       label: state.name,
//     }));
//     setStates(stateOptions);
//   }, []);

//   const selectedCountry = watch("country");
//   const selectedState = watch("state");

//   useEffect(() => {
//     if (selectedState) {
//       const cityOptions = City.getCitiesOfState("US", selectedState.value).map(
//         (city) => ({
//           value: city.name,
//           label: city.name,
//         })
//       );


//       if (cityOptions.length === 0) {
//         // No cities available, set city to the state name
//         setCities([{ value: selectedState.value, label: selectedState.label }]);
//         setValue("city", {
//           value: selectedState.value,
//           label: selectedState.label,
//         });
//       } else {
//         setCities(cityOptions);
//         setValue("city", null);
//       }
//       setValue("postal_code", "");
//     }
//   }, [selectedState, setValue]);

//   useEffect(() => {
//     if (selectedCountry && selectedState) {
//       const cityOptions = City.getCitiesOfState(
//         selectedCountry.value,
//         selectedState.value
//       ).map((city) => ({
//         value: city.name,
//         label: city.name,
//       }));
//       if (cityOptions.length === 0) {
//         // No cities available, set city to the state name
//         setCities([{ value: selectedState.value, label: selectedState.label }]);
//         setValue("city", {
//           value: selectedState.value,
//           label: selectedState.label,
//         });
//       } else {
//         setCities(cityOptions);
//         setValue("city", null);
//       }
//       setValue("postal_code", "");
//     }
//   }, [selectedCountry, selectedState, setValue]);

//   const handleRegister = async (data) => {
//     try {
//       if (data) {
//         const formData = {
//           ...data,
//           country: data.country.label,
//           state: data.state.label,
//           city: data.city.label,
//           subscription_id: planId,
//           duration: period,
//           //   organization_name: "continental",
//         };

//         const response = await trigger({ requestBody: formData });

//         // Set Stripe keys from API response
//         const { public_key, client_secret } = response;
//         setStripePromise(loadStripe(public_key));
//         setClientSecret(client_secret);
//       }
//     } catch (error) {
//       if (error.data.status == "warning") {
//         const warningMessage = error.data.msg
//           .map((msg) =>
//             msg.replace(
//               "Downgrade Alert:",
//               `<span class="text-red-600 font-bold">Downgrade Alert:</span>`
//             )
//           )
//           .map(
//             (msg) =>
//               `<li class="mb-2 text-sm text-gray-700 leading-5 list-disc list-inside">${msg}</li>`
//           )
//           .join("");

//         MySwal.fire({
//           html: (
//             <div className="flex flex-col items-center">
//               <div className="w-18 h-20 mb-2">
//                 <ProstrategyLogo />
//               </div>

//               <h2 className="text-xl font-semibold">Warning!</h2>
//               <div
//                 className="mt-2 text-sm text-gray-700 leading-5"
//                 dangerouslySetInnerHTML={{ __html: warningMessage }}
//               />
//             </div>
//           ),
//           confirmButtonText: "Okay",
//           customClass: {
//             confirmButton:
//               "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
//           },
//         });
//       }
//     }
//   };

//   if (clientSecret && stripePromise) {
//     const options = {
//       // passing the client secret obtained from the server
//       clientSecret: clientSecret,
//       paymentMethodOrder: ["card"],
//     };

//     return (
//       <Elements stripe={stripePromise} options={options}>
//         <StripeForm />
//       </Elements>
//     );
//   }

//   return (
//     <div className="bg-white shadow-sm  rounded-lg p-6 w-full md:w-1/2">
//       <form onSubmit={handleSubmit(handleRegister)} noValidate>
//         <h2 className="text-2xl font-bold">Contact Information</h2>

//         <div className="pt-5 ">
//           <FormInput
//             label="Full Name"
//             placeholder="Enter Full Name"
//             size="lg"
//             className="mb-10  "
//             fieldName="name"
//             type="text"
//             errors={errors}
//             register={register}
//             onChange
//           />

//           <FormInput
//             label="Email"
//             placeholder="Enter Email"
//             size="lg"
//             className="mb-10  "
//             type="email"
//             errors={errors}
//             register={register}
//             fieldName="email"
//           />

//           <FormInput
//             label="Address Information"
//             placeholder="Enter Address Line 1"
//             size="lg"
//             className="mb-2  "
//             type="text"
//             errors={errors}
//             register={register}
//             fieldName="line1"
//           />
//           <FormInput
//             placeholder="Enter Address Line 2"
//             size="lg"
//             className="mb-2  "
//             type="text"
//             errors={errors}
//             register={register}
//             fieldName="line2"
//           />

//           <div className=" flex gap-2">
//             <div className="w-full">
//               <label
//                 className={cn(errors?.country?.message ? "text-danger" : "")}
//                 htmlFor="country"
//               >
//                 Country
//               </label>
//               <Controller
//                 name="country"
//                 control={control}
//                 render={({ field }) => (
//                   <Select
//                     {...field}
//                     options={[{ value: "US", label: "United States" }]}
//                     value={{ value: "US", label: "United States" }}
//                     isDisabled={true}
//                   />
//                 )}
//               />
//               {errors.country && (
//                 <p className="text-red-500 text-sm mt-1">
//                   {errors.country.message}
//                 </p>
//               )}
//             </div>

//             <div className="w-full">
//               <label
//                 className={cn(errors?.state?.message ? "text-danger" : "")}
//                 htmlFor="state"
//               >
//                 State
//               </label>
//               <Controller
//                 name="state"
//                 control={control}
//                 render={({ field }) => (
//                   <Select
//                     {...field}
//                     styles={{
//                       menu: (base) => ({
//                         ...base,
//                         zIndex: 9999,
//                         position: "absolute",
//                       }),
//                       menuList: (base) => ({ ...base, zIndex: 9999 }),
//                     }}
//                     options={states}
//                     placeholder="Select State"
//                     isDisabled={!selectedCountry}
//                   />
//                 )}
//               />
//               {errors.state && (
//                 <p className="text-red-500 text-sm mt-1">
//                   {errors?.state?.message}
//                 </p>
//               )}
//             </div>
//           </div>
//           <div className="flex gap-2 mt-4">
//             <div className="w-full">
//               <label
//                 className={cn(errors?.city?.message ? "text-danger" : "")}
//                 htmlFor="city"
//               >
//                 City
//               </label>
//               <Controller
//                 name="city"
//                 control={control}
//                 render={({ field }) => (
//                   <Select
//                     {...field}
//                     options={cities}
//                     placeholder="Select City"
//                     isDisabled={!selectedState}
//                   />
//                 )}
//               />
//               {errors.city && (
//                 <p className="text-red-500 text-sm mt-1">
//                   {errors.city.message}
//                 </p>
//               )}
//             </div>
//             <div className="w-full">
//               <FormInput
//                 placeholder="Zip Code"
//                 size="md"
//                 label={"Zip code"}
//                 labelPlacement="outside"
//                 className="mb-2"
//                 type="text"
//                 errors={errors}
//                 register={register}
//                 fieldName="postal_code"
//               />
//             </div>
//           </div>

//           <Button
//             radius="sm"
//             type="submit"
//             color="primary"
//             className="bg-appSecondary mt-5"
//             isLoading={isMutating}
//           >
//             Proceed to payment
//           </Button>
//         </div>
//       </form>
//     </div>
//   );
// };

// export default ContactInfo;

import { Button } from "@nextui-org/button";
import { FormInput } from "../../../../../components";
import { Controller, useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { PaymentInfoSchema } from "../../../../../../validationSchema/authValidation";
import useApi from "../../../../../hooks/useApi";
import { apiList } from "../../../../../services";
import { useEffect, useState } from "react";
import { loadStripe } from "@stripe/stripe-js";
import { Elements } from "@stripe/react-stripe-js";
import StripeForm from "./StripeForm";
import Swal from "sweetalert2/dist/sweetalert2.js";
import withReactContent from "sweetalert2-react-content";
import ProstrategyLogo from "../../../../../assets/icons/ProstrategyLogo";
import Select from "react-select";
import { Country, State, City } from "country-state-city";
import { cn } from "../../../../../utils/twMege";
import useUnsavedChanges from "../../../../../hooks/useUnsavedChanges";
import UnsavedChangesModal from "../../../../../components/Alert/UnsavedChangesModal";

const MySwal = withReactContent(Swal);

const ContactInfo = ({ planId, period }) => {
  const [stripePromise, setStripePromise] = useState(null);
  const [clientSecret, setClientSecret] = useState(null);
  const [countries, setCountries] = useState([]);
  const [states, setStates] = useState([]);
  const [cities, setCities] = useState([]);
  const [isUserMadeChanges, setIsUserMadeChanges] = useState(false);

  const {
    register,
    handleSubmit,
    control,
    watch,
    setValue,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(PaymentInfoSchema),
    defaultValues: {
      country: { value: "US", label: "United States" },
    },
  });

  const { showModal, confirmNavigation, cancelNavigation } = useUnsavedChanges(isUserMadeChanges);


  // Handler for input changes
  const handleInputChange = () => {
    if (!isUserMadeChanges) {
      setIsUserMadeChanges(true);
    }
  };

  const { trigger, isMutating } = useApi(
    null,
    apiList.admin.subscription.proceed_checkout.call(),
    { method: "POST" }
  );

  useEffect(() => {
    // Set states for United States
    const stateOptions = State.getStatesOfCountry("US").map((state) => ({
      value: state.isoCode,
      label: state.name,
    }));
    setStates(stateOptions);
  }, []);

  const selectedCountry = watch("country");
  const selectedState = watch("state");

  useEffect(() => {
    if (selectedState) {
      const cityOptions = City.getCitiesOfState("US", selectedState.value).map(
        (city) => ({
          value: city.name,
          label: city.name,
        })
      );

      if (cityOptions.length === 0) {
        // No cities available, set city to the state name
        setCities([{ value: selectedState.value, label: selectedState.label }]);
        setValue("city", {
          value: selectedState.value,
          label: selectedState.label,
        });
      } else {
        setCities(cityOptions);
        setValue("city", null);
      }
      setValue("postal_code", "");
    }
  }, [selectedState, setValue]);

  useEffect(() => {
    if (selectedCountry && selectedState) {
      const cityOptions = City.getCitiesOfState(
        selectedCountry.value,
        selectedState.value
      ).map((city) => ({
        value: city.name,
        label: city.name,
      }));
      if (cityOptions.length === 0) {
        // No cities available, set city to the state name
        setCities([{ value: selectedState.value, label: selectedState.label }]);
        setValue("city", {
          value: selectedState.value,
          label: selectedState.label,
        });
      } else {
        setCities(cityOptions);
        setValue("city", null);
      }
      setValue("postal_code", "");
    }
  }, [selectedCountry, selectedState, setValue]);

  const handleRegister = async (data) => {
    try {
      if (data) {
        const formData = {
          ...data,
          country: data.country.label,
          state: data.state.label,
          city: data.city.label,
          subscription_id: planId,
          duration: period,
        };

        const response = await trigger({ requestBody: formData });

        // Set Stripe keys from API response
        const { public_key, client_secret } = response;
        setStripePromise(loadStripe(public_key));
        setClientSecret(client_secret);

        // Reset the user changes flag after successful submission
        setIsUserMadeChanges(false);
      }
    } catch (error) {
      if (error.status == "warning") {
        const warningMessage = error.msg
          .map((msg) =>
            msg.replace(
              "Downgrade Alert:",
              `<span class="text-red-600 font-bold">Downgrade Alert:</span>`
            )
          )
          .map(
            (msg) =>
              `<li class="mb-2 text-sm text-gray-700 leading-5 list-disc list-inside">${msg}</li>`
          )
          .join("");

        MySwal.fire({
          html: (
            <div className="flex flex-col items-center">
              <div className="w-18 h-20 mb-2">
                <ProstrategyLogo />
              </div>

              <h2 className="text-xl font-semibold">Warning!</h2>
              <div
                className="mt-2 text-sm text-gray-700 leading-5"
                dangerouslySetInnerHTML={{ __html: warningMessage }}
              />
            </div>
          ),
          confirmButtonText: "Okay",
          customClass: {
            confirmButton:
              "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
          },
        });
      }
    }
  };

  if (clientSecret && stripePromise) {
    const options = {
      clientSecret: clientSecret,
      paymentMethodOrder: ["card"],
    };

    return (
      <Elements stripe={stripePromise} options={options}>
        <StripeForm />
      </Elements>
    );
  }

  return (
    <div className="bg-white shadow-sm  rounded-lg p-6 w-full md:w-1/2">
      {showModal && (
        <UnsavedChangesModal
          isConfirmNavigation={confirmNavigation}
          isCancelNavigation={cancelNavigation}
        />
      )}
      <form onSubmit={handleSubmit(handleRegister)} noValidate>
        <h2 className="text-2xl font-bold">Contact Information</h2>

        <div className="pt-5 ">
          <FormInput
            label="Full Name"
            placeholder="Enter Full Name"
            size="lg"
            className="mb-10"
            fieldName="name"
            type="text"
            errors={errors}
            register={register}
            onChange={handleInputChange}
          />

          <FormInput
            label="Email"
            placeholder="Enter Email"
            size="lg"
            className="mb-10"
            type="email"
            errors={errors}
            register={register}
            fieldName="email"
            onChange={handleInputChange}
          />

          <FormInput
            label="Address Information"
            placeholder="Enter Address Line 1"
            size="lg"
            className="mb-2"
            type="text"
            errors={errors}
            register={register}
            fieldName="line1"
            onChange={handleInputChange}
          />
          <FormInput
            placeholder="Enter Address Line 2"
            size="lg"
            className="mb-2"
            type="text"
            errors={errors}
            register={register}
            fieldName="line2"
            onChange={handleInputChange}
          />

          <div className="flex gap-2">
            <div className="w-full">
              <label
                className={cn(errors?.country?.message ? "text-danger" : "")}
                htmlFor="country"
              >
                Country
              </label>
              <Controller
                name="country"
                control={control}
                render={({ field }) => (
                  <Select
                    {...field}
                    options={[{ value: "US", label: "United States" }]}
                    value={{ value: "US", label: "United States" }}
                    isDisabled={true}
                    onChange={(value) => {
                      field.onChange(value);
                      handleInputChange();
                    }}
                  />
                )}
              />
              {errors.country && (
                <p className="text-red-500 text-sm mt-1">
                  {errors.country.message}
                </p>
              )}
            </div>

            <div className="w-full">
              <label
                className={cn(errors?.state?.message ? "text-danger" : "")}
                htmlFor="state"
              >
                State
              </label>
              <Controller
                name="state"
                control={control}
                render={({ field }) => (
                  <Select
                    {...field}
                    styles={{
                      menu: (base) => ({
                        ...base,
                        zIndex: 9999,
                        position: "absolute",
                      }),
                      menuList: (base) => ({ ...base, zIndex: 9999 }),
                    }}
                    options={states}
                    placeholder="Select State"
                    isDisabled={!selectedCountry}
                    onChange={(value) => {
                      field.onChange(value);
                      handleInputChange();
                    }}
                  />
                )}
              />
              {errors.state && (
                <p className="text-red-500 text-sm mt-1">
                  {errors?.state?.message}
                </p>
              )}
            </div>
          </div>
          <div className="flex gap-2 mt-4">
            <div className="w-full">
              <label
                className={cn(errors?.city?.message ? "text-danger" : "")}
                htmlFor="city"
              >
                City
              </label>
              <Controller
                name="city"
                control={control}
                render={({ field }) => (
                  <Select
                    {...field}
                    options={cities}
                    placeholder="Select City"
                    isDisabled={!selectedState}
                    onChange={(value) => {
                      field.onChange(value);
                      handleInputChange();
                    }}
                  />
                )}
              />
              {errors.city && (
                <p className="text-red-500 text-sm mt-1">
                  {errors.city.message}
                </p>
              )}
            </div>
            <div className="w-full">
              <FormInput
                placeholder="Zip Code"
                size="md"
                label={"Zip code"}
                labelPlacement="outside"
                className="mb-2"
                type="text"
                errors={errors}
                register={register}
                fieldName="postal_code"
                onChange={handleInputChange}
              />
            </div>
          </div>

          <Button
            radius="sm"
            type="submit"
            color="primary"
            className="bg-appSecondary mt-5"
            isLoading={isMutating}
          >
            Proceed to payment
          </Button>
        </div>
      </form>
    </div>
  );
};

export default ContactInfo;
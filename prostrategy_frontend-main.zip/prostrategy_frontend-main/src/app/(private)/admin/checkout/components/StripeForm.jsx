import { Button } from "@nextui-org/button";
import {
  PaymentElement,
  CardElement,
  useElements,
  useStripe,
} from "@stripe/react-stripe-js";
import React, { useState } from "react";
import ConfirmationModal from "../../../../../components/ConfirmationModal/ConfirmationModal";

const StripeForm = () => {
  const stripe = useStripe();
  const elements = useElements();
  const [isLoading, setIsLoading] = useState(false); // State for button loading
  const [confirmation, setConfirmation] = useState(false);

  const handlePaymentSubmit = async (e) => {
    e.preventDefault();

    if (!stripe || !elements) return;

    setConfirmation(true);
  };

  const confirmPayment = async () => {
    setIsLoading(true); // Start loading when the form is submitted
    const currentDomain = window.location.origin;

    try {
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${currentDomain}/payment/success`, // Replace with your return URL
        },
      });

      if (error) {
        console.error("Payment error:", error.message);
      }
    } catch (error) {
      console.error("Unexpected error:", error);
    } finally {
      setIsLoading(false); // Stop loading when the process is complete
      setConfirmation(false);
    }
  };

  return (
    <div className="bg-white shadow-sm  rounded-lg p-6 w-full md:w-1/2">
      {" "}
      <ConfirmationModal
        isLoading={isLoading}
        isOpen={confirmation}
        onClose={setConfirmation}
        onConfirm={confirmPayment}
        deleteTitle={"Confirm Payment"} 
        deleteMessage={"Do you confirm this payment information ?"}
        buttonText={"ConfirmType"}
        buttonColor={"primary"}
      />
      <form onSubmit={handlePaymentSubmit}>
        <PaymentElement />
        <Button
          radius="sm"
          type="submit"
          color="primary"
          className="bg-appSecondary mt-5"
          // isLoading={isLoading}
        >
          Complete Payment
        </Button>
      </form>
    </div>
  );
};

export default StripeForm;

import "./CommentEditorTheme.css"

import baseTheme from "./PlaygroundEditorTheme"

const theme = {
  ...baseTheme,
  paragraph: "CommentEditorTheme__paragraph"
}

export default theme

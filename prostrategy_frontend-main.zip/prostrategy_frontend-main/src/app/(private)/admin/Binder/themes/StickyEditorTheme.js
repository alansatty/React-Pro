import "./StickyEditorTheme.css"

import baseTheme from "./PlaygroundEditorTheme"

const theme = {
  ...baseTheme,
  paragraph: "StickyEditorTheme__paragraph"
}

export default theme

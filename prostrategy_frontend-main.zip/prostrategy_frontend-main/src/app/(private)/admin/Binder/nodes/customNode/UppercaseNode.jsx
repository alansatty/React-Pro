import { TextNode } from 'lexical';

export class UppercaseNode extends TextNode {
  static getType() {
    return 'uppercase';
  }

  static clone(node) {
    return new UppercaseNode(node.__text, node.__key);
  }

  createDOM(config) {
    const element = super.createDOM(config);
    element.style.textTransform = 'uppercase';
    return element;
  }

  updateDOM(prevNode, dom, config) {
    const updated = super.updateDOM(prevNode, dom, config);
    if (updated) {
      dom.style.textTransform = 'uppercase';
    }
    return updated;
  }

//   exportJSON() {
//     return {
//       ...super.exportJSON(),
//       className: this.getClassName(),
//       type: "uppercase"
//     }
//   }
}


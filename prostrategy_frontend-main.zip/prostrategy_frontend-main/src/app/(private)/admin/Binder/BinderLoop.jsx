import { Checkbox } from "@nextui-org/checkbox";
import PlaygroundApp from "./App";
import { Switch } from "@nextui-org/switch";

function BinderLoop() {
  const looper = [
    {
        id:1,
        label: "Organization",
        content:'<h1>organization</h1>',
    },
    {
        id:2,
        label: "mission",
        content:'<h1>mission</h1>',
    },
    {
        id:3,
        label: "vision",
        content:'<h1>vision</h1>',
    }
];
  return <div>
    
    

    {
        looper?.map((item, index)=>(
            <div key={index} className="mt-12">
                <div className="text-lg bg-[#3d83ec15] flex gap-4 py-2 px-3"><Checkbox size="md" defaultChecked={true} className="text-red-600"  />{item.label}</div>
                <PlaygroundApp content={item.content} />
            </div>
        ))
    }
    
    </div>;
}

export default BinderLoop;

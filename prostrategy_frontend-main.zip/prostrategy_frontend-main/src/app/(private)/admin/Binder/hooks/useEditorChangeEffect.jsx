import { useLexicalComposerContext } from "@lexical/react/LexicalComposerContext";
import { useEffect } from "react";

const useEditorChangeEffect = (callback) => {
  const [editor] = useLexicalComposerContext();

  useEffect(() => {
    // Register update listener
    const unregisterListener = editor.registerUpdateListener(({ editorState }) => {
      // Trigger the callback when the editor state updates
      callback(editorState);
    });

    // Cleanup the listener on unmount
    return () => {
      unregisterListener();
    };
  }, [editor, callback]); // Dependencies: Re-run if editor or callback changes
};

export default useEditorChangeEffect
import { useQueryState } from "nuqs";
import { apiList } from "../../../../../services";
import BinderStepOne from "../../BinderstepOne/page";
import usePermissionsStore from "../../../../../stores/usePermissionStore";
import useApi from "../../../../../hooks/useApi";

export default function BinderSteps() {
    const [step, setStep] = useQueryState("TableofContents", { defaultValue: "" }); // start with no step
    const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
    // const { data: BinderSide, isLoading: isLoadingBinderSide } = useApi(
    //     strategicPlan ? apiList.admin.binder_template.list.key(strategicPlan) : null,
    //     apiList.admin.binder_template.list.call(strategicPlan)
    // );
    return (
        <>
        </>
        // <BinderStepOne content={BinderSide?.data} step={step} setStep={setStep} />
    )
}

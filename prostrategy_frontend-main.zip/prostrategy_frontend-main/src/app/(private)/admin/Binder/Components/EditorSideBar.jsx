"use client"

import { useState, useEffect } from "react"
import { Checkbox } from "@nextui-org/checkbox"
import { IconChevronDown, IconChevronRight } from "@tabler/icons-react"

const initialSidebarData = {
    "Guiding Information": [

        {
            slug: "mission",
            name: "Mission",
            _is_selected: false,
            _is_editable: true,
        },
        {
            slug: "vision",
            name: "Vision",
            _is_selected: true,
            _is_editable: false,
        },
        {
            slug: "value",
            name: "Value",
            _is_selected: true,
            _is_editable: true,
        },

    ],
    "Organization Insights": [

        {
            slug: "organization-swot",
            name: "Organization SWOT",
            _is_selected: true,
            _is_editable: false,
        },
        {
            slug: "strategic-value-analysis",
            name: "Strategic Value Analysis",
            _is_selected: true,
            _is_editable: true,
        },
        {
            slug: "organization-goals",
            name: "Organization Goals",
            _is_selected: true,
            _is_editable: true,
        },
    ],
    "SEO and Digital Marketing": [

        {
            slug: "department-swot",
            name: "Department SWOT",
            _is_selected: true,
            _is_editable: true,
        },
        {
            slug: "strategic-value-analysis",
            name: "Strategic Value Analysis",
            _is_selected: true,
            _is_editable: true,
        },
        {
            slug: "department-goals",
            name: "Department Goals",
            _is_selected: true,
            _is_editable: true,
        },
        {
            slug: "department-strategies",
            name: "Department Strategies",
            _is_selected: true,
            _is_editable: true,
        },
    ],
    "Data Analytics and AI Development": [

        {
            slug: "department-swot",
            name: "Department SWOT",
            _is_selected: true,
            _is_editable: true,
        },
        {
            slug: "strategic-value-analysis",
            name: "Strategic Value Analysis",
            _is_selected: true,
            _is_editable: true,
        },
        {
            slug: "department-goals",
            name: "Department Goals",
            _is_selected: true,
            _is_editable: true,
        },
        {
            slug: "department-strategies",
            name: "Department Strategies",
            _is_selected: true,
            _is_editable: true,
        },
    ],
}


export default function EditorSideBar({ setEditorValue }) {
    // State for sidebar data
    const [sidebarData, setSidebarData] = useState(initialSidebarData)

    // Track expanded sections
    const [expandedSections, setExpandedSections] = useState(() => {
        // Initialize with all sections expanded
        const initialState = {}
        Object.keys(initialSidebarData).forEach((key) => {
            initialState[key] = true
        })
        return initialState
    })

    // Track parent checkbox states
    const [parentCheckboxes, setParentCheckboxes] = useState({})

    // Update parent checkbox states based on children
    useEffect(() => {
        const newParentStates = {}

        Object.entries(sidebarData).forEach(([sectionName, items]) => {
            // A parent is checked only if all children are checked
            newParentStates[sectionName] = items.every((item) => item._is_selected)
        })

        setParentCheckboxes(newParentStates)
    }, [sidebarData])

    // Handle section toggle
    const toggleSection = (section) => {
        setExpandedSections((prev) => ({
            ...prev,
            [section]: !prev[section],
        }))
    }

    // Handle parent checkbox change
    const handleParentCheckboxChange = (section, checked) => {
        setSidebarData((prevData) => {
            const newData = { ...prevData }

            // Update all children to match parent state
            newData[section] = newData[section].map((item) => ({
                ...item,
                _is_selected: checked,
            }))

            return newData
        })


    }

    // Handle child checkbox change
    const handleChildCheckboxChange = (section, itemSlug, checked) => {
        setSidebarData((prevData) => {
            const newData = { ...prevData }

            // Update the specific child item
            newData[section] = newData[section].map((item) =>
                item.slug === itemSlug ? { ...item, _is_selected: checked } : item,
            )

            return newData
        })
    }

    const handlingEditorData = (data) => {
        setEditorValue(data)

    }

    return (
        <div className="w-64 bg-white border-r border-gray-200 h-full overflow-y-auto">
            <div className="p-4">
                <h2 className="text-sm font-semibold mb-4">Table of Contents</h2>

                <div className="space-y-1">
                    {Object.entries(sidebarData).map(([sectionName, items]) => (
                        <div key={sectionName} className="mb-2">
                            <div className="flex items-center w-full text-left text-sm font-medium py-1">
                                <Checkbox
                                    isSelected={parentCheckboxes[sectionName]}
                                    onValueChange={(checked) => handleParentCheckboxChange(sectionName, checked)}
                                    className="mr-2"
                                    color="primary"
                                />
                                <button
                                    className="flex items-center flex-grow hover:bg-gray-100 rounded"
                                    onClick={() => toggleSection(sectionName)}
                                >
                                    {expandedSections[sectionName] ? (
                                        <IconChevronDown className="h-4 w-4 mr-1 text-gray-500" />
                                    ) : (
                                        <IconChevronRight className="h-4 w-4 mr-1 text-gray-500" />
                                    )}
                                    <span>{sectionName}</span>
                                </button>
                            </div>

                            {expandedSections[sectionName] && (
                                <div className="ml-8 mt-1 space-y-1">
                                    {items.map((item) => (
                                        <div key={item.slug} className="flex items-center py-1">
                                            <Checkbox
                                                id={`${sectionName}-${item.slug}`}
                                                isSelected={item._is_selected}
                                                onValueChange={(checked) => handleChildCheckboxChange(sectionName, item.slug, checked)}
                                                className="mr-2"
                                                color="primary"
                                            />
                                            <label
                                                onClick={() => handlingEditorData(item)}
                                                htmlFor={`${sectionName}-${item.slug}`}
                                                className="text-sm cursor-pointer flex-grow px-2 py-1 rounded hover:bg-gray-100"
                                            >
                                                {item.name}
                                            </label>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            </div>
        </div>
    )
}

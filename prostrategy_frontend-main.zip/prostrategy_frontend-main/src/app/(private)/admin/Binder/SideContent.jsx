import React, { useState } from "react";
import { Accordion, AccordionItem } from "@nextui-org/accordion";
import { Button } from "@nextui-org/button";

export default function AccordionNav({ data ,selectedSubItem,setSelectedSubItem, setSelectedItem,selectedItem }) {
  const [selectedKeys, setSelectedKeys] = useState(new Set([])); // Opened accordions


  const handleSubItemClick = (subItemKey,subItem) => {
    setSelectedSubItem(subItemKey);
    setSelectedItem(subItem?.text)
  };

  return (
    <div className=" bg-white shadow-sm rounded-lg w-1/4  p-4">
      <Accordion
        selectedKeys={Array.from(selectedKeys)} // Ensure selectedKeys is an array
        onSelectionChange={(keys) => setSelectedKeys(new Set(keys))} // Update opened accordions
        className="p-2 "
        
        
      >
        {data.map((item, index) => {
          const section = item.section || item;
          const itemKey = `section-${index}`;
          const text = section.text || "Untitled Section";
          const subHeadings = section.sub_heading || [];

          return (
            <AccordionItem  aria-multiselectable key={itemKey} title={text} aria-label={text}>
              {subHeadings.length > 0 ? (
                <div className="flex flex-col gap-2 pl-4">
                  {subHeadings.map((subItem, subIndex) => {
                    const subItemKey = `${itemKey}-sub-${subIndex}`;
                    const subText =
                      subItem.text || subItem.department_name || "Untitled Subcontent";

                    return (
                      <Button
                        key={subItemKey}
                        variant="bordered"
                        onClick={() => handleSubItemClick(subItemKey,subItem)}
                        className={`text-left py-2 px-4 rounded hover:bg-blue-50 transition-colors ${
                          selectedSubItem === subItemKey ? "bg-blue-100" : "bg-white"
                        }`}
                      >
                        {subText}
                      </Button>
                    );
                  })}
                </div>
              ) : (
                <p className="pl-4 text-gray-500">No sub-content available</p>
              )}
            </AccordionItem>
          );
        })}
      </Accordion>
    </div>
  );
}

import { DecoratorNode } from "lexical";

export class WrappableImageNode extends DecoratorNode {
  __src;
  __altText;
  __alignment;

  static getType() {
    return "wrappable-image";
  }

  static clone(node) {
    return new WrappableImageNode(
      node.__src,
      node.__altText,
      node.__alignment,
      node.__key
    );
  }

  constructor(src, altText, alignment = "left", key) {
    super(key);
    this.__src = src;
    this.__altText = altText;
    this.__alignment = alignment;
  }

  createDOM() {
    const img = document.createElement("img");
    img.src = this.__src;
    img.alt = this.__altText;
    img.className = `wrappable-image ${this.__alignment}`;
    return img;
  }

  updateDOM(prevNode, dom) {
    if (prevNode.__src !== this.__src) {
      dom.src = this.__src;
    }
    if (prevNode.__altText !== this.__altText) {
      dom.alt = this.__altText;
    }
    if (prevNode.__alignment !== this.__alignment) {
      dom.className = `wrappable-image ${this.__alignment}`;
    }
    return false;
  }
}

export function $createWrappableImageNode(src, altText, alignment) {
  return new WrappableImageNode(src, altText, alignment);
}

export function $isWrappableImageNode(node) {
  return node instanceof WrappableImageNode;
}

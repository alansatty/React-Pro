/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */

import {
  $isCodeNode,
  CODE_LANGUAGE_FRIENDLY_NAME_MAP,
  CODE_LANGUAGE_MAP,
  getLanguageFriendlyName,
} from "@lexical/code";
import { $isLinkNode, TOGGLE_LINK_COMMAND } from "@lexical/link";
import { $isListNode, ListNode } from "@lexical/list";
import { $isHeadingNode } from "@lexical/rich-text";
import {
  $getSelectionStyleValueForProperty,
  $isParentElementRTL,
  $patchStyleText,
} from "@lexical/selection";
import { $isTableNode, $isTableSelection } from "@lexical/table";
import {
  $findMatchingParent,
  $getNearestNodeOfType,
  $isEditorIsNestedEditor,
  mergeRegister,
} from "@lexical/utils";
import {
  $getNodeByKey,
  $getRoot,
  $getSelection,
  $isDecoratorNode,
  $isElementNode,
  $isParagraphNode,
  $isRangeSelection,
  $isRootOrShadowRoot,
  $isTextNode,
  CAN_REDO_COMMAND,
  CAN_UNDO_COMMAND,
  COMMAND_PRIORITY_CRITICAL,
  FORMAT_ELEMENT_COMMAND,
  FORMAT_TEXT_COMMAND,
  INDENT_CONTENT_COMMAND,
  OUTDENT_CONTENT_COMMAND,
  REDO_COMMAND,
  SELECTION_CHANGE_COMMAND,
  UNDO_COMMAND,
} from "lexical";
import { $generateHtmlFromNodes } from "@lexical/html";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  blockTypeToBlockName,
  useToolbarState,
} from "../../context/ToolbarContext";
import useModal from "../../hooks/useModal";
import DropDown, { DropDownItem } from "../../ui/DropDown";
import DropdownColorPicker from "../../ui/DropdownColorPicker";
import { getSelectedNode } from "../../utils/getSelectedNode";
import { sanitizeUrl } from "../../utils/url";
// import { INSERT_EXCALIDRAW_COMMAND } from "../ExcalidrawPlugin"
import { INSERT_IMAGE_COMMAND, InsertImageDialog } from "../ImagesPlugin";
import { InsertInlineImageDialog } from "../InlineImagePlugin";
import { SHORTCUTS } from "../ShortcutsPlugin/shortcuts";
import { InsertTableDialog } from "../TablePlugin";
import FontSize from "./fontSize";
import {
  clearFormatting,
  formatBulletList,
  formatCheckList,
  formatHeading,
  formatNumberedList,
  formatParagraph,
} from "./utils";
import { IS_APPLE } from "../../shared/src/environment";
import { Button as Btns } from "@nextui-org/button";
import {
  IconFileInvoice,
  IconFileTypeDocx,
  IconPdf,
  IconRefresh,
} from "@tabler/icons-react";
import usePermissionsStore from "../../../../../../stores/usePermissionStore";
import { apiList } from "../../../../../../services";
import useApi from "../../../../../../hooks/useApi";
import axios from "axios";
import { useAuth } from "../../../../../../providers/authProviders";
import { INSERT_PAGE_BREAK } from "../PageBreakPlugin";
import {
  Dropdown,
  DropdownItem,
  DropdownMenu,
  DropdownTrigger,
} from "@nextui-org/dropdown";
import withReactContent from "sweetalert2-react-content";
import ProstrategyLogo from "../../../../../../assets/icons/ProstrategyLogo";
import LoadingPopup from "../../../../../../components/LoadingPopup/LoadingPopup";
import toast from "react-hot-toast";
import { mutate } from "swr";
import useUnsavedChanges from "../../../../../../hooks/useUnsavedChanges";
import UnsavedChangesModal from "../../../../../../components/Alert/UnsavedChangesModal";
import { useSharedHistoryContext } from "../../context/SharedHistoryContext";
import Swal from "sweetalert2/dist/sweetalert2.js";
const MySwal = withReactContent(Swal);

function getCodeLanguageOptions() {
  const options = [];

  for (const [lang, friendlyName] of Object.entries(
    CODE_LANGUAGE_FRIENDLY_NAME_MAP
  )) {
    options.push([lang, friendlyName]);
  }

  return options;
}

const CODE_LANGUAGE_OPTIONS = getCodeLanguageOptions();

const FONT_FAMILY_OPTIONS = [
  ["Arial", "Arial"],
  ["Courier New", "Courier New"],
  ["Georgia", "Georgia"],
  ["Times New Roman", "Times New Roman"],
  ["Trebuchet MS", "Trebuchet MS"],
  ["Verdana", "Verdana"],
];

const FONT_SIZE_OPTIONS = [
  ["10px", "10px"],
  ["11px", "11px"],
  ["12px", "12px"],
  ["13px", "13px"],
  ["14px", "14px"],
  ["15px", "15px"],
  ["16px", "16px"],
  ["17px", "17px"],
  ["18px", "18px"],
  ["19px", "19px"],
  ["20px", "20px"],
];

const ELEMENT_FORMAT_OPTIONS = {
  center: {
    icon: "center-align",
    iconRTL: "center-align",
    name: "Center Align",
  },
  end: {
    icon: "right-align",
    iconRTL: "left-align",
    name: "End Align",
  },
  justify: {
    icon: "justify-align",
    iconRTL: "justify-align",
    name: "Justify Align",
  },
  left: {
    icon: "left-align",
    iconRTL: "left-align",
    name: "Left Align",
  },
  right: {
    icon: "right-align",
    iconRTL: "right-align",
    name: "Right Align",
  },
  start: {
    icon: "left-align",
    iconRTL: "right-align",
    name: "Start Align",
  },
};

function dropDownActiveClass(active) {
  if (active) {
    return "active dropdown-item-active";
  } else {
    return "";
  }
}

function BlockFormatDropDown({
  editor,
  blockType,
  rootType,
  disabled = false,
}) {
  return (
    <DropDown
      disabled={disabled}
      buttonClassName="toolbar-item block-controls"
      buttonIconClassName={"icon block-type " + blockType}
      buttonLabel={blockTypeToBlockName[blockType]}
      buttonAriaLabel="Formatting options for text style"
    >
      <DropDownItem
        className={
          "item wide " + dropDownActiveClass(blockType === "paragraph")
        }
        onClick={() => formatParagraph(editor)}
      >
        <div className="icon-text-container">
          <i className="icon paragraph" />
          <span className="text">Normal</span>
        </div>
        <span className="shortcut">{SHORTCUTS.NORMAL}</span>
      </DropDownItem>
      <DropDownItem
        className={"item wide " + dropDownActiveClass(blockType === "h1")}
        onClick={() => formatHeading(editor, blockType, "h1")}
      >
        <div className="icon-text-container">
          <i className="icon h1" />
          <span className="text">Heading 1</span>
        </div>
        <span className="shortcut">{SHORTCUTS.HEADING1}</span>
      </DropDownItem>
      <DropDownItem
        className={"item wide " + dropDownActiveClass(blockType === "h2")}
        onClick={() => formatHeading(editor, blockType, "h2")}
      >
        <div className="icon-text-container">
          <i className="icon h2" />
          <span className="text">Heading 2</span>
        </div>
        <span className="shortcut">{SHORTCUTS.HEADING2}</span>
      </DropDownItem>
      {/* <DropDownItem
        className={"item wide " + dropDownActiveClass(blockType === "h3")}
        onClick={() => formatHeading(editor, blockType, "h3")}
      >
        <div className="icon-text-container">
          <i className="icon h3" />
          <span className="text">Heading 3</span>
        </div>
        <span className="shortcut">{SHORTCUTS.HEADING3}</span>
      </DropDownItem> */}
      <DropDownItem
        className={"item wide " + dropDownActiveClass(blockType === "bullet")}
        onClick={() => formatBulletList(editor, blockType)}
      >
        <div className="icon-text-container">
          <i className="icon bullet-list" />
          <span className="text">Bullet List</span>
        </div>
        <span className="shortcut">{SHORTCUTS.BULLET_LIST}</span>
      </DropDownItem>
      <DropDownItem
        className={"item wide " + dropDownActiveClass(blockType === "number")}
        onClick={() => formatNumberedList(editor, blockType)}
      >
        <div className="icon-text-container">
          <i className="icon numbered-list" />
          <span className="text">Numbered List</span>
        </div>
        <span className="shortcut">{SHORTCUTS.NUMBERED_LIST}</span>
      </DropDownItem>
      {/* <DropDownItem
        className={"item wide " + dropDownActiveClass(blockType === "check")}
        onClick={() => formatCheckList(editor, blockType)}
      >
        <div className="icon-text-container">
          <i className="icon check-list" />
          <span className="text">Check List</span>
        </div>
        <span className="shortcut">{SHORTCUTS.CHECK_LIST}</span>
      </DropDownItem> */}
      {/* <DropDownItem
        className={"item wide " + dropDownActiveClass(blockType === "quote")}
        onClick={() => formatQuote(editor, blockType)}
      >
        <div className="icon-text-container">
          <i className="icon quote" />
          <span className="text">Quote</span>
        </div>
        <span className="shortcut">{SHORTCUTS.QUOTE}</span>
      </DropDownItem> */}
      {/* <DropDownItem
        className={"item wide " + dropDownActiveClass(blockType === "code")}
        onClick={() => formatCode(editor, blockType)}
      >
        <div className="icon-text-container">
          <i className="icon code" />
          <span className="text">Code Block</span>
        </div>
        <span className="shortcut">{SHORTCUTS.CODE_BLOCK}</span>
      </DropDownItem> */}
    </DropDown>
  );
}

function Divider() {
  return <div className="divider" />;
}

function FontDropDown({ editor, value, style, disabled = false }) {
  const handleClick = useCallback(
    (option) => {
      editor.update(() => {
        const selection = $getSelection();
        if (selection !== null) {
          $patchStyleText(selection, {
            [style]: option,
          });
        }
      });
    },
    [editor, style]
  );

  const buttonAriaLabel =
    style === "font-family"
      ? "Formatting options for font family"
      : "Formatting options for font size";

  return (
    <DropDown
      disabled={disabled}
      buttonClassName={"toolbar-item " + style}
      buttonLabel={value}
      buttonIconClassName={
        style === "font-family" ? "icon block-type font-family" : ""
      }
      buttonAriaLabel={buttonAriaLabel}
    >
      {(style === "font-family" ? FONT_FAMILY_OPTIONS : FONT_SIZE_OPTIONS).map(
        ([option, text]) => (
          <DropDownItem
            className={`item ${dropDownActiveClass(value === option)} ${style === "font-size" ? "fontsize-item" : ""
              }`}
            onClick={() => handleClick(option)}
            key={option}
          >
            <span className="text">{text}</span>
          </DropDownItem>
        )
      )}
    </DropDown>
  );
}

function ElementFormatDropdown({ editor, value, isRTL, disabled = false }) {
  const formatOption = ELEMENT_FORMAT_OPTIONS[value || "left"];

  return (
    <DropDown
      disabled={disabled}
      buttonLabel={formatOption.name}
      buttonIconClassName={`icon ${isRTL ? formatOption.iconRTL : formatOption.icon
        }`}
      buttonClassName="toolbar-item spaced alignment"
      buttonAriaLabel="Formatting options for text alignment"
    >
      <DropDownItem
        onClick={() => {
          editor.dispatchCommand(FORMAT_ELEMENT_COMMAND, "left");
        }}
        className="item wide"
      >
        <div className="icon-text-container">
          <i className="icon left-align" />
          <span className="text">Left Align</span>
        </div>
        <span className="shortcut">{SHORTCUTS.LEFT_ALIGN}</span>
      </DropDownItem>
      <DropDownItem
        onClick={() => {
          editor.dispatchCommand(FORMAT_ELEMENT_COMMAND, "center");
        }}
        className="item wide"
      >
        <div className="icon-text-container">
          <i className="icon center-align" />
          <span className="text">Center Align</span>
        </div>
        <span className="shortcut">{SHORTCUTS.CENTER_ALIGN}</span>
      </DropDownItem>
      <DropDownItem
        onClick={() => {
          editor.dispatchCommand(FORMAT_ELEMENT_COMMAND, "right");
        }}
        className="item wide"
      >
        <div className="icon-text-container">
          <i className="icon right-align" />
          <span className="text">Right Align</span>
        </div>
        <span className="shortcut">{SHORTCUTS.RIGHT_ALIGN}</span>
      </DropDownItem>
      {/* <DropDownItem
        onClick={() => {
          editor.dispatchCommand(FORMAT_ELEMENT_COMMAND, "justify");
        }}
        className="item wide"
      >
        <div className="icon-text-container">
          <i className="icon justify-align" />
          <span className="text">Justify Align</span>
        </div>
        <span className="shortcut">{SHORTCUTS.JUSTIFY_ALIGN}</span>
      </DropDownItem> */}
      {/* <DropDownItem
        onClick={() => {
          editor.dispatchCommand(FORMAT_ELEMENT_COMMAND, "start");
        }}
        className="item wide"
      >
        <i
          className={`icon ${
            isRTL
              ? ELEMENT_FORMAT_OPTIONS.start.iconRTL
              : ELEMENT_FORMAT_OPTIONS.start.icon
          }`}
        />
        <span className="text">Start Align</span>
      </DropDownItem> */}
      {/* <DropDownItem
        onClick={() => {
          editor.dispatchCommand(FORMAT_ELEMENT_COMMAND, "end");
        }}
        className="item wide"
      >
        <i
          className={`icon ${
            isRTL
              ? ELEMENT_FORMAT_OPTIONS.end.iconRTL
              : ELEMENT_FORMAT_OPTIONS.end.icon
          }`}
        />
        <span className="text">End Align</span>
      </DropDownItem>
      <Divider />
      <DropDownItem
        onClick={() => {
          editor.dispatchCommand(OUTDENT_CONTENT_COMMAND, undefined);
        }}
        className="item wide"
      >
        <div className="icon-text-container">
          <i className={"icon " + (isRTL ? "indent" : "outdent")} />
          <span className="text">Outdent</span>
        </div>
        <span className="shortcut">{SHORTCUTS.OUTDENT}</span>
      </DropDownItem>
      <DropDownItem
        onClick={() => {
          editor.dispatchCommand(INDENT_CONTENT_COMMAND, undefined);
        }}
        className="item wide"
      >
        <div className="icon-text-container">
          <i className={"icon " + (isRTL ? "outdent" : "indent")} />
          <span className="text">Indent</span>
        </div>
        <span className="shortcut">{SHORTCUTS.INDENT}</span>
      </DropDownItem> */}
    </DropDown>
  );
}

export default function ToolbarPlugin({
  isReset,
  setIsReset,
  editor,
  activeEditor,
  setActiveEditor,
  setIsLinkEditMode,
  handlingSetUserMadeChange,
  strategicBinderId,
  slug,
  isUserMadeChange,
  setPreviousContent
}) {
  const [selectedElementKey, setSelectedElementKey] = useState(null);
  const [modal, showModal] = useModal();
  const [isEditable, setIsEditable] = useState(() => editor.isEditable());
  const { toolbarState, updateToolbarState } = useToolbarState();
  const [documentType, setDocumentType] = useState("pdf");
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
  const [loading, setLoading] = useState(false);
  const [isEmpty, setIsEmpty] = useState(false);
  const isInitialRender = useRef(true);
  const { historyState } = useSharedHistoryContext();
  const auth = useAuth();

  const { trigger, isMutating } = useApi(
    null,
    apiList.admin.binder_template.save.call(),
    { method: "POST" }
  );

  const { trigger: GenPdf, isMutating: isMutatingGenPdf } = useApi(
    null,
    apiList.admin.binder_template.pdf.call(documentType),
    { method: "POST" }
  );

  // const {
  //   showModal: showWarningModal,
  //   confirmNavigation,
  //   cancelNavigation,
  // } = useUnsavedChanges(isChanged);

  useEffect(() => {
    return editor.registerUpdateListener(() => {
      checkIfEditorIsEmpty();
    });
  }, [editor]);

  const $updateToolbar = useCallback(() => {
    const selection = $getSelection();
    if ($isRangeSelection(selection)) {
      if (activeEditor !== editor && $isEditorIsNestedEditor(activeEditor)) {
        const rootElement = activeEditor.getRootElement();
        updateToolbarState(
          "isImageCaption",
          !!rootElement?.parentElement?.classList.contains(
            "image-caption-container"
          )
        );
      } else {
        updateToolbarState("isImageCaption", false);
      }

      const anchorNode = selection.anchor.getNode();
      let element =
        anchorNode.getKey() === "root"
          ? anchorNode
          : $findMatchingParent(anchorNode, (e) => {
            const parent = e.getParent();
            return parent !== null && $isRootOrShadowRoot(parent);
          });

      if (element === null) {
        element = anchorNode.getTopLevelElementOrThrow();
      }

      const elementKey = element.getKey();
      const elementDOM = activeEditor.getElementByKey(elementKey);

      updateToolbarState("isRTL", $isParentElementRTL(selection));

      // Update links
      const node = getSelectedNode(selection);
      const parent = node.getParent();
      const isLink = $isLinkNode(parent) || $isLinkNode(node);
      updateToolbarState("isLink", isLink);

      const tableNode = $findMatchingParent(node, $isTableNode);
      if ($isTableNode(tableNode)) {
        updateToolbarState("rootType", "table");
      } else {
        updateToolbarState("rootType", "root");
      }

      if (elementDOM !== null) {
        setSelectedElementKey(elementKey);
        if ($isListNode(element)) {
          const parentList = $getNearestNodeOfType(anchorNode, ListNode);
          const type = parentList
            ? parentList.getListType()
            : element.getListType();

          updateToolbarState("blockType", type);
        } else {
          const type = $isHeadingNode(element)
            ? element.getTag()
            : element.getType();
          if (type in blockTypeToBlockName) {
            updateToolbarState("blockType", type);
          }
          if ($isCodeNode(element)) {
            const language = element.getLanguage();
            updateToolbarState(
              "codeLanguage",
              language ? CODE_LANGUAGE_MAP[language] || language : ""
            );
            return;
          }
        }
      }
      // Handle buttons
      updateToolbarState(
        "fontColor",
        $getSelectionStyleValueForProperty(selection, "color", "#000")
      );
      updateToolbarState(
        "bgColor",
        $getSelectionStyleValueForProperty(
          selection,
          "background-color",
          "#fff"
        )
      );
      updateToolbarState(
        "fontFamily",
        $getSelectionStyleValueForProperty(selection, "font-family", "Arial")
      );
      let matchingParent;
      if ($isLinkNode(parent)) {
        // If node is a link, we need to fetch the parent paragraph node to set format
        matchingParent = $findMatchingParent(
          node,
          (parentNode) => $isElementNode(parentNode) && !parentNode.isInline()
        );
      }

      // If matchingParent is a valid node, pass it's format type
      updateToolbarState(
        "elementFormat",
        $isElementNode(matchingParent)
          ? matchingParent.getFormatType()
          : $isElementNode(node)
            ? node.getFormatType()
            : parent?.getFormatType() || "left"
      );
    }
    if ($isRangeSelection(selection) || $isTableSelection(selection)) {
      // Update text format
      updateToolbarState("isBold", selection.hasFormat("bold"));
      updateToolbarState("isItalic", selection.hasFormat("italic"));
      updateToolbarState("isUnderline", selection.hasFormat("underline"));
      updateToolbarState(
        "isStrikethrough",
        selection.hasFormat("strikethrough")
      );
      updateToolbarState("isSubscript", selection.hasFormat("subscript"));
      updateToolbarState("isSuperscript", selection.hasFormat("superscript"));
      updateToolbarState("isCode", selection.hasFormat("code"));
      updateToolbarState(
        "fontSize",
        $getSelectionStyleValueForProperty(selection, "font-size", "15px")
      );
      updateToolbarState("isLowercase", selection.hasFormat("lowercase"));
      updateToolbarState("isUppercase", selection.hasFormat("uppercase"));
      updateToolbarState("isCapitalize", selection.hasFormat("capitalize"));
    }
  }, [activeEditor, editor, updateToolbarState]);

  useEffect(() => {
    return editor.registerCommand(
      SELECTION_CHANGE_COMMAND,
      (_payload, newEditor) => {
        setActiveEditor(newEditor);
        $updateToolbar();
        return false;
      },
      COMMAND_PRIORITY_CRITICAL
    );
  }, [editor, $updateToolbar, setActiveEditor]);

  useEffect(() => {
    activeEditor.getEditorState().read(() => {
      $updateToolbar();
    });
  }, [activeEditor, $updateToolbar]);

  useEffect(() => {
    return mergeRegister(
      editor.registerEditableListener((editable) => {
        setIsEditable(editable);
      }),
      activeEditor.registerUpdateListener(({ editorState }) => {
        editorState.read(() => {
          $updateToolbar();
        });
      }),
      activeEditor.registerCommand(
        CAN_UNDO_COMMAND,
        (payload) => {
          updateToolbarState("canUndo", payload);
          return false;
        },
        COMMAND_PRIORITY_CRITICAL
      ),

      activeEditor.registerCommand(
        CAN_REDO_COMMAND,
        (payload) => {
          updateToolbarState("canRedo", payload);
          return false;
        },
        COMMAND_PRIORITY_CRITICAL
      )
    );
  }, [$updateToolbar, activeEditor, editor, updateToolbarState]);

  const applyStyleText = useCallback(
    (styles, skipHistoryStack) => {
      activeEditor.update(
        () => {
          const selection = $getSelection();
          if (selection !== null) {
            $patchStyleText(selection, styles);
          }
        },
        skipHistoryStack ? { tag: "historic" } : {}
      );
    },
    [activeEditor]
  );

  const onFontColorSelect = useCallback(
    (value, skipHistoryStack) => {
      applyStyleText({ color: value }, skipHistoryStack);
    },
    [applyStyleText]
  );

  const onBgColorSelect = useCallback(
    (value, skipHistoryStack) => {
      applyStyleText({ "background-color": value }, skipHistoryStack);
    },
    [applyStyleText]
  );

  const insertLink = useCallback(() => {
    if (!toolbarState.isLink) {
      setIsLinkEditMode(true);
      activeEditor.dispatchCommand(
        TOGGLE_LINK_COMMAND,
        sanitizeUrl("https://")
      );
    } else {
      setIsLinkEditMode(false);
      activeEditor.dispatchCommand(TOGGLE_LINK_COMMAND, null);
    }
  }, [activeEditor, setIsLinkEditMode, toolbarState.isLink]);

  const onCodeLanguageSelect = useCallback(
    (value) => {
      activeEditor.update(() => {
        if (selectedElementKey !== null) {
          const node = $getNodeByKey(selectedElementKey);
          if ($isCodeNode(node)) {
            node.setLanguage(value);
          }
        }
      });
    },
    [activeEditor, selectedElementKey]
  );
  const insertGifOnClick = (payload) => {
    activeEditor.dispatchCommand(INSERT_IMAGE_COMMAND, payload);
  };

  const canViewerSeeInsertDropdown = !toolbarState.isImageCaption;
  const canViewerSeeInsertCodeButton = !toolbarState.isImageCaption;

  const saveTemplate = async () => {
    let jsonContent = null;

    activeEditor.update(() => {
      const editorState = activeEditor.getEditorState();
      jsonContent = editorState.toJSON();
    });

 
    const saveTemplatee = async () => {
      const htmlContent = document.querySelector(".ContentEditable__root");
      if (htmlContent) {

        const wrapperDiv = document.createElement("div");
        wrapperDiv.classList.add("editor-shell");
        wrapperDiv.appendChild(htmlContent.cloneNode(true)); // Clone instead of setting innerHTML

        // Convert italic spans to <i> tags
        wrapperDiv.querySelectorAll(".PlaygroundEditorTheme__textItalic").forEach((element) => {
          const italicTag = document.createElement("i"); // Change to <em> if needed
          italicTag.innerHTML = element.innerHTML;
          italicTag.className = element.className;
          italicTag.style.fontStyle = "italic";
          element.replaceWith(italicTag);
        });

        // Preserve text alignment classes and ensure images inherit alignment
        wrapperDiv.querySelectorAll("[style]").forEach((element) => {
          const style = element.getAttribute("style");
          if (style.includes("text-align")) {
            const match = style.match(/text-align:\s*(left|center|right)/);
            if (match) {
              const alignment = match[1];
              const alignmentClass = `text-${alignment}`;
              element.classList.add(alignmentClass);

              // Ensure images inside inherit the alignment
              element.querySelectorAll("img").forEach((img) => {
                if (!img.parentElement.style.textAlign) {
                  const wrapper = document.createElement("div");
                  wrapper.style.textAlign = alignment;
                  wrapper.classList.add(alignmentClass);

                  img.parentElement.insertBefore(wrapper, img);
                  wrapper.appendChild(img);
                }

                img.style.display = "block";
                img.style.marginLeft = alignment === "center" ? "auto" : alignment === "right" ? "auto" : "0";
                img.style.marginRight = alignment === "center" ? "auto" : alignment === "left" ? "auto" : "0";
              });
            }
          }
        });

        // Replace content safely instead of setting innerHTML
        htmlContent.replaceChildren(...wrapperDiv.childNodes);

        return htmlContent.innerHTML;
      }
      return null;
    };


    activeEditor.setEditable(false);
    await new Promise((resolve) => setTimeout(resolve, 100));

    const htmlContent = await saveTemplatee();

    const template = {
      strategic_plan_id: strategicPlan,
      value: htmlContent,
      lexical_content: JSON.stringify(jsonContent),
    };

    MySwal.fire({
      html: (
        <div className="flex flex-col items-center">
          <div className="w-18 h-20 mb-2">
            <ProstrategyLogo />
          </div>
          <h2 className="text-xl font-semibold">Confirm</h2>
          <p className="mt-2">Are you sure you want to save changes?</p>
        </div>
      ),
      confirmButtonText: "Confirm",
      showCancelButton: true,
      customClass: {
        confirmButton: "bg-primary text-white font-medium py-2 px-4 rounded",
      },
    }).then(async (result) => {

      if (result.isDismissed) {
        activeEditor.setEditable(true);
      }
      if (result.isConfirmed) {
        // **Show Loading Alert**
        MySwal.fire({
          html: (
            <div className="flex flex-col items-center">
              {/* Logo at the top */}
              <div className="w-18 h-20 mb-2">
                <ProstrategyLogo />
              </div>
              {/* Title inside HTML (instead of Swal's title property) */}
              <h2 className="text-xl font-semibold">Saving...</h2>
              <p className="mt-2">Please wait while we save your changes.</p>
            </div>
          ),
          allowOutsideClick: false,
          didOpen: () => {
            Swal.showLoading(); // Show a built-in loading spinner
          },
        });
        // Swal.fire({
        //   title: "Saving...",
        //   html: `
        //     <div class="custom-loading-spinner"></div>
        //     <p>Please wait while we save your changes.</p>
        //   `,
        //   allowOutsideClick: false,
        //   showConfirmButton: false,
        //   didOpen: () => {
        //     Swal.showLoading(); // Show a built-in loading spinner
        //   },
        // });

        try {
          let response = await trigger({ requestBody: template });
          handlingSetUserMadeChange(false)
          // **Close Loading & Show Success Message**
          Swal.close();
          MySwal.fire({
            html: (
              <div className="flex flex-col items-center">
                {/* Logo at the top */}
                <div className="w-18 h-20 mb-2">
                  <ProstrategyLogo />
                </div>
                {/* Title inside HTML (instead of Swal's title property) */}
                <h2 className="text-xl font-semibold">Success!</h2>
                <p className="mt-2">{response?.data}</p>
              </div>
            ),
            allowOutsideClick: false,
            confirmButtonText: "Okay",
            customClass: {
              confirmButton: "my-confirm-button",
            },
          });

          console.log("Saved template successfully:", template);
        } catch (error) {
          // **Close Loading & Show Error Message**
          Swal.close();
          MySwal.fire({
            html: (
              <div className="flex flex-col items-center">
                <div className="w-18 h-20">
                  <ProstrategyLogo />
                </div>
                <h2 className="text-xl font-semibold ">Error!</h2>
                <p className="mt-2">
                  Failed to save template. Please try again.
                </p>
              </div>
            ),
            confirmButtonText: "Retry",
          });
          console.error("Error saving template:", error);
        } finally {
          activeEditor.setEditable(true);
        }
      }
    });
  };

  const saveTemplateAsHTML = async () => {
    const contentEditableElement = document.querySelector(
      ".ContentEditable__root"
    );
    if (!contentEditableElement) return;

    // Clone the element to avoid modifying the DOM directly
    const clone = contentEditableElement.cloneNode(true);

    // Traverse and add inline styles
    const traverseAndApplyStyles = (node) => {
      if (node.nodeType === Node.ELEMENT_NODE) {
        const computedStyle = window.getComputedStyle(node);
        const styleString = Array.from(computedStyle)
          .map((key) => `${key}: ${computedStyle.getPropertyValue(key)};`)
          .join(" ");
        node.setAttribute("style", styleString);
      }

      node.childNodes.forEach(traverseAndApplyStyles);
    };

    traverseAndApplyStyles(clone);

    // Generate the HTML content
    const htmlContent = clone.outerHTML;

    // Create a Blob and trigger download
    const blob = new Blob([htmlContent], { type: "text/html" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "template.html"; // Specify the file name
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };


  const saveanddownloadTemplate = async () => {
    let jsonContent = null;

    activeEditor.update(() => {
      const editorState = activeEditor.getEditorState();
      jsonContent = editorState.toJSON();
    });

    const extractHtmlContent = async () => {
      const htmlContent = document.querySelector(".ContentEditable__root");
      if (htmlContent) {

        const wrapperDiv = document.createElement("div");
        wrapperDiv.classList.add("editor-shell");
        wrapperDiv.appendChild(htmlContent.cloneNode(true)); // Clone instead of setting innerHTML

        // Convert italic spans to <i> tags
        wrapperDiv.querySelectorAll(".PlaygroundEditorTheme__textItalic").forEach((element) => {
          const italicTag = document.createElement("i"); // Change to <em> if needed
          italicTag.innerHTML = element.innerHTML;
          italicTag.className = element.className;
          italicTag.style.fontStyle = "italic";
          element.replaceWith(italicTag);
        });

        // Preserve text alignment classes and ensure images inherit alignment
        wrapperDiv.querySelectorAll("[style]").forEach((element) => {
          const style = element.getAttribute("style");
          if (style.includes("text-align")) {
            const match = style.match(/text-align:\s*(left|center|right)/);
            if (match) {
              const alignment = match[1];
              const alignmentClass = `text-${alignment}`;
              element.classList.add(alignmentClass);

              // Ensure images inside inherit the alignment
              element.querySelectorAll("img").forEach((img) => {
                if (!img.parentElement.style.textAlign) {
                  const wrapper = document.createElement("div");
                  wrapper.style.textAlign = alignment;
                  wrapper.classList.add(alignmentClass);

                  img.parentElement.insertBefore(wrapper, img);
                  wrapper.appendChild(img);
                }

                img.style.display = "block";
                img.style.marginLeft = alignment === "center" ? "auto" : alignment === "right" ? "auto" : "0";
                img.style.marginRight = alignment === "center" ? "auto" : alignment === "left" ? "auto" : "0";
              });
            }
          }
        });

        // Replace content safely instead of setting innerHTML
        htmlContent.replaceChildren(...wrapperDiv.childNodes);

        return htmlContent.innerHTML;
      }
      return null;
    };



    activeEditor.setEditable(false);
    await new Promise((resolve) => setTimeout(resolve, 100));

    const htmlContent = await extractHtmlContent();
    const template = {
      strategic_plan_id: strategicPlan,
      value: htmlContent,
      lexical_content: JSON.stringify(jsonContent),
    };

    MySwal.fire({
      html: (
        <div className="flex flex-col items-center">
          <div className="w-18 h-20 mb-2">
            <ProstrategyLogo />
          </div>
          <h2 className="text-xl font-semibold">Saving...</h2>
          <p className="mt-2">Please wait while we save your changes.</p>
        </div>
      ),
      allowOutsideClick: false,
      didOpen: () => {
        Swal.showLoading();
      },
    });

    try {
      let response = await trigger({ requestBody: template });
      handlingSetUserMadeChange(false)

      Swal.close();
      // MySwal.fire({
      //   html: (
      //     <div className="flex flex-col items-center">
      //       <div className="w-18 h-20 mb-2">
      //         <ProstrategyLogo />
      //       </div>
      //       <h2 className="text-xl font-semibold">Success!</h2>
      //       <p className="mt-2">{response?.data}</p>
      //     </div>
      //   ),
      //   confirmButtonText: "Okay",
      //   customClass: {
      //     confirmButton: "my-confirm-button",
      //   },
      // });

      return true; // Indicating successful save
    } catch (error) {
      Swal.close();
      MySwal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20">
              <ProstrategyLogo />
            </div>
            <h2 className="text-xl font-semibold">Error!</h2>
            <p className="mt-2">Failed to save template. Please try again.</p>
          </div>
        ),
        confirmButtonText: "Retry",

      });

      console.error("Error saving template:", error);
      return false; // Indicating failure
    } finally {
      activeEditor.setEditable(true);
    }
  };

  const downloadPdf = async (docType) => {
    if (isUserMadeChange) {
      const result = await MySwal.fire({
        // title: "Unsaved Changes",
        // text: `Do you want to save changes before downloading the ${docType}?`,
        // icon:<ProstrategyLogo />,
        html: (
          <div className="flex flex-col items-center">
            {/* Logo at the top */}
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>
            {/* Title inside HTML (instead of Swal's title property) */}
            <h2 className="text-xl font-semibold">Unsaved Changes</h2>
            <p className="mt-2">Do you want to save changes before downloading the {docType}?</p>
          </div>
        ),
        showCancelButton: true,
        confirmButtonText: "Download",
        cancelButtonText: "Cancel",
        customClass: {
          confirmButton: "my-confirm-button",
        },
      });

      if (result.isConfirmed) {
        const saveSuccess = await saveanddownloadTemplate();
        if (!saveSuccess) return; // Stop execution if saving fails
      } else {
        return; // Stop execution if the user cancels
      }
    }

    setDocumentType(docType);
    activeEditor.setEditable(false);

    try {
      setLoading(true);
      const { data: response } = await axios.post(
        `/organization/binder/template/generate_document/${docType}/`,
        { strategic_plan_id: strategicPlan, document_type: docType },
        { headers: { Authorization: `Bearer ${auth?.user?.token}` } }
      );

      if (response?.s3_url) {
        const fileExtension = docType === "pdf" ? "pdf" : "docx";
        const link = document.createElement("a");
        link.href = response.s3_url;
        link.download = `${new Date().toISOString().split("T")[0]}-strategic_plan.${fileExtension}`;
        link.target = "_blank";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } else {
        console.error("No document URL returned from the server.");
      }
    } catch (error) {
      if (
        error.response?.data?.error ===
        "BinderTemplate not found for the given organization and strategic_plan_id."
      ) {
        toast.error("Please Save Your Strategic Report");
      }
      console.error(error);
    } finally {
      setLoading(false);
      activeEditor.setEditable(true);
    }
  };

  // const handleExportToPDF = () => {
  //   const contentEditableElement = document.querySelector(
  //     ".ContentEditable__root"
  //   );
  //   if (contentEditableElement) {

  //     editor.setEditable(false)
  //     contentEditableElement.style.display = "block";
  //     const images = contentEditableElement.querySelectorAll("img");
  //     images.forEach((img) => {
  //       img.style.pageBreakInside = "avoid";
  //     });
  //     // Generate PDF
  //     const options = {
  //       margin: 0.2, // Margin in cm
  //       filename: `${new Date()}-content.pdf`,
  //       html2canvas: { scale: 1 }, // Adjust scale for better quality
  //       jsPDF: { unit: "in", format: "letter", orientation: "portrait" }, // Customize format
  //     };

  //     html2pdf().set(options).from(contentEditableElement).save();
  //   }
  // };

  // const handleExportToPDF = async () => {
  //   const contentEditableElement = document.querySelector(".ContentEditable__root");
  //   if (!contentEditableElement) return;

  //   // Disable editing during export
  //  activeEditor.setEditable(false);
  //  await new Promise((resolve) => setTimeout(resolve, 100));
  //   const pdf = new jsPDF("landscape", "mm", "a4",true);
  //   const pageWidth = pdf.internal.pageSize.getWidth();
  //   const pageHeight = pdf.internal.pageSize.getHeight();

  //   try {
  //     // Render the content as a canvas

  //     const canvas = await html2canvas(contentEditableElement, {
  //       scale: 2, // Increase scale for better quality
  //       useCORS: true,
  //       allowTaint: true,
  //     });

  //     const imgWidth = pageWidth;
  //     const imgHeight = (canvas.height * pageWidth) / canvas.width;

  //     const totalHeight = canvas.height;
  //     const pageHeightPx = (pageHeight * canvas.width) / pageWidth; // Convert PDF page height to canvas scale

  //     let currentHeight = 0;

  //     while (currentHeight < totalHeight) {
  //       const canvasPage = document.createElement("canvas");
  //       canvasPage.width = canvas.width;
  //       canvasPage.height = Math.min(pageHeightPx, totalHeight - currentHeight);

  //       const context = canvasPage.getContext("2d");
  //       context.drawImage(
  //         canvas,
  //         0,
  //         currentHeight,
  //         canvas.width,
  //         canvasPage.height,
  //         0,
  //         0,
  //         canvas.width,
  //         canvasPage.height
  //       );

  //       const imgData = canvasPage.toDataURL("image/png");

  //       pdf.addImage(
  //         imgData,
  //         "PNG",
  //         0,
  //         0,
  //         imgWidth,
  //         (canvasPage.height * pageWidth) / canvas.width
  //       );

  //       currentHeight += pageHeightPx;

  //       if (currentHeight < totalHeight) {
  //         pdf.addPage();
  //       }
  //     }

  //     pdf.save("editor-content.pdf");
  //   } catch (error) {
  //     console.error("Error exporting to PDF:", error);
  //   } finally {
  //     // Re-enable editing
  //     editor.setEditable(true);
  //   }
  // };

  // const handleExportToPDF = async () => {
  //   const contentEditableElement = document.querySelector(
  //     ".ContentEditable__root"
  //   );
  //   if (!contentEditableElement) return;

  //   // Disable editing during export
  //   activeEditor.setEditable(false);
  //   await new Promise((resolve) => setTimeout(resolve, 100));

  //   const pdf = new jsPDF("landscape", "mm", "a4", true);
  //   const pageWidth = pdf.internal.pageSize.getWidth();
  //   const pageHeight = pdf.internal.pageSize.getHeight();

  //   try {
  //     // Render the content as a canvas
  //     const canvas = await html2canvas(contentEditableElement, {
  //       scale: 2, // Increase scale for better quality
  //       useCORS: true,
  //       allowTaint: true,
  //     });

  //     const imgWidth = pageWidth;
  //     const imgHeight = (canvas.height * pageWidth) / canvas.width;

  //     const totalHeight = canvas.height;
  //     const pageHeightPx = (pageHeight * canvas.width) / pageWidth; // Convert PDF page height to canvas scale

  //     let currentHeight = 0;

  //     while (currentHeight < totalHeight) {
  //       const remainingHeight = totalHeight - currentHeight;
  //       let heightToDraw = Math.min(pageHeightPx, remainingHeight);

  //       // Check if there's an image that would be split
  //       const imageElement = findImageAtPosition(
  //         contentEditableElement,
  //         currentHeight + heightToDraw
  //       );
  //       if (imageElement) {
  //         const imageTop = getElementTopOffset(
  //           imageElement,
  //           contentEditableElement
  //         );
  //         const imageBottom = imageTop + imageElement.offsetHeight;

  //         if (
  //           imageTop < currentHeight + heightToDraw &&
  //           imageBottom > currentHeight + heightToDraw
  //         ) {
  //           // Image would be split, adjust heightToDraw to stop before the image
  //           heightToDraw = imageTop - currentHeight;

  //           // If this results in a very small section, just move to the next page
  //           if (heightToDraw < pageHeightPx * 0.1) {
  //             if (currentHeight > 0) {
  //               pdf.addPage();
  //             }
  //             currentHeight = imageTop;
  //             continue;
  //           }
  //         }
  //       }

  //       const canvasPage = document.createElement("canvas");
  //       canvasPage.width = canvas.width;
  //       canvasPage.height = heightToDraw;

  //       const context = canvasPage.getContext("2d");
  //       context.drawImage(
  //         canvas,
  //         0,
  //         currentHeight,
  //         canvas.width,
  //         heightToDraw,
  //         0,
  //         0,
  //         canvas.width,
  //         heightToDraw
  //       );

  //       const imgData = canvasPage.toDataURL("image/png");

  //       pdf.addImage(
  //         imgData,
  //         "PNG",
  //         0,
  //         0,
  //         imgWidth,
  //         (heightToDraw * pageWidth) / canvas.width
  //       );

  //       currentHeight += heightToDraw;

  //       if (currentHeight < totalHeight) {
  //         pdf.addPage();
  //       }
  //     }

  //     pdf.save("editor-content.pdf");
  //   } catch (error) {
  //     console.error("Error exporting to PDF:", error);
  //   } finally {
  //     // Re-enable editing
  //     activeEditor.setEditable(true);
  //   }
  // };

  // const handleExportToDocx = async () => {
  //   const contentEditableElement = document.querySelector(
  //     ".ContentEditable__root"
  //   );
  //   if (!contentEditableElement) return;

  //   // Disable editing during export
  //   editor.setEditable(false);
  //   await new Promise((resolve) => setTimeout(resolve, 100));

  //   try {
  //     const html = contentEditableElement.innerHTML;
  //     const docxBlob = await htmlToDocx(html);

  //     // Save the file
  //     saveAs(docxBlob, "editor-content.docx");
  //   } catch (error) {
  //     console.error("Error exporting to DOCX:", error);
  //   } finally {
  //     // Re-enable editing
  //     editor.setEditable(true);
  //   }
  // };

  // Helper function to find an image at a specific position
  function findImageAtPosition(container, position) {
    const images = container.querySelectorAll("img");
    for (const img of images) {
      const top = getElementTopOffset(img, container);
      const bottom = top + img.offsetHeight;
      if (top < position && bottom > position) {
        return img;
      }
    }
    return null;
  }

  // Helper function to get the top offset of an element relative to its container
  function getElementTopOffset(element, container) {
    let topOffset = 0;
    let currentElement = element;
    while (currentElement && currentElement !== container) {
      topOffset += currentElement.offsetTop;
      currentElement = currentElement.offsetParent;
    }
    return topOffset;
  }

  // handleExportToPDF()
  // handleExportToDocx()

  const checkIfEditorIsEmpty = () => {
    editor.update(() => {
      const root = $getRoot();
      const textContent = root.getTextContent().trim();
      let hasContent = textContent.length > 0;
      if (!hasContent) {
        root.getChildren().forEach(node => {
          const nodeType = node.getType();
          if (nodeType === 'page-break' || nodeType === 'pagebreak' || nodeType === 'break') {
            hasContent = true;
            return; // Exit loop early if content found
          }

          // Check for images and other content
          if ($isElementNode(node)) {
            node.getChildren().forEach(child => {
              const childType = child.getType() || child.__type;
              // Detect both images and page breaks
              if (childType === 'image' || childType === 'page-break' || childType === 'pagebreak' || childType === 'break') {
                hasContent = true;
                return; // Exit loop early if content found
              }
            });
          }
        });
      }
      setIsEmpty(!hasContent);

    });
  };

  return (
    <div>
      <div className="toolbar">
        <button
          disabled={!toolbarState.canUndo}
          onClick={() => {
            activeEditor.dispatchCommand(UNDO_COMMAND, undefined);
          }}
          title={IS_APPLE ? "Undo (⌘Z)" : "Undo (Ctrl+Z)"}
          type="button"
          className="toolbar-item spaced"
          aria-label="Undo"
        >
          <i className="format undo" />
        </button>
        <button
          disabled={!toolbarState.canRedo}
          onClick={() => {
            activeEditor.dispatchCommand(REDO_COMMAND, undefined);
          }}
          title={IS_APPLE ? "Redo (⇧⌘Z)" : "Redo (Ctrl+Y)"}
          type="button"
          className="toolbar-item"
          aria-label="Redo"
        >
          <i className="format redo" />
        </button>
        <Divider />
        {toolbarState.blockType in blockTypeToBlockName &&
          activeEditor === editor && (
            <>
              <BlockFormatDropDown
                // disabled={!isEditable}
                blockType={toolbarState.blockType}
                rootType={toolbarState.rootType}
                editor={activeEditor}
              />
              <Divider />
            </>
          )}
        {toolbarState.blockType === "code" ? (
          <DropDown
            // disabled={!isEditable}
            buttonClassName="toolbar-item code-language"
            buttonLabel={getLanguageFriendlyName(toolbarState.codeLanguage)}
            buttonAriaLabel="Select language"
          >
            {CODE_LANGUAGE_OPTIONS.map(([value, name]) => {
              return (
                <DropDownItem
                  className={`item ${dropDownActiveClass(
                    value === toolbarState.codeLanguage
                  )}`}
                  onClick={() => onCodeLanguageSelect(value)}
                  key={value}
                >
                  <span className="text">{name}</span>
                </DropDownItem>
              );
            })}
          </DropDown>
        ) : (
          <>
            {/* <FontDropDown
            disabled={!isEditable}
            style={"font-family"}
            value={toolbarState.fontFamily}
            editor={activeEditor}
          /> */}
            {/* <Divider /> */}
            <FontSize
              selectionFontSize={toolbarState.fontSize.slice(0, -2)}
              editor={activeEditor}
            // disabled={!isEditable}
            />
            <Divider />
            <button
              // disabled={!isEditable}
              onClick={() => {
                activeEditor.dispatchCommand(FORMAT_TEXT_COMMAND, "bold");
              }}
              className={
                "toolbar-item spaced " + (toolbarState.isBold ? "active" : "")
              }
              title={`Bold (${SHORTCUTS.BOLD})`}
              type="button"
              aria-label={`Format text as bold. Shortcut: ${SHORTCUTS.BOLD}`}
            >
              <i className="format bold" />
            </button>
            <button
              // disabled={!isEditable}
              onClick={() => {
                activeEditor.dispatchCommand(FORMAT_TEXT_COMMAND, "italic");
              }}
              className={
                "toolbar-item spaced " + (toolbarState.isItalic ? "active" : "")
              }
              title={`Italic (${SHORTCUTS.ITALIC})`}
              type="button"
              aria-label={`Format text as italics. Shortcut: ${SHORTCUTS.ITALIC}`}
            >
              <i className="format italic" />
            </button>
            <button
              // disabled={!isEditable}
              onClick={() => {
                activeEditor.dispatchCommand(FORMAT_TEXT_COMMAND, "underline");
              }}
              className={
                "toolbar-item spaced " +
                (toolbarState.isUnderline ? "active" : "")
              }
              title={`Underline (${SHORTCUTS.UNDERLINE})`}
              type="button"
              aria-label={`Format text to underlined. Shortcut: ${SHORTCUTS.UNDERLINE}`}
            >
              <i className="format underline" />
            </button>
            {/* {canViewerSeeInsertCodeButton && (
            <button
              disabled={!isEditable}
              onClick={() => {
                activeEditor.dispatchCommand(FORMAT_TEXT_COMMAND, "code")
              }}
              className={
                "toolbar-item spaced " + (toolbarState.isCode ? "active" : "")
              }
              title={`Insert code block (${SHORTCUTS.INSERT_CODE_BLOCK})`}
              type="button"
              aria-label="Insert code block"
            >
              <i className="format code" />
            </button>
          )} */}
            <button
              // disabled={!isEditable}
              onClick={insertLink}
              className={
                "toolbar-item spaced " + (toolbarState.isLink ? "active" : "")
              }
              aria-label="Insert link"
              title={`Insert link (${SHORTCUTS.INSERT_LINK})`}
              type="button"
            >
              <i className="format link" />
            </button>
            <DropdownColorPicker
              // disabled={!isEditable}
              buttonClassName="toolbar-item color-picker"
              buttonAriaLabel="Formatting text color"
              buttonIconClassName="icon font-color"
              color={toolbarState.fontColor}
              onChange={onFontColorSelect}
              title="text color"
            />
            {/* <DropdownColorPicker
            disabled={!isEditable}
            buttonClassName="toolbar-item color-picker"
            buttonAriaLabel="Formatting background color"
            buttonIconClassName="icon bg-color"
            color={toolbarState.bgColor}
            onChange={onBgColorSelect}
            title="bg color"
          /> */}
            <DropDown
              // disabled={!isEditable}
              buttonClassName="toolbar-item spaced"
              buttonLabel=""
              buttonAriaLabel="Formatting options for additional text styles"
              buttonIconClassName="icon dropdown-more"
            >
              <DropDownItem
                onClick={() => {
                  activeEditor.dispatchCommand(
                    FORMAT_TEXT_COMMAND,
                    "lowercase"
                  );
                }}
                className={
                  "item wide " + dropDownActiveClass(toolbarState.isLowercase)
                }
                title="Lowercase"
                aria-label="Format text to lowercase"
              >
                <div className="icon-text-container">
                  <i className="icon lowercase" />
                  <span className="text">Lowercase</span>
                </div>
                <span className="shortcut">{SHORTCUTS.LOWERCASE}</span>
              </DropDownItem>
              <DropDownItem
                onClick={() => {
                  activeEditor.dispatchCommand(
                    FORMAT_TEXT_COMMAND,
                    "uppercase"
                  );
                }}
                className={
                  "item wide " + dropDownActiveClass(toolbarState.isUppercase)
                }
                title="Uppercase"
                aria-label="Format text to uppercase"
              >
                <div className="icon-text-container">
                  <i className="icon uppercase" />
                  <span className="text">Uppercase</span>
                </div>
                <span className="shortcut">{SHORTCUTS.UPPERCASE}</span>
              </DropDownItem>
              <DropDownItem
                onClick={() => {
                  activeEditor.dispatchCommand(
                    FORMAT_TEXT_COMMAND,
                    "capitalize"
                  );
                }}
                className={
                  "item wide " + dropDownActiveClass(toolbarState.isCapitalize)
                }
                title="Capitalize"
                aria-label="Format text to capitalize"
              >
                <div className="icon-text-container">
                  <i className="icon capitalize" />
                  <span className="text">Capitalize</span>
                </div>
                <span className="shortcut">{SHORTCUTS.CAPITALIZE}</span>
              </DropDownItem>
              {/* <DropDownItem
              onClick={() => {
                activeEditor.dispatchCommand(
                  FORMAT_TEXT_COMMAND,
                  "strikethrough"
                );
              }}
              className={
                "item wide " + dropDownActiveClass(toolbarState.isStrikethrough)
              }
              title="Strikethrough"
              aria-label="Format text with a strikethrough"
            >
              <div className="icon-text-container">
                <i className="icon strikethrough" />
                <span className="text">Strikethrough</span>
              </div>
              <span className="shortcut">{SHORTCUTS.STRIKETHROUGH}</span>
            </DropDownItem> */}
              {/* <DropDownItem
              onClick={() => {
                activeEditor.dispatchCommand(FORMAT_TEXT_COMMAND, "subscript")
              }}
              className={
                "item wide " + dropDownActiveClass(toolbarState.isSubscript)
              }
              title="Subscript"
              aria-label="Format text with a subscript"
            >
              <div className="icon-text-container">
                <i className="icon subscript" />
                <span className="text">Subscript</span>
              </div>
              <span className="shortcut">{SHORTCUTS.SUBSCRIPT}</span>
            </DropDownItem>
            <DropDownItem
              onClick={() => {
                activeEditor.dispatchCommand(FORMAT_TEXT_COMMAND, "superscript")
              }}
              className={
                "item wide " + dropDownActiveClass(toolbarState.isSuperscript)
              }
              title="Superscript"
              aria-label="Format text with a superscript"
            >
              <div className="icon-text-container">
                <i className="icon superscript" />
                <span className="text">Superscript</span>
              </div>
              <span className="shortcut">{SHORTCUTS.SUPERSCRIPT}</span>
            </DropDownItem> */}
              <DropDownItem
                onClick={() => clearFormatting(activeEditor)}
                className="item wide"
                title="Clear text formatting"
                aria-label="Clear all text formatting"
              >
                <div className="icon-text-container">
                  <i className="icon clear" />
                  <span className="text">Clear Formatting</span>
                </div>
                <span className="shortcut">{SHORTCUTS.CLEAR_FORMATTING}</span>
              </DropDownItem>
            </DropDown>
            {canViewerSeeInsertDropdown && (
              <>
                <Divider />
                <DropDown
                  // disabled={!isEditable}
                  buttonClassName="toolbar-item spaced"
                  buttonLabel="Insert"
                  buttonAriaLabel="Insert specialized editor node"
                  buttonIconClassName="icon plus"
                >
                  {/* <DropDownItem
                  onClick={() => {
                    activeEditor.dispatchCommand(
                      INSERT_HORIZONTAL_RULE_COMMAND,
                      undefined
                    )
                  }}
                  className="item"
                >
                  <i className="icon horizontal-rule" />
                  <span className="text">Horizontal Rule</span>
                </DropDownItem> */}
                  <DropDownItem
                    onClick={() => {
                      activeEditor.dispatchCommand(
                        INSERT_PAGE_BREAK,
                        undefined
                      );
                    }}
                    className="item"
                  >
                    <i className="icon page-break" />
                    <span className="text">Page Break</span>
                  </DropDownItem>
                  <DropDownItem
                    onClick={() => {
                      showModal("Insert Image", (onClose) => (
                        <InsertImageDialog
                          activeEditor={activeEditor}
                          onClose={onClose}
                        />
                      ));
                    }}
                    className="item"
                  >
                    <i className="icon image" />
                    <span className="text">Image</span>
                  </DropDownItem>
                  {/* <DropDownItem
                  onClick={() => {
                    showModal("Insert Inline Image", (onClose) => (
                      <InsertInlineImageDialog
                        activeEditor={activeEditor}
                        onClose={onClose}
                      />
                    ));
                  }}
                  className="item"
                >
                  <i className="icon image" />
                  <span className="text">Inline Image</span>
                </DropDownItem> */}
                  {/* <DropDownItem
                  onClick={() =>
                    insertGifOnClick({
                      altText: "Cat typing on a laptop",
                      src: catTypingGif
                    })
                  }
                  className="item"
                >
                  <i className="icon gif" />
                  <span className="text">GIF</span>
                </DropDownItem> */}
                  {/* <DropDownItem
                  onClick={() => {
                    activeEditor.dispatchCommand(
                      INSERT_EXCALIDRAW_COMMAND,
                      undefined
                    )
                  }}
                  className="item"
                >
                  <i className="icon diagram-2" />
                  <span className="text">Excalidraw</span>
                </DropDownItem> */}
                  {/* <DropDownItem
                  onClick={() => {
                    showModal("Insert Table", (onClose) => (
                      <InsertTableDialog
                        activeEditor={activeEditor}
                        onClose={onClose}
                      />
                    ));
                  }}
                  className="item"
                >
                  <i className="icon table" />
                  <span className="text">Table</span>
                </DropDownItem> */}
                  {/* <DropDownItem
                  onClick={() => {
                    showModal("Insert Poll", onClose => (
                      <InsertPollDialog
                        activeEditor={activeEditor}
                        onClose={onClose}
                      />
                    ))
                  }}
                  className="item"
                >
                  <i className="icon poll" />
                  <span className="text">Poll</span>
                </DropDownItem> */}
                  {/* <DropDownItem
                  onClick={() => {
                    showModal("Insert Columns Layout", onClose => (
                      <InsertLayoutDialog
                        activeEditor={activeEditor}
                        onClose={onClose}
                      />
                    ))
                  }}
                  className="item"
                >
                  <i className="icon columns" />
                  <span className="text">Columns Layout</span>
                </DropDownItem> */}

                  {/* <DropDownItem
                  onClick={() => {
                    showModal("Insert Equation", onClose => (
                      <InsertEquationDialog
                        activeEditor={activeEditor}
                        onClose={onClose}
                      />
                    ))
                  }}
                  className="item"
                >
                  <i className="icon equation" />
                  <span className="text">Equation</span>
                </DropDownItem>
                <DropDownItem
                  onClick={() => {
                    editor.update(() => {
                      const root = $getRoot()
                      const stickyNode = $createStickyNode(0, 0)
                      root.append(stickyNode)
                    })
                  }}
                  className="item"
                >
                  <i className="icon sticky" />
                  <span className="text">Sticky Note</span>
                </DropDownItem> */}
                  {/* <DropDownItem
                  onClick={() => {
                    editor.dispatchCommand(
                      INSERT_COLLAPSIBLE_COMMAND,
                      undefined
                    )
                  }}
                  className="item"
                >
                  <i className="icon caret-right" />
                  <span className="text">Collapsible container</span>
                </DropDownItem> */}
                  {/* {EmbedConfigs.map(embedConfig => (
                  <DropDownItem
                    key={embedConfig.type}
                    onClick={() => {
                      activeEditor.dispatchCommand(
                        INSERT_EMBED_COMMAND,
                        embedConfig.type
                      )
                    }}
                    className="item"
                  >
                    {embedConfig.icon}
                    <span className="text">{embedConfig.contentName}</span>
                  </DropDownItem>
                ))} */}
                </DropDown>
              </>
            )}
          </>
        )}
        {/* <InsertWrappableImageDialog activeEditor={activeEditor} onClose={false} /> */}
        <Divider />
        <ElementFormatDropdown
          // disabled={!isEditable}
          value={toolbarState.elementFormat}
          editor={activeEditor}
          isRTL={toolbarState.isRTL}
        />
        <div className="ml-auto flex gap-2">
          <Btns
            size="sm"
            className="flex gap-0 item-center"
            onPress={async () => {
              const result = await MySwal.fire({
                html: (
                  <div className="flex flex-col items-center">
                    <div className="w-18 h-20 mb-2">
                      <ProstrategyLogo />
                    </div>
                    <h2 className="text-xl font-semibold">Are you sure?</h2>
                    <p className="mt-2">
                      This will reset the template and lose all data.
                    </p>
                  </div>
                ),
                showCancelButton: true,
                confirmButtonText: "Yes, Reset",
                cancelButtonText: "Cancel",
                reverseButtons: true,
                customClass: {
                  confirmButton: "my-confirm-button",
                },
              });

              if (result.isConfirmed) {

                try {
                  Swal.fire({
                    title: "Resetting...",
                    text: "Please wait while we refresh the template.",
                    icon: "info",
                    allowOutsideClick: false,
                    didOpen: () => {
                      Swal.showLoading();
                    },
                  });
                  handlingSetUserMadeChange(false)

                  await mutate(apiList.admin.binder_template.get.key(strategicBinderId, slug))
                  setIsReset(!isReset)
                  setPreviousContent('')
                  MySwal.fire({
                    html: (
                      <div className="flex flex-col items-center">
                        <div className="w-18 h-20 mb-2">
                          <ProstrategyLogo />
                        </div>
                        <h2 className="text-xl font-semibold">
                          Reset Successful!
                        </h2>
                        <p className="mt-2">The template has been refreshed.</p>
                      </div>
                    ),
                    timer: 2000,
                    showConfirmButton: false,
                  });
                } catch (error) {
                  console.error(error);
                  MySwal.fire({
                    html: (
                      <div className="flex flex-col items-center">
                        <div className="w-18 h-20 mb-2">
                          <ProstrategyLogo />
                        </div>
                        <h2 className="text-xl font-semibold">Error!</h2>
                        <p className="mt-2">
                          Something went wrong while resetting.
                        </p>
                      </div>
                    ),
                    confirmButtonText: "OK",
                  });
                }
              }
            }}
          >
            <IconRefresh className="h-5" /> Reset
          </Btns>
          {/* <Btns
            isLoading={isMutating}
            onClick={saveTemplate}
            size="sm"
            isDisabled={isEmpty}
            radius="sm"
            className={"bg-primary text-white"}
          >
            Save Changes
          </Btns> */}
          {/* <Btns onClick={downloadPdf} className="flex gap-0" size="sm">
          <IconArrowDown className="h-5 w-5"  />
          Download
        </Btns> */}

          {/* <Dropdown size="sm" radius="sm">
            <DropdownTrigger>
              <Btns
                size="sm"
                radius="sm"
                variant="bordered"
                className="flex gap-0"
              >
                <IconFileInvoice className="h-5" />
                Download
              </Btns>
            </DropdownTrigger>
            <DropdownMenu aria-label="Download options">
              <DropdownItem onPress={() => downloadPdf("pdf")} key="pdf">
                <div className="flex gap-1 items-center ">
                  <IconPdf className="h-8" /> Download as PDF
                </div>
              </DropdownItem>
              <DropdownItem onPress={() => downloadPdf("docx")} key="docx">
                <div className="flex gap-1 items-center ">
                  <IconFileTypeDocx className="h-5" /> Download as DOCX
                </div>
              </DropdownItem>
            </DropdownMenu>
          </Dropdown> */}
        </div>
        {/* {isChanged ? "true" : "false"} */}

        {/* {showWarningModal && (
          <UnsavedChangesModal
            isCancelNavigation={cancelNavigation}
            isConfirmNavigation={confirmNavigation}
          />
        )} */}

        {modal}
      </div>

      {loading && <LoadingPopup strings={["Please wait we are exporting..."]} />}
    </div>
  );
}

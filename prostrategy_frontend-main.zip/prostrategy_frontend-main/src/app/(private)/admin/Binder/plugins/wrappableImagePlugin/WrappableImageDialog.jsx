import React, { useState } from "react";
import { INSERT_WRAPPABLE_IMAGE_COMMAND } from "./WrappableImagePlugin";
import './style.css'
export function InsertWrappableImageDialog({ activeEditor, onClose }) {
  const [src, setSrc] = useState("");
  const [altText, setAltText] = useState("");
  const [alignment, setAlignment] = useState("left");

  const handleSubmit = () => {
    activeEditor.dispatchCommand(INSERT_WRAPPABLE_IMAGE_COMMAND, {
      src,
      altText,
      alignment,
    });
    onClose();
  };

  return (
    <div>
      <div>
        <label>
          Image URL:
          <input
            type="text"
            value={src}
            onChange={(e) => setSrc(e.target.value)}
          />
        </label>
      </div>
      <div>
        <label>
          Alt Text:
          <input
            type="text"
            value={altText}
            onChange={(e) => setAltText(e.target.value)}
          />
        </label>
      </div>
      <div>
        <label>
          Alignment:
          <select value={alignment} onChange={(e) => setAlignment(e.target.value)}>
            <option value="left">Left</option>
            <option value="right">Right</option>
            <option value="center">Center</option>
          </select>
        </label>
      </div>
      <button onClick={handleSubmit}>Insert Image</button>
    </div>
  );
}

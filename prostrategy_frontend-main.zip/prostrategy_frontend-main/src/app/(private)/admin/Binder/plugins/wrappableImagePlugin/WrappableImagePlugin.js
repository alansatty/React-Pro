import { useLexicalComposerContext } from "@lexical/react/LexicalComposerContext";
import { $insertNodes, createCommand } from "lexical";
import { $createWrappableImageNode } from "./WrappableImageNode";

export const INSERT_WRAPPABLE_IMAGE_COMMAND = createCommand("INSERT_WRAPPABLE_IMAGE_COMMAND");

export default function WrappableImagePlugin() {
  const [editor] = useLexicalComposerContext();

  editor.registerCommand(
    INSERT_WRAPPABLE_IMAGE_COMMAND,
    (payload) => {
      const { src, altText, alignment } = payload;
      const imageNode = $createWrappableImageNode(src, altText, alignment);
      $insertNodes([imageNode]);
      return true;
    },
    0
  );

  return null;
}

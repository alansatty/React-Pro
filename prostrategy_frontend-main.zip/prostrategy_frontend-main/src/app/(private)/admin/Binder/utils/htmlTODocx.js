// import { Document, Packer, Paragraph, TextRun, ImageRun } from "docx";

// export async function htmlToDocx(html) {
//   const doc = new Document({
//     sections: [
//       {
//         properties: {},
//         children: [],
//       },
//     ],
//   });

//   const parser = new DOMParser();
//   const htmlDoc = parser.parseFromString(html, "text/html");
//   const elements = htmlDoc.body.childNodes;

//   const docElements = [];

//   for (let i = 0; i < elements.length; i++) {
//     const element = elements[i];
//     if (element.nodeType === Node.TEXT_NODE) {
//       if (element.textContent.trim()) {
//         docElements.push(
//           new Paragraph({
//             children: [new TextRun(element.textContent.trim())],
//           }),
//         );
//       }
//     } else if (element.nodeType === Node.ELEMENT_NODE) {
//       switch (element.tagName.toLowerCase()) {
//         case "p":
//           docElements.push(
//             new Paragraph({
//               children: [new TextRun(element.textContent)],
//             }),
//           );
//           break;
//         case "h1":
//         case "h2":
//         case "h3":
//         case "h4":
//         case "h5":
//         case "h6":
//           docElements.push(
//             new Paragraph({
//               children: [
//                 new TextRun({
//                   text: element.textContent,
//                   bold: true,
//                   size: 28 - (Number.parseInt(element.tagName[1]) - 1) * 2,
//                 }),
//               ],
//             }),
//           );
//           break;
//         case "img":
//           try {
//             const base64Data = element.src.split(",")[1]; // Extract the base64 string
//             const binaryData = Uint8Array.from(atob(base64Data), (char) => char.charCodeAt(0));
//             console.log(base64Data,"loo")
//             const width = element.width || 500; // Default width if not specified
//             const height = element.height || 300; // Default height if not specified

//             const alignment = element.parentElement?.style?.textAlign || "left";

//             docElements.push(
//               new Paragraph({
//                 alignment: alignment === "center" ? "center" : alignment === "right" ? "right" : "left",
//                 children: [
//                   new ImageRun({
//                     data: binaryData,
//                     transformation: {
//                       width: width,
//                       height: height,
//                     },
//                   }),
//                 ],
//               }),
//             );
//           } catch (error) {
//             console.error("Error processing base64 image:", error);
//           }
//           break;
//         // Add more cases for other HTML elements as needed
//       }
//     }
//   }

//   doc.addSection({
//     children: docElements,
//   });

//   return await Packer.toBlob(doc);
// }

/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */


import { LexicalComposer } from "@lexical/react/LexicalComposer";
import {
  $isTextNode,
  TextNode,
} from "lexical";

import { FlashMessageContext } from "./context/FlashMessageContext";
import { SettingsContext, useSettings } from "./context/SettingsContext";
import { SharedHistoryContext } from "./context/SharedHistoryContext";
import { ToolbarContext } from "./context/ToolbarContext";
import Editor from "./Editor";
import PlaygroundNodes from "./nodes/PlaygroundNodes";
import { TableContext } from "./plugins/TablePlugin";
import { parseAllowedFontSize } from "./plugins/ToolbarPlugin/fontSize";
import PlaygroundEditorTheme from "./themes/PlaygroundEditorTheme";
import { parseAllowedColor } from "./ui/ColorPicker";
import "./index.css";
import { UppercaseNode } from "./nodes/customNode/UppercaseNode";
import { useEffect, useState } from "react";
import BinderStepOne from "../BinderstepOne/page";

import usePermissionsStore from "../../../../stores/usePermissionStore";
import useApi from "../../../../hooks/useApi";
import { apiList } from "../../../../services";
import { PageSpinner } from "../../../../components";
import { useQueryState } from "nuqs";
console.warn(
  "If you are profiling the playground app, please ensure you turn off the debug view. You can disable it by pressing on the settings control in the bottom-left of your screen and toggling the debug view setting."
);

function getExtraStyles(element) {
  // Parse styles from pasted input, but only if they match exactly the
  // sort of styles that would be produced by exportDOM
  let extraStyles = "";
  const fontSize = parseAllowedFontSize(element.style.fontSize);
  const backgroundColor = parseAllowedColor(element.style.backgroundColor);
  const color = parseAllowedColor(element.style.color);
  if (fontSize !== "" && fontSize !== "15px") {
    extraStyles += `font-size: ${fontSize};`;
  }
  if (backgroundColor !== "" && backgroundColor !== "rgb(255, 255, 255)") {
    extraStyles += `background-color: ${backgroundColor};`;
  }
  if (color !== "" && color !== "rgb(0, 0, 0)") {
    extraStyles += `color: ${color};`;
  }
  return extraStyles;
}

function buildImportMap() {
  const importMap = {};

  // Wrap all TextNode importers with a function that also imports
  // the custom styles implemented by the playground
  for (const [tag, fn] of Object.entries(TextNode.importDOM() || {})) {
    importMap[tag] = (importNode) => {
      const importer = fn(importNode);
      if (!importer) {
        return null;
      }
      return {
        ...importer,
        conversion: (element) => {
          const output = importer.conversion(element);
          if (
            output === null ||
            output.forChild === undefined ||
            output.after !== undefined ||
            output.node !== null
          ) {
            return output;
          }
          const extraStyles = getExtraStyles(element);
          if (extraStyles) {
            const { forChild } = output;
            return {
              ...output,
              forChild: (child, parent) => {
                const textNode = forChild(child, parent);
                if ($isTextNode(textNode)) {
                  textNode.setStyle(textNode.getStyle() + extraStyles);
                }
                return textNode;
              },
            };
          }
          return output;
        },
      };
    };
  }

  return importMap;
}


function App({ setIsEmptyEditor, isUserMadeChange, reportPlanningData, content, setStep, activeEditor, setActiveEditor, setActiveEditorParent, handlingSetUserMadeChange, strategicBinderId, slug, typingCount, setTypingCount }) {
  const {
    settings: { isCollab, emptyEditor, measureTypingPerf },
  } = useSettings();

  const initialConfig = {
    editorState: isCollab ? null : emptyEditor ? null : null,
    html: { import: buildImportMap() },
    namespace: "Playground",
    nodes: [...PlaygroundNodes, UppercaseNode],
    onError: (error) => {
      throw error;
    },
    onChange: () => {

    }
    ,
    theme: PlaygroundEditorTheme,
  };

  return (
    // <LexicalComposer initialConfig={initialConfig}>
    //   <SharedHistoryContext>
    //     <TableContext>
    //       <ToolbarContext>
    //         <div className="editor-shell">
    //           <Editor content={content} setStep={setStep} />
    //         </div>
    //         {/* <Settings /> */}
    //       </ToolbarContext>
    //     </TableContext>
    //   </SharedHistoryContext>
    // </LexicalComposer>

    <div className="editor-shell">
      <Editor
        setIsEmptyEditor={setIsEmptyEditor}
        isUserMadeChange={isUserMadeChange}
        reportPlanningData={reportPlanningData}
        content={content}
        setStep={setStep}
        activeEditor={activeEditor}
        setActiveEditor={setActiveEditor}
        setActiveEditorParent={setActiveEditorParent}
        handlingSetUserMadeChange={handlingSetUserMadeChange}
        strategicBinderId={strategicBinderId}
        slug={slug}
        typingCount={typingCount}
        setTypingCount={setTypingCount}
      />
    </div>

  );
}



export default function PlaygroundApp({
  setIsEmptyEditor,
  reportPlanningData,
  isLoading,
  content = false,
  activeEditor,
  isUserMadeChange,
  setActiveEditorParent,
  handlingSetUserMadeChange,
  strategicBinderId,
  activeItem,
  typingCount,
  setTypingCount
}) {
  const [step, setStep] = useQueryState("TableofContents", { defaultValue: "" }); // start with no step

  const [modifiedBinderData, setModifiedBinderData] = useState(null)
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);

  // const { data: BinderSide, isLoading: isLoadingBinderSide } = useApi(
  //   strategicPlan && strategicBinderId && activeItem?.slug ? apiList.admin.binder_template.list.key(strategicBinderId, activeItem?.slug) : null,
  //   strategicPlan && strategicBinderId && activeItem?.slug ? apiList.admin.binder_template.list.call(strategicBinderId, activeItem?.slug) : null
  // );

  // When data is loaded, determine which step to show
  // useEffect(() => {
  //   if (!isLoadingBinderSide) {
  //     if (BinderSide && BinderSide.has_content) {

  //       setStep("2");
  //     } else {
  //       setStep("1");
  //     }
  //   }
  // }, [BinderSide, isLoadingBinderSide]);
  // useEffect(() => {
  //   if (!isLoadingBinderSide && BinderSide?.data) {
  //     const updatedData = BinderSide.data.map((section) => {
  //       if (section.section.text === "Organization Foundation Pillars") {

  //           return {
  //             section: {
  //               ...section.section,
  //               sub_heading: [
  //                 {
  //                   text: "Organization Foundation Pillars",
  //                   is_selected: section.section.is_selected,
  //                   image: section.section.image || null, // Use the same image if it exists
  //                 },
  //               ],
  //             },
  //           };

  //       }
  //       return section;
  //     });

  //     setModifiedBinderData(updatedData);
  //   }
  // }, [BinderSide, isLoadingBinderSide]);
  // While deciding, or loading, show a spinner
  // if (isLoadingBinderSide || step === null && modifiedBinderData) {
  //   return <PageSpinner className="bg-white" />;
  // }

  if (isLoading) {
    return <PageSpinner className="bg-white" />
  }

  return (
    // <div>
    //   {step === "1" ? (
    //     <BinderStepOne content={BinderSide?.data} step={step} setStep={setStep} />
    //   ) : (
    //     <SettingsContext>
    //       <FlashMessageContext>
    //         <App content={content} setStep={setStep} />
    //       </FlashMessageContext>
    //     </SettingsContext>
    //   )}
    // </div>
    <div>
      <SettingsContext>
        <FlashMessageContext>
          <App
            setIsEmptyEditor={setIsEmptyEditor}
            reportPlanningData={reportPlanningData}
            content={content}
            setStep={setStep}
            isUserMadeChange={isUserMadeChange}
            activeEditor={activeEditor}
            setActiveEditorParent={setActiveEditorParent}
            handlingSetUserMadeChange={handlingSetUserMadeChange}
            strategicBinderId={strategicBinderId}
            slug={activeItem?.slug}
            typingCount={typingCount}
            setTypingCount={setTypingCount}
          />
        </FlashMessageContext>
      </SettingsContext>
    </div>
  );
}
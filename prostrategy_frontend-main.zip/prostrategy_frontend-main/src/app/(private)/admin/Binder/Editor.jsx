import { AutoFocusPlugin } from "@lexical/react/LexicalAutoFocusPlugin";
import { CharacterLimitPlugin } from "@lexical/react/LexicalCharacterLimitPlugin";
import { CheckListPlugin } from "@lexical/react/LexicalCheckListPlugin";
import { ClearEditorPlugin } from "@lexical/react/LexicalClearEditorPlugin";
import { ClickableLinkPlugin } from "@lexical/react/LexicalClickableLinkPlugin";
import { CollaborationPlugin } from "@lexical/react/LexicalCollaborationPlugin";
import { useLexicalComposerContext } from "@lexical/react/LexicalComposerContext";
import { LexicalErrorBoundary } from "@lexical/react/LexicalErrorBoundary";
import { HashtagPlugin } from "@lexical/react/LexicalHashtagPlugin";
import { HistoryPlugin } from "@lexical/react/LexicalHistoryPlugin";
import { HorizontalRulePlugin } from "@lexical/react/LexicalHorizontalRulePlugin";
import { ListPlugin } from "@lexical/react/LexicalListPlugin";
import { PlainTextPlugin } from "@lexical/react/LexicalPlainTextPlugin";
import { RichTextPlugin } from "@lexical/react/LexicalRichTextPlugin";
import { SelectionAlwaysOnDisplay } from "@lexical/react/LexicalSelectionAlwaysOnDisplay";
import { TabIndentationPlugin } from "@lexical/react/LexicalTabIndentationPlugin";
import { TablePlugin } from "@lexical/react/LexicalTablePlugin";
import { useLexicalEditable } from "@lexical/react/useLexicalEditable";
import { useEffect, useMemo, useRef, useState } from "react";
import { createWebsocketProvider } from "./collaboration";
import { useSettings } from "./context/SettingsContext";
import { useSharedHistoryContext } from "./context/SharedHistoryContext";
import ActionsPlugin from "./plugins/ActionsPlugin";
import AutocompletePlugin from "./plugins/AutocompletePlugin";
import AutoEmbedPlugin from "./plugins/AutoEmbedPlugin";
import AutoLinkPlugin from "./plugins/AutoLinkPlugin";
import CodeActionMenuPlugin from "./plugins/CodeActionMenuPlugin";
import CodeHighlightPlugin from "./plugins/CodeHighlightPlugin";
import CollapsiblePlugin from "./plugins/CollapsiblePlugin";
import ComponentPickerPlugin from "./plugins/ComponentPickerPlugin";
import ContextMenuPlugin from "./plugins/ContextMenuPlugin";
import DragDropPaste from "./plugins/DragDropPastePlugin";
import DraggableBlockPlugin from "./plugins/DraggableBlockPlugin";
import EmojiPickerPlugin from "./plugins/EmojiPickerPlugin";
import EmojisPlugin from "./plugins/EmojisPlugin";
import EquationsPlugin from "./plugins/EquationsPlugin";
import FigmaPlugin from "./plugins/FigmaPlugin";
import FloatingLinkEditorPlugin from "./plugins/FloatingLinkEditorPlugin";
import FloatingTextFormatToolbarPlugin from "./plugins/FloatingTextFormatToolbarPlugin";
import ImagesPlugin from "./plugins/ImagesPlugin";
import InlineImagePlugin from "./plugins/InlineImagePlugin";
import KeywordsPlugin from "./plugins/KeywordsPlugin";
import { LayoutPlugin } from "./plugins/LayoutPlugin/LayoutPlugin";
import LinkPlugin from "./plugins/LinkPlugin";
import ListMaxIndentLevelPlugin from "./plugins/ListMaxIndentLevelPlugin";
import MarkdownShortcutPlugin from "./plugins/MarkdownShortcutPlugin";
import { MaxLengthPlugin } from "./plugins/MaxLengthPlugin";
import MentionsPlugin from "./plugins/MentionsPlugin";
import PageBreakPlugin from "./plugins/PageBreakPlugin";
import PollPlugin from "./plugins/PollPlugin";
import ShortcutsPlugin from "./plugins/ShortcutsPlugin";
import SpecialTextPlugin from "./plugins/SpecialTextPlugin";
import SpeechToTextPlugin from "./plugins/SpeechToTextPlugin";
import TabFocusPlugin from "./plugins/TabFocusPlugin";
import TableCellActionMenuPlugin from "./plugins/TableActionMenuPlugin";
import TableCellResizer from "./plugins/TableCellResizer";
import TableHoverActionsPlugin from "./plugins/TableHoverActionsPlugin";
import TableOfContentsPlugin from "./plugins/TableOfContentsPlugin";
import ToolbarPlugin from "./plugins/ToolbarPlugin";
import TreeViewPlugin from "./plugins/TreeViewPlugin";
import TwitterPlugin from "./plugins/TwitterPlugin";
import YouTubePlugin from "./plugins/YouTubePlugin";
import ContentEditable from "./ui/ContentEditable";
import { CAN_USE_DOM } from "./shared/src/canUseDOM";
import { OnChangePlugin } from "@lexical/react/LexicalOnChangePlugin";
import { Card } from "@nextui-org/card";
import { $getRoot, CLEAR_EDITOR_COMMAND, COMMAND_PRIORITY_EDITOR } from "lexical";
import { appendHtmlToEditor } from "./customModules/htmlToLexical";
import { apiList } from "../../../../services";
import useApi from "../../../../hooks/useApi";
import usePermissionsStore from "../../../../stores/usePermissionStore";
import { PageSpinner } from "../../../../components";
import WrappableImagePlugin from "./plugins/wrappableImagePlugin/WrappableImagePlugin";
import { useAuth } from "../../../../providers/authProviders";
import withReactContent from "sweetalert2-react-content";
import Swal from "sweetalert2/dist/sweetalert2.js";
import ProstrategyLogo from "../../../../assets/icons/ProstrategyLogo";
import { Modal, ModalContent } from "@nextui-org/modal";
import toast from "react-hot-toast";
import debounce from "lodash.debounce";

const MySwal = withReactContent(Swal);

const skipCollaborationInit =
  // @ts-expect-error
  window.parent != null && window.parent.frames.right === window;

export default function Editor({
  isUserMadeChange,
  reportPlanningData,
  content = false,
  setStep,
  setActiveEditorParent,
  handlingSetUserMadeChange,
  strategicBinderId,
  slug,
  typingCount,
  setTypingCount
}) {
  const [editorValue, setEditorValue] = useState({});
  const { historyState } = useSharedHistoryContext();
  const {
    settings: {
      isCollab,
      isAutocomplete,
      isMaxLength,
      isCharLimit,
      hasLinkAttributes,
      isCharLimitUtf8,
      isRichText,
      showTreeView,
      shouldUseLexicalContextMenu,
      tableCellMerge,
      tableCellBackgroundColor,
      tableHorizontalScroll,
      shouldAllowHighlightingWithBrackets,
      selectionAlwaysOnDisplay,
    },
  } = useSettings();
  const isEditable = useLexicalEditable();
  const placeholder = isCollab
    ? "Enter some collaborative rich text..."
    : isRichText
      ? "Enter some rich text..."
      : "Enter some plain text...";
  const [floatingAnchorElem, setFloatingAnchorElem] = useState(null);
  const [isSmallWidthViewport, setIsSmallWidthViewport] = useState(false);
  const [editor] = useLexicalComposerContext();
  const [activeEditor, setActiveEditor] = useState(editor);
  const [isLinkEditMode, setIsLinkEditMode] = useState(false);
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
  const [loading, setLoading] = useState(true); // Start with loading true
  const [initialLoad, setInitialLoad] = useState(true);
  const [isReset, setIsReset] = useState(false);
  const [isChanged, setIsChanged] = useState(false);
  const [isEditableOrNot, setIsEditable] = useState(false);
  const [showAccessDeniedModal, setShowAccessDeniedModal] = useState(false);
  const [editorReady, setEditorReady] = useState(false); // New state to track editor readiness
  const [previousContent, setPreviousContent] = useState("");
  const [isFirstChange, setIsFirstChange] = useState(true);
  const mutateErrorShown = useRef(false)
  const userChangeRef = useRef(false);
  const [apiError, setApiError] = useState(null);
  const [changeCount, setChangeCount] = useState(0);

  const initialLoadRef = useRef(true);
  const onRef = (_floatingAnchorElem) => {
    if (_floatingAnchorElem !== null) {
      setFloatingAnchorElem(_floatingAnchorElem);
    }
  };

  useEffect(() => {
    if (editor) {
      setActiveEditorParent(editor);
      setEditorReady(true); // Mark editor as ready when it's available
    }
  }, [editor, setActiveEditorParent]);

  useEffect(() => {
    const updateViewPortWidth = () => {
      const isNextSmallWidthViewport =
        CAN_USE_DOM && window.matchMedia("(max-width: 1025px)").matches;

      if (isNextSmallWidthViewport !== isSmallWidthViewport) {
        setIsSmallWidthViewport(isNextSmallWidthViewport);
      }
    };
    updateViewPortWidth();
    window.addEventListener("resize", updateViewPortWidth);

    return () => {
      window.removeEventListener("resize", updateViewPortWidth);
    };
  }, [isSmallWidthViewport]);

  const { trigger: saveTemplate, mutationError } = useApi(
    null,
    strategicBinderId && slug ? apiList.admin.binder_template.save.call(strategicBinderId, slug) : null,
    { method: "PATCH" }
  );

  useEffect(() => {
    if (mutationError) {
      if (mutationError?.status === 400) {
        setApiError(mutationError.data?.message || "An error occurred");
      }
    }
  }, [mutationError]);

  useEffect(() => {
    if (apiError && !mutateErrorShown.current) {
      toast.error(apiError);
      mutateErrorShown.current = true;
      setApiError(null); // Reset error after showing
    }
  }, [apiError]);


  const callPatchApi = async () => {
    try {
      const response = await saveTemplate({ requestBody: { is_current_user_editing: true } });
      if (response?.status === "error") {
        toast.error(response?.message)
      }
    } catch (error) {
      console.error('Error calling PATCH API:', error);
    }
  };

  const auth = useAuth();

  useEffect(() => {
    if (reportPlanningData) {
      if (!reportPlanningData.is_allow_edit) {
        handlingSetUserMadeChange(false)
      } else if (reportPlanningData.is_another_user_editing) {
        handlingSetUserMadeChange(false)
      }
    }
  }, [reportPlanningData])


  useEffect(() => {
    if (changeCount === 1) {
      callPatchApi()
    }
  }, [changeCount])


  // Initialize editor content
  useEffect(() => {
    if (!editorReady || !reportPlanningData) return;

    const initializeEditor = async () => {

      try {
        setLoading(true);
        handlingSetUserMadeChange(false);
        userChangeRef.current = false;
        setChangeCount(0);
        // Clear editor first
        editor.update(() => {
          $getRoot().clear();
        });

        const BinderContent = reportPlanningData?.data;

        if (BinderContent) {
          const hasContent = BinderContent.lexical_content || BinderContent.value;

          if (hasContent) {
            if (BinderContent.lexical_content) {
              try {
                const serializedEditorState = JSON.parse(BinderContent.lexical_content);
                const editorState = editor.parseEditorState(serializedEditorState);
                editor.setEditorState(editorState);
              } catch (error) {
                console.error("Failed to parse lexical content:", error);
                editor.update(() => {
                  $getRoot().clear();
                });
              }
            } else if (BinderContent.value) {
              await appendHtmlToEditor(editor, BinderContent.value);
            }
          }

          // Set editability based on permissions
          const isContentEditable = reportPlanningData?.is_allow_edit && !reportPlanningData?.is_another_user_editing;
          setIsEditable(isContentEditable);
          editor.setEditable(isContentEditable);

          // Focus the editor if editable
          if (isContentEditable) {
            setTimeout(() => {
              editor.focus();
            }, 100);
          }
        }

        initialLoadRef.current = false;
        setInitialLoad(false);
        setIsChanged(false);
        handlingSetUserMadeChange(false);
      } catch (error) {
        console.error("Error initializing editor:", error);
        editor.update(() => {
          $getRoot().clear();
        });
      } finally {
        setLoading(false);
        setTimeout(() => {
          userChangeRef.current = true;
        }, 100);
      }
    };

    initializeEditor();
  }, [reportPlanningData, editorReady, isReset]);

  // Add this effect to handle binder changes
  useEffect(() => {
    return () => {
      // Cleanup when component unmounts or binder changes
      userChangeRef.current = false;
      initialLoadRef.current = true;
      setIsFirstChange(true);
    };
  }, [strategicBinderId, slug]); // Add dependencies that change when binder changes

  const debouncedPatchApi = useMemo(
    () => debounce(() => {
      console.log('Actually calling patch API now');
      callPatchApi();
    }, 500),
    [callPatchApi]
  );

  // Add cleanup for debounce
  useEffect(() => {
    return () => {
      debouncedPatchApi.cancel();
    };
  }, [debouncedPatchApi]);
  // Add this useEffect to track user interactions
  useEffect(() => {
    if (!editorReady || !editor) return;

    return editor.registerCommand(
      COMMAND_PRIORITY_EDITOR,
      (type) => {
        // Only mark as user change for specific command types
        if (type === 'keypress' || type === 'delete' || type === 'paste' ||
          type === 'click' || type === 'cut' || type === 'drag') {
          userChangeRef.current = true;
        }
        return false;
      },
      COMMAND_PRIORITY_EDITOR
    );
  }, [editor, editorReady]);

  useEffect(() => {
    if (!editorReady || !content) return;

    const handleContent = async () => {
      editor.dispatchCommand(CLEAR_EDITOR_COMMAND, undefined);
      await appendHtmlToEditor(editor, content);
      editor.focus();
    };

    handleContent();
  }, [content, editor, editorReady]);

  useEffect(() => {
    // if (!editorReady || !editor || initialLoadRef.current) return;

    const handleUserInteraction = () => {
      if (!isUserMadeChange && isEditableOrNot) {
        handlingSetUserMadeChange(true);
        callPatchApi()
      }
    };

    const editorElement = document.querySelector('.editor');
    if (!editorElement) return;

    editorElement.addEventListener('mousedown', handleUserInteraction);
    editorElement.addEventListener('keydown', handleUserInteraction);

    // Clean up
    return () => {
      editorElement.removeEventListener('mousedown', handleUserInteraction);
      editorElement.removeEventListener('keydown', handleUserInteraction);
    };
  }, [editorReady, editor, isUserMadeChange, isEditableOrNot, handlingSetUserMadeChange]);

  // Close access denied modal
  const closeAccessDeniedModal = () => {
    setShowAccessDeniedModal(false);
  };

  // Show loading state if we don't have data yet or editor is initializing
  if (!reportPlanningData || loading || !editorReady) {
    return <PageSpinner />;
  }

  return (
    <div className="flex flex-col mt-0 bt-12 h-full" id="playcu"
      onMouseEnter={() => !isEditableOrNot && setShowAccessDeniedModal(true)}
      onMouseLeave={() => !isEditableOrNot && setShowAccessDeniedModal(false)}
    >
      {!isEditableOrNot && (
        <div
          className="absolute inset-0 z-[9998]"
          onMouseEnter={() => setShowAccessDeniedModal(true)}
          onMouseLeave={() => setShowAccessDeniedModal(false)}
        />
      )}

      <Modal
        isOpen={showAccessDeniedModal && !isEditableOrNot}
        onClose={closeAccessDeniedModal}
        placement="center"
        className="z-[9999] max-w-md"
      >
        <ModalContent>
          <div className="p-6 text-center">
            <div className="flex justify-center mb-4">
              <ProstrategyLogo className="h-10" />
            </div>

            <h3 className="text-lg font-semibold text-gray-700 mb-3">
              ACCESS RESTRICTED
            </h3>
            <p className="text-gray-600 mb-6">
              {!reportPlanningData?.is_allow_edit
                ?
                "Your current access level doesn't permit modifications to these strategic support settings."
                : "This document is currently being edited by another user. Please try again later."
              }
            </p>
          </div>
        </ModalContent>
      </Modal>

      {isRichText && (
        <ToolbarPlugin
          isReset={isReset}
          setIsReset={setIsReset}
          setStep={setStep}
          editor={editor}
          activeEditor={activeEditor}
          setActiveEditor={setActiveEditor}
          setIsLinkEditMode={setIsLinkEditMode}
          handlingSetUserMadeChange={handlingSetUserMadeChange}
          strategicBinderId={strategicBinderId}
          slug={slug}
          setTypingCount={setTypingCount}
          isUserMadeChange={isUserMadeChange}
        />
      )}
      {isRichText && (
        <ShortcutsPlugin
          editor={activeEditor}
          setIsLinkEditMode={setIsLinkEditMode}
        />
      )}
      <div
        className={`editor-container${showTreeView ? "tree-view" : ""} ${!isRichText ? "plain-text" : ""
          }`}
      >
        {isMaxLength && <MaxLengthPlugin maxLength={30} />}
        <DragDropPaste />
        <AutoFocusPlugin />
        {selectionAlwaysOnDisplay && <SelectionAlwaysOnDisplay />}
        <ClearEditorPlugin />
        <ComponentPickerPlugin />
        <EmojiPickerPlugin />
        <AutoEmbedPlugin />
        <MentionsPlugin />
        <EmojisPlugin />
        <HashtagPlugin />
        <KeywordsPlugin />
        <SpeechToTextPlugin />
        <AutoLinkPlugin />
        <div className="flex-grow flex mt-2 gap-2 ">
          <div className="w-full pros">
            <Card className="h-full [box-shadow:0_0_#0000] border-b-0" radius="none">
              {isRichText ? (
                <>
                  {isCollab ? (
                    <CollaborationPlugin
                      id="main"
                      providerFactory={createWebsocketProvider}
                      shouldBootstrap={!skipCollaborationInit}
                    />
                  ) : (
                    <HistoryPlugin externalHistoryState={historyState} />
                  )}
                  <RichTextPlugin
                    contentEditable={
                      <div className="editor-scroller ">
                        <div className="editor" ref={onRef}>
                          <ContentEditable
                            placeholder={placeholder} />
                        </div>
                      </div>
                    }
                    ErrorBoundary={LexicalErrorBoundary}
                  />

                  <MarkdownShortcutPlugin />
                  <CodeHighlightPlugin />
                  <ListPlugin />
                  {/* <CheckListPlugin /> */}
                  <ListMaxIndentLevelPlugin maxDepth={7} />
                  <TablePlugin
                    hasCellMerge={tableCellMerge}
                    hasCellBackgroundColor={tableCellBackgroundColor}
                    hasHorizontalScroll={tableHorizontalScroll}
                  />
                  <TableCellResizer />
                  <WrappableImagePlugin />
                  <ImagesPlugin />
                  <InlineImagePlugin />
                  <LinkPlugin hasLinkAttributes={hasLinkAttributes} />
                  <PollPlugin />
                  <TwitterPlugin />
                  <YouTubePlugin />
                  <FigmaPlugin />
                  <ClickableLinkPlugin disabled={isEditable} />
                  <HorizontalRulePlugin />
                  <EquationsPlugin />
                  <TabFocusPlugin />
                  <TabIndentationPlugin />
                  <CollapsiblePlugin />
                  <PageBreakPlugin />
                  <LayoutPlugin />
                  {/* <OnChangePlugin
                    onChange={(editorState) => {
                      if (!initialLoadRef.current && isEditableOrNot) {

                        const isEmpty = editorState.read(() => $getRoot().isEmpty());
                        const textContent = editorState.read(() => $getRoot().getTextContent());

                        if (textContent.trim().length > 0 && !isUserMadeChange) {
                          handlingSetUserMadeChange(true);
                          callPatchApi();
                        }
                      }
                    }}
                  /> */}
                  {/* <OnChangePlugin
                    onChange={(editorState) => {

                      if (!initialLoadRef.current && isEditableOrNot) {
                        alert("onChange called");
                        const currentContent = editorState.read(() => $getRoot().getTextContent());

                        // Skip the first change (initial content load)
                        if (isFirstChange) {
                          setPreviousContent(currentContent);
                          setIsFirstChange(false);
                          return;
                        }

                        // Only trigger if content actually changed and it's not empty
                        if (currentContent !== previousContent && currentContent.trim().length > 0) {
                          setPreviousContent(currentContent);

                          if (!isUserMadeChange) {
                            handlingSetUserMadeChange(true);
                            callPatchApi();
                          }
                        }
                      }
                    }}
                  /> */}
                  {/* <OnChangePlugin
                    onChange={(editorState) => {
                      if (!initialLoadRef.current && isEditableOrNot && userChangeRef.current) {
                        const currentContent = editorState.read(() => $getRoot().getTextContent());

                        // Skip the first change (initial content load)
                        if (isFirstChange) {
                          setPreviousContent(currentContent);
                          setIsFirstChange(false);
                          return;
                        }

                        // Only trigger if content actually changed
                        if (currentContent !== previousContent) {
                          setPreviousContent(currentContent);
                          handlingSetUserMadeChange(true);
                          // debouncedPatchApi();
                        }
                      }
                    }}
                  /> */}
                  <OnChangePlugin
                    onChange={(editorState) => {

                      if (!initialLoadRef.current && isEditableOrNot && userChangeRef.current) {
                        const currentContent = editorState.read(() => $getRoot().getTextContent());
                        console.log('Content changed:', currentContent);

                        if (isFirstChange) {
                          console.log('Skipping first change');
                          setPreviousContent(currentContent);
                          setIsFirstChange(false);
                          return;
                        }

                        if (currentContent !== previousContent) {
                          console.log('Content changed - calling API');
                          setPreviousContent(currentContent);
                          handlingSetUserMadeChange(true);
                          setChangeCount(prev => prev + 1); // Increment change count
                          // debouncedPatchApi();
                        }
                      }
                    }}
                  />
                  {floatingAnchorElem && !isSmallWidthViewport && isEditableOrNot && (
                    <>
                      <DraggableBlockPlugin anchorElem={floatingAnchorElem} />
                      <CodeActionMenuPlugin anchorElem={floatingAnchorElem} />
                      <FloatingLinkEditorPlugin
                        anchorElem={floatingAnchorElem}
                        isLinkEditMode={isLinkEditMode}
                        setIsLinkEditMode={setIsLinkEditMode}
                      />
                      <TableCellActionMenuPlugin
                        anchorElem={floatingAnchorElem}
                        cellMerge={true}
                      />
                      <TableHoverActionsPlugin
                        anchorElem={floatingAnchorElem}
                      />
                      <FloatingTextFormatToolbarPlugin
                        anchorElem={floatingAnchorElem}
                        setIsLinkEditMode={setIsLinkEditMode}
                      />
                    </>
                  )}
                </>
              ) : (
                <>
                  <PlainTextPlugin
                    contentEditable={
                      <ContentEditable placeholder={placeholder} />
                    }
                    ErrorBoundary={LexicalErrorBoundary}
                  />
                  <HistoryPlugin externalHistoryState={historyState} />
                </>
              )}
            </Card>
          </div>
        </div>
        {(isCharLimit || isCharLimitUtf8) && (
          <CharacterLimitPlugin
            charset={isCharLimit ? "UTF-16" : "UTF-8"}
            maxLength={5}
          />
        )}
        {isAutocomplete && <AutocompletePlugin />}
        {shouldUseLexicalContextMenu && <ContextMenuPlugin />}
        {shouldAllowHighlightingWithBrackets && <SpecialTextPlugin />}
      </div>
    </div>
  );
}  
import { $generateNodesFromDOM } from "@lexical/html";
import {
  $createParagraphNode,
  $createTextNode,
  $getRoot,
  $insertNodes,
} from "lexical";
import { $createImageNode } from "../nodes/ImageNode";
import { $createHeadingNode } from "@lexical/rich-text";
import { $createListItemNode, $createListNode } from "@lexical/list"

// export function appendHtmlToEditor(editor, htmlString) {

//     editor.update(() => {
//         // Parse the HTML string into a DOM document
//         const parser = new DOMParser();
//         const dom = parser.parseFromString(htmlString, 'text/html');

//         // Convert the DOM structure to Lexical nodes
//         const nodes = $generateNodesFromDOM(editor, dom);
//         console.log(nodes,"gloo");
//         // Select the root of the editor
//         const root = $getRoot();
//         root.select();
//         console.log(nodes,"gooo")

//         // Insert the nodes into the editor
//         $insertNodes(nodes);
//       });
//   }

// export function appendHtmlToEditor(editor, htmlString) {
//   editor.update(() => {
//     // Parse the HTML string into a DOM document
//     const parser = new DOMParser();
//     const dom = parser.parseFromString(htmlString, 'text/html');

//     // Function to recursively convert DOM nodes to Lexical nodes
//     const convertDomToLexicalNodes = (element) => {
//       const nodes = [];

//       // Loop through each child node of the element
//       element.childNodes.forEach((childNode) => {
//         if (childNode.nodeType === Node.ELEMENT_NODE) {
//           // Handle image elements separately
//           if (childNode.tagName.toLowerCase() === 'img') {
//             const src = childNode.getAttribute('src');
//             const alt = childNode.getAttribute('alt') || '';
//             const imageNode = $createImageNode({ src, alt });
//             nodes.push(imageNode);
//           } else {
//             // Recursively convert other elements
//             const childNodes = convertDomToLexicalNodes(childNode);
//             nodes.push(...childNodes);
//           }
//         } else if (childNode.nodeType === Node.TEXT_NODE) {
//           // Convert text nodes to Lexical text nodes
//           const textNode = $createTextNode(childNode.textContent);
//           nodes.push(textNode);
//         }
//       });

//       return nodes;
//     };

//     // Convert the DOM structure to Lexical nodes
//     const nodes = convertDomToLexicalNodes(dom.body);

//     // Select the root of the editor
//     const root = $getRoot();
//     root.select();

//     // Insert the nodes into the editor
//     $insertNodes(nodes);
//   });
// }

// export function appendHtmlToEditor(editor, htmlString) {
//   editor.update(() => {
//     // Parse the HTML string into a DOM document
//     const parser = new DOMParser();
//     const dom = parser.parseFromString(htmlString, "text/html");

//     // Function to recursively convert DOM nodes to Lexical nodes
//     const convertDomToLexicalNodes = (element) => {
//       const nodes = [];

//       // Loop through each child node of the element
//       element.childNodes.forEach((childNode) => {
//         if (childNode.nodeType === Node.ELEMENT_NODE) {
//           // Handle image elements
//           if (childNode.tagName.toLowerCase() === "img") {
//             const src = childNode.getAttribute("src");
//             const alt = childNode.getAttribute("alt") || "";
//             const imageNode = $createImageNode({ src, alt });
//             nodes.push(imageNode);
//           }
//           // Handle headings (h1, h2, h3, etc.)
//           else if (/^h[1-6]$/i.test(childNode.tagName)) {
//             const level = parseInt(childNode.tagName.substring(1), 10); // Extract heading level
//             const headingNode = $createHeadingNode(`h${level}`);
//             const textNode = $createTextNode(childNode.textContent);
//             headingNode.append(textNode);
//             nodes.push(headingNode);
//           }
//           // Handle bold elements (strong or b)
//           else if (
//             childNode.tagName.toLowerCase() === "strong" ||
//             childNode.tagName.toLowerCase() === "b"
//           ) {
//             const textNode = $createTextNode(childNode.textContent);
//             textNode.toggleFormat("bold"); // Apply bold formatting
//             nodes.push(textNode);
//           }
//           // Handle italic elements (em or i)
//           else if (
//             childNode.tagName.toLowerCase() === "em" ||
//             childNode.tagName.toLowerCase() === "i"
//           ) {
//             const textNode = $createTextNode(childNode.textContent);
//             textNode.toggleFormat("italic"); // Apply italic formatting
//             nodes.push(textNode);
//           }
//           // Handle paragraphs
//           else if (childNode.tagName.toLowerCase() === "p") {
//             const paragraphNode = $createParagraphNode();
//             const childNodes = convertDomToLexicalNodes(childNode); // Recursively process children
//             paragraphNode.append(...childNodes);
//             nodes.push(paragraphNode);
//           }
//           // Handle other elements (div, span, etc.)
//           else {
//             const childNodes = convertDomToLexicalNodes(childNode); // Recursively process children
//             nodes.push(...childNodes);
//           }
//         } else if (childNode.nodeType === Node.TEXT_NODE) {
//           // Convert text nodes to Lexical text nodes
//           const textContent = childNode.textContent.trim(); // Trim to remove extra spaces
//           if (textContent) {
//             const textNode = $createTextNode(textContent);
//             nodes.push(textNode);
//           }
//         }
//       });

//       return nodes;
//     };

//     // Convert the DOM structure to Lexical nodes
//     const nodes = convertDomToLexicalNodes(dom.body);

//     // Select the root of the editor
//     const root = $getRoot();
//     root.select();

//     // Insert the nodes into the editor
//     $insertNodes(nodes);
//   });
// }
export function appendHtmlToEditor(editor, htmlString) {
  editor.update(() => {
    // Parse the HTML string into a DOM document
    const parser = new DOMParser();
    const dom = parser.parseFromString(htmlString, "text/html");

    // Function to recursively convert DOM nodes to Lexical nodes
    const convertDomToLexicalNodes = (element) => {
      const nodes = [];

      // Loop through each child node of the element
      element.childNodes.forEach((childNode) => {
        // if (childNode.nodeType === Node.ELEMENT_NODE) {
        //   // Handle image elements
        //   if (childNode.tagName.toLowerCase() === "img") {
        //     const src = childNode.getAttribute("src");
        //     const alt = childNode.getAttribute("alt") || "";
        //     const height =248;
        //     const width = 248;
        //     const imageNode = $createImageNode({ src, alt, height, width });
        //     nodes.push(imageNode);
        //   }
        if (childNode.nodeType === Node.ELEMENT_NODE) {
          // Handle image elements - MODIFIED SECTION
          if (childNode.tagName.toLowerCase() === "img") {
            const src = childNode.getAttribute("src");
            const alt = childNode.getAttribute("alt") || "";
            // Use actual dimensions if available, otherwise fallback to 248
            const height = childNode.getAttribute("height") || 248;
            const width = childNode.getAttribute("width") || 248;

            // Create paragraph wrapper for the image
            const paragraphNode = $createParagraphNode();
            const imageNode = $createImageNode({
              src,
              altText: alt,
              height: Number(height),
              width: Number(width)
            });

            paragraphNode.append(imageNode);
            nodes.push(paragraphNode);
          }
          // Handle headings (h1, h2, h3, etc.)
          else if (/^h[1-6]$/i.test(childNode.tagName)) {
            if (nodes?.length > 0) {
              const spacingNode = $createParagraphNode();
              nodes.push(spacingNode);
            }
            const level = parseInt(childNode.tagName.substring(1), 10); // Extract heading level
            const headingNode = $createHeadingNode(`h${level}`);
            const textNode = $createTextNode(childNode.textContent);
            headingNode.append(textNode);
            nodes.push(headingNode);
          }
          // Handle bold elements (strong or b)
          else if (
            childNode.tagName.toLowerCase() === "strong" ||
            childNode.tagName.toLowerCase() === "b"
          ) {
            const textNode = $createTextNode(childNode.textContent);
            textNode.toggleFormat("bold"); // Apply bold formatting
            nodes.push(textNode);
          }
          // Handle italic elements (em or i)
          else if (
            childNode.tagName.toLowerCase() === "em" ||
            childNode.tagName.toLowerCase() === "i"
          ) {
            const textNode = $createTextNode(childNode.textContent);
            textNode.toggleFormat("italic"); // Apply italic formatting
            nodes.push(textNode);
          }
          // Handle paragraphs
          else if (childNode.tagName.toLowerCase() === "p") {
            const paragraphNode = $createParagraphNode();
            const childNodes = convertDomToLexicalNodes(childNode); // Recursively process children
            paragraphNode.append(...childNodes);
            nodes.push(paragraphNode);
          }
          // Handle ordered lists
          else if (childNode.tagName.toLowerCase() === "ol") {
            const listNode = $createListNode("number"); // Create an ordered list
            const listItems = convertDomToLexicalNodes(childNode); // Recursively process list items
            listNode.append(...listItems);
            nodes.push(listNode);
          }
          // Handle unordered lists
          else if (childNode.tagName.toLowerCase() === "ul") {
            const listNode = $createListNode("bullet"); // Create an unordered list
            const listItems = convertDomToLexicalNodes(childNode); // Recursively process list items
            listNode.append(...listItems);
            nodes.push(listNode);
          }
          // Handle list items
          else if (childNode.tagName.toLowerCase() === "li") {
            const listItemNode = $createListItemNode();
            const childNodes = convertDomToLexicalNodes(childNode); // Recursively process children
            listItemNode.append(...childNodes);
            nodes.push(listItemNode);
          }
          // Handle other elements (div, span, etc.)
          else {
            const childNodes = convertDomToLexicalNodes(childNode); // Recursively process children
            nodes.push(...childNodes);
          }
        } else if (childNode.nodeType === Node.TEXT_NODE) {
          // Convert text nodes to Lexical text nodes
          const textContent = childNode.textContent.trim(); // Trim to remove extra spaces
          if (textContent) {
            const textNode = $createTextNode(textContent);
            nodes.push(textNode);
          }
        }
      });

      return nodes;
    };

    // Convert the DOM structure to Lexical nodes
    const nodes = convertDomToLexicalNodes(dom.body);

    // Select the root of the editor
    const root = $getRoot();
    root.select();

    // Insert the nodes into the editor
    $insertNodes(nodes);
  });
}
import { Card } from "@nextui-org/card";
import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  PageSpinner,
  PermissionWrapper,
  SearchInput,
} from "../../../../../components";
import { Divider } from "@nextui-org/divider";
import { Tooltip } from "@nextui-org/tooltip";
import { IconEdit } from "@tabler/icons-react";
import useApi from "../../../../../hooks/useApi";
import { apiList } from "../../../../../services";
import useTopbarStore from "../../../../../stores/torbarStore";
import { useAuth } from "../../../../../providers/authProviders";

const DepartmentUsers = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [searchVal, setSearchVal] = useState("");
  const [searchedList, setSearchedList] = useState([]);

  const { data, isLoading } = useApi(
    apiList.admin.departments.department_users.key(id),
    apiList.admin.departments.department_users.call(id)
  );
  const auth = useAuth();

  // Handle search input change
  const onSearchChange = (value) => {
    const trimmedValue = value?.trim();
    setSearchVal(trimmedValue); // Update search input value

    if (trimmedValue) {
      // Filter the users based on the search value
      const filteredList = data?.data?.filter(
        (user) =>
          user.name.toLowerCase().includes(trimmedValue.toLowerCase()) ||
          user.role.toLowerCase().includes(trimmedValue.toLowerCase())
      );
      setSearchedList(filteredList);
    } else {
      // If search input is cleared, reset the list to the full data
      setSearchedList(data?.data);
    }
  };

  // Clear the search input
  const onClear = () => {
    setSearchVal(""); // Clear the search input value
    setSearchedList(data?.data); // Reset to original user list
  };

  const { subtitle, setSubtitle } = useTopbarStore();

  useEffect(() => {
    setSubtitle(data?.department_name || "");
    setSearchedList(data?.data || []); // Initialize the list with fetched data
  }, [data]);

  if (isLoading) {
    return <PageSpinner />;
  }



  return (
    <Card
      className="pr-6 bg-white p-4 min-h-[calc(100vh-50vh)] relative"
      shadow="sm"
    >
      <div className="flex justify-between items-center">
        <div className="w-1/3">
          <h2 className="pl-2 text-gray-700 font-semibold text-xl mt-2">
            Department Users
          </h2>
          <h4 className="pl-2 text-primary font-semibold text-lg mt-1">
            {subtitle}
          </h4>
        </div>

        <div className="flex flex-col lg:flex-row justify-end items-center gap-3 w-full">
          <div className="flex justify-start items-center w-full sm:max-w-full lg:max-w-[44%]">
            <SearchInput
              onSearch={onSearchChange}
              onClear={onClear}
              placeholder="Search Department Name, Username"
              setSearch={setSearchVal}
              value={searchVal}
            />
          </div>
        </div>
      </div>

      <Divider className="my-4" />

      <div className="max-h-[calc(100vh-35vh)] overflow-auto">
        {searchedList.length > 0 ? (
          searchedList.map((user) =>{ 
            const isAction =
            auth?.user?.user_id == user?.id || user?.is_account_owner
              ? false
              : true;
            
            return(
            <div
              className="flex justify-between items-center p-2 px-4 border-b-1"
              key={user?.id}
            >
              <div>
                <h2 className="pl-2 text-gray-700 font-semibold text-base">
                  {user.name}
                </h2>
                <h4 className="pl-2 text-sm">{user.role}</h4>
              </div>
              {
                isAction && (
              <PermissionWrapper resource={"users"} actions={["edit"]}>
                <Tooltip content="Edit Department user">
                  <span className="me-3 text-lg text-default-500 cursor-pointer active:opacity-50">
                    <IconEdit
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        navigate(`/users/edit/${user?.id}`);
                      }}
                    />
                  </span>
                </Tooltip>
              </PermissionWrapper>
                )
              }
             
            </div>
          )})
        ) : (
          <div className="text-center text-gray-600 mt-6">No users found.</div>
        )}
      </div>
    </Card>
  );
};

export default DepartmentUsers;

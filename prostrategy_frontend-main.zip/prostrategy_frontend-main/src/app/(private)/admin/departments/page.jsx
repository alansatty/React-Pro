/* eslint-disable no-case-declarations */
import React, { useEffect, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";

import useApi from "../../../../hooks/useApi";
import { apiList } from "../../../../services";
import DepartmentCard from "./components/departmentCard";
import { PermissionWrapper, SearchInput } from "../../../../components";
import { Pagination } from "@nextui-org/pagination";
import hasPermission from "../../../../utils/hasPermission";
import { Card } from "@nextui-org/card";
import { Divider } from "@nextui-org/divider";
import { Button } from "@nextui-org/button";
import {
  IconCurrentLocation,
  IconEdit,
  IconListDetails,
  IconPlus,
  IconTrash,
  IconUsers,
  IconEye
} from "@tabler/icons-react";
import clsx from "clsx";
import CustomTable from "../../../../components/Table/CustomTable";
import { Tooltip } from "@nextui-org/tooltip";
import { useAuth } from "../../../../providers/authProviders";
import ConfirmationModal from "../../../../components/ConfirmationModal/ConfirmationModal";
import toast from "react-hot-toast";
import { mutate } from "swr";
import { useDisclosure } from "@nextui-org/modal";
import { DepartmentDrawer } from "./components/DepartmentDrawer";
import hasPlanPermission from "../../../../utils/hasPlanPermission";
import Swal from "sweetalert2/dist/sweetalert2.js";
import { getCurrentDate } from "../../../../utils/helpers";
import ProstrategyLogo from "../../../../assets/icons/ProstrategyLogo";
import withReactContent from "sweetalert2-react-content";
import usePermissionsStore from "../../../../stores/usePermissionStore";
const MySwal = withReactContent(Swal);
const DepartmentsPage = () => {
  const [viewType, setViewType] = useState(() => {
    return localStorage.getItem("viewType") || "card";
  });

  // Set up search params and navigation
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();

  // Get the page from URL params, default to 1 if not present
  const initialPage = Number(searchParams.get("page")) || 1;
  const [page, setPage] = useState(initialPage);
  const [confirmation, setConfirmation] = useState(false);
  const [selectedId, setSelectedId] = useState(null);
  const { isOpen, onOpen, onOpenChange } = useDisclosure();
  const [search, setSearch] = useState("");
  const [searchval, setSearchVal] = useState("");
  const [deparmentListsState, setDepartmentListState] = useState([])
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
  const [perPage, setPerPage] = useState(10);


  const { trigger: departmentDelete, isMutating: loadingDelete } = useApi(
    null,
    apiList.admin.departments.delete.call(selectedId),
    { method: "DELETE" }
  );

  const columns = [
    { name: "Department Name", uid: "name" },
    { name: "Created By", uid: "createdBy" },
    { name: "Creator Email", uid: "creator_email" },
    { name: "Created At", uid: "created_at" },
    { name: "", uid: "actions" },
  ];
  const auth = useAuth();

  // Update the URL query parameter when page changes
  const handlePageChange = (newPage) => {
    setPage(newPage);
    setSearchParams({ page: newPage });
  };

  useEffect(() => {
    localStorage.setItem("viewType", viewType);
  }, [viewType]);

  // Fetch department list using API hook
  const {
    data: departmentList,
    isLoading,
    error,
  } = useApi(
    strategicPlan ? apiList.admin.departments.index.key(1, perPage, strategicPlan, search) : null,
    strategicPlan ? apiList.admin.departments.index.call(1, perPage, strategicPlan, search) : null
  );


  const {
    data: currentPlanData,
    error: currentPlanError,
    isLoading: currentPlanDataLoading,
  } = useApi(
    apiList.admin.subscription.current_plan.key(),
    apiList.admin.subscription.current_plan.call()
  );

  // API for reordering - note we'll call this directly from the table
  const { trigger: reorderDepartmentList, isMutating: isReordering } = useApi(
    null,
    apiList.admin.departments.reorder.call(),
    { method: "POST" }
  );


  const confirmDeleteDepartment = (id) => {
    setSelectedId(id);
    setConfirmation(true);
  };

  const handleMutation = () => {
    mutate(apiList.admin.departments.index.key(page, perPage, strategicPlan, search));
  }

  const handleClick = (dept) => {
    try {

      if (dept?.has_business_target) {
        navigate(`/departments/${dept?.id}`);
      } else {
        MySwal.fire({
          html: (
            <div className="flex flex-col items-center">
              <div className="w-18 h-20 mb-2">
                <ProstrategyLogo />
              </div>
              <h2 className="text-xl font-semibold">Warning!</h2>
              <p className="mt-2">{`Please update the Business Target.`}</p>
            </div>
          ),
          confirmButtonText: `Go to Business Target`,
          customClass: {
            confirmButton: "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
          },
          // allowOutsideClick: false, // Prevent closing on backdrop click
        }).then((result) => {
          if (result.isConfirmed) {
            navigate(`/departments/target/${dept?.id}`);
          }
        });
      }
    } catch (error) {
      console.error("Error handling department click:", error);
      toast.error("Failed to load department data");
    }
  };


  const handleRowReorder = async (departmentId, newPosition) => {
    try {
      const formData = new FormData()
      formData.append('department_id', departmentId)
      formData.append('new_position', newPosition)

      await reorderDepartmentList({ requestBody: formData })
      handleMutation();
    } catch (error) {
      console.error("Failed to reorder plan", error);
      toast.error("Failed to reorder plan");
      handleMutation();
    }
  };

  const renderCell = React.useCallback(
    (departments, columnKey, pagef, rowIndex) => {
      let cellValue = departments[columnKey];
      if (!cellValue) {
        cellValue = "-";
      }

      const isAction =
        auth?.user?.user_id == departments?.id || departments?.is_account_owner
          ? false
          : true;
      switch (columnKey) {
        case "creator_email":
          return <div>{departments?.created_by?.email}</div>;
        case "createdBy":
          return <div>{departments?.created_by?.name}</div>;
        case "created_at":
          const createdAt = departments?.created_by?.created_at;
          const formattedDate = createdAt
            ? new Date(createdAt)
              .toLocaleDateString("en-US", {
                year: "numeric",
                month: "short",
                day: "numeric",
              })
              .replace(",", "") // Format to "Oct-7-2024"
            : "-";
          return <div>{formattedDate}</div>;
        case "actions":
          return (
            <>
              {isAction && (
                <div className="relative flex items-center gap-2">

                  <Tooltip content="Select Department">
                    <span className="text-lg text-default-500 cursor-pointer active:opacity-50">
                      <IconEye
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          handleClick(departments)
                        }}
                      />
                    </span>
                  </Tooltip>

                  <Tooltip content="Department Users">
                    <span className="text-lg text-default-500 cursor-pointer active:opacity-50">
                      <IconUsers
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          navigate(
                            `/departments/dept_users/${departments?.id}`
                          );
                        }}
                      />
                    </span>
                  </Tooltip>

                  <Tooltip content="Department Targets">
                    <span className="  text-lg text-default-500 cursor-pointer active:opacity-50">
                      <IconCurrentLocation
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          navigate(`/departments/target/${departments?.id}`);
                        }}
                      />
                    </span>
                  </Tooltip>

                  <PermissionWrapper resource={"department"} actions={["edit"]}>
                    <Tooltip content="Edit Department">
                      <span className=" text-lg text-default-500 cursor-pointer active:opacity-50">
                        <IconEdit
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            setSelectedId(departments?.id);
                            onOpenChange(true);
                          }}
                        />
                      </span>
                    </Tooltip>
                  </PermissionWrapper>

                  <PermissionWrapper
                    resource={"department"}
                    actions={["delete"]}
                  >
                    <Tooltip color="danger" content="Delete Department">
                      <span className=" text-lg text-danger cursor-pointer active:opacity-50">
                        <IconTrash
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            confirmDeleteDepartment(departments?.id);
                          }}
                        />
                      </span>
                    </Tooltip>
                  </PermissionWrapper>
                </div>
              )}
            </>
          );
        default:
          return cellValue;
      }
    },
    []
  );


  if (error) {
    return <div>Error loading departments.</div>;
  }

  const toggleView = () => {
    setViewType((prevViewType) => (prevViewType === "card" ? "list" : "card"));
  };

  const deleteDepartment = async () => {
    try {
      let response = await departmentDelete();
      toast.success(response.msg);

      mutate(apiList.admin.departments.index.key(1, perPage, strategicPlan, search));
    } catch (error) {
      toast.error("Failed to delete department");
    } finally {
      setConfirmation(false);
    }
  };


  const onSearchChange = (value) => {
    const trimmedValue = value?.trim();
    if (trimmedValue) {
      // debouncedSearch(value);
      setSearch(trimmedValue);
      setPage(1);
    } else {
      setSearch(""); // Clear the search value
    }
  };

  const onClear = () => {
    setSearch("");
    setSearchVal("");
  };

  const checkPlanPermission = () => {
    if (
      hasPlanPermission(
        "departments_allowed_count",
        departmentList?.total_items
      )
    ) {
      setSelectedId(null);
      onOpenChange(true);
    } else {
      if (
        ["Free", "Essential", "Plus"].includes(currentPlanData?.data?.plan_name)
      ) {
        MySwal.fire({
          html: (
            <div className="flex flex-col items-center">
              <div className="w-18 h-20 mb-2">
                <ProstrategyLogo />
              </div>

              <h2 className="text-xl font-semibold">Warning!</h2>
              <p className="mt-2">
                Department creation on this plan is exceeded. Please update your
                plan
              </p>
            </div>
          ),
          confirmButtonText: "Go to plans",
          customClass: {
            confirmButton:
              "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
          },
        }).then((result) => {
          if (result.isConfirmed) {
            navigate("/settings/account_tab"); // Perform navigation after clicking "Okay"
          }
        });
      } else {
        MySwal.fire({
          html: (
            <div className="flex flex-col items-center">
              <div className="w-18 h-20 mb-2">
                <ProstrategyLogo />
              </div>

              <h2 className="text-xl font-semibold">Warning!</h2>
              <p className="mt-2">
                Department creation on this plan is exceeded. please contact
                admin.
              </p>
            </div>
          ),
          confirmButtonText: "Okay",
          customClass: {
            confirmButton:
              "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
          },
        });
      }
    }
  };

  return (
    <Card
      className="pr-6 bg-white p-4 min-h-[calc(100vh-50vh)]  relative"
      shadow="sm"
    >
      <ConfirmationModal
        isLoading={loadingDelete}
        isOpen={confirmation}
        onClose={setConfirmation}
        onConfirm={deleteDepartment}
      />
      <DepartmentDrawer
        selectedId={selectedId}
        title={selectedId ? "Edit Department" : "Create New Department"}
        drawerState={isOpen}
        setDrawerState={onOpenChange}
        perPage={perPage}
        page={page}
      />
      <div className="flex justify-between items-center">
        <h2 className="pl-2 text-gray-700 font-semibold text-xl mt-2">
          Departments
        </h2>

        <div className="flex flex-col lg:flex-row justify-end items-center gap-3 w-full">
          <div className="flex justify-start items-center w-full sm:max-w-full lg:max-w-[44%]">
            <SearchInput
              // isDisabled={true}
              onSearch={onSearchChange}
              onClear={onClear}
              placeholder="Search name"
              setSearch={setSearchVal}
              value={searchval}
            />
          </div>

          <Tooltip content={viewType == "list" ? "Card view" : "Table View"}>
            <Button
              // isDisabled={true}
              isIconOnly
              onClick={toggleView}
              color="default"
              variant="bordered"
              radius="sm"
              aria-label="List view"
              className={clsx(
                viewType == "list" && "bg-gray-300",
                "font-medium py-[20px] px-3 w-full md:w-auto "
              )}
            >
              <IconListDetails color="#39465F" />
            </Button>
          </Tooltip>

          {hasPermission("department", "create") && viewType == "list" && (
            // hasPlanPermission("departments_allowed_count", departmentList?.total_items) &&
            <Button
              // isDisabled={true}
              size="md"
              color="primary"
              startContent={<IconPlus className="mb-1" />}
              radius="sm"
              className="font-medium py-[20px] w-full md:w-auto "
              onClick={() => {
                checkPlanPermission();
              }}
            >
              Create New
            </Button>
          )}
        </div>
      </div>

      <Divider className="my-4" />

      {viewType == "card" && (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-4">
          {/* Add Department Card */}

          {hasPermission("department", "create") && page == 1 && (
            // hasPlanPermission("departments_allowed_count",departmentList?.total_items) &&
            <DepartmentCard
              type="add"
              departmentCount={departmentList?.total_items}

            />
          )}

          {/* Map over department list */}
          {departmentList?.data?.map((data, index) => (
            <DepartmentCard key={index} value={data} page={page} perPage={perPage} search={search} />
          ))}

          {departmentList?.data.length == 0 && (
            <p className="text-center self-center">No data to display.</p>
          )}
        </div>
      )}

      {viewType == "list" && (
        <CustomTable
          columns={columns}
          renderCell={renderCell}
          responceData={departmentList}
          handlePageChange={handlePageChange}
          isLoading={isLoading}
          page={page}
          isClickable={true}
          handleClick={handleClick}
          isDraggable={true}
          onRowReorder={handleRowReorder}
          setPage={setPage}
          setPerPage={setPerPage}
          perPage={perPage}
        />
      )}

      {/* Pagination */}
      {viewType == "card" && (
        <div className="mt-4  w-full">
          <Divider orientation="horizontal" className="my-4" />
          <div className="flex pr-4 justify-between items-center">
            <div className="text-sm text-gray-600">
              ©{" "}
              {getCurrentDate({
                includeYear: true,
                includeMonth: false,
                includeDay: false,
              })}{" "}
              ProStrategy.ai . All Rights Reserved | Support Contact us
            </div>
            {viewType == "card" && departmentList?.total_pages > 1 && (
              <Pagination
                radius="sm"
                isCompact
                classNames={{
                  wrapper: "bg-white", // Apply white background to the wrapper
                  item: "bg-white text-black ", // Apply white background and black text to all items
                  cursor: "bg-white text-primary ", // Apply white background and black text to the active item
                  prev: "bg-white text-black ", // Apply white background and black text to the previous button
                  next: "bg-white text-black ", // Apply white background and black text to the next button
                }}
                variant="light"
                showControls
                total={departmentList?.total_pages || 1}
                page={page}
                onChange={handlePageChange}
              />
            )}
          </div>
        </div>
      )}
    </Card>
  );
};

export default DepartmentsPage;

import React, { useState, useEffect, useMemo } from "react";
import { Button } from "@nextui-org/button";
import { Input, Textarea } from "@nextui-org/input";
import { Checkbox } from "@nextui-org/checkbox";
import { IconPlus } from "@tabler/icons-react";
import { StrategicFormModal } from "./StrategicFormModal";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { Controller, useForm } from "react-hook-form";
import toast from "react-hot-toast";
import { Card } from "@nextui-org/card";
import { useNavigate, useParams } from "react-router-dom";
import Swal from "sweetalert2/dist/sweetalert2.js";
import useApi from "../../../../../../hooks/useApi";
import { apiList } from "../../../../../../services";
import hasPlanPermission from "../../../../../../utils/hasPlanPermission";
import AiHelpIcon from "../../../../../../assets/icons/aihelp-icon";
import CustomTooltip from "../../../../../../components/CustomTooltip/CustomTooltip";
import { PermissionWrapper } from "../../../../../../components";
import AiHelpGoalsAndStrategiesDrawer from "./goalsDrawer";
import withReactContent from "sweetalert2-react-content";
import ProstrategyLogo from "../../../../../../assets/icons/ProstrategyLogo";
import useUnsavedChanges from "../../../../../../hooks/useUnsavedChanges";
import UnsavedChangesModal from "../../../../../../components/Alert/UnsavedChangesModal";
import AIHelpStrategiesDrawer from "./strategiesDrawer";
import HelpModal from "../../../../../../components/Topbar/HelpModal";
import { DepartmentValueHelp, MemorializingUpdatingStrategyHelp } from "../../../../../../components/Topbar/helpComponents/Helps";
import ConfirmationModal from "../../../../../../components/ConfirmationModal/ConfirmationModal";
import { mutate } from "swr";
const MySwal = withReactContent(Swal);

const schema = yup.object().shape({
    description: yup
        .string()
        .required("Goal description is required.")
        .min(5, "Goals description needs at least 5 characters")
        .max(1054, "Goals description max characters are 1054"),
    strategies: yup.array().of(
        yup
            .string()
            .test(
                "min-length-or-empty",
                "Strategy needs at least 4 characters",
                (value) => !value || value.trim().length >= 4 // Allow empty values or enforce minimum length
            )
            .max(500, "Strategy max characters are 500")
    ),
});

function StrategicList({
    activeGoal,
    handleSave,
    handleStrategyChange,
    handleGoalChange,
    AILoading,
    AIStrategiesLoading,
    isMutating,
    strategicPlan,
    fullAIResponse,
    fullAIStrategies,
    AIError,
    isEditing,
    setIsEditing,
    isItemSelected,
    updateFormDirty,
    showTabChangeModal,
    confirmTabChange,
    cancelTabChange,
    handleMutate
}) {


    const { id } = useParams();

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [stratIdEntry, setStratIdEntry] = useState(null);
    const [isSelectedFormExist, setIsSelectedFormExist] = useState(false);
    const [strategyText, setStrategyText] = useState('')
    const [isStrategiesExist, setIsStrategiesExist] = useState(false)
    const [isSelectedStrategicFormExist, setIsSelectedStrategicFormExist] = useState(false);
    const handleModalOpen = (strategyId, formExist, strategicFormExist, text) => {
        setStrategyText(text)
        setStratIdEntry(strategyId);
        setIsSelectedFormExist(formExist);
        setIsSelectedStrategicFormExist(strategicFormExist)
        setIsModalOpen(true);
    };

    const [drawerOpen, setDrawerOpen] = useState(false);
    const [strategieDrawerOpen, setStrategieDrawerOpen] = useState(false);
    const [selectedGoal, setSelectedGoal] = useState({});
    const [selectedStrategies, setSelectedStrategies] = useState([]);
    const [dirty, setIsDirty] = useState(false);
    const [isOpen, setIsOpenModal] = useState(false)

    const [selectedStrategiesForDeletion, setSelectedStrategiesForDeletion] = useState([]);
    const isSelectToDelete = selectedStrategiesForDeletion.length > 0;

    const navigate = useNavigate();


    const handleModalClose = () => {
        setIsModalOpen(false);
        setIsOpenModal(false);
    }
    const defaultValues = useMemo(() => {
        return {
            description: activeGoal.description,
            strategies: activeGoal.strategies.map((s) =>
                typeof s === "string" ? s : s.text
            ),
        };
    }, [activeGoal])

    const {
        control,
        handleSubmit,
        reset,
        formState: { errors, isDirty },
    } = useForm({
        defaultValues,
        resolver: yupResolver(schema),
    });

    useEffect(() => {
        const isExist = activeGoal.strategies.some(item => Boolean(item))
        setIsStrategiesExist(isExist)
        if (activeGoal.id) {
            setIsEditing(false);
        } else {
            setIsEditing(true);
        }
        reset({
            description: activeGoal.description,
            strategies: activeGoal.strategies.map((s) =>
                typeof s === "string" ? s : s.text
            ),
        });
    }, [activeGoal, reset]);

    const {
        data: currentPlanData,
        error,
        isLoading: currentPlanDataLoading,
    } = useApi(
        apiList.admin.subscription.current_plan.key(),
        apiList.admin.subscription.current_plan.call()
    );

    const { trigger: trigerDeleteStrategies, isMutating: deleteMutating } =
        useApi(null,
            apiList.admin.departmentStrategies.delete_strategies.call(id),
            { method: "POST" },)

    const dirtyStatus = dirty || isDirty;

    const {
        showModal: showRouteChangeModal,
        confirmNavigation,
        cancelNavigation
    } = useUnsavedChanges(dirtyStatus);
    -
        useEffect(() => {
            updateFormDirty(dirtyStatus);
        }, [dirtyStatus, updateFormDirty]);

    useEffect(() => {
        if (isItemSelected) {
            reset(defaultValues, {
                keepDefaultValues: false,
            });
        }
    }, [isItemSelected, reset, defaultValues]);

    const onSubmit = async (data) => {
        reset(defaultValues, {
            keepValues: true,
            keepDirty: false,
            keepIsValid: true
        });
        setIsDirty(false);
        const allEmpty =
            Array.isArray(data.strategies) &&
            data.strategies.every((strategy) => !strategy.trim());

        if (allEmpty) {
            toast.error("At least one strategy is required.");
            return; // Exit early to prevent further processing
        }

        if (data) {
            const formData = {
                strategic_plan_id: strategicPlan,
                goal: data.description,
                goal_id: activeGoal.id,
                strategies: activeGoal.strategies
                    .map((s, index) => {
                        if (typeof s === "string") {
                            return data.strategies[index];
                        } else {
                            return { [s.id]: data.strategies[index] };
                        }
                    })
                    .filter((strategy) => strategy !== ""),
            };

            try {
                await handleSave(formData);
                reset(data, {
                    keepValues: true,
                    keepDirty: false,
                    keepIsValid: true
                });
                updateFormDirty(false)
            } catch (error) {
                console.error(error);
                toast.error("Failed to save strategies. Please try again.");
            }
        }
    };

    const AIHelp = () => {
        if (AIError) {
            MySwal.fire({
                html: (
                    <div className="flex flex-col items-center">
                        <div className="w-18 h-20 mb-2">
                            <ProstrategyLogo />
                        </div>

                        <h2 className="text-xl font-semibold">Warning!</h2>
                        <p className="mt-2">{`Please update the ${AIError} Form to get AI Help.`}</p>
                    </div>
                ),
                confirmButtonText: `Go to ${AIError} Form`,
                customClass: {
                    confirmButton:
                        "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
                },
            }).then((result) => {
                if (result.isConfirmed) {
                    if (AIError === "SVA") {
                        navigate(`/departments/${id}/svaform`);
                    } else {
                        navigate(`/departments/${id}/swot_tab`);
                    }
                }
            });
        } else {
            if (fullAIResponse.length > 0 || AILoading) {
                setDrawerOpen((prev) => !prev);
            }
        }
    };

    const AIStrategiesHelp = () => {
        if (AIError) {
            MySwal.fire({
                html: (
                    <div className="flex flex-col items-center">
                        <div className="w-18 h-20 mb-2">
                            <ProstrategyLogo />
                        </div>

                        <h2 className="text-xl font-semibold">Warning!</h2>
                        <p className="mt-2">{`Please update the ${AIError} Form to get AI Help.`}</p>
                    </div>
                ),
                confirmButtonText: `Go to ${AIError} Form`,
                customClass: {
                    confirmButton:
                        "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
                },
            }).then((result) => {
                if (result.isConfirmed) {
                    if (AIError === "SVA") {
                        navigate(`/departments/${id}/svaform`);
                    } else {
                        navigate(`/departments/${id}/swot_tab`);
                    }
                }
            });
        } else {
            if (fullAIStrategies.length > 0 || AIStrategiesLoading) {
                setStrategieDrawerOpen((prev) => !prev);
            }
        }
    };

    const handleSaveGoals = (selectedGoal) => {

        const goalKey = Object.keys(selectedGoal)[0];

        const newGoalAndStrategies = {
            [goalKey]: selectedGoal[goalKey], // Use selectedGoal directly
            strategies: selectedGoal.strategies, 
        };

        // Update the form values
        reset({
            description: newGoalAndStrategies[goalKey], // Goal description
            strategies: newGoalAndStrategies.strategies, // Strategies list
        });

        // Update the active goal with the new data
        handleGoalChange(newGoalAndStrategies[goalKey]);

        // Loop through strategies and update them
        newGoalAndStrategies.strategies.forEach((strategy, index) => {
            handleStrategyChange(index, strategy);
        });
    };

    const handleSaveStrategies = (selectedStrategies) => {
        // Update the form values
        reset({
            description: activeGoal?.description,
            strategies: selectedStrategies,
        });

        // // Update the active goal with the new data
        // handleGoalChange(newGoalAndStrategies[goalKey]);

        // Loop through strategies and update them
        selectedStrategies?.forEach((strategy, index) => {
            handleStrategyChange(index, strategy);
        });
    };

    const handleIsDirty = (status) => {
        setIsDirty(status)
    }

    const handleConfirmTabChange = () => {
        confirmNavigation()
        confirmTabChange()
        setIsDirty(false)
        updateFormDirty(false)
    }

    const handleDeleteStrategies = () => {
        setIsOpenModal(true)
    }

    const deleteStrategies = async () => {
        try {

            const allStrategies = activeGoal.strategies.filter(s => s?.text?.trim())
            const wouldDeleteAll = selectedStrategiesForDeletion.length >= allStrategies.length

            if (wouldDeleteAll) {
                toast.error("You must keep at least one strategy");
                return
            }

            const formData = new FormData()
            formData.append('goal_id', activeGoal?.id)
            formData.append('strategies_id', JSON.stringify(selectedStrategiesForDeletion));
            const res = await trigerDeleteStrategies({ requestBody: formData })

            setSelectedStrategiesForDeletion([]);
            setIsOpenModal(false);

            // Check the response body status instead of HTTP status
            if (res?.status === "success") {
                toast.success(res.data || 'department strategies delete successfully')
                mutate(apiList.admin.departmentStrategies.get_saved.key(id, strategicPlan))
            } else {
                toast.error(res?.data || 'Something went wrong')
            }
        } catch (error) {
            console.log("Error", error)
            toast.error('An error occurred while deleting strategies')
        }
    }

    const handleStrategySelection = (index, isChecked) => {

        const allStrategies = activeGoal.strategies.filter(s => s?.text?.trim())
        const currentlySelectCount = selectedStrategiesForDeletion.length


        if (isChecked && currentlySelectCount >= allStrategies.length - 1) {
            toast.error("You must keep at least one strategy");
            return
        }

        setSelectedStrategiesForDeletion(prev =>
            isChecked
                ? [...prev, index]
                : prev.filter(i => i !== index)
        );

    };


    return (
        <>
            <ConfirmationModal isOpen={isOpen} onClose={handleModalClose} onConfirm={deleteStrategies} />

            {showTabChangeModal && (
                <UnsavedChangesModal
                    isConfirmNavigation={handleConfirmTabChange}
                    isCancelNavigation={cancelTabChange}
                />
            )}

            {showRouteChangeModal && (
                <UnsavedChangesModal
                    isConfirmNavigation={handleConfirmTabChange}
                    isCancelNavigation={cancelNavigation}
                />
            )}

            <StrategicFormModal
                isOpen={isModalOpen}
                onClose={handleModalClose}
                strategyIdEntry={stratIdEntry}
                isFormExist={isSelectedFormExist}
                isStrategicFormExist={isSelectedStrategicFormExist}
                mutateKey={handleMutate}
                strategyText={strategyText}
            />

            <AiHelpGoalsAndStrategiesDrawer
                drawerState={drawerOpen}
                setDrawerState={setDrawerOpen}
                title={
                    <span className="font-semibold">
                        AI Help -{" "}
                        <span className="text-[#0098F5]">Create Goals & Strategies</span>
                    </span>
                }
                // getGoalsWithlimitNumber={getGoalsWithlimitNumber}
                onSaveGoals={handleSaveGoals}
                AIGoalData={fullAIResponse}
                // AIUsedCount={AIUsedCount}
                AILoading={AILoading}
                selectedGoal={selectedGoal}
                setSelectedGoal={setSelectedGoal}
                handleIsDirty={handleIsDirty}
            />
            <AIHelpStrategiesDrawer
                drawerState={strategieDrawerOpen}
                setDrawerState={setStrategieDrawerOpen}
                title={
                    <span className="font-semibold">
                        AI Help - <span className="text-[#0098F5]">Create Strategies</span>
                    </span>
                }
                onSaveStrategies={handleSaveStrategies}
                AIStrategiesData={fullAIStrategies}
                AILoading={AIStrategiesLoading}
                selectedStrategies={selectedStrategies}
                setSelectedStrategies={setSelectedStrategies}
                handleIsDirty={handleIsDirty}
            />
            <div>
                <div className="flex flex-col gap-3">

                    {activeGoal.strategies?.map(
                        (strategy, index) =>

                            strategy?.text &&
                            strategy?.text?.trim() !== "" && (
                                <div key={strategy.id}>
                                    <div className="flex justify-between">
                                        <label className="text-sm text-gray-600">
                                            Strategy {index + 1}
                                        </label>

                                        <PermissionWrapper
                                            resource={"dept_strategy_form"}
                                            actions={["has_access"]}
                                        >
                                            {strategy?.id &&
                                                strategy?.text &&
                                                // strategic_binder_editing_list
                                                hasPlanPermission("strategic_form") && (
                                                    <label
                                                        onClick={() =>
                                                            navigate(`/departments/${id}/goals_and_strategies_list/${strategy?.id}/strategic-monitor-list`)
                                                        }
                                                        className="flex text-sm mt-1 text-[#0098F5]  cursor-pointer  gap-4 "
                                                    >
                                                        <span className="flex items-center hover:underline">
                                                            Monitor
                                                        </span>


                                                    </label>
                                                )}
                                        </PermissionWrapper>
                                    </div>
                                    <Card
                                        bordered
                                        shadow="none"
                                        radius="sm"
                                        className="p-2 bg-[#F4F7FA] border text-start border-[#E2E9F0]"
                                    >
                                        {strategy.text}
                                    </Card>
                                </div>
                            )
                    )}
                </div>
            </div>
        </>
    );
}

export default StrategicList;

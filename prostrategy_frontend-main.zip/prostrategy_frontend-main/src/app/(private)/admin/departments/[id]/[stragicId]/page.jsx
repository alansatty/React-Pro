import { useEffect, useRef, useState, useCallback } from "react";
import usePermissionsStore from "../../../../../../stores/usePermissionStore";
import { useNavigate, useParams } from "react-router-dom";
import { apiList } from "../../../../../../services";
import PlaygroundApp from "../../../Binder/App";
import GoalsCheckBoxDept from "./_components/GoalsCheckBoxDept";
import TableContentListDept from "./_components/TableContentListDept";
import GoalsAndStrategySaveDept from "./_components/GoalsAndStrategySaveDept";
import useApi from "../../../../../../hooks/useApi";
import { LexicalComposer } from "@lexical/react/LexicalComposer";
import { TableContext } from "../../../Binder/plugins/TablePlugin";
import { SharedHistoryContext } from "../../../Binder/context/SharedHistoryContext";
import { ToolbarContext } from "../../../Binder/context/ToolbarContext";
import { useSettings } from "../../../Binder/context/SettingsContext";
import { $isTextNode, TextNode } from "lexical";
import { parseAllowedFontSize } from "../../../Binder/plugins/ToolbarPlugin/fontSize";
import { parseAllowedColor } from "../../../Binder/ui/ColorPicker";
import PlaygroundNodes from "../../../Binder/nodes/PlaygroundNodes";
import { UppercaseNode } from "../../../Binder/nodes/customNode/UppercaseNode";
import PlaygroundEditorTheme from "../../../Binder/themes/PlaygroundEditorTheme";
import { PageSpinner } from "../../../../../../components";
import useInactivityTimer from "../../../../../../hooks/useInactivityTimer";
import useTopbarStore from "../../../../../../stores/torbarStore";
import toast from "react-hot-toast";
import Pusher from "pusher-js";
import { useAuth } from "../../../../../../providers/authProviders";
import useBinderUnsavedChanges from "../../../../../../hooks/useBinderUnsavedChanges";

//     org_goal_alignment: {
//         Goal1: {
//             org_goal_id: "905fbedf-e67e-4cd6-8955-d25e37e2cf79",
//             goal: "Goal 1",
//             is_checked: true
//         },
//         Goal2: {
//             org_goal_id: "a2c7eb85-f7a4-46ca-a8bd-40d43640e19f",
//             goal: "this is the second goal",
//             is_checked: true
//         },
//         Goal3: {
//             org_goal_id: "b101e7c1-951f-4651-8151-bab1aae6bb26",
//             goal: "This is the third goal",
//             is_checked: false
//         }
//     },
//     is_another_user_editing: false,
//     strategy_binder_id: "b35105c0-67b9-4ce7-83ed-af9e47b8dab5",
//     department_strategy_id: "002a5abf-86ad-4f89-b1ac-abed26575720",
//     is_allow_edit: true,
// };

function getExtraStyles(element) {
    let extraStyles = "";
    const fontSize = parseAllowedFontSize(element.style.fontSize);
    const backgroundColor = parseAllowedColor(element.style.backgroundColor);
    const color = parseAllowedColor(element.style.color);
    if (fontSize !== "" && fontSize !== "15px") {
        extraStyles += `font-size: ${fontSize};`;
    }
    if (backgroundColor !== "" && backgroundColor !== "rgb(255, 255, 255)") {
        extraStyles += `background-color: ${backgroundColor};`;
    }
    if (color !== "" && color !== "rgb(0, 0, 0)") {
        extraStyles += `color: ${color};`;
    }
    return extraStyles;
}

function buildImportMap() {
    const importMap = {};
    for (const [tag, fn] of Object.entries(TextNode.importDOM() || {})) {
        importMap[tag] = (importNode) => {
            const importer = fn(importNode);
            if (!importer) return null;
            return {
                ...importer,
                conversion: (element) => {
                    const output = importer.conversion(element);
                    if (output === null || output.forChild === undefined || output.after !== undefined || output.node !== null) {
                        return output;
                    }
                    const extraStyles = getExtraStyles(element);
                    if (extraStyles) {
                        const { forChild } = output;
                        return {
                            ...output,
                            forChild: (child, parent) => {
                                const textNode = forChild(child, parent);
                                if ($isTextNode(textNode)) {
                                    textNode.setStyle(textNode.getStyle() + extraStyles);
                                }
                                return textNode;
                            },
                        };
                    }
                    return output;
                },
            };
        };
    }
    return importMap;
}

const DepartmentStrategicReport = () => {
    const navigate = useNavigate()
    const saveComponentRef = useRef();
    const [isUserMadeChange, setIsUserMadeChange] = useState(false);
    const [activeItem, setActiveItem] = useState(null);
    const [activeEditor, setActiveEditorParent] = useState(null);
    const [isGoalExist, setIsGoalExist] = useState(false);
    const [checkedData, setCheckedData] = useState(null);
    const [primaryData, setPrimaryData] = useState('')
    const [typingCount, setTypingCount] = useState(0);
    const [isInitialized, setIsInitialized] = useState(false);
    const [isSaved, setIsSaved] = useState(false)
    const [takedCustomInput, setTakeCustomInput] = useState('')
    const [inputError, setInputError] = useState(false);
    const { id, strategicId } = useParams();

    const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
    const oldStrategicId = localStorage.getItem("oldstrategicPlan")

    useEffect(() => {

        if ((strategicPlan && oldStrategicId) && strategicPlan !== oldStrategicId) {
            localStorage.removeItem('oldstrategicPlan');
            toast.error("The strategic plan selection has been changed. Redirecting to goals and strategies...");
            navigate(`/departments/${id}/goals_and_strategies_tab`);
        }
    }, [strategicPlan, oldStrategicId, navigate, id]);

    const { data, isLoading } = useApi(
        strategicPlan ? apiList.admin.departments.strategicReportPlanning.key(strategicPlan, id, strategicId) : null,
        strategicPlan ? apiList.admin.departments.strategicReportPlanning.call(strategicPlan, id, strategicId) : null,
    );

    // checking box data here
    const { data: reportPlanningData, isLoading: loading } = useApi(
        strategicPlan &&
            data?.strategic_binder_id && activeItem?.slug ?
            apiList.admin.binder_template.get.key(data?.strategic_binder_id, activeItem?.slug)
            : null,
        strategicPlan && data?.strategic_binder_id && activeItem?.slug ?
            apiList.admin.binder_template.get.call(data?.strategic_binder_id, activeItem?.slug)
            : null
    )

    const { subtitle, setSubtitle } = useTopbarStore();
    useEffect(() => {
        setSubtitle(data?.department_name || "");
    }, [data]);



    const handlingIsGoal = useCallback((isGoal) => {
        setIsGoalExist(isGoal);
    }, []);

    const handleAutoSave = useCallback(async () => {
        if (saveComponentRef.current) {
            try {
                setIsUserMadeChange(false)
                await new Promise(resolve => setTimeout(resolve, 100))
                await saveComponentRef.current.handleSave(true);
                navigate('/strategic_report');
            } catch (error) {
                console.error("Auto-save failed:", error);
            }
        }
    }, [navigate]);

    useInactivityTimer(handleAutoSave, 600000, 300000);

    const { settings: { isCollab, emptyEditor } } = useSettings();

    const initialConfig = {
        editorState: isCollab ? null : emptyEditor ? null : null,
        html: { import: buildImportMap() },
        namespace: "Playground",
        nodes: [...PlaygroundNodes, UppercaseNode],
        onError: (error) => { throw error; },
        theme: PlaygroundEditorTheme,
    };

    useEffect(() => {
        const pusher = new Pusher(import.meta.env.VITE_PUSHER_ENV, {
            cluster: "mt1",
        })

        if (data?.strategic_binder_id) {

            const channel = pusher.subscribe(data?.strategic_binder_id)

            channel.bind('kicked-out', (data) => {
                setIsUserMadeChange(false);

                setTimeout(() => {
                    navigate(`/departments/${id}/goals_and_strategies_tab`);
                }, 100);
                toast.error(data.message, {
                    duration: 5000,
                });
            });

            return () => {
                channel.unbind_all()
                channel.unsubscribe();
                pusher.disconnect();
            };
        }

    }, [data?.strategic_binder_id])

    // Initialize component state when data loads
    useEffect(() => {
        if (data && !isInitialized) {
            const firstSection = Object.values(data)[0];
            if (Array.isArray(firstSection) && firstSection.length > 0) {
                const initialItem = firstSection[0];
                setActiveItem(initialItem);
                setIsGoalExist(initialItem.is_goal || false);
            }
            setIsInitialized(true);
        }
    }, [data, isInitialized]);

    if (isLoading) {
        return (<PageSpinner />);
    }


    return (
        <LexicalComposer initialConfig={initialConfig}>
            <SharedHistoryContext>
                <TableContext>
                    <ToolbarContext>
                        <div className="flex flex-col h-full">
                            <GoalsAndStrategySaveDept
                                id={id}
                                reportPlanningData={reportPlanningData}
                                goal={data?.goal}
                                strategyText={data?.strategy}
                                isNotEditor={isGoalExist}
                                activeEditor={activeEditor}
                                setActiveEditorParent={setActiveEditorParent}
                                setIsUserMadeChange={setIsUserMadeChange}
                                activeItem={activeItem}
                                checkedData={checkedData}
                                primaryData={primaryData}
                                customInput={takedCustomInput}
                                ref={saveComponentRef}
                                setTypingCount={setTypingCount}
                                setIsSaved={setIsSaved}
                                strategicBinderId={data?.strategic_binder_id}
                                inputError={inputError}
                                setInputError={setInputError}
                            />
                            <div className="flex flex-1 gap-3">
                                <div className="w-[30%] border-gray-200">
                                    <TableContentListDept
                                        listData={data}
                                        setTypingCount={setTypingCount}
                                        handlingIsGoal={handlingIsGoal}
                                        isUserMadeChange={isUserMadeChange}
                                        setIsUserMadeChange={setIsUserMadeChange}
                                        setActiveItem={setActiveItem}
                                        strategicBinderId={data?.strategic_binder_id}
                                        activeItem={activeItem}
                                        handleSave={async () => {
                                            if (saveComponentRef.current) {
                                                const success = await saveComponentRef.current.handleSave();
                                                return success

                                            }
                                        }}
                                        isSaved={isSaved}
                                        setIsSaved={setIsSaved}

                                    />
                                </div>
                                <div className="w-[70%] h-full bg-white">
                                    {isGoalExist ? (
                                        <GoalsCheckBoxDept
                                            reportPlanningData={reportPlanningData}
                                            handlingSetUserMadeChange={setIsUserMadeChange}
                                            setCheckedData={setCheckedData}
                                            setPrimaryData={setPrimaryData}
                                            primaryData={primaryData}
                                            typingCount={typingCount}
                                            setTypingCount={setTypingCount}
                                            strategicBinderId={data?.strategic_binder_id}
                                            activeItem={activeItem}
                                            isLaoding={loading}
                                            takeCustomInput={setTakeCustomInput}
                                            takedCustomInput={takedCustomInput}
                                            setInputError={setInputError}
                                            inputError={inputError}
                                        />
                                    ) : (
                                        <PlaygroundApp
                                            reportPlanningData={reportPlanningData}
                                            isLaoding={loading}
                                            activeEditor={activeEditor}
                                            setActiveEditorParent={setActiveEditorParent}
                                            isUserMadeChange={isUserMadeChange}
                                            handlingSetUserMadeChange={setIsUserMadeChange}
                                            strategicBinderId={data?.strategic_binder_id}
                                            activeItem={activeItem}
                                            typingCount={typingCount}
                                            setTypingCount={setTypingCount}
                                        />
                                    )}
                                </div>
                            </div>
                        </div>
                    </ToolbarContext>
                </TableContext>
            </SharedHistoryContext>
        </LexicalComposer>
    );
};

export default DepartmentStrategicReport;
import { Card, CardBody } from "@nextui-org/card";
import { Tab, Tabs } from "@nextui-org/tabs";
import DashboardIcon from "../../../../../assets/icons/Sva-DashIcon";
import DeptGoalsIcon from "../../../../../assets/icons/deptGoals-icon";
import FileSearchIcon from "../../../../../assets/icons/FileSearchIcon";
import SwotIcon from "../../../../../assets/icons/SwotIcon";
import SvaForm from "./_components/SvaForm";
import SvaDashboard from "./_components/SvaDashboard";
import useTopbarStore from "../../../../../stores/torbarStore";
import { useNavigate, useParams } from "react-router-dom";
import { useEffect, useRef, useState } from "react";
import { apiList } from "../../../../../services";
import useApi from "../../../../../hooks/useApi";
import hasPlanPermission from "../../../../../utils/hasPlanPermission";
import AnalysisIcon from "../../../../../assets/icons/analysis-icon";
import SwotFormTab from "./_components/SwotFormTab";
import SwotAnalysisTab from "./_components/swotAnalysisTab";
import hasPermission from "../../../../../utils/hasPermission";
import GoalsAndStrategiesTab from "./_components/GoalsAndStrategiesTab";
import GoalsAndStrategiesIcon from "../../../../../assets/icons/goalsAndStrategies-icon";
import usePermissionsStore from "../../../../../stores/usePermissionStore";
import { PageSpinner } from "../../../../../components";
import DepartmentMission from "./_components/DepartmentGoals/DepartmentMission";
import DepartmentVision from "./_components/DepartmentGoals/DepartmentVision";
import DepartmentValue from "./_components/DepartmentGoals/DepartmentValue";
import DepartmentSustainingObjective from "./_components/DepartmentGoals/DepartmentSustainingObjective";
import useUnsavedChanges from "../../../../../hooks/useUnsavedChanges";
import MissionIcon from "../../../../../assets/icons/mission-icon";
import VisionIcon from "../../../../../assets/icons/vision-icon";
import ValueIcon from "../../../../../assets/icons/value-icon";
import SustainIcon from "../../../../../assets/icons/sustain-icon";
import DepartmentReportTab from "./_components/DepartmentReportTab";
// import EditorPreview from "../../StrategicReport/components/EditorPreview";
import Goals from "../../../../../assets/icons/Goals";
import departmentReportIcon from "../../../../../assets/icons/departmentReportIcon";
import GoalsStrategiesList from "./_components/GoalsStrategiesList";

function CreateTitle({ title, Icon }) {
  return (
    <div className="flex items-center space-x-2">
      <Icon />
      <span>{title}</span>
    </div>
  );
}
function DepartmentDetailes() {
  const navigate = useNavigate();
  const { tabId, id } = useParams();
  const [formIsDirty, setFormIsDirty] = useState(false);
  const [pendingNavigation, setPendingNavigation] = useState(false);
  const [tabs, setTabs] = useState(null);
  const tabRefs = useRef({});


  const { data, isLoading, error } = useApi(
    apiList.admin.departments.detail.key(id),
    apiList.admin.departments.detail.call(id)
  );

  const { subtitle, setSubtitle } = useTopbarStore();

  useEffect(() => {
    setSubtitle(data?.data?.department_name || "");
  }, [data]);


  const PlanPermissions = usePermissionsStore((state) => state.planPermissions);

  const handleNavigationConfirm = (shouldNavigate) => {
    if (shouldNavigate) {
      setFormIsDirty(false);
    }
    setPendingNavigation(false);
  };


  useEffect(() => {
    if (PlanPermissions && !tabs) {
      setTabs([
        ...(hasPlanPermission("mission_vision_value") ||
          hasPlanPermission("sustainable_objectives")
          ? [
            {
              id: "mission",
              label: (
                <CreateTitle title="Mission " Icon={MissionIcon} />
              ),
              content: <DepartmentMission />,
            },
            {
              id: "Vision",
              label: (
                <CreateTitle title="Vision " Icon={VisionIcon} />
              ),
              content: <DepartmentVision />,
            },
            {
              id: "Value",
              label: (
                <CreateTitle title="Value " Icon={ValueIcon} />
              ),
              content: <DepartmentValue />,
            },

            {
              id: "sustaining_objective",
              label: (
                <CreateTitle title="Department Pillars " Icon={SustainIcon} />
              ),
              content: <DepartmentSustainingObjective />,
            },
          ]
          : []),
        {
          id: "svaform",
          label: <CreateTitle title="SVA Form" Icon={FileSearchIcon} />,
          content: <SvaForm />,
        },
        ...(hasPlanPermission("sva_dashboard_allowed")
          ? [
            {
              id: "sva_dashboard",
              label: (
                <CreateTitle title="SVA Dashboard" Icon={DashboardIcon} />
              ),
              content: <SvaDashboard />,
            },
          ]
          : []),

        {
          id: "swot_tab",
          label: <CreateTitle title="SWOT Form" Icon={SwotIcon} />,
          content: <SwotFormTab />,
        },

        ...(hasPlanPermission("swot_analysis")
          ? [
            {
              id: "analysis_tab",
              label: (
                <CreateTitle title="SWOT Dashboard" Icon={AnalysisIcon} />
              ),
              content: <SwotAnalysisTab />,
            },
          ]
          : []),

        ...(hasPlanPermission("goal_strategic")
          ? [
            {
              id: "goals_and_strategies_tab",
              label: (
                <CreateTitle
                  title="Goals & Strategies"
                  Icon={Goals}
                />
              ),
              content: <GoalsAndStrategiesTab />,
            },
          ]
          : []),
        // ...(hasPlanPermission("goal_strategic")
        //   ? [
        //     {
        //       id: "goals_and_strategies_list",
        //       label: (
        //         <CreateTitle
        //           title="Goals & Strategies"
        //           Icon={Goals}
        //         />
        //       ),
        //       content: <GoalsStrategiesList />,
        //     },
        //   ]
        //   : []),

        ...(hasPlanPermission("goal_strategic")
          ? [
            {
              id: "department_report_tab",
              label: (
                <CreateTitle
                  title="Department Report"
                  Icon={departmentReportIcon}
                />
              ),
              content: <DepartmentReportTab />,
            },
          ]
          : []),

        // ...(hasPlanPermission("goal_strategic")
        // ? [
        //   {
        //     id: "preview_tab",
        //     label: (
        //       <CreateTitle
        //         title="Editor Preview"
        //         Icon={GoalsAndStrategiesIcon}
        //       />
        //     ),
        //     content: <EditorPreview />,
        //   },
        // ]
        // : []),
      ]);
    }
  }, [PlanPermissions]);

  // useEffect(() => {
  //   // If no tab is selected in the URL, default to "Sent"
  //   if (!tabId) {
  //     navigate(`/departments/${id}/${tabId}`); // Redirect to default tab
  //   }
  // }, [tabId, navigate]);

  useEffect(() => {
    if (!tabId && tabs?.length > 0) {
      navigate(`/departments/${id}/${tabId}`);
    }
  }, [tabId, navigate, tabs]);


  useEffect(() => {
    if (tabId && tabRefs.current[tabId]) {
      tabRefs.current[tabId].scrollIntoView({
        behavior: "smooth",
        inline: "center",
        block: "nearest",
      });
    }
  }, [tabId]);

  if (!tabs) {
    return <PageSpinner />;
  }

  return (
    <Card shadow="sm" radius="md">
      <CardBody>
        <h2 className="font-semibold mb-3 mt-3 capitalize">
          {subtitle} - Department{" "}
        </h2>
        <div className="flex w-full flex-col">
          <Tabs
            // disabledKeys={["swat_analysis"]}
            key={tabId}
            selectedKey={tabId}
            aria-label="Dynamic tabs"
            color="primary"
            items={tabs}
            size="md"
            radius="sm"
            variant="underlined"
            classNames={{
              tabList:
                "gap-8 w-full  relative rounded-none p-0 border-b border-divider",
              cursor: "w-full bg-[#0098F5]",
              tab: "max-w-fit px-0 h-12",
              tabContent: "group-data-[selected=true]:text-[#0098F5]",
            }}
            onSelectionChange={(key) => {

              // if (selectedItem) setSelectedItem(null)
              navigate(`/departments/${id}/${key}`);
              setTimeout(() => {
                tabRefs.current[key]?.scrollIntoView({
                  behavior: "smooth",
                  inline: "center",
                  block: "nearest",
                });
              }, 0);
            }}
          >
            {(item) => (
              <Tab
                key={item.id}
                title={
                  <div ref={(el) => (tabRefs.current[item.id] = el)}>
                    {item.label}
                  </div>
                }>
                <Card shadow="none" radius="sm">
                  <CardBody>{item.content}</CardBody>
                </Card>
              </Tab>
            )}
          </Tabs>
        </div>
      </CardBody>
    </Card>
  );
}

export default DepartmentDetailes;

import { useEffect, useState } from "react";
import { apiList } from "../../../../../../../services";
import useApi from "../../../../../../../hooks/useApi";
import toast from "react-hot-toast";
import { useParams } from "react-router-dom";
import DepartmentSustainComponent from "./DepartmentSustainComponent";
import { Spinner } from "@nextui-org/spinner";
import hasPermission from "../../../../../../../utils/hasPermission";
import DepartmentSustainOptions from "./DepartmentSustainOptions";
import { mutate } from "swr";
import usePermissionsStore from "../../../../../../../stores/usePermissionStore";

function DepartmentSustainingObjective() {
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan) || "";
  const [selectedValues, setSelectedValues] = useState([]);
  const [currentStep, setCurrentStep] = useState(1);
  const [activeItem, setActiveItem] = useState(null);
  const [objectives, setObjectives] = useState({});
  const [options, setOptions] = useState([]);
  const [loading, setLoading] = useState(true);

  const { id } = useParams();

  const [dynamic_objective1, setDynamic_objective1] = useState({
    id: "",
    value: "",
  });

  const [dynamic_objective2, setDynamic_objective2] = useState({
    id: "",
    value: "",
  });

  const [dynamic_objective3, setDynamic_objective3] = useState({
    id: "",
    value: "",
  });


  const [dynamic_objective4, setDynamic_objective4] = useState({
    id: "",
    value: "",
  });

  const [customLoading, setCustomLoading] = useState(false)



  const { data: SustainingOptions, isLoading: isLoadingOptons } = useApi(
    apiList.admin.departments.sutaining_options.key(strategicPlan, id),
    strategicPlan ? apiList.admin.departments.sutaining_options.call(strategicPlan, id) : null
  );

  const { data: SavedSustainingOptions, isLoading: isLoadingSavedOptions } =
    useApi(
      apiList.admin.departments.saved_sutaining_options.key(id),
      apiList.admin.departments.saved_sutaining_options.call(id, strategicPlan)
    );

  const { data: SustainingDetails, isLoading: isLoadingDetails } = useApi(
    apiList.admin.departments.sustaining_objective_details,
    apiList.admin.departments.sustaining_objective_details.call(id, strategicPlan)
  );

  const { trigger, isMutating } = useApi(
    null,
    apiList.admin.departments.update_sustaining_options.call(id),
    { method: "POST" }
  );

  useEffect(() => {
    if (SustainingOptions?.data && SustainingOptions?.data.length > 0) {
      const mappedOptions = SustainingOptions.data.map((optionObj) => {
        const [id, name] = Object.entries(optionObj)[0];
        return { id, name };
      });
      setOptions(mappedOptions);
    }
  }, [SustainingOptions]);

  useEffect(() => {
    if (!isLoadingSavedOptions) {
      setLoading(false);
    }
  }, [isLoadingSavedOptions]);

  useEffect(() => {
    if (
      SavedSustainingOptions?.data &&
      SavedSustainingOptions?.data.length > 0
    ) {
      const parsedSavedOptions = SavedSustainingOptions.data.map((savedObj) => {
        const [id, name] = Object.entries(savedObj)[0];

        if (id === "dynamic_objective" && typeof name === "object") {
          Object.entries(name).map(([dynamicId, dynamicValue]) => {
            return { id: dynamicId, name: dynamicValue };
          });
        }

        return { id, name };
      });


      parsedSavedOptions.forEach((option) => {
        if (
          option.id === "dynamic_objective" &&
          typeof option.name === "object"
        ) {
          const dynamicEntries = Object.entries(option.name);

          // Set the first dynamic objective with id and value
          if (dynamicEntries[0]) {
            setDynamic_objective1({
              id: dynamicEntries[0][0], // Use the first entry's key as id
              value: dynamicEntries[0][1], // Use the first entry's value as value
            });
          } else {
            setDynamic_objective1({
              id: "", // Use the first entry's key as id
              value: "", // Use the first entry's value as value
            });
          }

          // Set the second dynamic objective with id and value
          if (dynamicEntries[1]) {
            setDynamic_objective2({
              id: dynamicEntries[1][0], // Use the second entry's key as id
              value: dynamicEntries[1][1], // Use the second entry's value as value
            });
          } else {
            setDynamic_objective2({ id: "", value: "" });
          }

          if (dynamicEntries[2]) {
            setDynamic_objective3({
              id: dynamicEntries[2][0], // Use the second entry's key as id
              value: dynamicEntries[2][1], // Use the second entry's value as value
            });
          } else {
            setDynamic_objective3({ id: "", value: "" });
          }

          if (dynamicEntries[3]) {
            setDynamic_objective4({
              id: dynamicEntries[3][0], // Use the second entry's key as id
              value: dynamicEntries[3][1], // Use the second entry's value as value
            });
          } else {
            setDynamic_objective4({ id: "", value: "" });
          }
        }
      });

      setActiveItem(parsedSavedOptions[0]);
      setSelectedValues(parsedSavedOptions);
      setCurrentStep(2);
    } else {
      setCurrentStep(1)
      setActiveItem(null);
      setSelectedValues([]);
      setDynamic_objective1({ id: "", value: "" });
      setDynamic_objective2({ id: "", value: "" });
      setDynamic_objective3({ id: "", value: "" });
      setDynamic_objective4({ id: "", value: "" });
    }
  }, [SavedSustainingOptions]);

  const mutateFn = async () => {
    setCustomLoading(true)
    await mutate(
      apiList.admin.departments.saved_sutaining_options.key(id),
    );
    setCustomLoading(false)
  }

  useEffect(() => {
    mutateFn()
  }, [strategicPlan]);


  const handleCheckboxChange = (values) => {

    const selectedOptions = options.filter((option) =>
      values.includes(option.id)
    );
    setSelectedValues(selectedOptions);

    if (!selectedOptions.find((option) => option.id === activeItem?.id)) {
      setActiveItem(null);
    }
  };

  const handleNext = async () => {
    const filteredSelectedValues = selectedValues.filter(
      (objective) => objective.id !== "dynamic_objective"
    );

    const totalSelectedCount =
      filteredSelectedValues.length +
      (dynamic_objective1.value.trim().length !== 0 ? 1 : 0) +
      (dynamic_objective2.value.trim().length !== 0 ? 1 : 0) +
      (dynamic_objective3.value.trim().length !== 0 ? 1 : 0) +
      (dynamic_objective4.value.trim().length !== 0 ? 1 : 0);
    // Check if the total count meets the range condition (5 to 9)
    if (totalSelectedCount >= 5 && totalSelectedCount <= 9) {
      try {
        // const data = selectedValues.reduce((acc, item, index) => {
        //   acc[`sus_objectives[${index}]`] = item.id;
        //   return acc;
        // }, {});

        const data = selectedValues
          .filter((option) => option.id !== "dynamic_objective")
          .map((item) => item.id);

        let res = await trigger({
          requestBody: {
            sus_objectives: data,
            strategic_plan_id: strategicPlan,
            dynamic_objective1:
              dynamic_objective1.value.trim().length !== 0
                ? dynamic_objective1.value
                : "",
            dynamic_objective2:
              dynamic_objective2.value.trim().length !== 0
                ? dynamic_objective2.value
                : "",
            dynamic_objective3:
              dynamic_objective3.value.trim().length !== 0
                ? dynamic_objective3.value
                : "",
            dynamic_objective4:
              dynamic_objective4.value.trim().length !== 0
                ? dynamic_objective4.value
                : "",
          },
        });
        setCurrentStep(2);
        setActiveItem(selectedValues[0]);

        mutate(apiList.admin.departments.saved_sutaining_options.key(id));
      } catch (error) {
        console.error(error);
        toast.error("Something Went Wrong. Please Try Again.");
      }
    } else {
      toast.error(
        "Please select a total of 5 to 9 values, including dynamic pillars."
      );
    }
  };

  const handlePrevious = () => {
    setCurrentStep(1);
  };

  const handleSave = (newObjectives) => {
    setObjectives(newObjectives);
  };
  const activeDetails = SustainingDetails?.data?.find(
    (detail) => detail.id === activeItem?.id
  );

  if (isLoadingDetails || isLoadingOptons || isLoadingSavedOptions || loading || customLoading) {
    return (
      <div className="flex items-center justify-center h-full w-full">
        <Spinner size="md" />
      </div>
    );
  }

  if (
    !hasPermission("dept_sustaining_objectives", "read_only") &&
    !hasPermission("dept_sustaining_objectives", "edit")
  ) {
    return <div>Department Pillars Not Available for the Department</div>;
  }

  if (
    hasPermission("dept_sustaining_objectives", "read_only") &&
    !hasPermission("dept_sustaining_objectives", "edit")
  ) {
    if (SustainingDetails?.data.length == 0) {
      return <div>Department Pillars Not Available for the Department</div>;
    }
  }

  return (
    <div className=" grid grid-cols-3 gap-4">
      {currentStep === 1 && (
        <DepartmentSustainOptions
          options={options}
          selectedValues={selectedValues}
          handleCheckboxChange={handleCheckboxChange}
          handleNext={handleNext}
          isMutating={isMutating}
          dynamic_objective1={dynamic_objective1}
          dynamic_objective2={dynamic_objective2}
          dynamic_objective3={dynamic_objective3}
          dynamic_objective4={dynamic_objective4}
          setDynamic_objective1={setDynamic_objective1}
          setDynamic_objective2={setDynamic_objective2}
          setDynamic_objective3={setDynamic_objective3}
          setDynamic_objective4={setDynamic_objective4}
        />
      )}

      {currentStep === 2 && (
        <DepartmentSustainComponent
          selectedValues={selectedValues}
          activeItem={activeItem}
          details={activeDetails}
          setActiveItem={setActiveItem}
          objectives={objectives}
          handleSaveLocal={handleSave}
          handlePrevious={handlePrevious}
          loadingState={isLoadingDetails}
        />
      )}
    </div>
  );
}

export default DepartmentSustainingObjective;

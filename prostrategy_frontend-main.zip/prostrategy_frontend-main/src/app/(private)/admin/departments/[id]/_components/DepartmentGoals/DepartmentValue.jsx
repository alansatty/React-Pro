import React, { useEffect, useState } from "react";
import { Button } from "@nextui-org/button";
import AiHelpIcon from "../../../../../../../assets/icons/aihelp-icon";
import { Textarea } from "@nextui-org/input";
import { Radio, RadioGroup } from "@nextui-org/radio";
import { Card } from "@nextui-org/card";
import toast from "react-hot-toast";
import { ValueSchema } from "../../../../../../../../validationSchema/authValidation";
import { useAuth } from "../../../../../../../providers/authProviders";
import { apiList } from "../../../../../../../services";
import useApi from "../../../../../../../hooks/useApi";
import Swal from "sweetalert2";
import { IconInfoCircle } from "@tabler/icons-react";
import { useNavigate, useParams } from "react-router-dom";
import DepartmentAiHelpDrawer from "./DapartmentAiHelpDrawer";
import useTopbarStore from "../../../../../../../stores/torbarStore";
import { PageSpinner } from "../../../../../../../components";
import { mutate } from "swr";
import { PermissionWrapper } from "../../../../../../../components";
import hasPermission from "../../../../../../../utils/hasPermission";
import HelpModal from "../../../../../../../components/Topbar/HelpModal";
import {
  DepartmentValueHelp,
} from "../../../../../../../components/Topbar/helpComponents/Helps";
import hasPlanPermission from "../../../../../../../utils/hasPlanPermission";
import usePermissionsStore from "../../../../../../../stores/usePermissionStore";
import CustomTooltip from "../../../../../../../components/CustomTooltip/CustomTooltip";
import withReactContent from "sweetalert2-react-content";
import ProstrategyLogo from "../../../../../../../assets/icons/ProstrategyLogo";
import useUnsavedChanges from "../../../../../../../hooks/useUnsavedChanges";
import UnsavedChangesModal from "../../../../../../../components/Alert/UnsavedChangesModal";
const MySwal = withReactContent(Swal);
function DepartmentValue() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [drawerStep, setDrawerStep] = useState(1);
  const [isOpen, setIsOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [isValueStatement, setIsValueStatement] = useState("");
  const [existingValue, setIsExistingValue] = useState("");
  const [fullBusinessEssentials, setFullBusinessEssentials] = useState([]); // Store business essentials data
  const [businessEssentialData, setBusinessEssentialData] = useState([]); // Store business essentials data
  const [value, setValue] = useState("");
  const [savedValue, setSavedValue] = useState("");
  const [valueError, setValueError] = useState(null); // Track validation errors for Value
  const [statements, setStatements] = useState([]);
  const [getMoreCount, setGetMoreCount] = useState(0);
  const [isEditable, setIsEditable] = useState(null);
  const [selectedBusinessEssentials, setSelectedBusinessEssentials] = useState(
    []
  );
  const [pendingNavigation, setPendingNavigation] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const { subtitle, setSubtitle } = useTopbarStore();
  const [customLoading, setCustomLoading] = useState(false)

  const [isDirty, setIsDirty] = useState(false)

  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);

  const handleNavigationConfirm = (shouldNavigate) => {
    if (shouldNavigate) {
      setIsDirty(false);
    }
    setPendingNavigation(false);
  };

  const { showModal,
    confirmNavigation,
    cancelNavigation } = useUnsavedChanges(isDirty, pendingNavigation, handleNavigationConfirm)



  const {
    data: currentPlanData,
    error,
    isLoading: currentPlanDataLoading,
  } = useApi(
    apiList.admin.subscription.current_plan.key(),
    apiList.admin.subscription.current_plan.call()
  );
  const toggleDrawer = () => {
    if (getMoreCount == 0) useBusinessEssentials();
    if (fullBusinessEssentials?.length > 0 || BELoading) {
      setIsOpen((prev) => !prev);
    } else {
      // toast.error("Please update the Settings to get AI Help.");
      MySwal.fire({
        // Combine warning messages and additional text
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>
            <h2 className="text-xl font-semibold">Warning!</h2>
            <p className="mt-2">Please update the Organization Profile to get AI Help.</p>
          </div>
        ),
        confirmButtonText: "Go to Settings",
        customClass: {
          confirmButton: "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
        },
      }).then((result) => {
        if (result.isConfirmed) {
          navigate("/settings/organization_tab"); // Navigate to the settings page
        }
      });

    }
  };

  const getBusinessEssentials = async () => {
    try {
      const bodyData = {
        department_goal: "value",
        // businessEssentialData: businessEssentialData,
      };

      let response = await businessEssentials({ requestBody: bodyData });
      setFullBusinessEssentials(response?.data);
    } catch (error) {
      console.log(error);
      // setIsOpen((prev) => !prev);
      // toast.error(error.data.message);
    } finally {
      // setIsLoading(false)
    }
  };

  const useBusinessEssentials = () => {
    // Only load if more data is available and count is less than 3

    if (
      getMoreCount < 2 &&
      fullBusinessEssentials?.length > businessEssentialData?.length
    ) {
      const nextDataStart = getMoreCount == 0 ? getMoreCount : 15;
      const nextDataEnd = getMoreCount == 0 ? 15 : 20;


      // Append the next 4 items to the business essentials data
      setBusinessEssentialData((prevData) => [
        ...prevData,
        ...fullBusinessEssentials.slice(nextDataStart, nextDataEnd),
      ]);

      // Increment the count for more data loading
      setGetMoreCount(getMoreCount + 1);
    }
  };

  const { data: Goals, isLoading: isLoadingGoals } = useApi(
    apiList.admin.departmentGoals.get_goals.key(id),
    apiList.admin.departmentGoals.get_goals.call(id, strategicPlan)
  );

  useEffect(() => {
    setValue(Goals?.data?.value);
    setSavedValue(Goals?.data?.value);
    getBusinessEssentials();
    if (Goals?.data?.value) {
      setEditMode(true);
    } else {
      setEditMode(false);
    }
  }, [Goals]);

  const mutateFn = async () => {
    setCustomLoading(true)
    await mutate(apiList.admin.departmentGoals.get_goals.key(id))
    setCustomLoading(false)
  }

  useEffect(() => {
    mutateFn()
  }, [strategicPlan]);


  const { trigger, isMutating } = useApi(
    null,
    apiList.admin.departmentGoals.create_value.call(),
    { method: "POST" }
  );

  const { trigger: businessEssentials, isMutating: BELoading } = useApi(
    null,
    apiList.admin.departmentGoals.business_essentials.call(id, strategicPlan),
    { method: "POST" }
  );

  useEffect(() => {
    if (!isLoadingGoals) {
      setIsLoading(false);
    }
    if (!BELoading) {
      if (getMoreCount == 0) useBusinessEssentials();
    }
  }, [isLoadingGoals, BELoading]);

  const auth = useAuth();

  // Real-time validation on input change
  const handleValueChange = async (e) => {
    const value = e.target.value;
    value ? setIsDirty(true) : setIsDirty(false)
    setValue(value);
    validateValue(value);
  };

  const validateValue = async (value) => {
    try {
      await ValueSchema.validate({ value: value });
      setValueError(null); // Clear errors if validation passes
    } catch (error) {
      setValueError(error.message); // Set validation error
    }
  };

  const handleIsDirty = (dirty) => {
    setIsDirty(dirty)
  }

  useEffect(() => {
    if (selectedBusinessEssentials?.length > 0) {
      setIsDirty(true)
    } else {
      setIsDirty(false)
    }
  }, [selectedBusinessEssentials])

  const onSubmit = async (e) => {
    e.preventDefault();

    // Validate the Value statement using Yup
    try {
      await ValueSchema.validate({ value });
      setValueError(""); // Clear errors if validation passes

      const bodyData = {
        content: value,
        department: id,
        strategic_plan_id: strategicPlan
      };

      let response = await trigger({ requestBody: bodyData });
      setIsDirty(false)
      // toast.success(response?.data);
      mutate(apiList.admin.departmentGoals.get_goals.key(id));

      MySwal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>
            <h2 className="text-xl font-semibold">Success!</h2>
            <p className="mt-2">{response?.data}</p>
          </div>
        ),
        // icon: 'success',
        // allowOutsideClick: false,
        confirmButtonText: "Okay",
        customClass: {
          confirmButton: "my-confirm-button",
        },
      });

      setEditMode(!editMode);
    } catch (error) {
      setValueError(error?.msg); // Set the validation error message
      if (!isValueStatement || !existingValue) {
        if (error?.msg) {
          toast.error(error?.msg);
        }
      }
      if (error?.data?.message) {
        toast.error(error?.data?.message);
      }
    }
  };

  const changeEditMode = () => {
    setIsExistingValue("yes");
    setIsValueStatement("yes");
    setEditMode(!editMode);
  };

  const renderContent = () => {
    if (
      !hasPermission("dept_value", "read_only") &&
      !hasPermission("dept_value", "edit")
    ) {
      return <div>Value Not Available for the Department</div>;
    }

    if (
      hasPermission("dept_value", "read_only") &&
      !hasPermission("dept_value", "edit")
    ) {
      if (!editMode) {
        return <div>Value Not Available for the Department</div>;
      }
    }

    if (isLoadingGoals || isMutating || isLoading || customLoading) {
      return <PageSpinner />;
    }
    if (editMode) {
      return (
        <div className={`my-2 mb-4 w-[80%]`}>
          <h5 className="text-gray-600 p-1">Value</h5>

          <Card
            bordered
            shadow="none"
            radius="md"
            className={`p-2 bg-[#F4F7FA] border text-start   border-[#E2E9F0]`}
          >
            {value}
          </Card>
          <PermissionWrapper resource={"dept_value"} actions={["edit"]}>
            <span
              className="mt-1 text-default-500 float-end cursor-pointer"
              onClick={changeEditMode}
            >
              Edit
            </span>
          </PermissionWrapper>
        </div>
      );
    }

    const handleFullStatementChange = (index, value) => {
      const updatedStatements = [...statements];
      updatedStatements[index] = value;
      setStatements(updatedStatements);
    };

    // Runs whenever 'isEditable' changes

    return (
      <div>

        {/* Modal for Route Changes */}
        {showModal && (
          <UnsavedChangesModal
            isConfirmNavigation={confirmNavigation}
            isCancelNavigation={cancelNavigation}
          />
        )}
        <form onSubmit={onSubmit} noValidate>
          <div className="flex gap-2   p-1 px-2 w-fit mb-5">
            <span>
              <IconInfoCircle />
            </span>
            <p>
              The "Department Goals" section, specifically under the Value tab
              in ProStrategy.ai, helps you manage your Department's value
              statement. Here's how to interact with this form
              <HelpModal
                title={"Department Goals Value Help"}
                ContentComponent={DepartmentValueHelp}
                isReadMore={true}
              />
            </p>
            <PermissionWrapper resource={"dept_value"} actions={["edit"]}>
              <Button
                type="submit"
                radius="sm"
                color="primary"
                className="min-w-fit bg-[#0098F5]"
                isLoading={isMutating}
              >
                Save Changes
              </Button>
            </PermissionWrapper>
          </div>
          <div>
            <p className="mb-6">
              Does the {subtitle} department currently have a value statement?
            </p>
            <RadioGroup
              className="mb-5"
              orientation="horizontal"
              value={isValueStatement}
              onValueChange={(value) => {
                setIsValueStatement(value);
                if (value == "no") {
                  setValue("");
                }
                if (existingValue === "yes" && value == "yes" && savedValue) {
                  setValue(savedValue);
                  validateValue(savedValue);
                }
              }}
            >
              <Radio value="yes">Yes</Radio>
              <Radio value="no">No</Radio>
            </RadioGroup>
          </div>

          {isValueStatement === "yes" && (
            <div>
              <p className="mb-6">
                Do you want to continue with the existing value or create a new
                one?
              </p>
              <RadioGroup
                className="mb-5"
                orientation="horizontal"
                value={existingValue}
                onValueChange={(value) => {
                  setIsExistingValue(value);
                  if (value == "no") {
                    setValue("");
                    if (hasPlanPermission("department_base_goals_with_pillars_ai")) {
                      toggleDrawer();
                    } else {
                      toast.error("Your current plan has limited features. Upgrade now to access more!");
                    }
                  }
                  if (
                    isValueStatement === "yes" &&
                    value == "yes" &&
                    savedValue
                  ) {
                    setValue(savedValue);
                    validateValue(savedValue);
                  }
                }}
              >
                <Radio value="yes">Use Existing One</Radio>
                <Radio value="no">
                  Use AI to help create new value statement
                </Radio>
              </RadioGroup>
            </div>
          )}

          {(existingValue === "no" || isValueStatement === "no") && (
            <div className="flex gap-2 items-center text-sm bg-slate-200 rounded-[8px] p-1 px-2 w-fit">
              <IconInfoCircle className="mb-[1px] h-5 w-5" />
              Click the{`"AI Help"`} button on the right side to generate a
              value statement using AI or type manually.
            </div>
          )}

          {(isValueStatement === "no" ||
            existingValue === "no" ||
            existingValue === "yes") && (
              <div>
                <Textarea
                  label={
                    <div className="flex items-end justify-between mt-2">
                      <label htmlFor="valueStatement">
                        Value Statement{" "}
                        <span className="text-red-600 text-base ml-1">*</span>
                      </label>
                      {(existingValue === "no" || isValueStatement === "no") &&
                        (hasPlanPermission("department_base_goals_with_pillars_ai") ? (
                          <Button
                            radius="sm"
                            color="primary"
                            className="mt-0 bg-[#39465F]"
                            onClick={toggleDrawer}
                          >
                            <AiHelpIcon />
                            AI Help
                          </Button>
                        ) : (
                          <CustomTooltip
                            tooltipTitle="Upgrade Plan"
                            tooltipContent={
                              currentPlanData?.data?.plan_name == "Enterprise"
                                ? "Your current plan has limited features. Please Contact Admin"
                                : "Your current plan has limited features. Upgrade now to access more!"
                            }
                            buttonText={
                              currentPlanData?.data?.plan_name == "Enterprise"
                                ? null
                                : "Go to Plans"
                            }
                            navigateTo="/settings/account_tab" // The route to navigate
                          />
                        ))}
                    </div>
                  }
                  labelPlacement="outside"
                  placeholder="Enter your value statement"
                  variant="bordered"
                  radius="sm"
                  value={value}
                  onChange={handleValueChange} // Real-time validation on change
                  isInvalid={valueError ? true : false}
                  errorMessage={valueError}
                  classNames={{
                    input: "min-h-[150px]",
                    label: "mb-2",
                    inputWrapper: [
                      "group-data-[focus=true]:border-[#0098F5]",
                      "dark:group-data-[focus=true]:border-[#0098F5]",
                    ],
                  }}
                />
              </div>
            )}

        </form>

        <DepartmentAiHelpDrawer
          drawerState={isOpen}
          setDrawerState={setIsOpen}
          title={
            <span className="font-semibold">
              AI Help -{" "}
              <span className="text-[#0098F5]">Create Department Value</span>
            </span>
          }
          businessEssentialData={businessEssentialData}
          getBusinessEssentials={useBusinessEssentials}
          setValue={setValue}
          validate={validateValue}
          type={"Value"}
          setDrawerOpen={setIsOpen}
          BELoading={BELoading}
          step={drawerStep}
          setStep={setDrawerStep}
          fullStatements={statements}
          setFullStatements={setStatements}
          getMoreCount={getMoreCount}
          selectedBusinessEssentials={selectedBusinessEssentials}
          setSelectedBusinessEssentials={setSelectedBusinessEssentials}
          isEditable={isEditable}
          setIsEditable={setIsEditable}
          handleFullStatementChange={handleFullStatementChange}
          departmentId={id}
          handleIsDirty={handleIsDirty}
        />
      </div>
    );
  };

  return <>{renderContent()}</>;
}

export default DepartmentValue;

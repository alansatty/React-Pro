import { useState, useEffect } from "react";
import { HierarchicalCheckboxList } from "./HierarchicalCheckboxList";
import usePermissionsStore from "../../../../../../stores/usePermissionStore";
import { useParams } from "react-router-dom";
import useApi from "../../../../../../hooks/useApi";
import { apiList } from "../../../../../../services";
import ProstrategyLogo from "../../../../../../assets/icons/ProstrategyLogo";
import Swal from "sweetalert2/dist/sweetalert2.js";
import withReactContent from "sweetalert2-react-content";
import { PageSpinner } from "../../../../../../components";

const MySwal = withReactContent(Swal);

export default function DepartmentReportTab() {
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
  const { id, strategicId } = useParams();

  const { data, isLoading, error } = useApi(
    id && strategicPlan ? apiList.admin.departments.departmentsReports.key(id, strategicPlan) : null,
    id && strategicPlan
      ? apiList.admin.departments.departmentsReports.call(id, strategicPlan)
      : null
  );

  const [datas, setData] = useState(data);
  const [isSaved, setIsSaved] = useState(false);

  // Sync API data with local state
  useEffect(() => {
    if (data) {
      setData(data);
    }
  }, [data]);

  const { trigger, isMutating } = useApi(
    null,
    apiList.admin.departments.departmentsReports.call(id, strategicPlan),
    { method: "POST" }
  );

  const handleDataSave = async (updatedData) => {
    setIsSaved(false);
    try {
      const response = await trigger({ requestBody: updatedData });

      MySwal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>
            <h2 className="text-xl font-semibold">
              {" "}
              Department Report Saved Successly!
            </h2>
            <p className="mt-2">{response?.data}</p>
          </div>
        ),
        allowOutsideClick: false,
        confirmButtonText: "Okay",
        customClass: {
          confirmButton: "my-confirm-button",
        },
      });
      setIsSaved(true)
    } catch (error) {
      console.log("error", error);
      MySwal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20">
              <ProstrategyLogo />
            </div>
            <h2 className="text-xl font-semibold ">Error!</h2>
            <p className="mt-2">
              Failed to save Department Report. Please try again.
            </p>
          </div>
        ),
        confirmButtonText: "Retry",
      });
    }
    setIsSaved(true)
  };


  if (isLoading) return <PageSpinner />
  // if (error) return <div>Error loading data</div>;
  if (!datas || Object.keys(datas).length === 0) return <p className="flex justify-center text-gray-600">No Data Available</p>;
  // if (!datas) return <div>No data available</div>;

  return (
    <main className="min-h-screen">
      <div className="">
        <HierarchicalCheckboxList
          data={datas}
          onSave={handleDataSave}
          setData={setData}
          isSaved={isSaved}
          isSaveLoading={isMutating}

        />
      </div>
    </main>
  );
}

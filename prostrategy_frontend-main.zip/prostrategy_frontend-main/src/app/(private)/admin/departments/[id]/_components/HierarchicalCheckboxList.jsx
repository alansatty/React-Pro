import { Button } from "@nextui-org/button";
import { Checkbox } from "@nextui-org/checkbox";
import { IconChevronDown, IconChevronRight } from "@tabler/icons-react";
import { useEffect, useState } from "react";
import withReactContent from "sweetalert2-react-content";
import Swal from "sweetalert2/dist/sweetalert2.js";
import useUnsavedChanges from "../../../../../../hooks/useUnsavedChanges";
import UnsavedChangesModal from "../../../../../../components/Alert/UnsavedChangesModal";

const MySwal = withReactContent(Swal);
export function HierarchicalCheckboxList({ data, onSave, setData, isSaved, isSaveLoading }) {

  const [checkboxData, setCheckboxData] = useState(() => data || {});
  const [expandedItems, setExpandedItems] = useState({});
  const [pendingNavigation, setPendingNavigation] = useState(false);
  const [isDirty, setIsDirty] = useState(false);

  const [shouldShowActions, setShouldShowActions] = useState(false);


  const hasAtLeastOneSelected = (node) => {
    if (isCheckboxItem(node)) {

      return node.is_selected;
    }

    if (Array.isArray(node)) {

      return node.some(hasAtLeastOneSelected);
    }

    if (typeof node === "object" && node !== null) {

      return Object.values(node).some(hasAtLeastOneSelected);
    }
    return false;
  };

  useEffect(() => {
    setShouldShowActions(hasAtLeastOneSelected(checkboxData));
  
  }, []);


  useEffect(() => {
    setCheckboxData(data || {})
    setIsDirty(false)
  }, [data])

  const toggleExpand = (key) => {
    setExpandedItems((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  useEffect(() => {
    if (isSaved) {
      setIsDirty(false);
    }
  }, [isSaved]);

  const handleNavigationConfirm = (shouldNavigate) => {
    if (shouldNavigate) {
      setIsDirty(false);
    }
    setPendingNavigation(false);
  };

  const { showModal, confirmNavigation, cancelNavigation } = useUnsavedChanges(
    isDirty,
    pendingNavigation,
    handleNavigationConfirm
  );

  const isCheckboxItem = (item) => {
    return (
      item &&
      typeof item === "object" &&
      "slug" in item &&
      "name" in item &&
      "is_selected" in item
    );
  };

  const areAllChildrenSelected = (node) => {
    if (isCheckboxItem(node)) return node.is_selected;

    if (Array.isArray(node)) {
      return node.length > 0 && node.every(areAllChildrenSelected);
    }

    if (typeof node === "object" && node !== null) {
      const keys = Object.keys(node);
      return (
        keys.length > 0 &&
        keys.every((key) => areAllChildrenSelected(node[key]))
      );
    }

    return false;
  };

  const updateSelectionState = (node, isSelected) => {
    if (isCheckboxItem(node)) {
      return { ...node, is_selected: isSelected };
    }

    if (Array.isArray(node)) {
      return node.map((item) => updateSelectionState(item, isSelected));
    }

    if (typeof node === "object" && node !== null) {
      const result = {};
      for (const key in node) {
        result[key] = updateSelectionState(node[key], isSelected);
      }
      return result;
    }

    return node;
  };

  const handleCheckboxChange = (path, isSelected) => {
    setIsDirty(true);
    const newData = JSON.parse(JSON.stringify(checkboxData));
    let current = newData;
   
    // Traverse to the parent node
    for (let i = 0; i < path.length - 1; i++) {
      current = current[path[i]];
    }

    const lastKey = path[path.length - 1];
    current[lastKey] = updateSelectionState(current[lastKey], isSelected);

    setCheckboxData(newData);
    setData(newData);
    setShouldShowActions(true)
  };

  const renderCheckboxItem = (item, path) => {
    return (
      <div className="ml-6 my-1" key={item.slug}>
        <Checkbox
          isSelected={item.is_selected}
          onValueChange={(val) => handleCheckboxChange([...path], val)}
          classNames={{
            base: "text-sm",
            label: "text-base",
          }}
        >
          {item.name}
        </Checkbox>
      </div>
    );
  };

  const renderNode = (node, path = [], level = 0) => {
    if (!node) return null;
    if (isCheckboxItem(node)) {
      return renderCheckboxItem(node, path);
    }

    if (Array.isArray(node)) {
      return (
        <div className="pl-6">
          {node.map((item, index) => (
            <div key={index}>
              {renderNode(item, [...path, index.toString()], level + 1)}
            </div>
          ))}
        </div>
      );
    }

    if (typeof node !== "object" || node === null) {
      return null;
    }

    const keys = Object.keys(node);
    if (keys.length === 0) return null;

    return (
      <div className={level > 0 ? "pl-6" : ""}>
        {keys.map((key) => {
          const isExpandable =
            typeof node[key] === "object" &&
            node[key] !== null &&
            !isCheckboxItem(node[key]);
          const isExpanded = expandedItems[path.join(".") + "." + key] || false;
          const allSelected = areAllChildrenSelected(node[key]);

          return (
            <div key={key} className="mt-1">
              <div className="flex items-center space-x-2">
                {isExpandable ? (
                  <button
                    onClick={() => toggleExpand(path.join(".") + "." + key)}
                    className="h-4 w-4 flex items-center justify-center "
                    Style="color:#0098F5"
                  >
                    {isExpanded ? (
                      <IconChevronDown className="h-3 w-3" />
                    ) : (
                      <IconChevronRight className="h-3 w-3" />
                    )}
                  </button>
                ) : (
                  <div className="w-4" />
                )}

                <Checkbox
                  isSelected={allSelected}
                  onValueChange={(val) =>
                    handleCheckboxChange([...path, key], val)
                  }
                  classNames={{
                    base: "text-sm",
                    label: "text-base",
                  }}
                >
                  {key}
                </Checkbox>
              </div>

              {isExpandable && isExpanded && (
                <div className="mt-1">
                  {renderNode(node[key], [...path, key], level + 1)}
                </div>
              )}
            </div>
          );
        })}
      </div>
    );
  };

  // const selectAllcheckBox = () => {
  //   // Function to recursively collect all checked items' full slugs
  //   const collectCheckedSlugs = (node, slugs = []) => {
  //     if (isCheckboxItem(node)) {
  //       if (node.is_selected) {
  //         // Push the complete slug (including both parts)
  //         slugs.push(node.slug);
  //       }
  //       return slugs;
  //     }

  //     if (Array.isArray(node)) {
  //       node.forEach((item) => collectCheckedSlugs(item, slugs));
  //     } else if (typeof node === 'object' && node !== null) {
  //       Object.values(node).forEach((value) => collectCheckedSlugs(value, slugs));
  //     }

  //     return slugs;
  //   };

  //   const checkedSlugs = collectCheckedSlugs(checkboxData);
  //   console.log("Checked full slugs:", checkedSlugs);

  //   // Pass the array of full slugs to the onChange prop
  //   setData(checkedSlugs);
  // };
  const selectAllcheckBox = () => {
    setShouldShowActions(false)
    const collectCheckedSlugs = (node, slugs = []) => {
      if (isCheckboxItem(node)) {
        if (node.is_selected) {
          slugs.push(node.slug);
        }
        return slugs;
      }

      if (Array.isArray(node)) {
        node.forEach((item) => collectCheckedSlugs(item, slugs));
      } else if (typeof node === "object" && node !== null) {
        Object.values(node).forEach((value) =>
          collectCheckedSlugs(value, slugs)
        );
      }

      return slugs;
    };

    return collectCheckedSlugs(checkboxData); // Return the slugs array
  };
  return (
    <div className="p-4  rounded-lg">
      <div className="mt-2 flex justify-end">

        <Button
          size="sm"
          radius="sm"
          color="primary"
          className={`bg-[#0098F5] px-4 py-2 text-white h-10 ${!shouldShowActions ? "opacity-50 cursor-not-allowed pointer-events-none" : ""
            }`}
          isLoading={isSaveLoading}
          onClick={() => onSave(selectAllcheckBox())}
        >
          Save Changes
        </Button>
        {showModal && (
          <UnsavedChangesModal
            isConfirmNavigation={confirmNavigation}
            isCancelNavigation={cancelNavigation}
          />
        )}
      </div>
      {renderNode(checkboxData)}
    </div>
  );
}

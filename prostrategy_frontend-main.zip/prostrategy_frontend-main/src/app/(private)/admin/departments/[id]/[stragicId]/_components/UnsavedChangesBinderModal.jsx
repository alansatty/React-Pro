import { useState, useEffect, useMemo } from "react";
import { Button } from "@nextui-org/button";
import { Modal, ModalBody, ModalContent, ModalFooter, ModalHeader } from "@nextui-org/modal";
import ProstrategyLogo from "../../../../../../../assets/icons/ProstrategyLogo";
import useApi from "../../../../../../../hooks/useApi";
import { apiList } from "../../../../../../../services";
import { useAuth } from "../../../../../../../providers/authProviders";
import axios from "axios";

const UnsavedChangesBinderModal = ({
    setTypingCount,
    confirmNavigation,
    isCancelNavigation,
    onSave,
    isSaved,
    setIsSaved,
    setIsUserMadeChange,
    strategicBinderId,
    slug
}) => {
    const [isVisible, setIsVisible] = useState(false);
    const auth = useAuth();
    const authToken = useMemo(() => auth?.user?.token, [auth?.user?.token])

    useEffect(() => {
        if (isSaved) {
            setIsVisible(false);
            // confirmNavigation();
            setIsUserMadeChange(false);
            setIsSaved(false)
        }
    }, [isSaved, setIsUserMadeChange, confirmNavigation])

    useEffect(() => {
        setIsVisible(true);
    }, []);

    const handleSaveAndNavigate = async () => {
        try {
            await onSave();
            confirmNavigation();

        } catch (error) {
            console.error('Error during save:', error);
            // Modal stays open on error
        }
    };

    // const { trigger: trackTemplete } = useApi(
    //     null,
    //     strategicBinderId && slug ? apiList.admin.binder_template.save.call(strategicBinderId, slug) : null,
    //     { method: "PATCH" }
    // );  

    const callPatchApi = async () => {
        const formData = new FormData()
        formData.append("is_current_user_editing", "false")
        try {
            await axios.patch(
                `/organization/strategic_binder_support/${strategicBinderId}/?slug=${slug}`,
                formData,
                {
                    headers: {
                        'Content-Type': 'multipart/form-data',
                        // 'Accept': 'application/json',  // Add this
                        Authorization: authToken ? `Bearer ${authToken}` : undefined,
                    }
                }
            );
        } catch (error) {
            console.error('Error during PATCH request:', error);
        }
    };


    // try {
    //     await trackTemplete({ requestBody: { is_current_user_editing: false } });
    // } catch (error) {
    //     console.error('Error calling PATCH API:', error);
    // }

    const handleDiscard = () => {
        callPatchApi()
        setTypingCount(0);
        setIsUserMadeChange(false);
        confirmNavigation();
    };

    return (
        <Modal
            isDismissable={false}
            isKeyboardDismissDisabled={true}
            isOpen={isVisible}
            onClose={isCancelNavigation}
            backdrop="transparent"
            className="fixed transform flex justify-center border-2 shadow-md"
        >
            <ModalContent className="w-full max-w-lg transition-all duration-300 ease-in-out transform items-center">
                {() => (
                    <>
                        <ModalHeader className="flex flex-col gap-1 text-danger">
                            <div className='mt-4 items-center gap-3'>
                                <ProstrategyLogo />
                            </div>
                        </ModalHeader>
                        <ModalBody>
                            <h2 className="text-black text-lg font-bold text-center">
                                ⚠️ Unsaved Changes
                            </h2>
                            <p className="text-gray-600 text-center">
                                You have unsaved changes. Would you like to save them before leaving?
                            </p>
                        </ModalBody>
                        <ModalFooter className='mb-4 gap-4 justify-center'>
                            <Button
                                onPress={handleSaveAndNavigate}
                                color="primary"
                                className='px-8 py-4 text-md font-medium'
                            >
                                Save
                            </Button>
                            <Button
                                onPress={handleDiscard}
                                color="default"
                                className='px-8 py-4 text-md font-medium'
                            >
                                Cancel
                            </Button>

                        </ModalFooter>
                    </>
                )}
            </ModalContent>
        </Modal>
    );
};
export default UnsavedChangesBinderModal;

import React, { useEffect } from "react";
import { useParams } from "react-router-dom";
import { mutate } from "swr";
import usePermissionsStore from "../../../../../../stores/usePermissionStore";
import useApi from "../../../../../../hooks/useApi";
import { apiList } from "../../../../../../services";
import { PageSpinner } from "../../../../../../components";

const SwotAnalysisTab = () => {
  const { id } = useParams();
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);

  const { data: SwotDetails, isLoading: SwotLoading } = useApi(
    strategicPlan ? apiList.admin.departments.get_swotValues.key(id) : null,
    strategicPlan ? apiList.admin.departments.get_swotValues.call(strategicPlan, id) : null
  );

  const mutateFn = async () => {
    await mutate(apiList.admin.departments.get_swotValues.key(id));
  };

  useEffect(() => {
    mutateFn();
  }, [strategicPlan]);

  if (SwotLoading || !strategicPlan) {
    return <PageSpinner />;
  }

  const colors = {
    Strengths: "#3D6C65",
    Weaknesses: "#6565D5",
    Opportunities: "#FFC965",
    Threats: "#94297D",
  };

  const textColors = {
    Strengths: "text-white",
    Weaknesses: "text-white",
    Opportunities: "text-white",
    Threats: "text-white",
  };

  const filteredData = SwotDetails?.data?.filter((section) => {
    const criteriaValues = Object.values(section.criteria || {});
    return criteriaValues.some((item) => item?.criteria?.trim());
  });

  if (!filteredData || filteredData.length === 0) {
    return (
      <div className="text-center text-gray-600 mt-4">
        Please update Department SWOT Form to see the analysis
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {filteredData.map((section, index) => {
        const criteriaItems = Object.values(section.criteria || {})
          .filter((item) => item?.criteria?.trim())
          .map((item) => item.criteria);

        return (
          <div
            key={index}
            className={`p-4 rounded-lg`}
            style={{
              backgroundImage: `url(/${section.swot_option_label.toLowerCase()}.svg)`, // Dynamically set the image
              backgroundSize: "cover", // Ensure the image covers the entire div
              backgroundRepeat: "no-repeat", // Prevent the image from repeating
            }}
          >
            <div className="relative">
              <h3
                className={`${textColors[section.swot_option_label]
                  } font-semibold mb-5 text-lg`}
              >
                {section.swot_option_label.toUpperCase()}
              </h3>
              <div className="absolute top-0 right-0 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-xl">
                  {section.swot_option_label.charAt(0).toUpperCase()}
                </span>
              </div>
            </div>
            <ol
              className={`${textColors[section.swot_option_label]
                } list-decimal list-inside `}
            >
              {criteriaItems.map((item, idx) => (
                <li key={idx} className="mb-1">
                  {item}
                </li>
              ))}
            </ol>
          </div>
        );
      })}
    </div>
  );
};

export default SwotAnalysisTab;

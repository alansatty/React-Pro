import React, { useState } from "react";
import { Button } from "@nextui-org/button";
import { Card } from "@nextui-org/card";
import { IconCircleX, IconInfoCircle, IconReload } from "@tabler/icons-react";
import SlidingPane from "react-sliding-pane";
import "react-sliding-pane/dist/react-sliding-pane.css";
import toast from "react-hot-toast";
import { Skeleton } from "@nextui-org/skeleton";
import { Accordion, AccordionItem } from "@nextui-org/accordion";

function AIHelpStrategiesDrawer({
  drawerState,
  setDrawerState,
  title,
  onSaveStrategies,
  AIStrategiesData,
  AILoading,
  selectedStrategies,
  setSelectedStrategies,
  handleIsDirty

}) {
  const handleSelectStrategies = (index) => {
    if (selectedStrategies.includes(index)) {
      // Deselect if already selected
      setSelectedStrategies(selectedStrategies.filter((i) => i !== index));
    } else {
      // Add new selection
      setSelectedStrategies([...selectedStrategies, index]);
    }
  };

  const useSelectedStrategies = () => {
    const selectedData = selectedStrategies.map(
      (index) => AIStrategiesData[index]
    );

    if (selectedData.length > 0) {
      if (typeof handleIsDirty === "function") {
        handleIsDirty(true);
      }
      onSaveStrategies(selectedData);
      setSelectedStrategies([]);
      setDrawerState(false);
    } else {
      toast.error("Please select atleast one Strategy.");
      if (typeof handleIsDirty === "function") {
        handleIsDirty(false);
      }
    }
  };

  return (
    <div>
      <SlidingPane
        closeIcon={
          <div>
            <span className="text-xl">
              <IconCircleX color="#11181C" className="w-12 h-12" />
            </span>
          </div>
        }
        overlayClassName="z-50 "
        width="600px"
        isOpen={drawerState}
        title={title}
        onRequestClose={() => setDrawerState(false)}
      >
        <div>
          <h5 className="text-gray-600 p-1 font-semibold">
            Based on the Department Goal Information added, here are the
            suggested Department Strategies.
          </h5>
          <div className="flex gap-2 items-start text-sm">
            <IconInfoCircle className="mb-1 h-7 w-7" />
            <p>
              You can generate and select up to 10 Strategies from the list to create
              Department Strategies.
            </p>
          </div>

          <div className="mt-4 grid grid-cols-1 gap-4 max-h-[calc(100vh-30vh)] overflow-auto p-2">
            {AILoading
              ? Array.from({ length: 4 }).map((_, index) => (
                  <Card
                    key={index}
                    bordered
                    shadow="none"
                    radius="md"
                    className={`p-4 border-[#E2E9F0] bg-[#F4F7FA] border`}
                  >
                    <Skeleton className="rounded-lg">
                      <div className="h-10 rounded-lg bg-default-300"></div>
                    </Skeleton>
                  </Card>
                ))
              : AIStrategiesData?.map((StrategieData, index) => {
                  return (
                    <Card
                      bordered
                      key={index}
                      shadow="none"
                      isPressable
                      radius="sm"
                      className={`p-2 bg-[#F4F7FA] w-full border text-start min-h-12 ${
                        selectedStrategies.includes(index)
                          ? "border-primary border-2"
                          : "border-[#E2E9F0]"
                      }`}
                      onClick={() => handleSelectStrategies(index)}
                    >
                      {index + 1} : {StrategieData}
                    </Card>
                  );
                })}
          </div>

          <div className="flex justify-end mt-4">
            <Button
              color="primary"
              radius="sm"
              className="capitalize"
              onClick={useSelectedStrategies}
              disabled={!selectedStrategies}
              isLoading={AILoading}
            >
              Use Strategies
            </Button>
          </div>
        </div>
      </SlidingPane>
    </div>
  );
}

export default AIHelpStrategiesDrawer;

import { Checkbox } from "@nextui-org/checkbox"
import { Modal, ModalContent } from "@nextui-org/modal"
import { useState, useEffect, useRef } from "react"
import ProstrategyLogo from "../../../../../../../assets/icons/ProstrategyLogo"
import { Button } from "@nextui-org/button"
import { apiList } from "../../../../../../../services"
import useApi from "../../../../../../../hooks/useApi"
import { Spinner } from "@nextui-org/spinner"
import toast from "react-hot-toast"

const GoalsCheckBoxDept = ({
    takedCustomInput,
    takeCustomInput,
    reportPlanningData,
    handlingSetUserMadeChange,
    setCheckedData,
    setPrimaryData,
    primaryData,
    typingCount,
    setTypingCount,
    strategicBinderId,
    activeItem,
    isLoading,
    setInputError,
    inputError
}) => {
    const [checkBoxData, setCheckBoxData] = useState([])
    const [isEditable, setIsEditable] = useState(false)
    const [showAccessDeniedModal, setShowAccessDeniedModal] = useState(false)
    const [isGoal, setIsGoal] = useState(false)
    const [hasInteracted, setHasInteracted] = useState(false)
    const mutateErrorShown = useRef(false)

    const [apiError, setApiError] = useState(null);

    const { trigger: saveTemplate, mutationError } = useApi(
        null,
        strategicBinderId && activeItem?.slug ? apiList.admin.binder_template.save.call(strategicBinderId, activeItem?.slug) : null,
        { method: "PATCH" }
    );

    useEffect(() => {
        if (mutationError) {
            if (mutationError?.status === 400) {
                setApiError(mutationError.data?.message || "An error occurred");
            }
        }
    }, [mutationError]);

    useEffect(() => {
        if (apiError && !mutateErrorShown.current) {
            toast.error(apiError);
            mutateErrorShown.current = true;
            setApiError(null); // Reset error after showing
        }
    }, [apiError]);

    useEffect(() => {
        if (reportPlanningData) {
            if (!reportPlanningData.is_allow_edit) {
                handlingSetUserMadeChange(false)
            } else if (reportPlanningData.is_another_user_editing) {
                handlingSetUserMadeChange(false)
            }
        }
    }, [reportPlanningData])

    useEffect(() => {
        if (reportPlanningData) {

            setIsGoal(reportPlanningData?.is_goal_or_pillar === 'goal')
            // Filter out any non-object items and the custom_input object
            const goalsArray = Object.values(reportPlanningData.data)
                .filter(item => typeof item === 'object' && item.id && item.value)

            const checkedIds = goalsArray
                .filter(item => item.is_checked)
                .map(item => item.id)

            const primaryGoal = goalsArray.find(item => item.is_primary)

            setCheckedData(checkedIds)
            setCheckBoxData(goalsArray)
            setPrimaryData(primaryGoal?.id || null)
            setIsEditable(reportPlanningData.is_allow_edit && !reportPlanningData.is_another_user_editing)

            // Handle custom input initialization
            if (reportPlanningData.data.custom_input && typeof reportPlanningData.data.custom_input === 'string') {
                takeCustomInput(reportPlanningData.data.custom_input)
            } else {
                takeCustomInput('')
            }

            setHasInteracted(false)
        }
    }, [reportPlanningData])

    const handleCheckboxChange = (id, checked) => {
        if (!isEditable) return

        handlingSetUserMadeChange(true)
        setCheckBoxData(prevItems => {
            const updatedGoals = prevItems.map(item =>
                item.id === id ? { ...item, is_checked: checked } : item
            )
            setTypingCount(typingCount + 1)

            const checkedIds = updatedGoals
                .filter(item => item.is_checked)
                .map(item => item.id)

            setCheckedData(checkedIds)

            return updatedGoals
        })
    }

    const callPatchApi = async () => {
        try {
            await saveTemplate({ requestBody: { is_current_user_editing: true } })
        } catch (error) {
            console.error('Error calling PATCH API:', error)
        }
    }

    if (mutationError) {
        if (mutationError?.status === 400) {
            if (mutationError?.data?.status === "error" && mutationError?.data?.message && !mutateErrorShown.current) {
                mutateErrorShown.current = true
                toast.error(mutationError?.data?.message)
            }
        }
    }


    useEffect(() => {
        if (typingCount === 1 && isEditable) {
            callPatchApi()
        }
    }, [typingCount, isEditable])

    const handleCustomInput = (e) => {
        const { value } = e.target
        // Ensure we're only taking string values
        takeCustomInput(value)
        setHasInteracted(true)

        // Validation
        if (value.trim() !== '' && value.length < 4) {
            setInputError(true)
        } else {
            setInputError(false)
        }

        if (isEditable) {
            setTypingCount(typingCount + 1)
            handlingSetUserMadeChange(true)
        }
    }

    const closeAccessDeniedModal = () => {
        setShowAccessDeniedModal(false)
    }

    const handlePrimaryChange = (itemId) => {
        setCheckBoxData(prevItems => prevItems.map(item => ({
            ...item,
            is_primary: item.id === itemId ? true : false
        })))
        setPrimaryData(itemId)

        if (isEditable) {
            setTypingCount(typingCount + 1)
            handlingSetUserMadeChange(true)
        }
    }

    const shouldShowError = hasInteracted && inputError && takedCustomInput.trim() !== ''

    if (isLoading) {
        return <Spinner />
    }

    return (
        <>
            <div
                className="rounded-md w-full bg-white p-4 mb-4 relative"
                onMouseEnter={() => !isEditable && setShowAccessDeniedModal(true)}
                onMouseLeave={() => !isEditable && setShowAccessDeniedModal(false)}
            >
                <h2 className="text-xl font-medium text-gray-700 mb-4">
                    Organization {isGoal ? "Goal" : "Pillar"} Supported
                </h2>

                <div className="flex flex-col gap-2">
                    {checkBoxData.map((item) => (
                        <div key={item.id} className="flex items-start gap-6">
                            {isGoal && (
                                <div className="flex items-center gap-2 mt-1">
                                    <input
                                        type="radio"
                                        id={`primary-${item.id}`}
                                        name="primary-item"
                                        checked={item?.is_primary}
                                        onChange={() => handlePrimaryChange(item.id)}
                                        className="h-4 w-4 border-gray-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                                        disabled={!isEditable}
                                    />
                                    <label
                                        htmlFor={`primary-${item.id}`}
                                        className="text-sm text-gray-700 cursor-pointer select-none font-medium"
                                    >
                                        Primary
                                    </label>
                                </div>

                            )}
                            <>
                                <Checkbox
                                    id={`label-${item.id}`}
                                    isSelected={item.is_checked}
                                    isDisabled={!isEditable}
                                    onValueChange={(isSelected) => handleCheckboxChange(item.id, isSelected)}
                                    className="h-5 w-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500 mt-1 flex-shrink-0"
                                />
                                <label
                                    htmlFor={`label-${item.id}`}
                                    onClick={() => {
                                        if (isEditable) {
                                            handleCheckboxChange(item.id, !item.is_checked);
                                        }
                                    }}
                                    className="text-sm font-medium text-gray-700 break-words flex-1 mt-1 cursor-pointer"
                                >
                                    {item.value}
                                </label>
                            </>
                        </div>
                    ))}

                    {/* Custom input field */}
                    <div className="mt-2">
                        <input
                            id="custom_input"
                            name="custom_input"
                            type="text"
                            placeholder={isGoal ? "Enter a Goal (optional)" : "Enter a Pillar (optional)"}
                            value={typeof takedCustomInput === 'string' ? takedCustomInput : ''}
                            onChange={handleCustomInput}
                            disabled={!isEditable}
                            className={`w-full md:w-2/3 rounded-md border ${shouldShowError ? 'border-red-500' : 'border-gray-300'
                                } px-4 py-2 text-sm shadow-sm focus:border-[#0098F5] focus:outline-none focus:ring-1 focus:ring-[#0098F5]`}
                        />
                        {shouldShowError && (
                            <p className="mt-1 text-sm text-red-600">Please enter at least 4 characters</p>
                        )}
                    </div>
                </div>

                <Modal
                    isOpen={showAccessDeniedModal && !isEditable}
                    onClose={closeAccessDeniedModal}
                    placement="center"
                    className="z-[9999] max-w-md"
                >
                    <ModalContent>
                        <div className="p-6 text-center">
                            <div className="flex justify-center mb-4">
                                <ProstrategyLogo className="h-10" />
                            </div>
                            <h3 className="text-lg font-semibold text-gray-700 mb-3">
                                ACCESS RESTRICTED
                            </h3>
                            <p className="text-gray-600 mb-6">
                                {!reportPlanningData?.is_allow_edit
                                    ?
                                    "Your current access level doesn't permit modifications to these strategic support settings."
                                    : "This document is currently being edited by another user. Please try again later."
                                }
                            </p>
                        </div>
                    </ModalContent>
                </Modal>
            </div>
        </>
    )
}

export default GoalsCheckBoxDept
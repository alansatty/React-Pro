
import { Button } from "@nextui-org/button";
import { Input, Textarea } from "@nextui-org/input";
import {
  Modal,
  ModalBody,
  ModalContent,
  ModalFooter,
  ModalHeader,
} from "@nextui-org/modal";
import { Radio, RadioGroup } from "@nextui-org/radio";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";

import toast from "react-hot-toast";
import { useEffect, useState } from "react";

import { mutate } from "swr";
import { createStrategyFormSchema } from "../../../../../../../validationSchema/authValidation";
import usePermissionsStore from "../../../../../../stores/usePermissionStore";
import useApi from "../../../../../../hooks/useApi";
import { apiList } from "../../../../../../services";
import { cn } from "../../../../../../utils/twMege";
import { useParams } from "react-router-dom";
import { IconInfoCircle } from "@tabler/icons-react";
import { Tooltip } from "@nextui-org/tooltip";
import { parseBackendDate } from "../../../../../../utils/helpers";
import axios from "axios";
import { useAuth } from "../../../../../../providers/authProviders";

export function StrategicFormModal({
  isOpen,
  onClose,
  strategyIdEntry,
  departmentId = "",
  isFormExist,
  mutateKey = null,
  strategyText,
}) {
  const [textStrategy, setStrategyText] = useState(strategyText || '')
  const [inputError, setInputError] = useState('')
  const [yearRangeInput, setYearRangeInput] = useState('')
  const { id } = useParams();
  const auth = useAuth()
  const currentDeptId = id || departmentId;
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);

  const formDataKey = apiList.admin.departmentStrategies.get_entryFormDetails.key(strategyIdEntry)
  const parentListKey = mutateKey || apiList.admin.departmentStrategies.get_saved.key(currentDeptId, strategyIdEntry)

  const { data: initialStrategyData } = useApi(
    apiList.admin.settings.get_startegyData.key(strategicPlan, false),
    strategicPlan ? apiList.admin.settings.get_startegyData.call(strategicPlan, false) : null
  );

  const minYear = initialStrategyData?.data?.start_year || 2024;
  const maxYear = Number(minYear) + 10;

  const { data: metricQuestions } = useApi(
    apiList.admin.departmentStrategies.get_metricQuestions.key(strategicPlan),
    apiList.admin.departmentStrategies.get_metricQuestions.call(strategicPlan)
  )

  const {
    control,
    handleSubmit,
    reset,
    setValue,
    watch,
    getValues,
    formState: { errors },
  } = useForm({
    defaultValues: {
      name: strategyText || "",
      department_choices: "",
      start_date: "",
      production_date: "",
      metric_one: "",
      metric_two: "",
      metric_three: "",
      metric_four: "",
      metric_five: "",
      metric_six: "",
      metric_seven: "",
      metric_eight: "",
      expected_years_productive: "",
    },
    // Make sure the resolver uses the correct shape
    resolver: yupResolver(createStrategyFormSchema(minYear, maxYear, metricQuestions?.data?.questions || {}, yearRangeInput)),
    mode: "onChange",
  });

  const { data, isLoading, } = useApi(
    strategyIdEntry && isFormExist ? formDataKey : null,
    apiList.admin.departmentStrategies.get_entryFormDetails.call(
      currentDeptId,
      strategyIdEntry
    )
  );

  // Improved useEffect to handle strategyText
  useEffect(() => {
    // Ensure strategyText is set in both state and form
    if (strategyText) {
      setStrategyText(strategyText);
      setValue('name', strategyText);
    }
  }, [strategyText, setValue]);

  // for department 
  const { data: departmentsData } = useApi(
    apiList.admin.departmentStrategies.get_departments.key(strategyIdEntry),
    apiList.admin.departmentStrategies.get_departments.call()
  );

  const { trigger, isMutating, error, mutationError } = useApi(
    null,
    apiList.admin.departmentStrategies.save_entryForm.call(
      currentDeptId,
      strategyIdEntry
    ),
    { method: "POST" }
  );

  useEffect(() => {
    setInputError('');
  }, [onClose])

  useEffect(() => {
    if (mutationError?.status === 'error') {

      if (mutationError.msg && mutationError.range) {
        setInputError(mutationError.msg);
        setYearRangeInput(mutationError.range);
      }
    }
  }, [mutationError]);

  const yearsInput = watch("expected_years_productive");

  useEffect(() => {
    if (yearsInput) {

      if (yearRangeInput) {
        const parseYears = parseInt(yearsInput, 10)
        const maxYears = parseInt(yearRangeInput, 10);

        if (parseYears <= maxYears) {
          setInputError('');
        }

      }
    }
  }, [yearsInput])



  useEffect(() => {
    if (data?.data?.length > 0) {
      const savedData = data?.data[0];
      // Prioritize strategyText if available
      const nameToUse = strategyText || savedData.name || "";
      reset({
        name: nameToUse,
        department_choices: savedData.department_choices || "",
        start_date: parseBackendDate(savedData.start_date, "-") || "",
        production_date: parseBackendDate(savedData.production_date, "-") || "",
        metric_one:
          savedData.metric_one == 0 ? 0 : savedData.metric_one || "",
        metric_two:
          savedData.metric_two == 0 ? 0 : savedData.metric_two || "",
        metric_three:
          savedData.metric_three == 0 ? 0 : savedData.metric_three || "",
        metric_four:
          savedData.metric_four == 0 ? 0 : savedData.metric_four || "",
        metric_five:
          savedData.metric_five == 0 ? 0 : savedData.metric_five || "",
        metric_six:
          savedData.metric_six == 0 ? 0 : savedData.metric_six || "",
        metric_seven:
          savedData.metric_seven == 0 ? 0 : savedData.metric_seven || "",
        metric_eight:
          savedData.metric_eight == 0 ? 0 : savedData.metric_eight || "",
        expected_years_productive:
          savedData.expected_years_productive == 0
            ? 0
            : savedData.expected_years_productive || "",
      });
    } else {
      // Handle the case where no data is returned or data is invalid
      reset({
        name: strategyText || "",
        department_choices: id || "",
        start_date: "",
        production_date: "",
        metric_one: "",
        metric_two: "",
        metric_three: "",
        metric_four: "",
        metric_five: "",
        metric_six: "",
        metric_seven: "",
        metric_eight: "",
        expected_years_productive: "",
      });
    }
  }, [data, reset, strategyText]);

  function formatDate(inputDate) {
    const date = new Date(inputDate);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  }

  const onSubmit = async (formData) => {

    const parsedData = {
      name: formData.name,
      department_choices: formData?.department_choices,
      expected_years_productive: parseNumberValue(formData.expected_years_productive),
      start_date: formData.start_date ? formatDate(formData.start_date) : null,
      production_date: formData.production_date ? formatDate(formData.production_date) : null,
      strategic_plan_id: strategicPlan,
    };

    // Only include metric fields if they exist in metricQuestions.data
    if (metricQuestions?.data?.questions.metric_one !== "") {
      parsedData.metric_one = parseNumberValue(formData.metric_one);
    }
    if (metricQuestions?.data?.questions.metric_two !== "") {
      parsedData.metric_two = parseNumberValue(formData.metric_two);
    }
    if (metricQuestions?.data?.questions.metric_three !== "") {
      parsedData.metric_three = parseNumberValue(formData.metric_three);
    }
    if (metricQuestions?.data?.questions.metric_four !== "") {
      parsedData.metric_four = parseNumberValue(formData.metric_four);
    }
    if (metricQuestions?.data?.questions.metric_five !== "") {
      parsedData.metric_five = parseNumberValue(formData.metric_five);
    }
    if (metricQuestions?.data?.questions.metric_six !== "") {
      parsedData.metric_six = parseNumberValue(formData.metric_six);
    }
    if (metricQuestions?.data?.questions.metric_seven !== "") {
      parsedData.metric_seven = parseNumberValue(formData.metric_seven);
    }
    if (metricQuestions?.data?.questions.metric_eight !== "") {
      parsedData.metric_eight = parseNumberValue(formData.metric_eight);
    }

    if (parsedData) {
      try {
        const response = await trigger({ requestBody: parsedData });
        toast.success(response?.message || "Form saved successfully!");
        mutate(formDataKey);
        mutate(parentListKey);
        onClose();
        reset();
      } catch (error) {
        console.error(error);
        toast.error("Failed to save the form.");
      }
    }
  };

  // Helper function to parse number values (remove commas)
  const parseNumberValue = (value) => {
    if (!value && value !== 0) return "";
    if (typeof value === 'number') return value;
    if (typeof value === 'string') {
      return value.replace(/,/g, '') || "";
    }
    return "";
  };

  // Format number with commas
  const formatNumberWithCommas = (value) => {
    if (!value && value !== 0) return "";
    const numValue = Number(value.toString().replace(/,/g, ''));
    if (isNaN(numValue)) return "";
    return new Intl.NumberFormat('en-US').format(numValue);
  };



  let questionCounter = metricQuestions?.data?.questions ? Object.values(metricQuestions.data.questions).filter(item => item !== '').length : 0;

  return (
    <Modal
      isDismissable={false}
      isOpen={isOpen}
      onClose={onClose}
      size="4xl"
      scrollBehavior="inside"
    >
      <form onSubmit={handleSubmit(onSubmit)} noValidate>
        <ModalContent>
          <ModalHeader>Strategic Form</ModalHeader>
          <ModalBody className="gap-4">
            <Controller
              name="name"
              control={control}
              render={({ field }) => (
                <Input
                  {...field}
                  variant="bordered"
                  labelPlacement="outside"
                  // Use readOnly instead of disabled to maintain form submission
                  readOnly={!!strategyText || !!field.name}
                  label={
                    <div className="flex gap-2 items-center">
                      <p
                        className={cn(
                          "text-sm text-black",
                          errors && !!errors?.name ? "text-danger" : ""
                        )}
                      >
                        1. What is the name of this STRATEGIC INITIATIVE?
                        <span className="text-red-500 pl-1">*</span>
                      </p>
                      <Tooltip content="Select a descriptive name for this project">
                        <IconInfoCircle className="mb-1 cursor-pointer" />
                      </Tooltip>
                    </div>
                  }
                  placeholder="Please enter at most 150 characters"
                  errorMessage={errors.name?.message}
                  isInvalid={errors && !!errors?.name}
                  helperColor="error"
                />
              )}
            />
            {/* ... previous code remains the same ... */}
            <div className="mt-2">
              <Controller
                name="department_choices"
                control={control}
                render={({ field }) => {

                  return (
                    <RadioGroup
                      label={
                        <div className="flex gap-2 items-center">
                          <p
                            className={cn(
                              "text-sm text-black",
                              errors && !!errors?.department_choices
                                ? "text-danger"
                                : ""
                            )}
                          >
                            2. What department is submitting this STRATEGIC
                            INITIATIVE?
                            <span className="text-red-500 pl-1">*</span>
                          </p>
                          <Tooltip
                            className="max-w-80"
                            content="This question asks for the department that will serve as the lead on this strategic initiative. There are commonly other departments that will be contributors to the execution of this strategic initiative, but this question asks for the department that will ultimately be responsible for execution of this strategic initiative."
                          >
                            <IconInfoCircle
                              className={cn(
                                "mb-1 cursor-pointer text-black",
                                errors && !!errors?.department_choices
                                  ? "text-danger"
                                  : ""
                              )}
                            />
                          </Tooltip>
                        </div>
                      }
                      errorMessage={errors?.department_choices?.message}
                      isInvalid={errors && !!errors?.department_choices}
                      {...field}
                      value={field.value?.toString()}
                      onValueChange={field.onChange}
                    >
                      {
                        departmentsData?.data.length > 0 ? (
                          <div className="grid grid-cols-2 gap-2">
                            {departmentsData?.data.map((department) => (
                              <Radio key={department?.id} value={department.id.toString()}>{department?.name}</Radio>
                            ))}
                          </div>
                        ) : (
                          <p>No department data</p>
                        )
                      }
                    </RadioGroup>
                  )
                }}
              />
            </div>
            <div className="mt-4">
              <Controller
                name="start_date"
                control={control}
                render={({ field }) => (
                  <Input
                    {...field}
                    variant="bordered"
                    labelPlacement="outside"
                    label={
                      <div className="flex gap-2 items-center">
                        <p
                          className={cn(
                            "text-sm text-black",
                            errors && !!errors?.start_date ? "text-danger" : ""
                          )}
                        >
                          3. What date would you like this project to begin
                          development?
                          <span className="text-red-500 pl-1">*</span>
                        </p>
                        <Tooltip
                          className="max-w-80"
                          content="For the best response to this question, estimate the time required for the development phase of this strategic initiative. It is best to determine when you forecast activation in the production environment for this initiative then deduct the number of months required for the development phase. This should give an accurate estimate of the required development kickoff date."
                        >
                          <IconInfoCircle className="mb-1 cursor-pointer" />
                        </Tooltip>
                      </div>
                    }
                    placeholder="Please input date (mm/dd/yy)"
                    type="date"
                    isInvalid={errors && !!errors?.start_date}
                    errorMessage={errors.start_date?.message}
                    helperColor="error"
                    min={`${initialStrategyData?.data?.start_year}-01-01`}
                    max={`${Number(initialStrategyData?.data?.start_year) + 10}-12-31`}
                  />
                )}
              />
            </div>
            <div className="mt-4">
              <Controller
                name="production_date"
                control={control}
                render={({ field }) => (
                  <Input
                    {...field}
                    variant="bordered"
                    labelPlacement="outside"
                    label={
                      <div className="flex gap-2 items-center">
                        <p
                          className={cn(
                            "text-sm text-black",
                            errors && !!errors?.production_date
                              ? "text-danger"
                              : ""
                          )}
                        >
                          4. What date would you like this project to be moved
                          into production environments?
                          <span className="text-red-500 pl-1">*</span>
                        </p>
                        <Tooltip
                          className="max-w-80"
                          content="Enter the target date for release into the production environment. The production environment is simply defined as when this initiative will go live. This could be an internal or external facing initiative."
                        >
                          <IconInfoCircle className="mb-1 cursor-pointer" />
                        </Tooltip>
                      </div>
                    }
                    placeholder="Please input date (mm/dd/yy)"
                    type="date"
                    errorMessage={errors.production_date?.message}
                    isInvalid={errors && !!errors?.production_date}
                    helperColor="error"
                    min={watch("start_date")}
                    max={`${Number(initialStrategyData?.data?.start_year) + 10}-12-31`}
                  />
                )}
              />
            </div>
            <div className="mt-6">
              <Controller
                name="expected_years_productive"
                control={control}
                render={({ field }) => {
                  const displayValue = formatNumberWithCommas(field.value)
                  return (<Input
                    {...field}
                    value={displayValue}
                    variant="bordered"
                    labelPlacement="outside"
                    label={
                      <div className="flex gap-2 items-center ">
                        <p
                          className={cn(
                            "text-sm text-black",
                            errors && !!errors?.expected_years_productive
                              ? "text-danger"
                              : ""
                          )}
                        >
                          5. How many years do you expect this strategy to be reasonably ('reasonably' because this is an estimate)
                          productive?
                          <span className="text-red-500 pl-1">*</span>
                        </p>
                        <Tooltip
                          className="max-w-80"
                          content="Estimate the number of years this strategy will remain productive, considering market trends, technology lifespan, and the initiative's competitive advantage. 'Reasonably productive' means the timeframe during which the strategy is expected to generate value or meet its objectives before requiring significant updates or replacement."
                        >
                          <IconInfoCircle className="mb-1 cursor-pointer" />
                        </Tooltip>
                      </div>
                    }
                    onChange={(e) => {
                      // Remove all non-digit characters and update the form value
                      const rawValue = e.target.value.replace(/\D/g, '');
                      field.onChange(rawValue ? rawValue : '');
                    }}
                    placeholder="The value must be a number "
                    errorMessage={inputError || errors.expected_years_productive?.message}
                    isInvalid={inputError && !!inputError || !!errors?.expected_years_productive}
                    helperColor="error"
                  />
                  )
                }}
              />
            </div>
            {
              metricQuestions?.data?.questions && (
                Object.entries(metricQuestions.data.questions)
                  .filter(([key, value]) => value)
                  .map(([key, metricLabel], index) => {
                    const questionNumber = 6 + index;

                    return (
                      <div className="mt-4" key={key}>
                        <Controller
                          key={key}
                          name={key}
                          control={control}
                          defaultValue="" // Start with empty string instead of the label
                          render={({ field }) => {
                            const displayValue = formatNumberWithCommas(field.value);

                            return (
                              <Input
                                {...field}
                                value={displayValue}
                                variant="bordered"
                                labelPlacement="outside"
                                label={
                                  <div className="flex gap-2 items-center">
                                    <p className={cn(
                                      "text-sm text-black",
                                      errors?.[key] && "text-danger"
                                    )}>
                                      {questionNumber}. {metricLabel}
                                      <span className="text-red-500 pl-1">*</span>
                                    </p>
                                    <Tooltip
                                      className="max-w-80"
                                      content={
                                        key == "metric_one" ? `${metricQuestions?.data?.help_content.metric_one}`
                                          : key == "metric_two" ? `${metricQuestions?.data?.help_content.metric_two}`
                                            : key == "metric_three" ? `${metricQuestions?.data?.help_content.metric_three}`
                                              : key == "metric_four" ? `${metricQuestions?.data?.help_content.metric_four}`
                                                : key == "metric_five" ? `${metricQuestions?.data?.help_content.metric_five}`
                                                  : key == "metric_six" ? `${metricQuestions?.data?.help_content.metric_six}`
                                                    : key == "metric_seven" ? `${metricQuestions?.data?.help_content.metric_seven}`
                                                      : key == "metric_eight" ? `${metricQuestions?.data?.help_content.metric_eight}`
                                                        : "Enter the numeric value for this metric"
                                      }
                                    >
                                      <IconInfoCircle className="mb-1 cursor-pointer" />
                                    </Tooltip>
                                  </div>
                                }
                                placeholder="Enter numeric value"
                                onChange={(e) => {
                                  const rawValue = e.target.value.replace(/\D/g, '');
                                  field.onChange(rawValue || ''); // Ensure empty string if no value
                                }}
                                errorMessage={errors?.[key]?.message}
                                isInvalid={!!errors?.[key]}
                                helperColor="error"
                              />
                            );
                          }}
                        />
                      </div>

                    );
                  })
              )
            }


          </ModalBody>
          <ModalFooter>
            <Button color="danger" variant="light" onPress={onClose}>
              Cancel
            </Button>
            <Button color="primary" type="submit" isLoading={isMutating}>
              Save
            </Button>
          </ModalFooter>
        </ModalContent>
      </form>
    </Modal >
  );
}

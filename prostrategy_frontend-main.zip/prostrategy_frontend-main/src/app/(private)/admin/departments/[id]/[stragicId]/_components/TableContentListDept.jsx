import { IconInfoCircle } from "@tabler/icons-react";
import { useEffect, useState } from "react";
import useBinderUnsavedChanges from "../../../../../../../hooks/useBinderUnsavedChanges";
import UnsavedChangesBinderModal from "./UnsavedChangesBinderModal";

const formatSectionTitle = (title) => {
    return title
        .replace(/([A-Z])/g, " $1")
        .replace(/^./, (str) => str.toUpperCase())
        .replace(/([a-z])([A-Z])/g, "$1 $2");
};

const TableContentListDept = ({
    setTypingCount,
    listData,
    handlingIsGoal,
    isUserMadeChange,
    setIsUserMadeChange,
    strategicBinderId,
    activeItem,
    setActiveItem,
    handleSave,
    isSaved,
    setIsSaved,
}) => {

    // Initialize with the first item's is_goal status
    const [activeSlug, setActiveSlug] = useState(() => {
        if (listData && typeof listData === 'object') {
            const firstSection = Object.values(listData)[0];
            if (Array.isArray(firstSection) && firstSection.length > 0) {
                return firstSection[0]; // ✅ Just set the item, do not call handlingIsGoal here
            }
        }
        return null;
    });

    // Move this effect to trigger `handlingIsGoal` after mount/render
    useEffect(() => {
        if (activeSlug) {
            handlingIsGoal(activeSlug.is_goal);
            setActiveItem(activeSlug);
        }
    }, [activeSlug, handlingIsGoal, setActiveItem]);


    // Process data only if listData exists and is an object
    const processedData = listData && typeof listData === 'object'
        ? Object.entries(listData)
            .filter(([key]) => key !== "goal" && key !== "strategy" && key !== "department_name" && key !== 'strategic_binder_id')
            .reduce((acc, [key, value]) => {
                acc[key] = value;
                return acc;
            }, {})
        : {};


    const {
        showModal,
        confirmNavigation,
        cancelNavigation,
        triggerNavigation
    } = useBinderUnsavedChanges(isUserMadeChange);

    const handleItemClick = (item) => {

        const proceed = triggerNavigation(() => {
            setActiveItem(item);
            setActiveSlug(item);
            handlingIsGoal(item.is_goal);
        });

        if (proceed) {
            setActiveItem(item);
            setActiveSlug(item);
            handlingIsGoal(item.is_goal);
            setTypingCount(0);
        }
    };

    // Show loading or empty state if no data
    if (!listData || typeof listData !== 'object' || Object.keys(processedData).length === 0) {
        return (
            <div className="rounded-md w-full border-r bg-white border-gray-200 h-full flex items-center justify-center">
                <p className="text-gray-500">Loading content...</p>
            </div>
        );
    }

    return (
        <>
            {showModal && (
                <UnsavedChangesBinderModal
                    setTypingCount={setTypingCount}
                    confirmNavigation={confirmNavigation}
                    isCancelNavigation={cancelNavigation}
                    onSave={handleSave}
                    isSaved={isSaved}
                    setIsSaved={setIsSaved}
                    setIsUserMadeChange={setIsUserMadeChange}
                    strategicBinderId={strategicBinderId}
                    slug={activeItem?.slug}
                />
            )}
            <div className="rounded-md w-full border-r bg-white border-gray-200 h-full">
                <div className="p-4">
                    <div className="space-y-4">
                        {Object.entries(processedData)?.map(([sectionKey, items]) => (
                            <div key={sectionKey} className="mb-6">
                                <h2 className="text-lg font-semibold mb-2 text-gray-800">
                                    {formatSectionTitle(sectionKey)}
                                </h2>
                                <div className="space-y-1">
                                    {Array.isArray(items) ? (
                                        items.map((item) => {
                                            const isActive = item.slug === activeSlug?.slug;
                                            return (
                                                <div
                                                    key={item.slug}
                                                    data-active={isActive ? "true" : "false"}
                                                    data-goal={item?.is_goal}
                                                    onClick={() => handleItemClick(item)}
                                                    className={`flex items-center p-3 rounded-md cursor-pointer transition-colors ${isActive ? "bg-blue-50" : "hover:bg-gray-50"
                                                        }`}
                                                >
                                                    <div className="mr-3 relative flex items-center">
                                                        <div className="group">
                                                            <IconInfoCircle
                                                                size={20}
                                                                className={`${isActive ? "text-blue-500" : "text-gray-400"
                                                                    } hover:text-blue-400 transition-colors duration-200 cursor-pointer`}

                                                            />

                                                            <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 z-50 w-64 p-3 text-sm text-gray-700 bg-white border border-gray-200 rounded-md shadow-lg pointer-events-none">
                                                                {item.help_text}
                                                            </div>

                                                        </div>
                                                    </div>
                                                    <span className="text-gray-700">{item.name}</span>
                                                </div>
                                            );
                                        })
                                    ) : null}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </>
    );
};

export default TableContentListDept;
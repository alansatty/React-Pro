import React from 'react'
import { SuperAdminActionlist } from './SuperAdminActionlist'

const StrategicMonitorList = () => {
    return (
        <SuperAdminActionlist />
    )
}

export default StrategicMonitorList

const StrategyEditorBinderDept = () => {
    return (
        <div>StrategyEditorBinderDept</div>
    )
}

export default StrategyEditorBinderDept
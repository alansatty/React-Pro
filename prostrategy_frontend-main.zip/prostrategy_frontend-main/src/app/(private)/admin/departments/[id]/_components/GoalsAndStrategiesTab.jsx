import { useState, useEffect, useMemo, useCallback } from "react";
import { IconPlus, IconTrash } from "@tabler/icons-react";
import { Spinner } from "@nextui-org/spinner";
import { Button } from "@nextui-org/button";
import { mutate } from "swr";
import Swal from "sweetalert2/dist/sweetalert2.js";
import withReactContent from "sweetalert2-react-content";
import { useParams } from "react-router-dom";
import usePermissionsStore from "../../../../../../stores/usePermissionStore";
import useTabNavigation from "../../../../../../hooks/useTabNavigation";
import useApi from "../../../../../../hooks/useApi";
import { apiList } from "../../../../../../services";
import debounce from "lodash.debounce";
import toast from "react-hot-toast";
import ProstrategyLogo from "../../../../../../assets/icons/ProstrategyLogo";
import ConfirmationModal from "../../../../../../components/ConfirmationModal/ConfirmationModal";
import { cn } from "../../../../../../utils/twMege";
import { PermissionWrapper } from "../../../../../../components";
import StrategicInputs from "./StrategicInputs";
import hasPermission from "../../../../../../utils/hasPermission";
const MySwal = withReactContent(Swal);

export default function GoalsAndStrategiesTab() {
  const { id } = useParams();
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
  localStorage.setItem("oldstrategicPlan", strategicPlan);

  const [goals, setGoals] = useState([]);
  const [fullAIResponse, setFullAIResponse] = useState([]);
  const [fullAIStrategies, setFullAIStrategies] = useState([]);
  const [AIError, setAIError] = useState(null);
  const [activeGoalIndex, setActiveGoalIndex] = useState(0);
  const [isActiveSelected, setIsActiveSelected] = useState(false)
  const [isEditing, setIsEditing] = useState(false);
  const [debouncedDescription, setDebouncedDescription] = useState("");
  const [isConfirmModalOpen, setConfirmModalOpen] = useState(false);
  const [goalToDelete, setGoalToDelete] = useState({ index: null, id: null })
  const [formIsDirty, setFormIsDirty] = useState(false);
  const [isAddBtnClick, setAddBtnClick] = useState(false)

  const {
    showModal,
    targetTab,
    isNavigating,
    handleTabClick,
    confirmTabChange,
    cancelTabChange
  } = useTabNavigation(formIsDirty);

  useEffect(() => {
    if (isNavigating) {
      setActiveGoalIndex(targetTab);
      setFormIsDirty(false);
      setIsActiveSelected(!isActiveSelected);
    }
  }, [isNavigating, targetTab, isActiveSelected]);

  const updateFormDirtyState = (isDirty) => {
    setFormIsDirty(isDirty);
  };


  const handleTabNavigation = (index) => {
    const canNavigate = handleTabClick(index)
    if (canNavigate) {
      setIsActiveSelected(!isActiveSelected)
    }
  }

  useEffect(() => {
    if (!formIsDirty && isAddBtnClick) {
      addNewGoal()
      setAddBtnClick(false);
    }
  }, [formIsDirty, isAddBtnClick])


  const {
    data: apiData,
    error,
    isLoading,
  } = useApi(
    apiList.admin.departmentStrategies.get_saved.key(id, strategicPlan),
    apiList.admin.departmentStrategies.get_saved.call(id, strategicPlan)
  );

  const { trigger: genaratedAiHelp, isMutating: AILoading } = useApi(
    null,
    apiList.admin.departmentStrategies.genarate.call(),
    { method: "POST" }
  );

  const { trigger: genaratedAiStrategies, isMutating: AIStrategiesLoading } =
    useApi(null, apiList.admin.departmentStrategies.genarateStrategies.call(), {
      method: "POST",
    });

  const { trigger: SaveStrategies, isMutating } = useApi(
    null,
    apiList.admin?.departmentStrategies?.save.call(),
    { method: "POST" }
  );


  const getAIStatements = async () => {
    try {
      const bodyData = {
        strategic_plan_id: strategicPlan,
        department: id,
      };

      let data = await genaratedAiHelp({ requestBody: bodyData });
      if (data?.data?.length > 0) {
        setFullAIResponse(data?.data);
      }
    } catch (error) {
      console.log(error);
      if (error?.status === 'error') {
        if (error?.msg?.includes("SWOT")) {
          setAIError("SWOT");
        } else {
          setAIError("SVA");
        }
      }
    }
  };

  const getAIStrategies = async () => {
    try {
      const bodyData = {
        strategic_plan_id: strategicPlan,
        department: id,
        goal: goals[activeGoalIndex]?.description,
      };

      let data = await genaratedAiStrategies({ requestBody: bodyData });

      if (data?.data?.length > 0) {
        setFullAIStrategies(data?.data);
      }
    } catch (error) {
      console.log('error ', error);

      if (error?.message.includes("SWOT")) {
        setAIError("SWOT");
      } else if (error?.message.includes("SVA")) {
        setAIError("SVA");
      }
    }
  };

  const debouncedGetAIStrategies = useMemo(
    () => debounce(getAIStrategies, 800), // 800ms delay
    []
  );

  const addNewGoal = () => {
    if (goals.length < 20) {
      setGoals([
        ...goals,
        {
          id: null,
          title: `Goal ${goals.length + 1}`,
          description: "",
          strategies: Array(10).fill(""),
        },
      ]);
      setActiveGoalIndex(goals.length);
    }
  };

  const handleAddGoalButton = () => {
    if (formIsDirty) {
      setAddBtnClick(true)
      handleTabNavigation()
    } else {
      addNewGoal()
      setAddBtnClick(false)
    }
  }

  const handleGoalChange = useCallback(
    (description) => {
      const updatedGoals = [...goals];
      updatedGoals[activeGoalIndex].description = description;
      setGoals(updatedGoals);

      setDebouncedDescription(description);
      debouncedGetAIStrategies(); // Call debounced function
    },
    [goals, activeGoalIndex, debouncedGetAIStrategies]
  );

  const handleStrategyChange = (index, value) => {
    const updatedGoals = [...goals];

    if (updatedGoals[activeGoalIndex].strategies[index]?.id) {
      updatedGoals[activeGoalIndex].strategies[index].text = value;
    } else {
      updatedGoals[activeGoalIndex].strategies[index] = value;
    }

    setGoals(updatedGoals);
  };


  const removeGoal = (goalIndex) => {
    setGoals((prevGoals) =>
      prevGoals.filter((_, index) => index !== goalIndex)
    );
  };

  const { trigger: DeleteGoalsAndStrategies, isMutating: deleteMutation } = useApi(
    null,
    apiList.admin?.departmentStrategies?.delete_goal_and_strategies.call(),
    { method: "DELETE" },
  );

  const handleDeleteGoalsAndStrategies = (index, goalId, e) => {
    e.stopPropagation();
    setGoalToDelete({ index, id: goalId });
    setConfirmModalOpen(true);
  };

  const confirmDeleteGoal = async () => {
    try {
      if (goalToDelete.id) {
        removeGoal(goalToDelete.index);
        await DeleteGoalsAndStrategies({
          requestBody: { goal_id: goalToDelete.id }
        });
      } else {
        removeGoal(goalToDelete.index);
      }
      if (activeGoalIndex >= goals.length - 1) {
        setActiveGoalIndex(Math.max(0, goals.length - 2));
      }
      setConfirmModalOpen(false);
    } catch (error) {
      toast.error("Error deleting goal:", error);
    }
  };


  const handleSave = async (formData) => {
    try {
      let updatedFromData = { ...formData, department: id };

      const { data } = await SaveStrategies({ requestBody: updatedFromData });

      // Filter out goals that have no id or empty description
      const validGoals = goals.filter(
        (goal) => goal.id && goal.description.trim()
      );

      setGoals(validGoals);
      setIsEditing(false);
      setActiveGoalIndex(0);

      mutate(
        apiList.admin.departmentStrategies.get_saved.key(id, strategicPlan)
      );
      // Refresh the data after saving
      MySwal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>

            <h2 className="text-xl font-semibold">Success!</h2>
            <p className="mt-2">{data}</p>
          </div>
        ),
        confirmButtonText: "Okay",
        customClass: {
          confirmButton: "my-confirm-button",
        },
      });
    } catch (error) {
      console.error("Error saving strategies:", error);
    }
  };

  useEffect(() => {
    getAIStatements();

    if (goals[activeGoalIndex]?.description !== "") {
      getAIStrategies();
    }
  }, [activeGoalIndex]);

  useEffect(() => {
    if (apiData?.data && apiData.data.length > 0) {

      const processedGoals = apiData.data.map((goalObj) => {
        const [goalId, title] = Object.entries(goalObj)[0];
        const strategies = goalObj.strategies.map((strategyObj) => {
          const [strategyId, strategy] = Object.entries(strategyObj)[0];
          return {
            id: strategyId,
            text: strategy,
            form_exist: strategyObj.form_exist,
            strategic_form_exists: strategyObj.strategic_form_exists,
          };
        });

        // Ensure strategies array has at least 7 elements
        while (strategies.length < 10) {
          strategies.push("");
        }

        return { id: goalId, title, description: title, strategies };
      });
      setGoals(processedGoals);
    } else {
      setGoals([
        {
          id: null,
          title: "Goal 1",
          description: "",
          strategies: Array(10).fill(""), // Initialize with 7 empty strategies
        },
      ]);
      setIsEditing(true);
    }
  }, [apiData, strategicPlan]);


  if (isLoading || !strategicPlan) {
    return (
      <div className="flex items-center justify-center h-full w-full">
        <Spinner size="md" />
      </div>
    );
  }

  if (
    hasPermission("dept_strategic_goals", "read_only") &&
    (goals.length === 0 || goals.every((goal) => !goal.id))
  ) {
    return <>Goals & Strategies Not Available for This Organization</>;
  }

  const handleModalClose = () => {
    setConfirmModalOpen(false);
  }

  return (
    <div className="grid grid-cols-3 gap-4">
      {isConfirmModalOpen && (
        <ConfirmationModal
          isOpen={isConfirmModalOpen}
          onClose={handleModalClose}
          onConfirm={confirmDeleteGoal}
          isLoading={deleteMutation}
          deleteTitle="Delete Goal"
          deleteMessage="Are you sure you want to delete this goal and all its strategies? This action cannot be undone."
          buttonText="Delete"
          buttonColor="danger"
        />
      )}
      <div className="col-span-1">
        <div className="bg-white p-4 border-e h-full rounded-none">
          <ul className="space-y-4">
            {goals.map((goal, index) => (
              <li
                key={goal.id}
                className={cn(
                  "text-gray-700 cursor-pointer py-2 px-2 rounded-lg",
                  activeGoalIndex === index
                    ? "bg-[#EBF7FF] text-appSecondary"
                    : ""
                )}
                onClick={() => handleTabNavigation(index)}
              >
                <div className="flex justify-between">
                  <label>{goal.title}</label>
                  <button
                    type="button"
                    disabled={goals.length == 1}
                    onClick={(e) => handleDeleteGoalsAndStrategies(index, goal?.id, e)}
                    className={`${goals.length == 1 ? "text-danger-100" : "text-danger-500"}`}
                  >
                    <IconTrash />
                  </button>
                </div>
              </li>
            ))}
          </ul>
          <PermissionWrapper
            resource={"dept_strategic_goals"}
            actions={["edit"]}
          >
            {goals.length < 20 && (
              <Button
                size="sm"
                onClick={handleAddGoalButton}
                type="submit"
                color="primary"
                radius="sm"
                className="mt-4 w-full p-2"
              >
                <IconPlus size={15} />
                <div>Add New Goal</div>
              </Button>
            )}
          </PermissionWrapper>
        </div>
      </div>
      <div className="col-span-2">
        {goals[activeGoalIndex] && (
          <StrategicInputs
            AILoading={AILoading}
            AIStrategiesLoading={AIStrategiesLoading}
            isMutating={isMutating}
            activeGoal={goals[activeGoalIndex]}
            handleSave={handleSave}
            handleStrategyChange={handleStrategyChange}
            handleGoalChange={handleGoalChange}
            strategicPlan={strategicPlan}
            fullAIResponse={fullAIResponse}
            fullAIStrategies={fullAIStrategies}
            AIError={AIError}
            isEditing={isEditing}
            setIsEditing={setIsEditing}
            isItemSelected={isActiveSelected}
            updateFormDirty={updateFormDirtyState}
            showTabChangeModal={showModal}
            confirmTabChange={confirmTabChange}
            cancelTabChange={cancelTabChange}
            handleMutate={apiList.admin.departmentStrategies.get_saved.key(id, strategicPlan)}
          />
        )}
      </div>
    </div>
  );


}

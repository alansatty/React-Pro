import { useState } from "react";
import useApi from "../../../../../../../hooks/useApi";
import { useAuth } from "../../../../../../../providers/authProviders";
import { apiList } from "../../../../../../../services";
import toast from "react-hot-toast";
import { useEffect } from "react";
import { SustainSchema } from "../../../../../../../../validationSchema/authValidation";
import { mutate } from "swr";
import hasPermission from "../../../../../../../utils/hasPermission";
import { Radio, RadioGroup } from "@nextui-org/radio";
import { IconEdit, IconInfoCircle } from "@tabler/icons-react";
import { Textarea } from "@nextui-org/input";
import { Button } from "@nextui-org/button";
import AiHelpIcon from "../../../../../../../assets/icons/aihelp-icon";
import {
  PageSpinner,
  PermissionWrapper,
} from "../../../../../../../components";
import { Card } from "@nextui-org/card";
import AiHelpDrawerSustaining from "../../../../organizationgoals/components/AiHelpDrawerSustaining";
import { Spinner } from "@nextui-org/spinner";
import { useNavigate, useParams } from "react-router-dom";
import AiHelpDrawerDepartmentSustaining from "./AiHelpDrawerDepartmentSustaining";
import Swal from "sweetalert2/dist/sweetalert2.js";
import { set } from "react-hook-form";
import useTopbarStore from "../../../../../../../stores/torbarStore";
import HelpModal from "../../../../../../../components/Topbar/HelpModal";
import {
  ObjectiveHelp,
  SustainingObjectivesHelp,
} from "../../../../../../../components/Topbar/helpComponents/Helps";
import hasPlanPermission from "../../../../../../../utils/hasPlanPermission";
import { Tooltip } from "@nextui-org/tooltip";
import usePermissionsStore from "../../../../../../../stores/usePermissionStore";
import CustomTooltip from "../../../../../../../components/CustomTooltip/CustomTooltip";
import withReactContent from "sweetalert2-react-content";
import ProstrategyLogo from "../../../../../../../assets/icons/ProstrategyLogo";
import useUnsavedChanges from "../../../../../../../hooks/useUnsavedChanges";
import UnsavedChangesModal from "../../../../../../../components/Alert/UnsavedChangesModal";
const MySwal = withReactContent(Swal);

function DepartmentSustainComponent({
  selectedValues,
  activeItem,
  details,
  setActiveItem,
  objectives,
  handleSaveLocal,
  handlePrevious,
  loadingState,
}) {
  const navigate = useNavigate();
  const auth = useAuth();
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
  const { id } = useParams();
  const { trigger: triggerSustaining, isMutating: isMutatingSustaining } =
    useApi(null, apiList.admin.departments.sustaining_objective_create.call(), {
      method: "POST",
    });

  const { trigger: businessEssentials, isMutating: BELoading } = useApi(
    null,
    apiList.admin.departments.sustainging_business_essentials.call(id, strategicPlan),
    { method: "POST" }
  );


  const [isDirty, setIsDirty] = useState(false)
  const {
    data: currentPlanData,
    error,
    isLoading: currentPlanDataLoading,
  } = useApi(
    apiList.admin.subscription.current_plan.key(),
    apiList.admin.subscription.current_plan.call()
  );

  // State for growth objective
  const [hasGrowthObjective, setHasGrowthObjective] = useState("");
  const [existingObjective, setExistingObjective] = useState("");
  const [objectiveDetails, setObjectiveDetails] = useState("");
  const [editMode, setEditMode] = useState(false);
  const [loading, setLoading] = useState(true);
  const [fullBusinessEssentials, setFullBusinessEssentials] = useState([]);
  const [isEditable, setIsEditable] = useState(null);
  const [statements, setStatements] = useState([]);
  const [drawerStep, setDrawerStep] = useState(1);
  const [isOpen, setIsOpen] = useState(false);
  const [businessEssentialData, setBusinessEssentialData] = useState([]);
  const [getMoreCount, setGetMoreCount] = useState(0);
  const [selectedBusinessEssentials, setSelectedBusinessEssentials] = useState(
    []
  );
  const [sustainError, setSustainError] = useState(null);
  const [selectedStatement, setSelectedStatement] = useState(null);
  const [isMutatingSave, setIsMutatingSave] = useState(false);
  const [savedValue, setsavedValue] = useState("");

  const { subtitle, setSubtitle } = useTopbarStore();
  const [customLoading, setCustomLoading] = useState(false)


  const [pendingNavigation, setPendingNavigation] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [editClicked, setEditClicked] = useState(false);

  const handleTabClick = (item) => {
    if (isDirty) {
      setSelectedItem(item)
      setPendingNavigation(true)
    } else {
      setActiveItem(item)
    }
  }


  useEffect(() => {
    if (selectedBusinessEssentials.length > 0) {
      setIsDirty(true)
    } else {
      setIsDirty(false)
    }
  }, [selectedBusinessEssentials])


  const handleNavigationConfirm = (shouldNavigate) => {
    if (shouldNavigate) {
      if (editClicked) {

        handlePrevious();
        setEditClicked(false);
      } else {

        setActiveItem(selectedItem);
      }
      setIsDirty(false);
    }

    setPendingNavigation(false);
    setEditClicked(false);
  };


  const handleEditButtonClick = () => {
    if (isDirty) {
      setEditClicked(true);
      setPendingNavigation(true);
    } else {

      handlePrevious();
    }
  };

  const {
    showModal,
    confirmNavigation,
    cancelNavigation
  } = useUnsavedChanges(isDirty, pendingNavigation, handleNavigationConfirm);


  const toggleDrawer = () => {
    if (getMoreCount == 0) useBusinessEssentials();
    if (fullBusinessEssentials.length > 0 || BELoading) {
      setIsOpen((prev) => !prev);
    } else {
      // toast.error("Please update the Settings to get AI Help.");
      MySwal.fire({
        html: (
          <div className="flex flex-col items-center">
            {/* Logo at the top */}
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>
            {/* Title inside HTML (instead of Swal's title property) */}
            <h2 className="text-xl font-semibold">Warning!</h2>
            <p className="mt-2">Please update the Settings to get AI Help.</p>
          </div>
        ),
        confirmButtonText: "Go to Settings",
        customClass: {
          confirmButton: "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
        },
      }).then((result) => {
        if (result.isConfirmed) {
          navigate("/settings/organization_tab"); // Navigate to the settings page
        }
      });

    }
  };
  const getBusinessEssentials = async () => {
    try {
      const bodyData = {
        organization_goal: "sustaining_objective",
        sustaining_objective: activeItem?.name,
      };

      let response = await businessEssentials({ requestBody: bodyData });
      setFullBusinessEssentials(response?.data);
    } catch (error) {
      console.log(error);
      // setIsOpen((prev) => !prev);
      // toast.error(error.data.message);
    }
  };
  // AI Help logic could be here

  useEffect(() => {
    getBusinessEssentials();
    setGetMoreCount(0);
    setBusinessEssentialData([]);
    setDrawerStep(1);
    setSelectedStatement(null);
    setSelectedBusinessEssentials([]);
    setsavedValue("");
    // setSustainError("");
    setHasGrowthObjective("");
    setExistingObjective("");
    setIsEditable(null);

    if (details?.objective) {
      setObjectiveDetails(details?.objective);
      setsavedValue(details?.objective);
      setEditMode(true);
    } else {
      setEditMode(false);
      setObjectiveDetails("");
    }
  }, [details, activeItem]);

  useEffect(() => {
    if (!loadingState) {
      setLoading(false);
    }
    if (!BELoading) {
      if (getMoreCount == 0) useBusinessEssentials();
    }
  }, [loading, BELoading]);

  const mutateFn = async () => {
    setCustomLoading(true)
    await mutate(
      apiList.admin.departments.sustaining_objective_details
    );
    setCustomLoading(false)
  }

  useEffect(() => {
    mutateFn()
  }, [strategicPlan]);



  const useBusinessEssentials = () => {
    // Only load if more data is available and count is less than 3

    if (
      getMoreCount < 2 &&
      fullBusinessEssentials.length > businessEssentialData.length
    ) {
      const nextDataStart = getMoreCount == 0 ? getMoreCount : 15;
      const nextDataEnd = getMoreCount == 0 ? 15 : 20;


      // Append the next 4 items to the business essentials data
      setBusinessEssentialData((prevData) => [
        ...prevData,
        ...fullBusinessEssentials.slice(nextDataStart, nextDataEnd),
      ]);

      // Increment the count for more data loading
      setGetMoreCount(getMoreCount + 1);
    }
  };



  const handleSave = async () => {
    const formData = {
      department: id,
      sus_objective_id: activeItem?.id,
      content: objectiveDetails || "", // Objective details
      strategic_plan_id: strategicPlan
    };

    try {
      setIsMutatingSave(true);
      await SustainSchema.validate({ sustain: objectiveDetails });
      let response = await triggerSustaining({ requestBody: formData });
      setIsDirty(false)
      await mutate(apiList.admin.departments.sustaining_objective_details);

      //   toast.success("objective !");
      MySwal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>

            <h2 className="text-xl font-semibold">Success!</h2>
            <p className="mt-2">{response?.data}</p>
          </div>
        ),
        confirmButtonText: "Okay",
        customClass: {
          confirmButton: "my-confirm-button",
        },
      });
      setEditMode(!editMode);
    } catch (error) {
      setSustainError(error?.message); // Set the validation error message
      if (!hasGrowthObjective || !existingObjective) {
        if (error?.message) {
          toast.error(error?.message);
        }
      }
      if (error?.data?.message) {
        toast.error(error?.data?.message);
      }
    } finally {
      setIsMutatingSave(false);
    }
  };

  const handleFullStatementChange = (index, value) => {
    const updatedStatements = [...statements];
    updatedStatements[index] = value;
    setStatements(updatedStatements);
  };

  const changeEditMode = () => {
    setHasGrowthObjective("yes");
    setExistingObjective("yes");
    setEditMode(false);
  };

  const validateMission = async (value) => {
    try {
      await SustainSchema.validate({ sustain: value });
      setSustainError(null); // Clear errors if validation passes
    } catch (error) {
      console.log(error);
      setSustainError(error.message); // Set validation error
    }
  };

  const renderContent = () => {
    if (
      !hasPermission("dept_sustaining_objectives", "read_only") &&
      !hasPermission("dept_sustaining_objectives", "edit")
    ) {
      return (
        <div className="w-full col-span-2">
          {activeItem?.name} Not Available for the Department
        </div>
      );
    }

    if (
      hasPermission("dept_sustaining_objectives", "read_only") &&
      !hasPermission("dept_sustaining_objectives", "edit")
    ) {
      if (!editMode) {
        return (
          <div className="w-full col-span-2">
            {activeItem?.name} Not Available for the Department
          </div>
        );
      }
    }
    return (
      <>
        {/* Modal for Route Changes */}
        {showModal && (
          <UnsavedChangesModal
            isConfirmNavigation={confirmNavigation}
            isCancelNavigation={cancelNavigation}
          />
        )}
        {(loading || customLoading) ? (
          <div className="flex items-center justify-center h-full w-full">
            <Spinner size="md" />
          </div>
        ) : (
          <div className="col-span-2">
            {/* Question about Growth Objective */}
            <div className="flex gap-2 p-1 px-2 w-fit mb-3">
              <IconInfoCircle className="h-12 w-12" />
              <p>
                The "Department Pillars" section within the Department Goals
                tab helps you identify the key pillars for your Department's
                long-term success.
                <HelpModal
                  title={"Department Goals Pillars Tab Help"}
                  ContentComponent={() => (
                    <ObjectiveHelp type={activeItem?.name} />
                  )}
                  isReadMore={true}
                />
              </p>
              <div className="flex justify-end">
                <PermissionWrapper
                  resource={"dept_sustaining_objectives"}
                  actions={["edit"]}
                >
                  <Button
                    type="button"
                    radius="sm"
                    color="primary"
                    className="min-w-fit bg-[#0098F5]"
                    onClick={handleSave} // Call handleSave to save the growth objective
                    isLoading={isMutatingSustaining || isMutatingSave}
                  >
                    Save Changes
                  </Button>
                </PermissionWrapper>
              </div>
            </div>

            <div className="mb-6">
              <p className="mb-2">
                Does your {subtitle} currently have a {activeItem?.name}{" "}
                pillar?
              </p>
              <RadioGroup
                orientation="horizontal"
                value={hasGrowthObjective}
                // onValueChange={setHasGrowthObjective}
                className="mb-4"
                onValueChange={(value) => {
                  setHasGrowthObjective(value);
                  if (value == "no") {
                    setObjectiveDetails("");
                  }
                  if (
                    existingObjective === "yes" &&
                    value == "yes" &&
                    savedValue
                  ) {
                    setObjectiveDetails(savedValue);
                    validateMission(savedValue);
                  }
                }}
              >
                <Radio value="yes">Yes</Radio>
                <Radio value="no">No</Radio>
              </RadioGroup>

              {/* If No, show TextArea and AI Help button */}
              {hasGrowthObjective === "no" && (
                <>
                  {/* <div className="flex justify-end mb-4">
                     <Button
                       radius="sm"
                       color="primary"
                       className="mt-0 bg-[#39465F]"
                       // onClick={toggleDrawer}
                     >
                       <AiHelpIcon />
                       AI Help
                     </Button>
                   </div> */}
                  <div className="flex gap-2 items-center text-sm bg-slate-200 rounded-[8px] p-1 px-2 w-fit">
                    <IconInfoCircle className="mb-[1px] h-5 w-5" />
                    Click the{`"AI Help"`} button on the right side to generate
                    a pillar statement using AI or type manually.
                  </div>
                  <Textarea
                    label={
                      <div className="flex items-end justify-between mt-2">
                        <label htmlFor="missionStatement">
                          {activeItem?.name} Pillar{" "}
                          <span className="text-red-600 text-base ml-1">*</span>
                        </label>
                        {hasPlanPermission("department_base_goals_with_pillars_ai") ? (
                          <Button
                            radius="sm"
                            color="primary"
                            className="mt-0 bg-[#39465F]"
                            onPress={toggleDrawer}
                          >
                            <AiHelpIcon />
                            AI Help
                          </Button>
                        ) : (
                          <CustomTooltip
                            tooltipTitle="Upgrade Plan"
                            tooltipContent={
                              currentPlanData?.data?.plan_name == "Enterprise"
                                ? "Your current plan has limited features. Please Contact Admin"
                                : "Your current plan has limited features. Upgrade now to access more!"
                            }
                            buttonText={
                              currentPlanData?.data?.plan_name == "Enterprise"
                                ? null
                                : "Go to Plans"
                            }
                            navigateTo="/settings/account_tab" // The route to navigate
                          />
                        )}
                      </div>
                    }
                    placeholder={`Enter your ${activeItem?.name} Pillar`}
                    variant="bordered"
                    labelPlacement="outside"
                    radius="sm"
                    value={objectiveDetails}
                    onChange={(e) => {
                      validateMission(e.target.value);
                      setObjectiveDetails(e.target.value);
                      setIsDirty(true)
                    }}
                    isInvalid={sustainError ? true : false}
                    errorMessage={sustainError}
                  />
                </>
              )}

              {/* If Yes, show follow-up question */}
              {hasGrowthObjective === "yes" && (
                <>
                  <p className="mb-2">
                    Do you want to continue with the existing {activeItem?.name}{" "}
                    pillar or create a new one?
                  </p>
                  <RadioGroup
                    orientation="horizontal"
                    value={existingObjective}
                    onValueChange={(value) => {
                      setExistingObjective(value);
                      if (value == "no") {
                        setObjectiveDetails("");
                        if (hasPlanPermission("department_base_goals_with_pillars_ai")) {
                          toggleDrawer();
                        } else {
                          toast.error("Your current plan has limited features. Upgrade now to access more!");
                        }
                      }
                      if (
                        hasGrowthObjective === "yes" &&
                        value == "yes" &&
                        savedValue
                      ) {
                        setObjectiveDetails(savedValue);
                        validateMission(savedValue);
                      }
                    }}
                    className="mb-4"
                  >
                    <Radio value="yes">Use Existing One</Radio>
                    <Radio value="no">
                      Use AI to help create a new {activeItem?.name} Pillar
                    </Radio>
                  </RadioGroup>

                  {/* If Use Existing One, show TextArea */}
                  {existingObjective === "yes" && (
                    <Textarea
                      label={`${activeItem?.name} Pillar`}
                      placeholder={`Enter your ${activeItem?.name} Pillar`}
                      variant="bordered"
                      labelPlacement="outside"
                      isRequired
                      radius="sm"
                      classNames={{
                        input: "min-h-[150px]",
                        label: "mb-2",
                        inputWrapper: [
                          "group-data-[focus=true]:border-[#0098F5]",
                          "dark:group-data-[focus=true]:border-[#0098F5]",
                        ],
                      }}
                      value={objectiveDetails}
                      onChange={(e) => {
                        e.target.value ? setIsDirty(true) : setIsDirty(false)
                        validateMission(e.target.value);
                        setObjectiveDetails(e.target.value);
                      }}
                      isInvalid={sustainError ? true : false}
                      errorMessage={sustainError}
                    />
                  )}

                  {/* If Use AI to help create new, show TextArea and AI Help button */}
                  {existingObjective === "no" && (
                    <>
                      <div className="flex gap-2 items-center text-sm bg-slate-200 rounded-[8px] p-1 px-2 w-fit">
                        <IconInfoCircle className="mb-[1px] h-5 w-5" />
                        Click the{`"AI Help"`} button on the right side to
                        generate a pillar statement using AI or type
                        manually.
                      </div>
                      <Textarea
                        label={
                          <div className="flex items-end justify-between mt-2">
                            <label htmlFor="missionStatement">
                              {activeItem?.name} Pillar
                              <span className="text-red-600 text-base ml-1">
                                *
                              </span>
                            </label>
                            {hasPlanPermission("department_base_goals_with_pillars_ai") ? (
                              <Button
                                radius="sm"
                                color="primary"
                                className="mt-0 bg-[#39465F]"
                                onPress={toggleDrawer}
                              >
                                <AiHelpIcon />
                                AI Help
                              </Button>
                            ) : (
                              <CustomTooltip
                                tooltipTitle="Upgrade Plan"
                                tooltipContent={
                                  currentPlanData?.data?.plan_name == "Enterprise"
                                    ? "Your current plan has limited features. Please Contact Admin"
                                    : "Your current plan has limited features. Upgrade now to access more!"
                                }
                                buttonText={
                                  currentPlanData?.data?.plan_name == "Enterprise"
                                    ? null
                                    : "Go to Plans"
                                }
                                navigateTo="/settings/account_tab" // The route to navigate
                              />
                            )}
                          </div>
                        }
                        labelPlacement="outside"
                        placeholder={`Enter your ${activeItem?.name} Pillar`}
                        variant="bordered"
                        radius="sm"
                        value={objectiveDetails}
                        onChange={(e) => {
                          e.target.value ? setIsDirty(true) : setIsDirty(false)
                          validateMission(e.target.value);
                          setObjectiveDetails(e.target.value);
                        }}
                        isInvalid={sustainError ? true : false}
                        errorMessage={sustainError}
                        classNames={{
                          input: "min-h-[150px]",
                          label: "mb-2",
                          inputWrapper: [
                            "group-data-[focus=true]:border-[#0098F5]",
                            "dark:group-data-[focus=true]:border-[#0098F5]",
                          ],
                        }}
                      />
                    </>
                  )}
                </>
              )}
            </div>

          </div>
        )}
      </>
    );
  };

  const renderEditModeContent = () => {
    return (
      <div className={`my-2 mb-4 w-[80%] col-span-2`}>
        <h5 className="text-gray-600 p-1">{details?.obj_name}</h5>

        <Card
          bordered
          shadow="none"
          radius="md"
          className={`p-2 bg-[#F4F7FA] w-full border text-start   border-[#E2E9F0]`}
        >
          {details?.objective}
        </Card>
        <PermissionWrapper
          resource={"dept_sustaining_objectives"}
          actions={["edit"]}
        >
          <span
            className="mt-1 text-default-500 float-end cursor-pointer"
            onClick={changeEditMode}
          >
            Edit
          </span>
        </PermissionWrapper>
      </div>
    );
  };

  if (loading || customLoading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-50vh)] w-full">
        <Spinner size="md" />
      </div>
    );
  }


  return (
    <>
      <div className="col-span-1 ">
        <div className="bg-white p-4 border-e rounded-none ">
          <ul className="space-y-4">
            {selectedValues.map((item) =>
              item.id === "dynamic_objective" &&
                typeof item.name === "object" ? (
                // If dynamic_objective has nested items, map over them
                Object.entries(item.name).map(([dynamicId, dynamicName]) => (
                  <li
                    key={dynamicId}
                    className={`text-gray-700 cursor-pointer py-2 px-2 rounded-lg ${activeItem?.id === dynamicId
                      ? "bg-[#EBF7FF] text-appSecondary"
                      : ""
                      }`}
                    onClick={() => {

                      handleTabClick({ id: dynamicId, name: dynamicName })

                    }}
                  >
                    {dynamicName}
                  </li>
                ))
              ) : (
                // Regular item rendering
                <li
                  key={item.id}
                  className={`text-gray-700 cursor-pointer py-2 px-2 rounded-lg ${activeItem?.id === item.id
                    ? "bg-[#EBF7FF] text-appSecondary"
                    : ""
                    }`}
                  onClick={() => handleTabClick(item)}
                >
                  {item.name}
                </li>
              )
            )}
          </ul>
        </div>
        <div className="flex justify-start ">
          <Button
            type="button"
            radius="sm"
            variant="light"
            color="primary"
            onClick={
              handleEditButtonClick
            }
          >
            <IconEdit />
            Edit
          </Button>
        </div>
        <AiHelpDrawerDepartmentSustaining
          drawerState={isOpen}
          setDrawerState={setIsOpen}
          title={
            <span className="font-semibold">
              AI Help -{" "}
              <span className="text-[#0098F5]">Create {activeItem?.name}</span>
            </span>
          }
          businessEssentialData={businessEssentialData}
          getBusinessEssentials={useBusinessEssentials}
          setValue={setObjectiveDetails}
          validate={validateMission}
          type={activeItem?.name}
          setDrawerOpen={setIsOpen}
          BELoading={BELoading}
          step={drawerStep}
          setStep={setDrawerStep}
          fullStatements={statements}
          setFullStatements={setStatements}
          getMoreCount={getMoreCount}
          selectedBusinessEssentials={selectedBusinessEssentials}
          setSelectedBusinessEssentials={setSelectedBusinessEssentials}
          isEditable={isEditable}
          setIsEditable={setIsEditable}
          handleFullStatementChange={handleFullStatementChange}
          selectedStatement={selectedStatement}
          setSelectedStatement={setSelectedStatement}
        // handleIsDirty={handleIsDirty}
        />
      </div>

      {
        editMode ? renderEditModeContent() : renderContent() // Render either edit mode content or regular content based on editMode state.
      }

    </>
  );
}

export default DepartmentSustainComponent;

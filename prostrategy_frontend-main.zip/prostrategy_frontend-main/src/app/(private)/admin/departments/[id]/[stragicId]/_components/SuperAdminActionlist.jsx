import { Button } from "@nextui-org/button";
import { Table, TableBody, TableCell, TableColumn, TableHeader, TableRow } from "@nextui-org/table";
import { useCallback, useEffect, useState } from "react";
import useApi from "../../../../../../../hooks/useApi";
import { apiList } from "../../../../../../../services";
import usePermissionsStore from "../../../../../../../stores/usePermissionStore";
import { PageSpinner } from "../../../../../../../components";
import toast from "react-hot-toast";
import { mutate } from "swr";
import { useNavigate, useParams } from "react-router-dom";
import useTopbarStore from "../../../../../../../stores/torbarStore";
import axios from "axios";
import Pusher from "pusher-js";
import { useAuth } from "../../../../../../../providers/authProviders";

export const SuperAdminActionlist = () => {
    const { id, strategicId } = useParams();
    const [binderId, setBinderId] = useState('');
    const [username, setUsername] = useState('');
    const [isKickout, setIsKickout] = useState(false);
    const [slug, setSlug] = useState('');
    const [isMutating, setIsMutating] = useState(false);
    const navigate = useNavigate()
    const auth = useAuth();
    const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
    const { subtitle, setSubtitle } = useTopbarStore();

    const { data, isLoading } = useApi(
        apiList.admin.departments.strategicMonitorList.key(id, strategicId, strategicPlan),
        strategicPlan ? apiList.admin.departments.strategicMonitorList.call(id, strategicId, strategicPlan) : null,
    );

    useEffect(() => {
        if (data?.binder_id) {
            setBinderId(data?.binder_id);
        }
    }, [data?.binder_id])

    useEffect(() => {
        if (data?.dept_name) {
            setSubtitle(data?.dept_name);
        }
    }, [data?.dept_name, setSubtitle]);

    const handleKickout = useCallback(async () => {
        if (!binderId || !slug) return;

        setIsMutating(true);
        try {
            await axios.post(`/organization/strategic_binder_kickout/${binderId}/?slug=${slug}`,
                {},
                { headers: { Authorization: `Bearer ${auth?.user?.token}` } }
            )
            mutate(apiList.admin.departments.strategicMonitorList.key(id, strategicId, strategicPlan));
            toast.success("User kicked out successfully");
        } catch (error) {
            toast.error("Failed to kick out user");
            console.error("Kickout error:", error);
        } finally {
            setIsMutating(false);
            setIsKickout(false);
        }
    }, [binderId, slug, id, strategicId, strategicPlan]);

    useEffect(() => {
        if (isKickout) {
            handleKickout();
        }
    }, [isKickout, handleKickout]);

    useEffect(() => {
        if (!binderId) return;
        // alert("Binder ID 1: " + binderId);
        const pusher = new Pusher(import.meta.env.VITE_PUSHER_ENV, {
            cluster: "mt1",
        });
        // alert("Binder ID 2: " + binderId);
        const channel = pusher.subscribe(binderId);
        channel.bind('user-moved', () => {

            mutate(apiList.admin.departments.strategicMonitorList.key(id, strategicId, strategicPlan));
        });

        return () => {
            channel.unbind_all();
            channel.unsubscribe();
            pusher.disconnect();
        };
    }, [binderId, id, strategicId, strategicPlan]);


    if (isLoading) return <PageSpinner />;

    return (
        <>
            <div className="w-full bg-white rounded-md border-r border-gray-200 p-4 border-b mb-4">
                <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
                    <div className="space-y-4 flex-1">

                        <Button
                            onClick={() => navigate(`/departments/${id}/goals_and_strategies_tab`)}
                            className={`bg-default text-black px-8 self-end`}
                        >
                            Back
                        </Button>
                        <div>
                            <span className="font-medium text-gray-700">Goal : </span>
                            <span className="text-gray-800">{data?.goal}</span>
                        </div>
                        <div>
                            <span className="font-medium text-gray-700">Strategy : </span>
                            <span className="text-gray-800">{data?.strategy}</span>
                        </div>
                    </div>
                </div>
            </div >
            <Table aria-label="User action list">
                <TableHeader>
                    <TableColumn>NAME</TableColumn>
                    <TableColumn>USERNAME</TableColumn>
                    <TableColumn>ACTION</TableColumn>
                </TableHeader>
                <TableBody>
                    {data?.data?.map((item) => (
                        <TableRow key={item.slug}>
                            <TableCell>{item?.name}</TableCell>
                            <TableCell>{item.username || '-'}</TableCell>
                            <TableCell>
                                {item.username ? (
                                    <Button
                                        isLoading={isMutating && username === item.username}
                                        onPress={() => {

                                            setSlug(item?.slug);
                                            setUsername(item?.username);
                                            setIsKickout(true);
                                        }}
                                        color="error"
                                        style={{ color: 'white', backgroundColor: "#E66A6A" }}
                                        size="sm"
                                    >
                                        Kickout
                                    </Button>
                                ) : ('-')}
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </>
    );
};
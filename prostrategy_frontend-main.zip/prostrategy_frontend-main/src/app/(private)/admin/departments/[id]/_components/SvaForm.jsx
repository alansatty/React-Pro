import { useState, useEffect, useRef } from "react";
import { cn } from "../../../../../../utils/twMege";
import useApi from "../../../../../../hooks/useApi";
import { apiList } from "../../../../../../services";
import { useParams, useSearchParams } from "react-router-dom";
import { SvaCriterias } from "./SvaCriterias";
import { Spinner } from "@nextui-org/spinner";
import usePermissionsStore from "../../../../../../stores/usePermissionStore";
import { mutate } from "swr";
import useTabNavigation from "../../../../../../hooks/useTabNavigation";

function SvaForm() {

  const { id } = useParams();
  const [customLoading, setCustomLoading] = useState(false);
  const [searchParams, setSearchParams] = useSearchParams();
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
  const hasFetchedRef = useRef(false);


  // Fetching SVA options
  const { data, isLoading } = useApi(
    apiList.admin.departments.get_sva_options.key,
    apiList.admin.departments.get_sva_options.call()
  );

  // Fetching saved criteria
  const { data: DetailsCriteria, isLoading: isLoadingDetailsCriteria } = useApi(
    apiList.admin.departments.get_saved_criterea.key(id),
    apiList.admin.departments.get_saved_criterea.call(id, strategicPlan)
  );

  const [selectedValues, setSelectedValues] = useState([]);
  const [activeItem, setActiveItem] = useState(null);
  const [formIsDirty, setFormIsDirty] = useState(false);

  // Update selectedValues from API response when data is fetched
  useEffect(() => {
    if (data?.status === "success" && data?.data?.length > 0) {
      setSelectedValues(data.data);
      setActiveItem(data.data[0]); // Set the first option as the default active item
    }
  }, [data]);

  const mutateFn = async () => {
    setCustomLoading(true);
    await mutate(apiList.admin.departments.get_saved_criterea.key(id));
    setCustomLoading(false);
  };

  useEffect(() => {
    mutateFn();
  }, [strategicPlan]);

  const {
    showModal,
    targetTab,
    isNavigating,
    handleTabClick,
    confirmTabChange,
    cancelTabChange,
  } = useTabNavigation(formIsDirty);

  useEffect(() => {
    if (isNavigating && targetTab) {
      setActiveItem(targetTab);
      setFormIsDirty(false); // Reset dirty state after navigation
    }
  }, [isNavigating, targetTab]);

  const updateFormDirtyState = (isDirty) => {
    setFormIsDirty(isDirty);
  };

  const handleTabNavigation = (item) => {
    if (activeItem?.sva_option_id !== item.sva_option_id) {
      hasFetchedRef.current = false
      handleTabClick(item);
    }
  };

  useEffect(() => {
    // Update URL whenever the active item changes
    setSearchParams({ section: activeItem?.sva_option_label });
  }, [activeItem, setSearchParams]);

  // Render the form content dynamically based on the active item
  const renderContent = () => {
    if (!activeItem || isLoadingDetailsCriteria || customLoading)
      return (
        <div className="flex items-center justify-center h-full w-full">
          <Spinner size="md" />
        </div>
      );

    // Find the criteria data for the active item
    const criteria = DetailsCriteria?.data?.find(
      (item) => item.sva_option_id === activeItem.sva_option_id
    );

    return (
      <SvaCriterias
        criteria={criteria}
        updateFormDirty={updateFormDirtyState}
        showTabChangeModal={showModal}
        confirmTabChange={confirmTabChange}
        cancelTabChange={cancelTabChange}
        hasFetchedRef={hasFetchedRef}
      />
    );
  };

  // Render a loading message while data is being fetched
  if (isLoading || isLoadingDetailsCriteria || !strategicPlan) {
    return (
      <div className="flex items-center justify-center h-full w-full">
        <Spinner size="md" />
      </div>
    );
  }

  return (
    <div className="grid grid-cols-3 gap-4">
      <div className="col-span-1">
        <div className="bg-white p-4 border-e h-full rounded-none">
          <ul className="space-y-4">
            {selectedValues.map((item) => (
              <li
                key={item.sva_option_id}
                className={cn(
                  "text-gray-700 cursor-pointer py-2 px-2 rounded-lg",
                  activeItem?.sva_option_id === item.sva_option_id
                    ? "bg-[#EBF7FF] text-appSecondary"
                    : ""
                )}
                onClick={() => handleTabNavigation(item)}
              >
                {item?.sva_option_label}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="col-span-2">{renderContent()}</div>
    </div>
  );
}

export default SvaForm;

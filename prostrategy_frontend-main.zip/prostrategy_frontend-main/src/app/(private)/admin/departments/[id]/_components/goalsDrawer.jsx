import React, { useState } from "react";
import { Button } from "@nextui-org/button";
import { Card } from "@nextui-org/card";
import { IconCircleX, IconInfoCircle, IconReload } from "@tabler/icons-react";
import SlidingPane from "react-sliding-pane";
import "react-sliding-pane/dist/react-sliding-pane.css";
import toast from "react-hot-toast";
import { Skeleton } from "@nextui-org/skeleton";
import { Accordion, AccordionItem } from "@nextui-org/accordion";

function AiHelpGoalsAndStrategiesDrawer({
  drawerState,
  setDrawerState,
  title,
  onSaveGoals,
  AIGoalData,
  AILoading,
  selectedGoal,
  setSelectedGoal,
  handleIsDirty
}) {
  const handleSelectGoals = (goal) => {
    setSelectedGoal(goal);
  };

  const useSelectedGoals = () => {
    const hasSelectedGoal = !!Object.keys(selectedGoal).length;
    if (hasSelectedGoal) {
      if (typeof handleIsDirty === "function") {
        handleIsDirty(true);
      }
      onSaveGoals(selectedGoal);
      setDrawerState(false);
    } else {
      toast.error("Please select atleast one goal.");
      if (typeof handleIsDirty === "function") {
        handleIsDirty(false);
      }
    }
  };

  return (
    <div>
      <SlidingPane
        closeIcon={
          <div>
            <span className="text-xl">
              <IconCircleX color="#11181C" className="w-12 h-12" />
            </span>
          </div>
        }
        overlayClassName="z-50 "
        width="600px"
        isOpen={drawerState}
        title={title}
        onRequestClose={() => setDrawerState(false)}
      >
        <div>

          <h5 className="text-gray-600 p-1 font-semibold">
            Based on the Department Type, Department Name, Department Description, Department Mission, Vision, Value, Pillar Definitions, Department SWOT, Department SVA with Dashboard, Organization Type, Organization Description, Organization Goals, Web Address, Geographic Market Focus, Client Training, and Organization SVA with Dashboard — here are the suggested Department Goals and supporting Strategies.

          </h5>
          <div className="flex gap-2 items-start text-sm">
            <IconInfoCircle className="mb-1 h-7 w-7" />
            <p>
              You can generate up to 3 goals and select One goal and it's 10
              Strategies from the list to create Department Goals & Strategies.
            </p>
          </div>

          <div className="mt-4 grid grid-cols-1 gap-4 max-h-[calc(78vh-30vh)] overflow-auto p-2">
            {AILoading
              ? Array.from({ length: 4 }).map((_, index) => (
                <Card
                  key={index}
                  bordered
                  shadow="none"
                  radius="md"
                  className={`p-4 border-[#E2E9F0] bg-[#F4F7FA] border`}
                >
                  <Skeleton className="rounded-lg">
                    <div className="h-10 rounded-lg bg-default-300"></div>
                  </Skeleton>
                </Card>
              ))
              : AIGoalData?.map((goalData, index) => {
                const goalTitle = goalData["goal_" + (index + 1)]; // Accessing goal dynamically
                const selectedGoalKey = Object.keys(selectedGoal)[0];

                return (
                  <Card
                    bordered
                    key={index}
                    shadow="none"
                    isPressable
                    radius="sm"
                    className={`p-2 bg-[#F4F7FA] w-full border text-start min-h-12 ${selectedGoalKey === "goal_" + (index + 1)
                      ? "border-primary border-2"
                      : "border-[#E2E9F0]"
                      }`}
                    onClick={() => handleSelectGoals(goalData)}
                  >
                    <Accordion>
                      <AccordionItem
                        key={index}
                        title={`${index + 1} : ${goalTitle}`}
                      >
                        <ul className="list-disc ml-5">
                          {goalData?.strategies?.map((strategy, sIndex) => (
                            <li key={sIndex} className="py-1">
                              {strategy}
                            </li>
                          ))}
                        </ul>
                      </AccordionItem>
                    </Accordion>
                  </Card>
                );
              })}
          </div>

          <div className="flex justify-end mt-4">
            <Button
              color="primary"
              radius="sm"
              className="capitalize"
              onClick={useSelectedGoals}
              disabled={!selectedGoal}
              isLoading={AILoading}
            >
              Use Goals & Strategies
            </Button>
          </div>
        </div>
      </SlidingPane>
    </div>
  );
}

export default AiHelpGoalsAndStrategiesDrawer;

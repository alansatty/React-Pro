import { Button } from "@nextui-org/button";
import { Card } from "@nextui-org/card";
import { Input, Textarea } from "@nextui-org/input";
import { Skeleton } from "@nextui-org/skeleton";
import { Tooltip } from "@nextui-org/tooltip";
import { IconCircleX, IconInfoCircle, IconReload } from "@tabler/icons-react";
import SlidingPane from "react-sliding-pane";
import "react-sliding-pane/dist/react-sliding-pane.css";

import toast from "react-hot-toast";
import { useEffect, useState } from "react";
import { apiList } from "../../../../../../../services";
import useApi from "../../../../../../../hooks/useApi";
import { useParams } from "react-router-dom";
import { focalPointSchema } from "../../../../../../../../validationSchema/authValidation";
import usePermissionsStore from "../../../../../../../stores/usePermissionStore";
function AiHelpDrawerDepartmentSustaining({
  drawerState,
  setDrawerState,
  title,
  subTitle = "",
  businessEssentialData,
  getBusinessEssentials,
  type,
  setValue,
  validate,
  setDrawerOpen,
  BELoading,
  step,
  setStep,
  fullStatements,
  setFullStatements,
  getMoreCount,
  selectedBusinessEssentials,
  setSelectedBusinessEssentials,
  isEditable,
  setIsEditable,
  handleFullStatementChange,
  selectedStatement,
  setSelectedStatement,
}) {
  const [userFocalPointOne, setUserFocalPointOne] = useState("");
  const [userFocalPointTwo, setUserFocalPointTwo] = useState("");
  const [userFocalPointThree, setUserFocalPointThree] = useState("");
  const [userFocalPointFour, setUserFocalPointFour] = useState("");
  const { id } = useParams();
  const [focalError, setFocalError] = useState({});
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);

  // const [selectedBusinessEssentials, setSelectedBusinessEssentials] = useState([]);

  const [statements, setStatements] = useState([]);
  const [getMoreStatement, setgetMoreStatement] = useState(0);

  useEffect(() => {
    setUserFocalPointOne("");
    setUserFocalPointTwo("");
    setUserFocalPointThree("");
    setUserFocalPointFour("");
  }, [type]);

  // Handle business essential selection
  const toggleBusinessEssential = (index) => {
    if (selectedBusinessEssentials.includes(index)) {
      // Deselect if already selected
      setSelectedBusinessEssentials(
        selectedBusinessEssentials.filter((i) => i !== index)
      );
    } else if (selectedBusinessEssentials.length >= 5) {
      // Limit selection to 5
      toast.error(
        "Selection limit exceeded. You can only choose a maximum of 5 focal points."
      );
    } else {
      // Add new selection
      setSelectedBusinessEssentials([...selectedBusinessEssentials, index]);
    }
  };

  const handleStatementChange = (index, value) => {
    const updatedStatements = [...statements];
    updatedStatements[index] = value;
    setStatements(updatedStatements);

    handleFullStatementChange(index, value);
  };

  const handleGetMore = () => {
    if (getMoreCount < 2) {
      getBusinessEssentials();
      // setGetMoreCount(getMoreCount + 1)
    } else {
      // toast.error("Maximum focal points reached!");
    }
  };

  const handleValueChange = (fieldName, setState, value) => {
    setState(value);

    // Validate the input with Yup schema
    focalPointSchema
      .validateAt(fieldName, { [fieldName]: value })
      .then(() => {
        setFocalError((prevErrors) => ({
          ...prevErrors,
          [fieldName]: "", // Set the error message for this field
        }));
      })
      .catch((err) => {
        console.log(err.message);

        setFocalError((prevErrors) => ({
          ...prevErrors,
          [fieldName]: err.message, // Set the error message for this field
        }));
      });
  };

  const generateStatement = async () => {
    selectStatement(null);
    setSelectedStatement(null);
    setIsEditable(null);

    const hasFocalErrors = (focalError) => {
      return Object.values(focalError).some((error) => error !== "");
    };

    if (hasFocalErrors(focalError)) return;

    try {
      const selectedData = selectedBusinessEssentials.map(
        (index) => businessEssentialData[index]
      ).filter(item => item);
      const userAddedPoints = [];

      [
        userFocalPointOne,
        userFocalPointTwo,
        userFocalPointThree,
        userFocalPointFour
      ].forEach(point => {
        const trimmedPoint = point?.trim();
        if (trimmedPoint) {
          userAddedPoints.push(trimmedPoint); // Use trimmed version to avoid extra spaces
        }
      });

      if (selectedData.length === 0 && userAddedPoints.length === 0) {
        toast.error(
          `Please select at least one focal point or add a focal point to generate ${type} statements`
        );
        return;
      }

      const bodyData = {
        sustaining_objective: type,
        user_selected_points: selectedData,
        user_typed_points: userAddedPoints,
        strategic_plan_id: strategicPlan,
      };

      setgetMoreStatement(0);
      setStatements([]);
      setSelectedStatement(null);

      let response = await getStatements({ requestBody: bodyData });

      setFullStatements(response?.data || []);
      setStep(2);
    } catch (error) {
      console.log(error);
      toast.error(error?.data?.message || "An error occurred while generating statements");
    }
  };

  const { trigger: getStatements, isMutating } = useApi(
    null,
    apiList.admin.departments.generate_statements.call(id),
    { method: "POST" }
  );

  const selectStatement = (index) => {
    setSelectedStatement(index);
  };

  const handleEditClick = (index) => {
    setIsEditable(index);
    selectStatement(index);
  };


  const useStatement = () => {
    if (selectedStatement !== null) {
      setValue(fullStatements[selectedStatement]);
      validate(fullStatements[selectedStatement]);
      setDrawerOpen((prev) => !prev);
    }
  };

  const statementManage = () => {
    if (getMoreStatement < 2 && fullStatements.length > statements.length) {
      const nextDataStart = getMoreStatement == 0 ? getMoreStatement : 15;
      const nextDataEnd = getMoreStatement == 0 ? 15 : 20;

      // Append the next 5 items to the business essentials data
      setStatements((prevData) => [
        ...prevData,
        ...fullStatements.slice(nextDataStart, nextDataEnd),
      ]);

      // Increment the count for more data loading
      setgetMoreStatement(getMoreStatement + 1);
    }
  };

  useEffect(() => {
    if (!isMutating) {
      if (getMoreStatement == 0) statementManage();
    }
  }, [isMutating]);

  const renderStepOne = () => (
    <div className="flex flex-col min-h-[calc(100vh-18vh)] justify-between">
      <div>
        <h5 className="text-gray-600 p-1 font-semibold leading-6">

          Based on the Department Type, Department Name, Department Description, Mission, Vision, Value, Organization Goals, Organization Description, Organization Business Targets, Web Address, Geographic Market Focus, Client Training, and Department Goals — here are the suggested focal points for generating the Department’s {type} Pillars.

        </h5>
        <div className="flex gap-2 items-center text-sm mt-1">
          <IconInfoCircle className="mb-1 h-7 w-7" />
          {/* Based on the focal points selected & ratings added to business targets in settings below are the suggested organization&apos;s {type} statements */}
          You can generate up to 20 focal points and select your top 5 from the
          suggested options. Additionally, feel free to add 4 focal points
          manually to create {type} Pillars.
        </div>

        <div className="mt-4 grid grid-cols-1 gap-4 max-h-[calc(77vh-30vh)] overflow-auto p-2">
          {BELoading
            ? Array.from({ length: 4 }).map((_, index) => (
              <Card
                key={index}
                bordered
                shadow="none"
                radius="md"
                className={`p-4 border-[#E2E9F0] bg-[#F4F7FA] border`}
              >
                <Skeleton className="rounded-lg">
                  <div className="h-10 rounded-lg bg-default-300"></div>
                </Skeleton>
              </Card>
            ))
            : businessEssentialData?.map((item, index) => (
              <Card
                key={index}
                bordered
                shadow="none"
                isPressable
                radius="md"
                className={`p-4 border bg-[#F4F7FA] text-start ${selectedBusinessEssentials.includes(index)
                  ? "border-primary border-2"
                  : "border-[#E2E9F0] "
                  }`}
                onClick={() => toggleBusinessEssential(index)}
              >
                {index + 1} : {item}
              </Card>
            ))}

          <div>
            <Input
              onValueChange={(value) =>
                handleValueChange("focalOne", setUserFocalPointOne, value)
              }
              value={userFocalPointOne}
              type="text"
              variant="bordered"
              placeholder="Important user configured focal point"
              radius="sm"
              classNames={{
                label: "text-black",
                inputWrapper: [
                  "h-12",
                  userFocalPointOne?.trim() ? "border-[#0098F5]" : "",
                  "group-data-[focus=true]:border-[#0098F5]",
                  "dark:group-data-[focus=true]:border-[#0098F5]",
                ],
              }}
              isInvalid={focalError && !!focalError?.focalOne}
            />
            {focalError?.focalOne && (
              <span className="text-tiny text-danger">
                {focalError.focalOne}
              </span>
            )}
          </div>

          <div>
            <Input
              onValueChange={(value) =>
                handleValueChange("focalTwo", setUserFocalPointTwo, value)
              }
              value={userFocalPointTwo}
              type="text"
              variant="bordered"
              placeholder="Important user configured focal point"
              radius="sm"
              classNames={{
                label: "text-black",
                inputWrapper: [
                  "h-12",
                  userFocalPointTwo?.trim() ? "border-[#0098F5]" : "",
                  "group-data-[focus=true]:border-[#0098F5]",
                  "dark:group-data-[focus=true]:border-[#0098F5]",
                ],
              }}
              isInvalid={focalError && !!focalError?.focalTwo}
            />
            {focalError?.focalTwo && (
              <span className="text-tiny text-danger">
                {focalError.focalTwo}
              </span>
            )}
          </div>

          <div>
            <Input
              onValueChange={(value) =>
                handleValueChange("focalThree", setUserFocalPointThree, value)
              }
              value={userFocalPointThree}
              type="text"
              variant="bordered"
              placeholder="Important user configured focal point"
              radius="sm"
              classNames={{
                label: "text-black",
                inputWrapper: [
                  "h-12",
                  userFocalPointThree?.trim() ? "border-[#0098F5]" : "",
                  "group-data-[focus=true]:border-[#0098F5]",
                  "dark:group-data-[focus=true]:border-[#0098F5]",
                ],
              }}
              isInvalid={focalError && !!focalError?.focalThree}
            />
            {focalError?.focalThree && (
              <span className="text-tiny text-danger">
                {focalError.focalThree}
              </span>
            )}
          </div>

          <div>
            <Input
              onValueChange={(value) =>
                handleValueChange("focalFour", setUserFocalPointFour, value)
              }
              value={userFocalPointFour}
              type="text"
              variant="bordered"
              placeholder="Important user configured focal point"
              radius="sm"
              classNames={{
                label: "text-black",
                inputWrapper: [
                  "h-12",
                  userFocalPointFour?.trim() ? "border-[#0098F5]" : "",
                  "group-data-[focus=true]:border-[#0098F5]",
                  "dark:group-data-[focus=true]:border-[#0098F5]",
                ],
              }}
              isInvalid={focalError && !!focalError?.focalFour}
            />
            {focalError?.focalFour && (
              <span className="text-tiny text-danger">
                {focalError.focalFour}
              </span>
            )}
          </div>
        </div>
      </div>

      <div className="flex justify-between mt-4">
        {getMoreCount < 2 ? (
          <Tooltip content="Get 5 more focal points">
            <Button
              radius="sm"
              variant="bordered"
              color="primary"
              startContent={!BELoading && <IconReload />}
              auto
              className="bg-white text-black"
              onClick={handleGetMore}
              isLoading={BELoading}
            >
              {BELoading ? "Getting" : "Get 5 more"}
            </Button>
          </Tooltip>
        ) : (
          <div></div>
        )}

        <Button
          color="primary"
          radius="sm"
          onPress={generateStatement}
          isLoading={isMutating}
          className="capitalize"
        >
          Generate {type}
        </Button>
      </div>
    </div>
  );

  const renderStepTwo = () => (
    <div className="flex flex-col min-h-[calc(100vh-18vh)] justify-between">
      <div>

        <h5 className="text-gray-600 p-1  font-semibold">
          {/* Based on the focal points selected below are the suggested department&apos;s {type}{" "}
          statements */}
          Based on the Department Type and Department Name, Department Description, Organization Type, Mission, Vision, Value, Organization Description,
          Web Address, Geographic Market Focus and Client Training,
          AI-Generated {type} Focal Points
          and User-Entered {type} Focal Points the following
          are the suggested Department's {type} statements

        </h5>
        <div className="flex gap-2 items-start text-sm">
          <IconInfoCircle className="mb-1 h-7 w-7" />
          <p>
            {" "}
            Select a suggested {type} statement or edit any suggested {type}{" "}
            statement & click{" "}
            <span className="capitalize">{`"Use ${type}"`}</span>{" "}
          </p>
        </div>
        <div className="max-h-[calc(77vh-30vh)] overflow-auto p-2">
          {statements.map((statement, index) => (
            <div key={index} className={`my-2 mb-4`}>
              <h5 className="text-gray-600 p-1 capitalize">
                {type} {index + 1}
              </h5>

              {isEditable == index ? (
                <Textarea
                  // autoFocus
                  value={statement}
                  variant="bordered"
                  radius="sm"
                  onChange={(e) => handleStatementChange(index, e.target.value)}
                />
              ) : (
                <Card
                  bordered
                  shadow="none"
                  isPressable
                  radius="md"
                  className={`p-2 bg-[#F4F7FA] border text-start ${selectedStatement === index
                    ? "border-primary border-2"
                    : "border-[#E2E9F0]"
                    }`}
                  onClick={() => {
                    setIsEditable(null);
                    selectStatement(index);
                  }}
                >
                  {statement}
                </Card>
              )}
              <span
                onClick={() => handleEditClick(index)}
                className="mt-1 text-default-500 float-end cursor-pointer"
              >
                {isEditable == index ? "On edit mode" : "Edit"}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="flex justify-between mt-4">
        <div className="flex gap-5">
          <Button
            radius="sm"
            variant="bordered"
            color="primary"
            auto
            className="bg-white text-black"
            onClick={() => setStep(1)}
          >
            Back
          </Button>

          {getMoreStatement < 2 ? (
            <Tooltip content="Get 5 more focal points">
              <Button
                radius="sm"
                variant="bordered"
                color="primary"
                startContent={!isMutating && <IconReload />}
                auto
                className="bg-white text-black"
                onClick={statementManage}
                isLoading={isMutating}
              >
                {isMutating ? "Getting" : "Get 5 more"}
              </Button>
            </Tooltip>
          ) : (
            <div></div>
          )}
        </div>
        <Button
          color="primary"
          radius="sm"
          className="capitalize"
          isDisabled={selectedStatement === null}
          onClick={useStatement}
        >
          Use {type}
        </Button>
      </div>
    </div>
  );
  return (
    <div>
      <SlidingPane
        closeIcon={
          <div>
            <span className="text-xl">
              {" "}
              <IconCircleX color="#11181C" className="w-12 h-12" />
            </span>
          </div>
        }
        overlayClassName="z-50 "
        width="600px"
        isOpen={drawerState}
        title={title}
        subtitle={subTitle}
        onRequestClose={() => {
          // triggered on "<" on left top click or on outside click
          setDrawerState(false);
        }}
      >
        <div>{step === 1 ? renderStepOne() : renderStepTwo()}</div>
      </SlidingPane>
    </div>
  );
}

export default AiHelpDrawerDepartmentSustaining;

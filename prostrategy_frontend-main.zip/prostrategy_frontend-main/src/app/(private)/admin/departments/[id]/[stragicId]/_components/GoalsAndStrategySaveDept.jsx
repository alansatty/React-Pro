import { Button } from "@nextui-org/button";
import { forwardRef, useEffect, useImperativeHandle, useState } from "react";
import withReactContent from "sweetalert2-react-content";
import Swal from "sweetalert2/dist/sweetalert2.js";
import ProstrategyLogo from "../../../../../../../assets/icons/ProstrategyLogo";
import usePermissionsStore from "../../../../../../../stores/usePermissionStore";
import { useLexicalComposerContext } from "@lexical/react/LexicalComposerContext";
import { apiList } from "../../../../../../../services";
import useApi from "../../../../../../../hooks/useApi";
import React from "react";
import { mutate } from "swr";
import { Tooltip } from "@nextui-org/tooltip";
import toast from "react-hot-toast";
import { IconArrowLeft, IconBackpack, IconBackspace } from "@tabler/icons-react";
import { useNavigate } from "react-router-dom";

const MySwal = withReactContent(Swal);

const GoalsAndStrategySaveDept = forwardRef(({

    id,
    reportPlanningData,
    goal,
    strategyText,
    isNotEditor,
    activeEditor,
    setActiveEditorParent,
    setIsUserMadeChange,
    activeItem,
    checkedData,
    primaryData,
    customInput,
    setTypingCount,
    setIsSaved,
    strategicBinderId,
    inputError,
    setInputError,

}, ref) => {
    const navigate = useNavigate();
    const [editor] = useLexicalComposerContext();
    const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
    const [goalText, setGoalText] = useState(
        "Increase annual sales revenue by 20% through strategic client acquisition and retention."
    );
    const [strategyState, setStrategyTextState] = useState(
        "Leverage AI tools to identify high-potential customer segments and prioritize targeted campaigns."
    );
    const [isEditable, setIsEditable] = useState(true);



    useEffect(() => {
        setIsEditable(reportPlanningData?.is_allow_edit && !reportPlanningData?.is_another_user_editing)

    }, [reportPlanningData])

    const saveTemplate = async (isAutoSave = false) => {
        let jsonContent = null;

        activeEditor.update(() => {
            const editorState = activeEditor.getEditorState();
            jsonContent = editorState.toJSON();
        });

        const saveTemplatee = async () => {
            const htmlContent = document.querySelector(".ContentEditable__root");
            if (htmlContent) {
                const wrapperDiv = document.createElement("div");
                wrapperDiv.classList.add("editor-shell");
                wrapperDiv.appendChild(htmlContent.cloneNode(true));

                wrapperDiv.querySelectorAll(".PlaygroundEditorTheme__textItalic").forEach((element) => {
                    const italicTag = document.createElement("i");
                    italicTag.innerHTML = element.innerHTML;
                    italicTag.className = element.className;
                    italicTag.style.fontStyle = "italic";
                    element.replaceWith(italicTag);
                });

                wrapperDiv.querySelectorAll("[style]").forEach((element) => {
                    const style = element.getAttribute("style");
                    if (style.includes("text-align")) {
                        const match = style.match(/text-align:\s*(left|center|right)/);
                        if (match) {
                            const alignment = match[1];
                            const alignmentClass = `text-${alignment}`;
                            element.classList.add(alignmentClass);

                            element.querySelectorAll("img").forEach((img) => {
                                if (!img.parentElement.style.textAlign) {
                                    const wrapper = document.createElement("div");
                                    wrapper.style.textAlign = alignment;
                                    wrapper.classList.add(alignmentClass);

                                    img.parentElement.insertBefore(wrapper, img);
                                    wrapper.appendChild(img);
                                }

                                img.style.display = "block";
                                img.style.marginLeft = alignment === "center" ? "auto" : alignment === "right" ? "auto" : "0";
                                img.style.marginRight = alignment === "center" ? "auto" : alignment === "left" ? "auto" : "0";
                            });
                        }
                    }
                });

                htmlContent.replaceChildren(...wrapperDiv.childNodes);
                return htmlContent.innerHTML;
            }
            return null;
        };

        await new Promise((resolve) => setTimeout(resolve, 100));

        const htmlContent = await saveTemplatee();

        const template = {
            strategic_plan_id: strategicPlan,
            value: htmlContent,
            lexical_content: JSON.stringify(jsonContent),
        };

        if (isAutoSave) {
            // Direct save without modals for auto-save
            try {
                const response = await trigger({ requestBody: template });
                if (response?.status == 400) {
                    toast.error(response?.data?.message)
                    setIsUserMadeChange(false)
                    return false;
                }
                await mutate(apiList.admin.binder_template.get.key(strategicBinderId, activeItem?.slug));
                return true;
            } catch (error) {
                console.error("Auto-save failed:", error);
                return false;
            }
        } else {
            MySwal.fire({
                html: (
                    <div className="flex flex-col items-center">
                        <div className="w-18 h-20 mb-2">
                            <ProstrategyLogo />
                        </div>
                        <h2 className="text-xl font-semibold">Saving...</h2>
                        <p className="mt-2">Please wait while we save your changes.</p>
                    </div>
                ),
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                },
            });

            try {
                const response = await trigger({ requestBody: template });
                if (response?.status == 400) {
                    toast.error(response?.data?.message)
                    setIsUserMadeChange(false)
                    return false;
                }

                Swal.close();
                MySwal.fire({
                    html: (
                        <div className="flex flex-col items-center">
                            <div className="w-18 h-20 mb-2">
                                <ProstrategyLogo />
                            </div>
                            <h2 className="text-xl font-semibold">Saved successfully!</h2>
                            <p className="mt-2">{response?.data}</p>
                        </div>
                    ),
                    allowOutsideClick: false,
                    confirmButtonText: "Okay",
                    customClass: {
                        confirmButton: "my-confirm-button",
                    },
                });

                setIsSaved(true)
                await mutate(apiList.admin.binder_template.get.key(strategicBinderId, activeItem?.slug))
                return true;
            } catch (error) {
                Swal.close();
                MySwal.fire({
                    html: (
                        <div className="flex flex-col items-center">
                            <div className="w-18 h-20">
                                <ProstrategyLogo />
                            </div>
                            <h2 className="text-xl font-semibold ">Error!</h2>
                            <p className="mt-2">Failed to save template. Please try again.</p>
                        </div>
                    ),
                    confirmButtonText: "Retry",
                });
                console.error("Error saving template:", error);
                setIsSaved(false)
                return false;
            } finally {
                activeEditor.setEditable(true);
            }
        }
    };


    const { trigger, isMutating } = useApi(
        null,
        apiList.admin.binder_template.save.call(strategicBinderId, activeItem?.slug),
        { method: "PUT" }
    );

    // {
    //     "data": {
    //         "Goal 1": {
    //             "id": "93263fc0-de7f-4d04-ba5f-5cc97c9a5501",
    //                 "value": "asdljkas;dlfjk;sadfkja;fljk",
    //                     "is_checked": true,
    //                         "is_primary": true
    //         },
    //         "Goal 2": {
    //             "id": "7ccc5582-af4f-42a6-b2ce-161761ba941c",
    //                 "value": ";lkjsdf; dsflkjasd;fjkasdf",
    //                     "is_checked": false,
    //                         "is_primary": false
    //         },
    //         "custom_input": ""
    //     },
    //     "is_another_user_editing": false,
    //         "strategy_binder_id": "fb11b997-e9cc-477d-bdb2-be2bc07c157b",
    //             "department_strategy_id": "a8f1d95b-1cb5-4772-a6ef-5b2e0163b54a",
    //                 "is_allow_edit": true,
    //                     "is_goal_or_pillar": "goal"
    // }

    const savePillerGoals = async (isAutoSave = false) => {
        try {
            if (inputError) {
                return false
            }

            if (reportPlanningData?.is_goal_or_pillar === 'goal') {
                // const hasCustomInput = Boolean(reportPlanningData.data['custom_input'])
                const hasGoals = Object.keys(reportPlanningData.data).some(item => item !== 'custom_input')

                if (hasGoals) {
                    if (!checkedData?.includes(primaryData)) {
                        toast.error("You must select one of your chosen goals as primary");
                        return;
                    }

                }

            }
            const template = {};
            for (const key in reportPlanningData?.data) {
                const item = { ...reportPlanningData?.data[key] }
                item.is_checked = checkedData?.includes(item?.id)
                item.is_primary = primaryData === item?.id
                template[key] = item
            }



            if (customInput?.trim() !== '') {
                template['custom_input'] = customInput
            } else {
                template['custom_input'] = ''
            }

            if (isAutoSave) {
                // Direct save without modals for auto-save
                try {
                    await trigger({ requestBody: template });
                    await mutate(apiList.admin.binder_template.get.key(strategicBinderId, activeItem?.slug));
                    return true;
                } catch (error) {
                    console.error("Auto-save failed:", error);
                    return false;
                }
            } else {
                MySwal.fire({
                    html: (
                        <div className="flex flex-col items-center">
                            <div className="w-18 h-20 mb-2">
                                <ProstrategyLogo />
                            </div>
                            <h2 className="text-xl font-semibold">Saving...</h2>
                            <p className="mt-2">Please wait while we save your changes.</p>
                        </div>
                    ),
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    },
                });

                try {
                    const response = await trigger({ requestBody: template });
                    Swal.close();
                    MySwal.fire({
                        html: (
                            <div className="flex flex-col items-center">
                                <div className="w-18 h-20 mb-2">
                                    <ProstrategyLogo />
                                </div>
                                <h2 className="text-xl font-semibold">Saved successfully!</h2>
                                <p className="mt-2">{response?.data}</p>
                            </div >
                        ),
                        allowOutsideClick: false,
                        confirmButtonText: "Okay",
                        customClass: {
                            confirmButton: "my-confirm-button",
                        },
                    });
                    setIsSaved(true)
                    await mutate(apiList.admin.binder_template.get.key(strategicBinderId, activeItem?.slug))
                    return true
                } catch (error) {
                    Swal.close();
                    MySwal.fire({
                        html: (
                            <div className="flex flex-col items-center">
                                <div className="w-18 h-20">
                                    <ProstrategyLogo />
                                </div>
                                <h2 className="text-xl font-semibold ">Error!</h2>
                                <p className="mt-2">Failed to save template. Please try again.</p>
                            </div>
                        ),
                        confirmButtonText: "Retry",
                    });
                    console.error("Error saving template:", error);
                    setIsSaved(false)
                } finally {
                    activeEditor.setEditable(true);
                }
            }

        } catch (error) {
            console.log("error", error);

        }
    };

    const handleSave = async (isAutoSave = false) => {
        if (!isEditable) return;
        try {
            let success;
            if (isNotEditor) {
                success = await savePillerGoals(isAutoSave);
            } else {
                success = await saveTemplate(isAutoSave);
            }
            if (success) {
                setTypingCount(0);
                setIsUserMadeChange(false);
                return success
            }

            return false;
        } catch (error) {
            console.error("Save failed:", error);
            return false; // Indicate failure
        }
    };

    useImperativeHandle(ref, () => ({
        handleSave
    }));

    useEffect(() => {
        if (editor) {
            setActiveEditorParent(activeEditor);
        }
    }, [setActiveEditorParent, editor]);


    return (
        <div className="w-full bg-white rounded-md border-r border-gray-200 p-4 border-b mb-4">
            <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
                <div className="space-y-4 flex-1">

                    <Button
                        onClick={() => navigate(`/departments/${id}/goals_and_strategies_tab`)}
                        className={`bg-default text-black px-8 self-end`}
                    >
                        Back
                    </Button>
                    <div>
                        <span className="font-medium text-gray-700">Goal : </span>
                        <span className="text-gray-800">{goal ? goal : goalText}</span>
                    </div>
                    <div>
                        <span className="font-medium text-gray-700">Strategy : </span>
                        <span className="text-gray-800">{strategyText ? strategyText : strategyState}</span>
                    </div>
                </div>
                {!isEditable &&
                    !reportPlanningData?.is_allow_edit
                    || reportPlanningData?.is_another_user_editing ? (
                    <Tooltip content={!isEditable &&
                        (reportPlanningData?.is_allow_edit ?
                            "You don't have edit permissions" :
                            "Another user is currently editing")}>
                        <Button
                            disabled={!isEditable}
                            onClick={() => handleSave(false)}
                            className={`bg-primary text-white px-8 self-end ${!isEditable ? 'opacity-50 cursor-not-allowed' : ''}`}
                        >
                            Save
                        </Button>
                    </Tooltip>

                ) : (
                    <Button
                        disabled={!isEditable}
                        onClick={() => handleSave(false)}
                        className={`bg-primary text-white px-8 self-end ${!isEditable ? 'opacity-50 cursor-not-allowed' : ''}`}
                    >
                        Save
                    </Button>
                )}
            </div>
        </div >
    );
});

export default GoalsAndStrategySaveDept;
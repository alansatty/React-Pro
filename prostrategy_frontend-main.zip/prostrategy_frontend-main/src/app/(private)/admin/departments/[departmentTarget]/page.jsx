import { useEffect, useState } from "react";
import useApi from "../../../../../hooks/useApi";
import { apiList } from "../../../../../services";
import { DepartmentBussinessForm } from "./components/DepartmentBussinessForm";
import { PageSpinner } from "../../../../../components";
import useTopbarStore from "../../../../../stores/torbarStore";
import usePermissionsStore from "../../../../../stores/usePermissionStore";
import { mutate } from "swr";
import { useParams } from "react-router-dom";

export const DepartmentTarget = () => {
  const { id } = useParams();
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
  const [customLoading, setCustomLoading] = useState(false)

  const {
    data: ratingData,
    error: ratingError,
    isLoading: ratingLoading,
  } = useApi(
    apiList.admin.settings.get_department_rating.key(id),
    apiList.admin.settings.get_department_rating.call(id, strategicPlan)
  );



  const { subtitle, setSubtitle } = useTopbarStore();
  useEffect(() => {
    setSubtitle(ratingData?.department_name || "")
  }, [ratingData])

  const mutateFn = async () => {
    setCustomLoading(true)
    await mutate(apiList.admin.settings.get_department_rating.key(id),);
    setCustomLoading(false)

  }

  useEffect(() => {
    mutateFn()
  }, [strategicPlan]);

  if (ratingLoading || customLoading) {
    return <PageSpinner />
  }
  return (
    <div>
      <DepartmentBussinessForm initialData={ratingData?.data} id={id} />
    </div>
  );
};

import { Button } from "@nextui-org/button";
import { Controller, useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import toast from "react-hot-toast";
import hasPermission from "../../../../../../utils/hasPermission";
import { IconInfoCircle } from "@tabler/icons-react";
import { FormInput } from "../../../../../../components";
import Swal from "sweetalert2/dist/sweetalert2.js";
import { apiList } from "../../../../../../services";
import useApi from "../../../../../../hooks/useApi";
import { Card } from "@nextui-org/card";
import { memo, useEffect } from "react";
import usePermissionsStore from "../../../../../../stores/usePermissionStore";
import { mutate } from "swr";
import withReactContent from "sweetalert2-react-content";
import ProstrategyLogo from "../../../../../../assets/icons/ProstrategyLogo";
const MySwal = withReactContent(Swal);
const createValidationSchema = (initialData) => {
  const shape = {};

  initialData?.forEach((section) => {
    section?.child?.forEach((item) => {
      shape[item.id] = yup
        .number()
        .typeError("Rating must be between 1 and 10")
        .required(`${item.label} is required`)
        .integer(`${item.label} must be a whole number`)
        .min(1, "Rating must be between 1 and 10")
        .max(10, "Rating must be between 1 and 10");
    });
  });

  return yup.object().shape(shape);
};
export const DepartmentBussinessForm = memo(({ initialData, id }) => {
  const validationSchema = createValidationSchema(initialData);

  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);


  const {
    control,
    handleSubmit,
    getValues,
    setError,
    reset,
    clearErrors,
    formState: { errors, isValid, isDirty },
  } = useForm({
    resolver: yupResolver(validationSchema),
    // defaultValues: initialData?.reduce((acc, section) => {
    //   section?.child?.forEach((item) => {
    //     acc[item?.id] = item?.rating || ""; // Set default values for each input
    //   });
    //   return acc;
    // }, {}),
    mode: "onChange", // Trigger validation as the user types
    reValidateMode: "onChange", // Re-validate on every change after an error
  });

  useEffect(() => {
    if (initialData) {
      const defaultValues = initialData?.reduce((acc, section) => {
        section?.child?.forEach((item) => {
          acc[item?.id] = item?.rating || "";
        });
        return acc;
      }, {});
      reset(defaultValues);
    }
    // return () => reset();
  }, [initialData, reset]);

  const { trigger, isMutating } = useApi(
    null,
    apiList.admin.settings.update_deparmten_rating.call(id),
    { method: "POST" }
  );

  const onSubmit = async (data) => {
    try {
      const updatedData = {
        ...data,
        strategic_plan_id: strategicPlan,
      };
      // Trigger the API call
      let res = await trigger({ requestBody: updatedData });
      await mutate(
        apiList.admin.settings.get_department_rating.key(id),
      );
      if (res?.data) {
        // toast.success(res.data);
        MySwal.fire({
          html: (
            <div className="flex flex-col items-center">
              <div className="w-18 h-20 mb-2">
                <ProstrategyLogo />
              </div>

              <h2 className="text-xl font-semibold">Success!</h2>
              <p className="mt-2">{res?.data}</p>
            </div>
          ),
          confirmButtonText: "Okay",
          customClass: {
            confirmButton: "my-confirm-button",
          },
        });
      }
    } catch (error) {
      // Handle API error
      console.log(error);
      toast.error("Failed to save changes.");
    }
  };

  const handleKeyDown = (e) => {
    if (
      ["e", "E", "+", "-", "."].includes(e.key) ||
      (e.key === "0" && e.target.value === "") // Prevent starting with 0
    ) {
      e.preventDefault();
    }
  };

  if (
    !hasPermission("dept_settings_business_targets", "read_only") &&
    !hasPermission("dept_settings_business_targets", "edit")
  ) {
    return <div>You have no permission to read and edit</div>;
  }
  return (
    <Card className="p-4">
      <h1 className="text-lg font-semibold px-2 mb-2">
        Department Business Targets
      </h1>
      <form onSubmit={handleSubmit(onSubmit)} noValidate>
        {/* Grid layout for sections */}
        <div className="px-1 flex gap-2 items-center">
          <IconInfoCircle className="mb-1" />
          Rate the item in each section in order of importance, with
          <span className="underline">
            1 being the least important and 10 being the most important.
          </span>
        </div>
        <div className="grid grid-cols-3 gap-4  p-2 mt-2">
          {/* Map through the initialData to create sections */}
          {initialData?.map((section) => (
            <div key={section.parent.id} className="col-span-1">
              {/* Section title */}
              <div className="w-full bg-[#EBF7FF] p-3">
                <h2 className="text-[#0098F5] font-semibold">
                  {section.parent.label}
                </h2>
              </div>

              {/* Items within each section */}
              <div className="mt-10">
                {section.child.map((item) => (
                  <div key={item.id} className="mt-3">
                    <div className=" flex justify-between items-center">
                      <div>
                        <div className="">
                          <label htmlFor={item.id}>
                            {item.label}
                            <span className="text-red-600 text-base ml-1">
                              *
                            </span>
                          </label>
                        </div>
                      </div>
                      <Controller
                        name={item.id}
                        control={control}
                        defaultValue=""
                        // rules={{
                        //   validate: (value) =>
                        //     duplicateValidate(value, section.parent.id),
                        // }}
                        render={({ field }) => (
                          <FormInput
                            {...field}
                            id={item.id}
                            fieldName={item.id}
                            type={"number"}
                            placeholder=" "
                            radius="sm"
                            variant="bordered"
                            className="w-16"
                            // onBlur={(event) =>
                            //   duplicateValidate(event, section.parent.id)
                            // }
                            classNames={{
                              // input: "min-h-[150px]",
                              label: "mb-2",
                            }}
                            // Register the input with react-hook-form
                            // register={register}
                            // errors={errors}
                            isInvalid={errors && !!errors[item?.id]}
                            onKeyDown={handleKeyDown} // Prevent invalid input
                            // Show validation error if any
                            isReadOnly={hasPermission(
                              "dept_settings_business_targets",
                              "read_only"
                            )}
                            onWheel={(e) => e.target.blur()}
                          />
                        )} />

                    </div>
                    <div className="text-xs text-danger text-end mt-1">
                      {(errors && errors[item?.id]?.message) || ""}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Button for updating changes */}
        {hasPermission("dept_settings_business_targets", "edit") && (
          <div>
            <Button
              radius="sm"
              color="primary"
              className="mt-2 bg-[#0098F5]"
              type="submit"
              isDisabled={!isValid || !isDirty}
              isLoading={isMutating}
            >
              Save Changes
            </Button>
          </div>
        )}
      </form>
    </Card>
  );
});


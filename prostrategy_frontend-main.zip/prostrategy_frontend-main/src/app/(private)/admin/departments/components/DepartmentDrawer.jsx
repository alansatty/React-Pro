import { IconSquareRoundedX } from "@tabler/icons-react";
import SlidingPane from "react-sliding-pane";
import "react-sliding-pane/dist/react-sliding-pane.css";
import { PageSpinner } from "../../../../../components";
import { DepartmentForm } from "./DepartmentForm";
import { apiList } from "../../../../../services";
import useApi from "../../../../../hooks/useApi";
export const DepartmentDrawer = ({
  drawerState,
  setDrawerState,
  title,
  subTitle = "",
  selectedId,
  page = 1,
  perPage = 10,
}) => {

  const { data, isLoading, } = useApi(
    selectedId ? apiList.admin.departments.detail.key(selectedId) : null,
    apiList.admin.departments.detail.call(selectedId)
  );

  const {
    data: DepartmentList,
    isLoading: dipartmentListLoading,
    error: dipartmentListError,
  } = useApi(
    apiList.admin.user.autoSuggestion.key,
    apiList.admin.user.autoSuggestion.call()
  );

  return (
    <div>
      <SlidingPane
        overlayClassName="z-50 "
        width="600px"
        isOpen={drawerState}
        title={<span className="font-semibold text-black">{title}</span>}
        subtitle={subTitle}
        closeIcon={
          <span className="text-xl">
            {" "}
            <IconSquareRoundedX color="#11181C" className="w-8 h-8" />
          </span>
        }
        onRequestClose={() => {
          setDrawerState(false);
        }}
      >
        {isLoading ? (
          <PageSpinner />
        ) : (
          <DepartmentForm
            departmentList={DepartmentList?.data}
            initialData={data?.data}
            setDrawerState={setDrawerState}
            selectedId={selectedId}
            page={page}
            perPage={perPage}
          />
        )}
        {/* here contnent  */}
      </SlidingPane>
    </div>
  );
};

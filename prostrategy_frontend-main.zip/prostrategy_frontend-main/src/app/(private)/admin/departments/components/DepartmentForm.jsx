
import { yupResolver } from "@hookform/resolvers/yup";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";
import { validationSchemaDepartment } from "../../../../../../validationSchema/authValidation";
import { FormInput } from "../../../../../components";
import { Textarea } from "@nextui-org/input";
import { Button } from "@nextui-org/button";
import { hoverEff } from "../../../../../stores/constants";
import useApi from "../../../../../hooks/useApi";
import { apiList } from "../../../../../services";
import { useAuth } from "../../../../../providers/authProviders";
import { mutate } from "swr";
import { Autocomplete, AutocompleteItem } from "@nextui-org/autocomplete";
import hasPermission from "../../../../../utils/hasPermission";
import usePermissionsStore from "../../../../../stores/usePermissionStore";
import AiHelpDepartmentDescription from "./AiHelpDepartmentDescription";
import { useEffect, useState } from "react";
import hasPlanPermission from "../../../../../utils/hasPlanPermission";
import AiHelpIcon from "../../../../../assets/icons/aihelp-icon";
import CustomTooltip from "../../../../../components/CustomTooltip/CustomTooltip";
import { Checkbox } from "@nextui-org/checkbox";

export const DepartmentForm = ({
  initialData,
  setDrawerState,
  selectedId,
  page,
  departmentList,
  perPage
}) => {

  const [errorMessage, setErrorMessage] = useState("");
  // AI Help state management
  const [aiHelpState, setAiHelpState] = useState({
    drawerOpen: false,
    descriptions: [],
    selectedDescription: '',
    loading: false,
    getMoreCount: 0,
    fullDescriptions: []
  });

  const [selectedFoundations, setSelectedFoundations] = useState({
    mission: false,
    vision: false,
    value: false,
    foundationalPillars: false,
    businessTargetRatings: false,
  });

  const {
    register,
    handleSubmit,
    reset,
    trigger: trigg,
    setError,
    setValue,
    getValues,
    watch,
    formState: { errors: formErrors, isDirty },
  } = useForm({
    resolver: yupResolver(validationSchemaDepartment),
    mode: "onChange",
    defaultValues: {
      departmentName: initialData?.department_name || "",
      departmentType: initialData?.department_type || "",
      departmentInformation: initialData?.department_description || "",
      organization_goals: initialData?.organization_goals ? "True" : "False",
      departmentColor: initialData?.department_color_selection || "#0098f5",
      useMission: initialData?.selected_organization_goals_data?.includes("mission") ? true : false,
      useVision: initialData?.selected_organization_goals_data?.includes("vision") ? true : false,
      useValue: initialData?.selected_organization_goals_data?.includes("value") ? true : false,
      useFoundationalPillars: initialData?.selected_organization_goals_data?.includes("organization_pillars") ? true : false,
      useBusinessTargetRatings: initialData?.selected_organization_goals_data?.includes("business_targets") ? true : false,
    },

  });

  useEffect(() => {
    if (initialData?.organization_goals) {
      setSelectedFoundations({
        mission: initialData?.selected_organization_goals_data?.includes("mission") || false,
        vision: initialData?.selected_organization_goals_data?.includes("vision") || false,
        value: initialData?.selected_organization_goals_data?.includes("value") || false,
        businessTargetRatings: initialData?.selected_organization_goals_data?.includes("business_targets") || false,
        foundationalPillars: initialData?.selected_organization_goals_data?.includes("organization_pillars") || false,
      });
    }
  }, [initialData]);

  const departmentInformation = watch("departmentInformation")

  const auth = useAuth();
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);

  const { trigger, isMutating } = useApi(
    null,
    apiList.admin.departments.create.call(auth?.user?.user_id),
    { method: "POST" } // Use PUT for editing, POST for creating
  );

  const { trigger: departmentUpdate, isMutating: departmentMutating } = useApi(
    null,
    apiList.admin.departments.update.call(selectedId),
    { method: "PUT" }
  );

  const { trigger: triggerGenerateDescription, isMutating: BELoading } = useApi(
    null,
    strategicPlan ? apiList.admin.departments.generate_description.call(strategicPlan) : null,
    { method: "POST" }
  );

  const {
    data: currentPlanData,
    error: planError,
    isLoading: currentPlanDataLoading,
  } = useApi(
    apiList.admin.subscription.current_plan.key(),
    apiList.admin.subscription.current_plan.call()
  );

  const handleFoundationChange = (name, isChecked) => {
    setErrorMessage('')
    const updatedFoundations = {
      ...selectedFoundations,
      [name]: isChecked
    }
    setSelectedFoundations(updatedFoundations)

    const formFieldName = `use${name.charAt(0).toUpperCase() + name.slice(1)}`
    setValue(formFieldName, isChecked)
  };

  const onSubmit = async (data) => {
    if (data.organization_goals === "True" &&
      !Object.values(selectedFoundations).some(val => val)) {
      setErrorMessage("Please select at least one foundation to use");
      return;
    }

    if (data) {

      try {

        const selectedGoalsData = [];

        if (selectedFoundations.mission) selectedGoalsData.push("mission");
        if (selectedFoundations.vision) selectedGoalsData.push("vision");
        if (selectedFoundations.value) selectedGoalsData.push("value");
        if (selectedFoundations.foundationalPillars) selectedGoalsData.push("organization_pillars");
        if (selectedFoundations.businessTargetRatings) selectedGoalsData.push("business_targets");

        // Prepare the form data
        const formData = {
          department_name: data.departmentName,
          department_type: data.departmentType,
          department_description: data.departmentInformation,
          department_color_selection: data.departmentColor,
          organization_goals: selectedGoalsData.length > 0,
          selected_organization_goals_data: selectedGoalsData,
        };

        if (selectedId) {
          let response = await departmentUpdate({ requestBody: formData });
          toast.success(response.msg);

          setDrawerState(false);

          mutate(apiList.admin.departments.index.key(page, perPage, strategicPlan));
          mutate(apiList.admin.departments.detail.key(selectedId));
          mutate(apiList.admin.user.autoSuggestion.key);
        } else {
          let response = await trigger({ requestBody: formData });
          toast.success(response.msg);

          setDrawerState(false);
          mutate(apiList.admin.departments.index.key(page, perPage, strategicPlan));
          mutate(apiList.admin.user.autoSuggestion.key);
        }
      } catch (error) {
        console.log(error);

        if (error?.status === "validation_errors" && error?.data) {

          const validationErrors = error.data;
          for (const [field, message] of Object.entries(validationErrors)) {
            if (field == "department_name") {
              setError("departmentName", {
                type: "manual",
                message: message,
              });
            } else {
              setError(field, { type: "manual", message: message[0] });
            }
          }
          return;
        }
        if (error?.msg) {
          toast.error(error?.msg);
        }
      }
    }
  };


  const handleGetMoreDescriptions = () => {
    if (aiHelpState.getMoreCount < 2) {
      const nextDataStart = aiHelpState.getMoreCount === 0 ? 15 : 20;
      const nextDataEnd = nextDataStart + 5; // Get next 5 descriptions

      setAiHelpState(prev => ({
        ...prev,
        descriptions: [
          ...prev.descriptions,
          ...(prev.fullDescriptions?.slice(nextDataStart, nextDataEnd) || [])
        ],
        getMoreCount: prev.getMoreCount + 1
      }));
    }
  };

  const handleSelectDescription = (description) => {
    setAiHelpState(prev => ({ ...prev, selectedDescription: description }));
  };

  const handleUseDescription = () => {
    if (!aiHelpState.selectedDescription) {
      toast.error("Please select a description first");
      return;
    }

    setValue("departmentInformation", aiHelpState.selectedDescription, {
      shouldValidate: true,
      shouldDirty: true,
      shouldTouch: true
    });

    // setUserMadeChanges(true);

    // Close drawer and reset AI state
    setAiHelpState({
      drawerOpen: false,
      descriptions: [],
      selectedDescription: '',
      loading: false,
      getMoreCount: 0,
      fullDescriptions: []
    });
  };

  const generateDescription = async () => {
    try {
      setAiHelpState(prev => ({ ...prev, loading: true }));

      const { departmentName, departmentType } = getValues();
      const formData = new FormData();
      formData.append('department_name', departmentName);
      formData.append('department_type', departmentType);
      // formData.append('department_color_selection', departmentColor);

      const response = await triggerGenerateDescription({ requestBody: formData });

      setAiHelpState(prev => ({
        ...prev,
        descriptions: response?.data?.slice(0, 15) || [],
        fullDescriptions: response?.data || [],
        loading: false,
        getMoreCount: 0
      }));

    } catch (error) {
      console.error("Error generating description:", error);
      setAiHelpState(prev => ({ ...prev, loading: false }));
      toast.error("Failed to generate descriptions");
    }
  };

  const toggleDrawer = () => {
    if (aiHelpState.drawerOpen) {
      // Closing drawer - reset selection
      setAiHelpState(prev => ({ ...prev, drawerOpen: false, selectedDescription: '' }));
    } else {
      // Opening drawer - validate fields first
      const values = getValues();
      const newErrors = {};

      if (!values.departmentName) {
        newErrors.departmentName = {
          type: 'required',
          message: 'Department name is required'
        };
      }

      if (!values.departmentType) {
        newErrors.departmentType = {
          type: 'required',
          message: 'Department type is required'
        };
      }

      if (Object.keys(newErrors).length > 0) {
        // Set errors for missing fields
        Object.entries(newErrors).forEach(([name, error]) => {
          setError(name, error);
        });

        // Show error toast
        toast.error('Please fill in required fields to generate descriptions');
        return;
      }

      // Only generate descriptions if we don't have them already
      if (aiHelpState.fullDescriptions.length === 0) {
        generateDescription();
      }

      setAiHelpState(prev => ({ ...prev, drawerOpen: true }));
    }
  };



  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate>
      <AiHelpDepartmentDescription
        drawerState={aiHelpState.drawerOpen}
        setDrawerState={(open) => setAiHelpState(prev => ({ ...prev, drawerOpen: open }))}
        title="AI Help - Department Description"
        getDescriptionWithlimitNumber={handleGetMoreDescriptions}
        onSaveDescription={handleUseDescription}
        descriptions={aiHelpState.descriptions}
        getMoreCount={aiHelpState.getMoreCount}
        BELoading={aiHelpState.loading}
        selectedDescription={aiHelpState.selectedDescription}
        setSelectedDescription={handleSelectDescription}
      />
      <div className="mb-12">
        <Autocomplete
          classNames={{
            inputWrapper: [
              "data-[focus=true]:border-[#0098F5]",
              "dark:data-[focus=true]:border-[#0098F5]",
            ],
          }}
          isClearable={false}
          selectorIcon={""}
          allowsCustomValue
          defaultInputValue={initialData?.department_name || ""}
          label={<span className="text-black">Department Name</span>}
          labelPlacement="outside"
          placeholder="Enter department name"
          variant="bordered"
          radius="sm"
          errorMessage={formErrors && formErrors?.departmentName?.message}
          color={formErrors && formErrors.departmentName ? "danger" : ""}
          isInvalid={formErrors && !!formErrors["departmentName"]}
          onInputChange={(val) => {
            setValue("departmentName", val);
            trigg("departmentName");
          }}
          defaultItems={departmentList}
          isRequired={true}
        >
          {(item) => (
            <AutocompleteItem isReadOnly key={item.id}>
              {item.name}
            </AutocompleteItem>
          )}
        </Autocomplete>
      </div>
      <FormInput
        id="departmentType"
        fieldName="departmentType"
        label="Department Type"
        type="text"
        register={register}
        isRequired={true}
        errors={formErrors}
        description={"Eg. Educational, Manufacturing,..."}
        placeholder="Enter department type"
      />
      <Textarea
        classNames={hoverEff}
        radius="sm"
        className="mt-[-20px]"
        variant="bordered"
        labelPlacement="outside"
        value={departmentInformation} // Controlled value
        onValueChange={(value) => {
          setValue("departmentInformation", value, { shouldValidate: true });
        }}
        label={
          <div className="flex items-center justify-between w-full mt-2">
            <div className="flex items-center gap-1">
              <label className="text-black">Department Description</label>
              <span className="text-red-500">*</span>
            </div>
            {hasPlanPermission("department_base_goals_with_pillars_ai") ? (
              <Button
                radius="sm"
                color="primary"
                className="mt-0 bg-[#39465F]"
                onPress={toggleDrawer}
              >
                <AiHelpIcon />
                AI Help
              </Button>
            ) : (
              <CustomTooltip
                tooltipTitle="Upgrade Plan"
                tooltipContent={
                  currentPlanData?.data?.plan_name === "Enterprise"
                    ? "Your current plan has limited features. Please Contact Admin"
                    : "Your current plan has limited features. Upgrade now to access more!"
                }
                buttonText={
                  currentPlanData?.data?.plan_name === "Enterprise"
                    ? null
                    : "Go to Plans"
                }
                navigateTo="/settings/account_tab"
              />
            )}
          </div>
        }
        placeholder="Describe what your department does or is responsible for."
        errorMessage={formErrors?.departmentInformation?.message}
        color={formErrors?.departmentInformation ? "danger" : ""}
        isInvalid={!!formErrors?.departmentInformation}
      />
      {/* Department Color Picker */}
      <div className="mt-4 flex flex-col gap-2">
        <label className="text-black text-sm" >
          Department Color
          <span className="text-red-500 ms-1">*</span>
        </label>
        <input
          type="color"
          value={watch("departmentColor")}
          onChange={(e) => setValue("departmentColor", e.target.value, { shouldValidate: true })}
          className="w-16 h-10 border border-gray-300 rounded-md cursor-pointer"
        />
        {formErrors?.departmentColor && (
          <span className="text-sm text-red-500">
            {formErrors.departmentColor.message}
          </span>
        )}
      </div>

      <div className="mt-4 space-y-4">
        <div>
          <p className="text-black text-sm mb-2">
            Would you like this Department to use the Organization Foundations for Mission, Vision, Value, Foundational Pillars and Business Target Ratings?
          </p>
          <Checkbox
            isSelected={watch("organization_goals") === "True"}
            onValueChange={(isChecked) => {
              setErrorMessage('')
              const newValue = isChecked ? "True" : "False";
              setValue("organization_goals", newValue);
              // Reset all foundation selections when unchecking
              if (!isChecked) {
                // setUseAllFoundations(false);
                setSelectedFoundations({
                  mission: false,
                  vision: false,
                  value: false,
                  foundationalPillars: false,
                  businessTargetRatings: false,
                });

                setValue("useMission", false);
                setValue("useVision", false);
                setValue("useValue", false);
                setValue("useFoundationalPillars", false);
                setValue("useBusinessTargetRatings", false);
              }
            }}
          >
            Yes, Use the Organization Foundations for all of this Department's Foundations
          </Checkbox>
        </div>

        {watch("organization_goals") === "True" && (
          <div className="space-y-4 pl-4 border-l-2 border-gray-200">
            <div className="space-y-2">
              <p className="text-sm text-gray-600">Please Use the Organization Foundations for the following areas:</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                <Checkbox
                  isSelected={selectedFoundations.mission}
                  onValueChange={(isChecked) => handleFoundationChange("mission", isChecked)}
                // isDisabled={useAllFoundations}
                >
                  Mission
                </Checkbox>
                <Checkbox
                  isSelected={selectedFoundations.vision}
                  onValueChange={(isChecked) => handleFoundationChange("vision", isChecked)}
                // isDisabled={useAllFoundations} 
                >
                  Vision
                </Checkbox>
                <Checkbox
                  isSelected={selectedFoundations.value}
                  onValueChange={(isChecked) => handleFoundationChange("value", isChecked)}
                // isDisabled={useAllFoundations}
                >
                  Value
                </Checkbox>
                <Checkbox
                  isSelected={selectedFoundations.foundationalPillars}
                  onValueChange={(isChecked) => handleFoundationChange("foundationalPillars", isChecked)}
                // isDisabled={useAllFoundations}
                >
                  Foundational Pillars
                </Checkbox>
                <Checkbox
                  isSelected={selectedFoundations.businessTargetRatings}
                  onValueChange={(isChecked) => handleFoundationChange("businessTargetRatings", isChecked)}
                // isDisabled={useAllFoundations}
                >
                  Business Target Ratings
                </Checkbox>
              </div>
            </div>
            <div className="mt-1">
              {errorMessage && (
                <span className="text-sm text-red-500">
                  {errorMessage}
                </span>
              )}
            </div>

          </div>
        )}
      </div>
      {hasPermission("department", "create") && (
        <Button
          radius="sm"
          type="submit"
          color="primary"
          className="mt-9 px-8"
          isLoading={selectedId ? departmentMutating : isMutating}
        >
          {selectedId ? "Save Changes" : "Create"}
        </Button>
      )}
    </form>
  );
};

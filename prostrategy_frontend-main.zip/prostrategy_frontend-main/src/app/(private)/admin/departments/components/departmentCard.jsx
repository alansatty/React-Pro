import { Card, CardBody } from "@nextui-org/card";
import { useEffect, useState } from "react";
import PlusIcon from "../../../../../assets/icons/plus-icon";
import {
  useDisclosure,
} from "@nextui-org/modal";
import { Button } from "@nextui-org/button";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { DepartmentSchema } from "../../../../../../validationSchema/authValidation";

import { useAuth } from "../../../../../providers/authProviders";
import useApi from "../../../../../hooks/useApi";
import toast from "react-hot-toast";
import { apiList } from "../../../../../services";
import {
  Dropdown,
  DropdownItem,
  DropdownMenu,
  DropdownTrigger,
} from "@nextui-org/dropdown";
import { IconDotsVertical } from "@tabler/icons-react";
import { mutate } from "swr";
import { useNavigate } from "react-router-dom";
import ConfirmationModal from "../../../../../components/ConfirmationModal/ConfirmationModal";
import hasPermission from "../../../../../utils/hasPermission";
import { DepartmentDrawer } from "./DepartmentDrawer";
import hasPlanPermission from "../../../../../utils/hasPlanPermission";
import Swal from "sweetalert2/dist/sweetalert2.js";
import withReactContent from "sweetalert2-react-content";
import ProstrategyLogo from "../../../../../assets/icons/ProstrategyLogo";
import usePermissionsStore from "../../../../../stores/usePermissionStore";
const MySwal = withReactContent(Swal);
const DepartmentCard = ({ page, perPage, type, value, departmentCount, search }) => {
  const [selectedItem, setSelectedItem] = useState(null);

  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);


  const navigate = useNavigate();
  const { isOpen, onOpen, onOpenChange } = useDisclosure();
  const [confirmation, setConfirmation] = useState(false);
  const auth = useAuth();
  const isEditMode = type !== "add";

  const { trigger, isMutating } = useApi(
    null,
    apiList.admin.departments.create.call(auth?.user?.user_id),
    { method: "POST" } // Use PUT for editing, POST for creating
  );

  const { trigger: departmentDelete, isMutating: isLoadingDelete } = useApi(
    null,
    apiList.admin.departments.delete.call(value?.id),
    { method: "DELETE" }
  );

  const { trigger: departmentUpdate } = useApi(
    null,
    apiList.admin.departments.update.call(value?.id),
    { method: "PUT" }
  );

  const {
    data: currentPlanData,
    error,
    isLoading: currentPlanDataLoading,
  } = useApi(
    apiList.admin.subscription.current_plan.key(),
    apiList.admin.subscription.current_plan.call()
  );

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setError,
    setValue,
  } = useForm({
    resolver: yupResolver(DepartmentSchema),
  });

  // Populate the form with existing data when editing
  useEffect(() => {
    if (isEditMode && value) {
      setValue("name", value?.name);
    }
  }, [isEditMode, value, setValue]);

  const checkPlanPermission = () => {
    if (hasPlanPermission("departments_allowed_count", departmentCount)) {
      onOpen();
    } else {
      if (
        ["Free", "Essential", "Plus"].includes(currentPlanData?.data?.plan_name)
      ) {
        MySwal.fire({
          html: (
            <div className="flex flex-col items-center">
              <div className="w-18 h-20 mb-2">
                <ProstrategyLogo />
              </div>
              <h2 className="text-xl font-semibold">Warning!</h2>
              <p className="mt-2">
                Department creation on this plan is exceeded. Please update your
                plan
              </p>
            </div>
          ),
          confirmButtonText: "Go to plans",
          customClass: {
            confirmButton:
              "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
          },
        }).then((result) => {
          if (result.isConfirmed) {
            navigate("/settings/account_tab"); // Perform navigation after clicking "Okay"
          }
        });

      } else {
        MySwal.fire({
          html: (
            <div className="flex flex-col items-center">
              <div className="w-18 h-20 mb-2">
                <ProstrategyLogo />
              </div>
              <h2 className="text-xl font-semibold">Warning!</h2>
              <p className="mt-2">
                Department creation on this plan is exceeded. please contact
                admin.
              </p>
            </div>
          ),
          confirmButtonText: "Okay",
          customClass: {
            confirmButton:
              "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
          },
        });
      }
    }
  };

  const cardContent = (type, value) => {
    const formatDate = (date) => {
      return date
        ? new Date(date)
          .toLocaleDateString("en-US", {
            year: "numeric",
            month: "short",
            day: "numeric",
          })
          .replace(",", "") // Format to "Oct-7-2024"
        : "-";
    };
    if (type === "add") {
      return (
        <div className="flex items-center justify-center w-full h-full">
          <PlusIcon />
        </div>
      );
    } else {
      return (
        <>
          <div className="font-medium flex justify-center items-center w-full h-full text-lg text-center relative">
            <div className="absolute right-0 top-0">
              {/* {(hasPermission("department", "edit") ||
                hasPermission("department", "delete")) && ( */}
              <Dropdown>
                <DropdownTrigger>
                  <Button isIconOnly variant="light" size="sm">
                    <IconDotsVertical size={18} />
                  </Button>
                </DropdownTrigger>
                <DropdownMenu aria-label="Actions">
                  <DropdownItem
                    key="dept_users"
                    onPress={() => {
                      navigate(`/departments/dept_users/${value?.id}`);
                    }}
                  >
                    Department Users
                  </DropdownItem>

                  <DropdownItem
                    key="target"
                    onPress={() => {
                      navigate(`/departments/target/${value?.id}`);
                    }}
                  >
                    Department Business Targets
                  </DropdownItem>

                  {hasPermission("department", "edit") && (
                    <DropdownItem
                      key="edit"
                      onPress={() => {
                        setSelectedItem(value?.id);
                        onOpenChange(true);
                      }}
                    >
                      Edit
                    </DropdownItem>
                  )}
                  {hasPermission("department", "delete") && (
                    <DropdownItem
                      key="delete"
                      className="text-danger"
                      color="danger"
                      onClick={confirmDeleteDepartment}
                    >
                      Delete
                    </DropdownItem>
                  )}
                </DropdownMenu>
              </Dropdown>
              {/* )} */}
            </div>
            <h4 className="truncate-1-lines">{value?.name}</h4>
          </div>
          <div className="flex justify-between">
            <div className="text-sm truncate-2-lines">
              {value?.created_by?.name}
            </div>
            <div className="text-sm">
              {formatDate(value?.created_by?.created_at)}
            </div>
          </div>
        </>
      );
    }
  };





  const deleteDepartment = async () => {
    try {
      let response = await departmentDelete();
      toast.success(response.msg);

      mutate(apiList.admin.departments.index.key(page, perPage, strategicPlan, search));
    } catch (error) {
      console.log(error);
      toast.error("Failed to delete department");
    } finally {
      setConfirmation(false);
    }
  };

  const confirmDeleteDepartment = () => {
    setConfirmation(true);
  };

  const handleOnClick = (value) => {
    if (value?.has_business_target) {
      navigate(`/departments/${value?.id}`);
    } else {
      MySwal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>

            <h2 className="text-xl font-semibold">Warning!</h2>
            <p className="mt-2">{`Please update the Business Target.`}</p>
          </div>
        ),
        confirmButtonText: `Go to Business Target`,
        customClass: {
          confirmButton:
            "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
        },
      }).then((result) => {
        if (result.isConfirmed) {
          navigate(`/departments/target/${value?.id}`);
        }
      });
    }
  };

  return (
    <>
      <Card
        // isDisabled
        isHoverable
        isPressable
        radius="sm"
        shadow="sm"
        onPress={
          type === "add" ? checkPlanPermission : () => handleOnClick(value)
        }
        className={`w-full h-36 ${type === "add" ? "cursor-pointer" : ""}`}
      >
        <DepartmentDrawer
          title={selectedItem ? "Edit Department" : "Create New Department"}
          drawerState={isOpen}
          setDrawerState={onOpenChange}
          selectedId={selectedItem}
          page={page}
          perPage={perPage}
        />
        <ConfirmationModal
          isLoading={isLoadingDelete}
          isOpen={confirmation}
          onClose={setConfirmation}
          onConfirm={deleteDepartment}
        />
        <CardBody>{cardContent(type, value)}</CardBody>
      </Card>
      {/* <Modal
        isOpen={isOpen}
        onOpenChange={onOpenChange}
        content={modalContent()}
      /> */}
    </>
  );
};

export default DepartmentCard;

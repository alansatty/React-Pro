import { Card, CardBody } from "@nextui-org/card";
import { Tab, Tabs } from "@nextui-org/tabs";
import { useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { GeneralTab } from "./components/GeneralTab";
import { SubscriptionPlanTab } from "./components/SubscriptionPlanTab";
import { BillingHistoryTab } from "./components/BillingHistoryTab";
import hasPermission from "../../../../utils/hasPermission";
import useApi from "../../../../hooks/useApi";
import { apiList } from "../../../../services";
import { PageSpinner } from "../../../../components";

export const ProfilePage = () => {
  const { tabId } = useParams();
  const navigate = useNavigate();

  const { data, isLoading } = useApi(
    apiList.admin.subscription.current_plan.key(),
    apiList.admin.subscription.current_plan.call()
  );

  let tabs = [
    {
      id: "general",
      label: "Profile",
      content: <GeneralTab />,
    },
    // {
    //   id: "subscription_plan",
    //   label: "Subscription Plan",
    //   content: <SubscriptionPlanTab data={data} />,
    // },
    // ...(hasPermission("subscription_billing_history", "has_access")
    //   ? [
    //     {
    //       id: "billing_history",
    //       label: "Billing History",
    //       content: <BillingHistoryTab />,
    //     },
    //   ]
    //   : []),
  ];

  useEffect(() => {
    // If no tab is selected in the URL, default to "Sent"
    if (!tabId) {
      navigate("/profile/general"); // Redirect to default tab
    }
  }, [tabId, navigate]);

  if (isLoading) {
    return <PageSpinner />;
  }


  return (
    <Card shadow="sm" radius="md" className="p-2">
      <CardBody>
        {/* <h2 className=" text-gray-700 font-semibold text-xl mt-2">Profile</h2> */}
        <div className="flex w-full flex-col ">
          <Tabs
            key={tabId}
            selectedKey={tabId}
            aria-label="Dynamic tabs"
            color="primary"
            items={tabs}
            size="md"
            radius="sm"
            variant="underlined"
            classNames={{
              tabList:
                "gap-8 w-full relative rounded-none p-0 border-b border-divider",
              cursor: "w-full bg-[#0098F5]",
              tab: "max-w-fit px-2 h-12",
              tabContent: "group-data-[selected=true]:text-[#0098F5]",
            }}
            onSelectionChange={(key) => {
              // if (selectedItem) setSelectedItem(null)
              navigate(`/profile/${key}`);
            }}
          >
            {(item) => (
              <Tab key={item.id} title={item.label} activ>
                <Card shadow="none" radius="sm">
                  <CardBody className="p-0">{item.content}</CardBody>
                </Card>
              </Tab>
            )}
          </Tabs>
        </div>
      </CardBody>
    </Card>
  );
};

import React, { useState } from "react";
import CustomTable from "../../../../../components/Table/CustomTable";
import { Tooltip } from "@nextui-org/tooltip";
import { IconDownload, IconEdit, IconTrash } from "@tabler/icons-react";
import useApi from "../../../../../hooks/useApi";
import { apiList } from "../../../../../services";
import { Spinner } from "@nextui-org/spinner";

export const BillingHistoryTab = () => {
  const [page, setPage] = useState(1);
  const [perPage, setPerPage] = useState(10)

  const { data, error, isLoading } = useApi(
    apiList.admin.subscription.biling_history.key(page, perPage),
    apiList.admin.subscription.biling_history.call(page, perPage)
  );

  const columns = [
    { name: "Invoice#", uid: "invoice" },
    { name: "Invoice Date", uid: "invoice_date" },
    { name: "Plan", uid: "plan" },
    { name: "Amount", uid: "amount" },
    { name: "Expiry Date", uid: "plan_end_date" },
    { name: "Payment Status", uid: "payment_status" },
    { name: "Plan Status", uid: "plan_status" },
    { name: "", uid: "actions" },
  ];

  // const billingHistory ={data:data}

  const handlePageChange = (newPage) => {
    setPage(newPage);
    // navigate(pathname + "?" + createQueryString("page", newPage));
  };

  const downloadInvoice = (url) => {
    // Only use the anchor tag to handle the download in a new tab
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', "Invoice.pdf"); // Specify the filename for the download
    link.setAttribute('target', '_blank'); // Open the link in a new tab
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link); // Remove the link after triggering the download
  };


  const renderCell = React.useCallback((roles, columnKey, pagef, rowIndex) => {

    let cellValue = roles[columnKey];
    if (!cellValue) {
      cellValue = "-";
    }
    // const queryPage = pagef ? pagef : 1;

    // const rowsPerPage = 10;
    // const slNumber = (queryPage - 1) * rowsPerPage + (rowIndex + 1);

    switch (columnKey) {
      case "actions":
        return (
          <>
            {roles.plan !== "Free" && (
              <div className="relative flex items-center gap-2">
                {/* <PermissionWrapper resource={"roles"} actions={["delete"]}> */}
                <Tooltip color="primary" content="Download Invoice">
                  <span className=" text-lg text-primary cursor-pointer active:opacity-50">
                    <IconDownload
                      onClick={() => downloadInvoice(roles.invoice_url)}
                    />
                  </span>
                </Tooltip>
                {/* </PermissionWrapper> */}
              </div>
            )}
          </>
        );
      default:
        return cellValue;
    }
  }, []);

  if (isLoading) {
    return <Spinner />;
  }


  return (
    <div>
      <h3 className="text-[#02205F] font-bold text-lg">Billing History</h3>
      <p className="text-sm text-gray-600">
        View and track your payment records
      </p>

      <CustomTable
        columns={columns}
        renderCell={renderCell}
        responceData={data}
        handlePageChange={handlePageChange}
        page={page}
        headerColor="#02205F"
        headerTextClasses="text-white"
        striped={true}
        setPage={setPage}
        perPage={perPage}
        setPerPage={setPerPage}
      />
    </div>
  );
};

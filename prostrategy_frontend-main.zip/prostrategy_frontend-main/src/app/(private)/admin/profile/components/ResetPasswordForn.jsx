import { useState } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { changePasswordValidation } from "../../../../../../validationSchema/authValidation";
import { FormInput } from "../../../../../components";
import { PassIcon } from "../../../../../assets/icons/passIcon";
import { Button } from "@nextui-org/button";
import useApi from "../../../../../hooks/useApi";
import { useAuth } from "../../../../../providers/authProviders";
import { apiList } from "../../../../../services";
import toast from "react-hot-toast";
export const ResetPasswordForm = ({ setIsUserMadeChanges }) => {
  const auth = useAuth();
  const [isPassVisible, setIsPassVisible] = useState(false);
  const [isConfirmPassVisible, setIsConfirmPassVisible] = useState(false);

  const { trigger, isMutating } = useApi(
    null,
    apiList.auth.resetPassword.call(auth?.user?.user_id),
    { method: "PUT" }
  );

  const passToggleVisibility = () => setIsPassVisible(!isPassVisible);
  const confirmPassToggleVisibility = () =>
    setIsConfirmPassVisible(!isConfirmPassVisible);

  const {
    register: registerPassword,
    handleSubmit: handlePasswordSubmit,
    reset,
    formState: { errors: passwordErrors },
  } = useForm({
    resolver: yupResolver(changePasswordValidation),
  });

  const onPasswordSubmit = async (data) => {
    if (data) {
      try {
        let response = await trigger({ requestBody: data });
        toast.success(response?.data?.msg);
        //   navigate("/login")
        setIsUserMadeChanges(false)
        reset()
      } catch (error) {
        console.error("Error:", error);
        toast.error(error.data?.msg);
      } finally {
        setIsUserMadeChanges(false)
      }
    }
  };

  return (
    <form onSubmit={handlePasswordSubmit(onPasswordSubmit)}>
      <div>
        <h2 className="text-xl font-semibold text-gray-800 mb-1">
          Change Password
        </h2>
        <p className="text-gray-600 mb-8">Update password details.</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <FormInput
            label="Password"
            placeholder="Enter Password"
            size="lg"
            type={"password"}
            className="mb-5"
            startContent={<PassIcon className="text-[#D6D9DE] me-3" />}
            isVisible={isPassVisible}
            toggleVisibility={passToggleVisibility}
            errors={passwordErrors}
            register={registerPassword}
            fieldName="new_password"
            onChange={() => setIsUserMadeChanges(true)}

          />

          <FormInput
            label="Confirm Password"
            placeholder="Enter Confirm Password"
            size="lg"
            type={"password"}
            className="mb-5"
            startContent={<PassIcon className="text-[#D6D9DE] me-3" />}
            isVisible={isConfirmPassVisible}
            toggleVisibility={confirmPassToggleVisibility}
            errors={passwordErrors}
            register={registerPassword}
            fieldName="confirm_password"
            onChange={() => setIsUserMadeChanges(true)}

          />
        </div>
        <Button
          isLoading={isMutating}
          isDisabled={isMutating}
          radius="sm"
          type="submit"
          color="primary"
          className="bg-appSecondary"
        >
          Reset Password
        </Button>
      </div>
    </form>
  );
};

import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { profileSchema } from "../../../../../../validationSchema/authValidation";
import { FormInput } from "../../../../../components";
import { UserIcon } from "../../../../../assets/icons/userIcon";
import { EmailIcon } from "../../../../../assets/icons/emailIcon";
import { Button } from "@nextui-org/button";
import useApi from "../../../../../hooks/useApi";
import { apiList } from "../../../../../services";
import { mutate } from "swr";
import Swal from "sweetalert2/dist/sweetalert2.js";
import toast from "react-hot-toast";
import { useAuth } from "../../../../../providers/authProviders";
import withReactContent from "sweetalert2-react-content";
import ProstrategyLogo from "../../../../../assets/icons/ProstrategyLogo";
import useUnsavedChanges from "../../../../../hooks/useUnsavedChanges";
import UnsavedChangesModal from "../../../../../components/Alert/UnsavedChangesModal";
import usePermissionsStore from "../../../../../stores/usePermissionStore";
import { useState } from "react";
const MySwal = withReactContent(Swal);
export const ProfileDetailsForm = ({ initialData, setIsUserMadeChanges }) => {
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
  const auth = useAuth();

  const {
    register: registerProfile,
    handleSubmit: handleProfileSubmit,
    formState: { errors: profileErrors },
    setError,
  } = useForm({
    resolver: yupResolver(profileSchema),
    mode: "onChange",
    defaultValues: {
      name: initialData?.full_Name || "",
      email: initialData?.email || "",
    },
  });


  const { trigger, isMutating } = useApi(
    null,
    apiList.admin.profile.update.call(auth?.user?.user_id),
    { method: "PUT" }
  );

  const onProfileSubmit = async (data) => {
    try {
      let res = await trigger({ requestBody: data });

      if (res?.data) {
        // toast.success(res.data);
        mutate(apiList.admin.profile.details.key(auth?.user?.user_id, strategicPlan));
        // setIsAlert(true)
        MySwal.fire({
          html: (
            <div className="flex flex-col items-center">
              <div className="w-18 h-20 mb-2">
                <ProstrategyLogo />
              </div>
              <h2 className="text-xl font-semibold">Success!</h2>
              <p className="mt-2">{res?.data}</p>
            </div>
          ),
          confirmButtonText: "Okay",
          customClass: {
            confirmButton: "my-confirm-button",
          },
        });

        setIsUserMadeChanges(false)
      }
    } catch (error) {
      // toast.error("Failed to save changes.");
      if (error?.status === "validation_errors" && error?.data) {
        const validationErrors = error.data;
        for (const [field, messages] of Object.entries(validationErrors)) {
          setError(field, { type: "manual", message: messages[0] });
        }
        return;
      }
      if (error?.status == 400) {
        toast.error(error?.data?.msg);
      }
      console.log(error);
    }
  };
  return (
    <form onSubmit={handleProfileSubmit(onProfileSubmit)} noValidate>

      <div className="mb-10">
        <h2 className="text-xl font-semibold text-gray-800 mb-1">
          Profile Details
        </h2>
        <p className="text-gray-600 mb-8">Update your personal details here.</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <FormInput
            label="Full Name"
            placeholder="John Smith"
            size="lg"
            className="mb-5"
            fieldName="name"
            type="text"
            startContent={<UserIcon className="text-[#D6D9DE] me-3" />}
            errors={profileErrors}
            register={registerProfile}
            onChange={() => setIsUserMadeChanges(true)}
          />

          <FormInput
            label="Email"
            placeholder="example@gmail.com"
            size="lg"
            className="mb-5"
            type="email"
            startContent={<EmailIcon className="text-[#D6D9DE] me-3" />}
            errors={profileErrors}
            register={registerProfile}
            fieldName="email"
            onChange={() => setIsUserMadeChanges(true)}
          />
        </div>

        <Button
          radius="sm"
          isLoading={isMutating}
          isDisabled={isMutating}
          type="submit"
          color="primary"
          className="bg-appSecondary"
        >
          {isMutating ? "Updating..." : "Update Changes"}
        </Button>
      </div>
    </form>
  );
};

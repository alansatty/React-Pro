
import { Spinner } from "@nextui-org/spinner";
import useApi from "../../../../../hooks/useApi";
import { useAuth } from "../../../../../providers/authProviders";
import { apiList } from "../../../../../services";
import { ProfileDetailsForm } from "./ProfileDetailsForm";
import { ResetPasswordForm } from "./ResetPasswordForn";
import usePermissionsStore from "../../../../../stores/usePermissionStore";
import { useState } from "react";
import useUnsavedChanges from "../../../../../hooks/useUnsavedChanges";
import UnsavedChangesModal from "../../../../../components/Alert/UnsavedChangesModal";

export const GeneralTab = () => {
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
  const [isUserMadeChanges, setIsUserMadeChanges] = useState(false)

  const auth = useAuth()
  const { data, error, isLoading } = useApi(
    strategicPlan ? apiList.admin.profile.details.key(auth?.user?.user_id, strategicPlan) : null,
    strategicPlan ? apiList.admin.profile.details.call(auth?.user?.user_id, strategicPlan) : null
  );

  const { showModal, confirmNavigation, cancelNavigation } = useUnsavedChanges(isUserMadeChanges);


  if (isLoading) {
    return <Spinner />
  }

  return (
    <>
      {showModal && (
        <UnsavedChangesModal
          isConfirmNavigation={confirmNavigation}
          isCancelNavigation={cancelNavigation}
        />
      )}
      <ProfileDetailsForm initialData={data?.data} setIsUserMadeChanges={setIsUserMadeChanges} />
      <ResetPasswordForm setIsUserMadeChanges={setIsUserMadeChanges} />
    </>

  );
};

import { Button } from "@nextui-org/button";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import useApi from "../../../../../hooks/useApi";
import { apiList } from "../../../../../services";
import { Spinner } from "@nextui-org/spinner";
import ConfirmationModal from "../../../../../components/ConfirmationModal/ConfirmationModal";
import { mutate } from "swr";
import toast from "react-hot-toast";
import hasPermission from "../../../../../utils/hasPermission";
import Swal from "sweetalert2/dist/sweetalert2.js";
import { useAuth } from "../../../../../providers/authProviders";
import withReactContent from "sweetalert2-react-content";
import ProstrategyLogo from "../../../../../assets/icons/ProstrategyLogo";
const MySwal = withReactContent(Swal);

export const SubscriptionPlanTab = ({ data }) => {

  const navigate = useNavigate();
  const [confirmation, setConfirmation] = useState(false);
  const auth = useAuth();

  const { trigger, isMutating } = useApi(
    null,
    apiList.admin.subscription.cancel_subscription.call(),
    { method: "POST" }
  );

  const cancelSubscription = async (planId) => {
    try {
      if (data?.data?.current_plan_id) {
        const response = await trigger({ requestBody: { plan_id: data?.data.current_plan_id } });
        toast.success("Subscription cancelled successfully");
        setConfirmation(false);
        mutate(apiList.admin.subscription.current_plan.key());
        mutate(apiList.auth.getPermissions.key(auth?.user?.id));
      }
    } catch (error) {
      console.log(error);
      if (error.status == "warning") {
        const warningMessage = error.msg
          .map((msg) =>
            msg.replace(
              "Downgrade Alert:",
              `<span class="text-red-600 font-bold">Downgrade Alert:</span>`
            )
          )
          .map(
            (msg) =>
              `<li class="mb-2 text-sm text-gray-700 leading-5 list-disc list-inside">${msg}</li>`
          )
          .join("");

        MySwal.fire({
          html: (
            <div className="flex flex-col items-center">
              <div className="w-18 h-20 mb-2">
                <ProstrategyLogo />
              </div>
              <h2 className="text-xl font-semibold">Warning!</h2>
              <div
                className="mt-2 text-sm text-gray-700 leading-5"
                dangerouslySetInnerHTML={{ __html: warningMessage }}
              />
            </div>
          ),
          confirmButtonText: "Okay",
          customClass: {
            confirmButton:
              "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
          },
        });
      }
    }
  };

  // if (isLoading) {
  //   return <Spinner />;
  // }

  return (
    <section className="mt-3">
      <ConfirmationModal
        deleteTitle={"Cancel Subscription"}
        deleteMessage={"Are you sure you want to cancel subscription ?"}
        isLoading={isMutating}
        isOpen={confirmation}
        onClose={setConfirmation}
        onConfirm={cancelSubscription}
        buttonText={"yesNo"}
      />

      <div className="flex justify-between items-center ">
        <h2 className="text-lg font-semibold text-gray-800">Current Plan</h2>
        {data?.data?.plan_name !== "Free" &&
          hasPermission("subscription_upgrade_downgrade", "has_access") &&
          data?.data?.plan_name !== "Enterprise" && (
            <button
              className="text-blue-500  text-sm hover:underline"
              onClick={() => setConfirmation(true)}
            >
              Cancel Subscription
            </button>
          )}
      </div>
      <p className="text-sm text-gray-500 mb-6">
        Update your subscription plan.
      </p>

      <div className="mb-7">
        {data?.data?.plan_name === "Free" ? (
          <div className="mt-5 flex items-start">
            <span className="text-2xl font-semibold text-white bg-[#02205F] p-2 text-center rounded-md capitalize">
              {data?.data?.plan_name} Plan
            </span>
          </div>
        ) : (
          <>
            <span className="text-xs text-white bg-[#02205F] p-2 text-center rounded-md capitalize">
              {data?.data?.plan_name} Plan
            </span>
            <div className="mt-5 flex items-start">
              <span className="text-[#32239] text-3xl mr-1">$</span>
              <span className="text-5xl font-bold text-[#0A1734]">
                {data?.data?.price}
              </span>
              {data?.data?.plan_name == "Enterprise" ? (
                ""
              ) : (
                <span className="text-gray-500 ml-1">
                  /{data?.data?.duration}
                </span>
              )}
            </div>
          </>
        )}
      </div>
      {hasPermission("subscription_upgrade_downgrade", "has_access") &&
        // data?.data?.plan_name !== "Enterprise" && (
        <Button
          radius="sm"
          type="submit"
          className="bg-appSecondary text-white py-5 px-5"
          onClick={() => navigate("/pricingplans")}
        >
          Upgrade Now
        </Button>
        // )
      }
    </section>
  );
};

import { useEffect, useState } from "react";
import withReactContent from "sweetalert2-react-content";
import usePermissionsStore from "../../../../stores/usePermissionStore";
import { useParams } from "react-router-dom";
import useApi from "../../../../hooks/useApi";
import { apiList } from "../../../../services";
import Swal from 'sweetalert2';
import { DeptStrategicCheckboxList } from "./components/DeptStrategicCheckboxList";
import ProstrategyLogo from "../../../../assets/icons/ProstrategyLogo";
import { PageSpinner } from "../../../../components";


const MySwal = withReactContent(Swal);

export default function StrategicReport() {
    const strategicPlan = usePermissionsStore((state) => state.strategicPlan);

    const { data, isLoading, error } = useApi(
        strategicPlan ? apiList.admin.binder_template.strategic_planing_report.key(strategicPlan) : null,
        strategicPlan
            ? apiList.admin.binder_template.strategic_planing_report.call(strategicPlan)
            : null
    );

    const [datas, setData] = useState(data);
    const [isSaved, setIsSaved] = useState(false);

    useEffect(() => {
        if (data) {
            setData(data);
        }
    }, [data]);


    const { trigger, isMutating } = useApi(
        null,
        strategicPlan ? apiList.admin.binder_template.strategic_planing_report.call(strategicPlan) : null,
        { method: "POST" }
    );

    const handleDataSave = async (updatedData) => {
        setIsSaved(false);

        try {
            const response = await trigger({ requestBody: updatedData });

            MySwal.fire({
                html: (
                    <div className="flex flex-col items-center">
                        <div className="w-18 h-20 mb-2">
                            <ProstrategyLogo />
                        </div>
                        <h2 className="text-xl font-semibold">
                            {" "}
                            Strategic Report Saved Successly!
                        </h2>
                        <p className="mt-2">{response?.data}</p>
                    </div>
                ),
                allowOutsideClick: false,
                confirmButtonText: "Okay",
                customClass: {
                    confirmButton: "my-confirm-button",
                },
            });
            setIsSaved(true)
        } catch (error) {
            console.log("error", error);
            MySwal.fire({
                html: (
                    <div className="flex flex-col items-center">
                        <div className="w-18 h-20">
                            <ProstrategyLogo />
                        </div>
                        <h2 className="text-xl font-semibold ">Error!</h2>
                        <p className="mt-2">
                            Failed to save Department Report. Please try again.
                        </p>
                    </div>
                ),
                confirmButtonText: "Retry",
            });
        }
        setIsSaved(true)
    };

    if (isLoading) return <PageSpinner />
    // if (error) return <div>Error loading data</div>;
    if (!datas || Object.keys(datas).length === 0) return <PageSpinner />;
    // if (!datas) return <div>No data available</div>;

    return (
        <main className="min-h-screen">
            <div className="">
                <DeptStrategicCheckboxList
                    data={datas}
                    onSave={handleDataSave}
                    setData={setData}
                    isSaved={isSaved}
                    isSaveLoading={isMutating}
                />
            </div>
        </main>
    );
}

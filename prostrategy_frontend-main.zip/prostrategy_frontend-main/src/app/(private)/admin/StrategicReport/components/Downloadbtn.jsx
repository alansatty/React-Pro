import { useState, useRef, useEffect } from "react";

export default function Downloadbtn({ onDownload }) {
    const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className="relative inline-block text-left" ref={dropdownRef}>
      <button
        className="bg-[#0098F5] px-4 py-2 text-white rounded shadow"
        onClick={() => setIsOpen((prev) => !prev)}
      >
        Download
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-32 bg-white border rounded shadow z-10">
          <button
            className="block w-full px-4 py-2 text-left text-sm hover:bg-gray-100"
            onClick={() => {
              onDownload("pdf");
              setIsOpen(false);
            }}
          >
            PDF
          </button>
          <button
            className="block w-full px-4 py-2 text-left text-sm hover:bg-gray-100"
            onClick={() => {
              onDownload("doc");
              setIsOpen(false);
            }}
          >
            DOC
          </button>
        </div>
      )}
    </div>
  );
}

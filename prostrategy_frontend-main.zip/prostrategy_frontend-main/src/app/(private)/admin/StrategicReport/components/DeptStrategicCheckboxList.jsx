import { Button } from "@nextui-org/button";
import { Checkbox } from "@nextui-org/checkbox";
import {
  IconChevronDown,
  IconChevronRight,
  IconFileTypeDocx,
  IconPdf,
} from "@tabler/icons-react";
import { useEffect, useState } from "react";
import withReactContent from "sweetalert2-react-content";
import Swal from "sweetalert2";
import useUnsavedChanges from "../../../../../hooks/useUnsavedChanges";
import UnsavedChangesModal from "../../../../../components/Alert/UnsavedChangesModal";
import { useNavigate } from "react-router-dom";
import { Card } from "@nextui-org/card";
import Downloadbtn from "./Downloadbtn";
import {
  Dropdown,
  DropdownItem,
  DropdownMenu,
  DropdownTrigger,
} from "@nextui-org/dropdown";
import { Button as Btns } from "@nextui-org/button";
import ProstrategyLogo from "../../../../../assets/icons/ProstrategyLogo";
import usePermissionsStore from "../../../../../stores/usePermissionStore";
import axios from "axios";

const MySwal = withReactContent(Swal);
export function DeptStrategicCheckboxList({ data, onSave, setData, isSaved, isSaveLoading }) {
  const [checkboxData, setCheckboxData] = useState(() => data || {});
  const [expandedItems, setExpandedItems] = useState({});
  const [pendingNavigation, setPendingNavigation] = useState(false);
  const [isDirty, setIsDirty] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);

  const [shouldShowActions, setShouldShowActions] = useState(false);
  const [shouldShowActionsPreview, setShouldShowActionsPreview] = useState(false);

  const hasAtLeastOneSelected = (node) => {
    if (isCheckboxItem(node)) {
      return node.is_selected;
    }

    if (Array.isArray(node)) {
      return node.some(hasAtLeastOneSelected);
    }

    if (typeof node === "object" && node !== null) {
      return Object.values(node).some(hasAtLeastOneSelected);
    }

    return false;
  };

  useEffect(() => {
    setShouldShowActions(hasAtLeastOneSelected(checkboxData));
    setShouldShowActionsPreview(hasAtLeastOneSelected(checkboxData));
    setShouldShowActions(false)
  }, []);



  const navigate = useNavigate();
  const toggleExpand = (key) => {
    setExpandedItems((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  useEffect(() => {
    if (data) {
      setCheckboxData(data);
    }
  }, [data]);

  useEffect(() => {
    if (isSaved) {
      setIsDirty(false);
    }
  }, [isSaved]);

  const handleNavigationConfirm = (shouldNavigate) => {
    if (shouldNavigate) {
      setIsDirty(false);
    }
    setPendingNavigation(false);
  };

  const { showModal, confirmNavigation, cancelNavigation } = useUnsavedChanges(
    isDirty,
    pendingNavigation,
    handleNavigationConfirm
  );

  const isCheckboxItem = (item) => {
    return (
      item &&
      typeof item === "object" &&
      "slug" in item &&
      "name" in item &&
      "is_selected" in item
    );
  };

  const areAllChildrenSelected = (node) => {
    if (isCheckboxItem(node)) return node.is_selected;

    if (Array.isArray(node)) {
      return node.length > 0 && node.every(areAllChildrenSelected);
    }

    if (typeof node === "object" && node !== null) {
      const keys = Object.keys(node);
      return (
        keys.length > 0 &&
        keys.every((key) => areAllChildrenSelected(node[key]))
      );
    }

    return false;
  };

  const updateSelectionState = (node, isSelected) => {
    if (isCheckboxItem(node)) {
      return { ...node, is_selected: isSelected };
    }

    if (Array.isArray(node)) {
      return node.map((item) => updateSelectionState(item, isSelected));
    }

    if (typeof node === "object" && node !== null) {
      const result = {};
      for (const key in node) {
        result[key] = updateSelectionState(node[key], isSelected);
      }
      return result;
    }

    return node;
  };

  const handleCheckboxChange = (path, isSelected) => {

    setIsDirty(true);
    const newData = JSON.parse(JSON.stringify(checkboxData));
    let current = newData;

    // Traverse to the parent node
    for (let i = 0; i < path.length - 1; i++) {
      current = current[path[i]];
    }

    const lastKey = path[path.length - 1];
    current[lastKey] = updateSelectionState(current[lastKey], isSelected);

    setCheckboxData(newData);
    setData(newData);
    setShouldShowActions(hasAtLeastOneSelected(newData));
    setShouldShowActions(true);
    setShouldShowActionsPreview(true);
  };

  const renderCheckboxItem = (item, path) => {
    return (
      <div className="ml-6 my-1" key={item.slug}>
        <Checkbox
          isSelected={item.is_selected}
          onValueChange={(val) => handleCheckboxChange([...path], val)}
          classNames={{
            base: "text-sm",
            label: "text-base",
          }}
        >
          {item.name}
        </Checkbox>
      </div>
    );
  };

  const renderNode = (node, path = [], level = 0) => {
    if (!node) return null;
    if (isCheckboxItem(node)) {
      return renderCheckboxItem(node, path);
    }

    if (Array.isArray(node)) {
      return (
        <div className="pl-6">
          {node.map((item, index) => (
            <div key={index}>
              {renderNode(item, [...path, index.toString()], level + 1)}
            </div>
          ))}
        </div>
      );
    }

    if (typeof node !== "object" || node === null) {
      return null;
    }

    const keys = Object.keys(node);
    if (keys.length === 0) return null;

    return (
      <div className={level > 0 ? "pl-6" : ""}>
        {keys.map((key) => {
          const isExpandable =
            typeof node[key] === "object" &&
            node[key] !== null &&
            !isCheckboxItem(node[key]);
          const isExpanded = expandedItems[path.join(".") + "." + key] || false;
          const allSelected = areAllChildrenSelected(node[key]);

          return (
            <div key={key} className="mt-1">
              <div className="flex items-center space-x-2">
                {isExpandable ? (
                  <button
                    onClick={() => toggleExpand(path.join(".") + "." + key)}
                    className="h-4 w-4 flex items-center justify-center "
                    Style="color:#0098F5"
                  >
                    {isExpanded ? (
                      <IconChevronDown className="h-3 w-3" />
                    ) : (
                      <IconChevronRight className="h-3 w-3" />
                    )}
                  </button>
                ) : (
                  <div className="w-4" />
                )}
                <div
                  className={`${isExpandable
                    ? "flex items-center justify-between bg-blue-50 p-3 rounded shadow my-1"
                    : "flex items-center justify-between  p-3 rounded  my-1"
                    } w-full`}
                >
                  <Checkbox
                    isSelected={allSelected}
                    onValueChange={(val) =>
                      handleCheckboxChange([...path, key], val)
                    }
                    classNames={{
                      base: "text-sm",
                      label: isExpandable ? "font-bold text-base" : "text-sm",
                    }}
                  >
                    {key}
                  </Checkbox>
                </div>
              </div>

              {isExpandable && isExpanded && (
                <div className="mt-1">
                  {renderNode(node[key], [...path, key], level + 1)}
                </div>
              )}
            </div>
          );
        })}
      </div>
    );
  };

  const selectAllcheckBox = () => {
    setShouldShowActions(false)
    setShouldShowActionsPreview(true)

    const collectCheckedSlugs = (node, slugs = []) => {
      if (isCheckboxItem(node)) {
        if (node.is_selected) {
          slugs.push(node.slug);
        }
        return slugs;
      }

      if (Array.isArray(node)) {
        node.forEach((item) => collectCheckedSlugs(item, slugs));
      } else if (typeof node === "object" && node !== null) {
        Object.values(node).forEach((value) =>
          collectCheckedSlugs(value, slugs)
        );
      }

      return slugs;
    };

    return collectCheckedSlugs(checkboxData); // Return the slugs array
  };

  const downloadPdf = async (docType) => {
    // const result = await MySwal.fire({
    //   html: (
    //     <div className="flex flex-col items-center">
    //       <div className="w-18 h-20 mb-2">
    //         <ProstrategyLogo />
    //       </div>
    //       <p className="mt-2">Do you want to download {docType}?</p>
    //     </div>
    //   ),
    //   showCancelButton: true,
    //   confirmButtonText: "Download",
    //   cancelButtonText: "Cancel",
    //   customClass: {
    //     confirmButton: "my-confirm-button",
    //   },
    // });

    // if (result.isConfirmed) {
    const saveSuccess = await downloadFiles(docType, strategicPlan);
    if (!saveSuccess) return;
    // }
  };


  async function downloadFiles(docType, strategicPlan) {
    setIsDownloading(true); // Show spinner

    try {
      const storedUser = localStorage.getItem("prostrategy_auth");
      const token = storedUser ? JSON.parse(storedUser)?.token : null;

      const response = await axios.get(
        `/organization/strategic_support_preview/${strategicPlan}/?file_type=${docType}`,
        {

          headers: {
            Authorization: `Bearer ${token}`, // 🔐 Pass the token here
          },
        }
      );

      // Trigger file download
      const url = response?.data?.s3_url
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `report.${docType}`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      setIsDownloading(false);
      return true;
    } catch (error) {
      console.error("Download failed:", error);
      return false;
    }
    finally {
      setIsDownloading(false); // Hide spinner
    }
  }




  return (
    <Card className="p-6 bg-white min-h-screen mb-5 fixed w-[70%]">
      <div className="p-4  rounded-lg">
        <div className="mt-2 flex justify-end space-x-3 mb-5">
          <Button
            size="sm"
            radius="sm"
            color="primary"
            className={`bg-[#0098F5] px-4 py-2 text-white h-10 ${!shouldShowActions ? "opacity-50 cursor-not-allowed pointer-events-none" : ""
              }`}
            isLoading={isSaveLoading}
            onClick={() => onSave(selectAllcheckBox())}
            isDisabled={!shouldShowActions}
          >
            Save Changes
          </Button>

          <Button
            radius="sm"
            size="sm"
            color="primary"
            className={`bg-[#0098F5] px-4 py-2 text-white h-10 ${!shouldShowActionsPreview ? "opacity-50 cursor-not-allowed pointer-events-none" : ""
              }`}
            onClick={() => navigate("/strategic_report/preview")}
          >
            Preview
          </Button>

          <Dropdown size="sm" radius="sm">
            <DropdownTrigger>
              <Btns
                size="sm"
                radius="sm"
                variant="bordered"
                className={`bg-[#0098F5] px-4 py-2 text-white h-10 ${!shouldShowActionsPreview ? "opacity-50 cursor-not-allowed pointer-events-none" : ""
                  }`}
                color="primary"
                isLoading={isDownloading}
              >
                Download
              </Btns>
            </DropdownTrigger>

            <DropdownMenu aria-label="Download options">
              <DropdownItem onPress={() => downloadPdf("pdf")} key="pdf">
                <div className="flex gap-1 items-center">
                  <IconPdf className="h-8" /> Download as PDF
                </div>
              </DropdownItem>
              <DropdownItem onPress={() => downloadPdf("docx")} key="docx">
                <div className="flex gap-1 items-center">
                  <IconFileTypeDocx className="h-5" /> Download as DOCX
                </div>
              </DropdownItem>
            </DropdownMenu>
          </Dropdown>

          {showModal && (
            <UnsavedChangesModal
              isConfirmNavigation={confirmNavigation}
              isCancelNavigation={cancelNavigation}
            />
          )}
        </div>

        <div
          className="overflow-y-auto"
          style={{
            maxHeight: '500px',
            overflowY: 'auto',
            // Use 'auto' instead of 'scroll' to only show scrollbar when needed
          }}
        >
          {renderNode(checkboxData)}
        </div>
      </div>
    </Card>
  );
}
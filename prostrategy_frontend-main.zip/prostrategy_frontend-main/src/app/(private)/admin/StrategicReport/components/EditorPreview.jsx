import React, { useState } from 'react'
import { apiList } from '../../../../../services';
import useApi from '../../../../../hooks/useApi';
import usePermissionsStore from '../../../../../stores/usePermissionStore';
import { Button } from '@nextui-org/button';
import { Navigate, useNavigate } from 'react-router-dom';
import { Card } from '@nextui-org/card';
import Downloadbtn from './Downloadbtn';
import { Dropdown, DropdownItem, DropdownMenu, DropdownTrigger } from '@nextui-org/dropdown';
import { IconFileInvoice, IconFileTypeDocx, IconPdf } from '@tabler/icons-react';
import { Button as Btns } from "@nextui-org/button";
import axios from 'axios';
import withReactContent from 'sweetalert2-react-content';
import Swal from 'sweetalert2';
import ProstrategyLogo from '../../../../../assets/icons/ProstrategyLogo';
import { PageSpinner } from '../../../../../components';
import './preview.css'

const MySwal = withReactContent(Swal);

const EditorPreview = () => {
	const navigate = useNavigate()
	const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
	const [isDownloading, setIsDownloading] = useState(false);

	const { data, isLoading, error } = useApi(
		apiList.admin.binder_template.strategic_planing_report_preview.key(strategicPlan),
		strategicPlan ? apiList.admin.binder_template.strategic_planing_report_preview.call(strategicPlan)
			: null
	);

	const downloadPdf = async (docType) => {
		// const result = await MySwal.fire({
		// 	html: (
		// 		<div className="flex flex-col items-center">
		// 			<div className="w-18 h-20 mb-2">
		// 				<ProstrategyLogo />
		// 			</div>
		// 			<p className="mt-2">Do you want to download {docType}?</p>
		// 		</div>
		// 	),
		// 	showCancelButton: true,
		// 	confirmButtonText: "Download",
		// 	cancelButtonText: "Cancel",
		// 	customClass: {
		// 		confirmButton: "my-confirm-button",
		// 	},
		// });

		// if (result.isConfirmed) {
		const saveSuccess = await downloadFiles(docType, strategicPlan);
		if (!saveSuccess) return;
		// }
	};


	async function downloadFiles(docType, strategicPlan) {
		setIsDownloading(true); // Show spinner

		try {
			const storedUser = localStorage.getItem("prostrategy_auth");
			const token = storedUser ? JSON.parse(storedUser)?.token : null;

			const response = await axios.get(
				`/organization/strategic_support_preview/${strategicPlan}/?file_type=${docType}`,
				{

					headers: {
						Authorization: `Bearer ${token}`, // 🔐 Pass the token here
					},
				}
			);

			// Trigger file download
			const url = response?.data?.s3_url
			const link = document.createElement("a");
			link.href = url;
			link.setAttribute("download", `report.${docType}`);
			document.body.appendChild(link);
			link.click();
			link.remove();
			setIsDownloading(false);
			return true;
		} catch (error) {
			console.error("Download failed:", error);
			return false;
		}
		finally {
			setIsDownloading(false); // Hide spinner
		}
	}

	if (isLoading) {
		return (
			<PageSpinner />
		)
	}

	return (
		<>

			{data ? (
				<>

					<Card className="p-6 bg-white min-h-screen">


						<div className="p-4  rounded-lg">
							<div className="mt-2 flex justify-end space-x-3">

								<Button
									radius="sm"
									size="sm"
									color="primary"
									className="bg-[#0098F5] px-4 py-2 text-white h-10"
									onClick={() => navigate("/strategic_report")} // Replace with your preview logic
								>
									Strategic Report
								</Button>

								<Dropdown size="sm" radius="sm">

									<DropdownTrigger>
										<Btns
											size="sm"
											radius="sm"
											variant="bordered"
											className="bg-[#0098F5] px-4 py-2 text-white h-10"
											color="primary"
											isLoading={isDownloading}
										>
											{/* <IconFileInvoice className="h-5" /> */}
											Download
										</Btns>
									</DropdownTrigger>
									<DropdownMenu aria-label="Download options">
										<DropdownItem onPress={() => downloadPdf("pdf")} key="pdf">
											<div className="flex gap-1 items-center ">
												<IconPdf className="h-8" /> Download as PDF
											</div>
										</DropdownItem>
										<DropdownItem onPress={() => downloadPdf("docx")} key="docx">
											<div className="flex gap-1 items-center ">
												<IconFileTypeDocx className="h-5" /> Download as DOCX
											</div>
										</DropdownItem>
									</DropdownMenu>
								</Dropdown>

							</div>
						</div>

						<div
							className="notext"
							style={{ pointerEvents: 'none', userSelect: 'none' }}
							dangerouslySetInnerHTML={{ __html: data }}
						/>					</Card>
				</>
			) : (

				<>
					<Card className="p-6 bg-white min-h-screen">
						<div className="p-4  rounded-lg">
							<div className="mt-2 flex justify-end space-x-3 mb-5">

								<Button
									radius="sm"
									size="sm"
									color="primary"
									className="bg-[#0098F5] px-4 py-2 text-white h-10"
									onClick={() => navigate("/strategic_report")} // Replace with your preview logic
								>
									Strategic Report
								</Button>
								<Dropdown size="sm" radius="sm">

									<DropdownTrigger>
										<Btns
											size="sm"
											radius="sm"
											variant="bordered"
											className="bg-[#0098F5] px-4 py-2 text-white h-10"
											color="primary"
											isLoading={isDownloading}
										>
											{/* <IconFileInvoice className="h-5" /> */}
											Download
										</Btns>
									</DropdownTrigger>
									<DropdownMenu aria-label="Download options">
										<DropdownItem onPress={() => downloadPdf("pdf")} key="pdf">
											<div className="flex gap-1 items-center ">
												<IconPdf className="h-8" /> Download as PDF
											</div>
										</DropdownItem>
										<DropdownItem onPress={() => downloadPdf("docx")} key="docx">
											<div className="flex gap-1 items-center ">
												<IconFileTypeDocx className="h-5" /> Download as DOCX
											</div>
										</DropdownItem>
									</DropdownMenu>
								</Dropdown>

							</div>
						</div>

						<div className="flex flex-col items-center justify-center h-full py-20 text-gray-500">


							<p>No preview content available.</p>
						</div>	</Card> </>

			)}

		</>


	)
}

export default EditorPreview
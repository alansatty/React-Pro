import React, { useState, useEffect } from "react";
import { Card, CardBody } from "@nextui-org/card";
import { Tab, Tabs } from "@nextui-org/tabs";
import usePermissionsStore from "../../../../stores/usePermissionStore";
import useApi from "../../../../hooks/useApi";
import { apiList } from "../../../../services";
import { Spinner } from "@nextui-org/spinner";
import { DepartmentGS } from "./components/departmentGS";
import { Select, SelectItem } from "@nextui-org/select";
import { useAuth } from "../../../../providers/authProviders";

export const GSComparison = () => {
  const [selectedStrategic, setSelectedStrategic] = useState(null);
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
  const auth = useAuth()
  // Fetch Organization Goals
  const {
    data: apiData,
    error,
    isLoading,
  } = useApi(
    apiList.admin.strategies.get_saved.key(selectedStrategic || strategicPlan),
    strategicPlan ? apiList.admin.strategies.get_saved.call(selectedStrategic || strategicPlan) : null,
  );

  const organizationGoals = apiData?.data
    ? apiData.data.map((item) => Object.values(item)[0])
    : [];

  // Fetch Departments
  const {
    data: departmentsData,
    error: departmentError,
    isLoading: isLoadingDepartment,
  } = useApi(
    apiList.admin.user.departmentDropdown.key,
    apiList.admin.user.departmentDropdown.call()
  );

  const {
    data: strategicPlans,
    isLoading: strategicLoading,
  } = useApi(
    apiList.admin.strategicPlans.list.key(1, 10, auth?.user?.id),
    apiList.admin.strategicPlans.list.call()
  );

  const departments = departmentsData?.data?.map((dept) => ({
    id: dept.id,
    label: dept.name,
  }));

  const [selectedDepartment, setSelectedDepartment] = useState(null);

  useEffect(() => {
    if (strategicPlan && !selectedStrategic) {
      setSelectedStrategic(strategicPlan);
    }
    if (departments?.length && !selectedDepartment) {
      setSelectedDepartment(departments[0].id);
    }
  }, [departments, strategicPlan]);

  const handleStrategicChange = (selected) => {
    setSelectedStrategic(Array.from(selected)[0])
  }

  if (isLoading || isLoadingDepartment || !strategicPlan) {
    return (
      <div className="flex items-center justify-center h-full w-full">
        <Spinner size="md" />
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between my-3">
        <h2 className="text-gray-700 font-semibold text-lg mt-6">
          Organization Goals
        </h2>
        <div>
          <label className="block text-sm font-medium text-gray-500  mb-1">
            Select Strategic Plan
          </label>
          <Select
            radius="sm"
            size="md"
            selectionMode="single"
            selectedKeys={selectedStrategic ? new Set([selectedStrategic]) : new Set()}
            items={strategicPlans?.data || []}
            placeholder="Select strategic plan"
            className=" w-60 "
            scrollShadowProps={{
              isEnabled: true,
              hideScrollBar: false,
            }}
            classNames={{
              trigger: [
                "border-1 rounded-lg",
                "data-[open=true]:border-2 data-[open=true]:border-[#0098F5]",
                "data-[focus=true]:border-2 data-[focus=true]:border-[#0098F5]",
                "dark:data-[open=true]:border-2 dark:data-[open=true]:border-[#0098F5]",
                "dark:data-[focus=true]:border-2 dark:data-[focus=true]:border-[#0098F5]",
              ],
            }}
            onSelectionChange={handleStrategicChange}
          >
            {(item) => (
              <SelectItem key={item.id} textValue={item.name}>
                {item.name}
              </SelectItem>
            )}

          </Select>
        </div>

      </div>

      {/* Organization Goals Section */}

      <div className="bg-slate-50 p-6">
        <div className="space-y-3">
          {organizationGoals?.length > 0
            ? organizationGoals.map((goal, index) => (
              <div key={index} className="flex gap-3">
                <span className="">{index + 1}.</span>
                <p className="">{goal}</p>
              </div>
            ))
            : " No records."}
        </div>
      </div>

      {/* Department Goals Section */}
      <div className="mt-4">
        <h2 className="text-md font-semibold text-gray-900 mb-3">
          Department Goals & Strategy
        </h2>
        <div className="flex w-full flex-col mt-3">
          {departments?.length > 0 ? (
            <Tabs
              key={selectedDepartment}
              selectedKey={selectedDepartment}
              onSelectionChange={setSelectedDepartment}
              items={departments}
              aria-label="Department tabs"
              color="primary"
              size="md"
              radius="sm"
              variant="underlined"
              classNames={{
                tabList:
                  "gap-8 w-full relative rounded-none p-0 border-b border-divider ",
                cursor: "w-full bg-[#0098F5]",
                tab: "max-w-fit px-2 h-12",
                tabContent: "group-data-[selected=true]:text-[#0098F5]",
              }}
            >
              {(item) => (
                <Tab key={item.id} title={item.label}>
                  <Card shadow="none" radius="sm">
                    <CardBody>
                      <div className="space-y-4">
                        <DepartmentGS departmentId={item.id} selectedStrategic={selectedStrategic} />
                      </div>
                    </CardBody>
                  </Card>
                </Tab>
              )}
            </Tabs>
          ) : (
            "No records."
          )}
        </div>
      </div>
    </div>
  );
};

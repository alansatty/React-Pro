import React from "react";
import usePermissionsStore from "../../../../../stores/usePermissionStore";
import useApi from "../../../../../hooks/useApi";
import { apiList } from "../../../../../services";
import { Spinner } from "@nextui-org/spinner";
import { Accordion, AccordionItem } from "@nextui-org/accordion";
import { IconMinus, IconPlus } from "@tabler/icons-react";

export const DepartmentGS = ({ departmentId, selectedStrategic }) => {
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);

  const {
    data: apiData,
    error,
    isLoading,
  } = useApi(
    apiList.admin.departmentStrategies.get_saved.key(
      departmentId,
      selectedStrategic || strategicPlan
    ),
    apiList.admin.departmentStrategies.get_saved.call(
      departmentId,
      selectedStrategic || strategicPlan
    )
  );

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full w-full">
        <Spinner size="sm" />
      </div>
    );
  }

  if (error) {
    return <p className="text-red-500">Failed to load department details.</p>;
  }

  const goals = apiData?.data || [];


  return (
    <div className="space-y-6">
      {goals.length > 0 ? (
        <Accordion>
          {goals.map((goal, index) => {
            const [goalId, goalTitle] = Object.entries(goal)[0];
            const strategies = goal.strategies || [];

            return (
              <AccordionItem

                key={goalId}
                indicator={({ isOpen }) =>
                  isOpen ? (
                    <span
                      className={`text-small flex gap-1 items-center text-blue-500 hover:underline`}
                    >
                      <IconMinus size={15} /> Hide Strategies
                    </span>
                  ) : (
                    <span
                      className={`text-small flex gap-1 items-center  text-blue-500 hover:underline`}
                    >
                      <IconPlus size={15} /> View Strategies
                    </span>
                  )
                }
                disableIndicatorAnimation={true} // Disable animation
                title={
                  <div className="flex items-start gap-4">
                    <span className=" ">{index + 1}.</span>
                    <p className=" ">{goalTitle}</p>
                  </div>
                }
                className="scrollbar-hide"
              >
                {/* Strategies List */}
                <div className="space-y-4 p-4">
                  {strategies.map((strategy, strategyIndex) => {
                    const [strategyId, strategyTitle] =
                      Object.entries(strategy)[0];
                    return (
                      <div
                        key={strategyId}
                        className="flex items-start justify-between gap-4"
                      >
                        <p className=" ">
                          Strategy {strategyIndex + 1}: {strategyTitle}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </AccordionItem>
            );
          })}
        </Accordion>
      ) : (
        " No records."
      )}
    </div>
  );
};

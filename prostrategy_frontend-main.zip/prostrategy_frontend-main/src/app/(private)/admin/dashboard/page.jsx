import useApi from "../../../../hooks/useApi";
import { apiList } from "../../../../services";
import { useAuth } from "../../../../providers/authProviders";
import { PageSpinner } from "../../../../components";
import UserBreakdownChart from "./components/UserBreakdownChart";
import UserTypeBreakdown from "./components/UserTypeBreakdown";
import InternalChatsChart from "./components/InternalChartsChart";
import { useState } from "react";
import CountCard from "./components/CountCard";

const DashboardPage = () => {
  const auth = useAuth();
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());

  const { data, isLoading } = useApi(
    apiList.admin.dashboard.details.key(auth?.user?.user_id, selectedYear),
    apiList.admin.dashboard.details.call(selectedYear)
  );


  const {
    data: currentPlanData,
    error,
    isLoading: currentPlanDataLoading,
  } = useApi(
    apiList.admin.subscription.current_plan.key(),
    apiList.admin.subscription.current_plan.call()
  );

  if (isLoading || currentPlanDataLoading || !data) {
    return <PageSpinner />;
  }

  const { strategic_plan, users, departments, monthly_chat_counts } = data.data;

  const cardData = [
    {
      title: "Strategic Plans",
      count: strategic_plan.count,
      allowed: strategic_plan.allowed,
    },
    {
      title: "Users",
      count: users.count,
      allowed: users.allowed,
    },
    {
      title: "Departments",
      count: departments.count,
      allowed: departments.allowed,
    },
  ];

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {cardData.map((item, index) => (
          <CountCard
            key={index} // Use a unique key for each card
            title={item.title}
            count={item.count}
            allowed={item.allowed}
            currentPlan={currentPlanData?.data}
          />
        ))}
      </div>

      <div className="grid grid-cols-12 md:grid-cols-12 gap-4 pt-4 items-stretch">
        <div className="col-span-12 md:col-span-4 flex">
          <UserBreakdownChart breakdown={users.breakdown} />
        </div>
        <div className="col-span-12 sm:col-span-8 flex flex-col gap-3">
          <UserTypeBreakdown typeBreakdown={users.type_breakdown} />
          <InternalChatsChart
            selectedYear={selectedYear}
            onYearChange={setSelectedYear}
            monthlyChatCounts={monthly_chat_counts}
          />
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;

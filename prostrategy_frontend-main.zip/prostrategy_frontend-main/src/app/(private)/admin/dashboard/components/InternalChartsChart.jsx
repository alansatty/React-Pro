import { Card, CardBody, CardHeader } from "@nextui-org/card";
import { Select, SelectItem } from "@nextui-org/select";
import { BarChart, XAxis, YAxis, CartesianGrid, Tooltip, Bar } from "recharts";

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div
        style={{
          backgroundColor: "#ffffff", // White background
          border: "1px solid #ddd", // Light gray border
          borderRadius: "8px", // Rounded corners
          padding: "10px", // Padding inside the tooltip
          boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)", // Subtle shadow
        }}
      >
        <p style={{ margin: 0, fontSize: "14px", color: "#555" }}>
          <strong>{label}</strong>
        </p>
        <p style={{ margin: "5px 0 0", fontSize: "14px", color: "#888" }}>
          Count: {payload[0]?.value}
        </p>
      </div>
    );
  }
  return null;
};

const CustomCursor = (props) => {
  const { x, y, width, height } = props; // Props from Tooltip cursor
  return (
    <rect
      x={x}
      y={y}
      width={width}
      height={height}
      fill="#EBF7FF" // Light blue hover effect
      stroke="#0098F580" // Add a light border
      strokeWidth={0}
    />
  );
};

const InternalChatsChart = ({
  monthlyChatCounts,
  selectedYear,
  onYearChange,
}) => {
  const currentYear = new Date().getFullYear().toString(); // Ensure current year is a string
  const years = [
    currentYear,
    (currentYear - 1).toString(),
    (currentYear - 2).toString(),
  ];

  // Set default selected year to the current year if not provided
  const yearToSelect = selectedYear || currentYear;

  const fullToShortMonthMap = {
    January: "Jan",
    February: "Feb",
    March: "Mar",
    April: "Apr",
    May: "May",
    June: "June",
    July: "July",
    August: "Aug",
    September: "Sept",
    October: "Oct",
    November: "Nov",
    December: "Dec",
  };

  const allMonths = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "June",
    "July",
    "Aug",
    "Sept",
    "Oct",
    "Nov",
    "Dec",
  ];

  // Map all months and match the short forms to their values from `monthlyChatCounts`
  const data = allMonths.map((shortMonth) => {
    const fullMonth = Object.keys(fullToShortMonthMap).find(
      (key) => fullToShortMonthMap[key] === shortMonth
    );
    return {
      name: shortMonth,
      value: monthlyChatCounts[fullMonth] || 0, // Assign 0 if no data for that month
    };
  });

  return (
    <Card className="shadow-lg" radius="sm">
      <CardHeader className="flex justify-between items-center">
        <h4 className="text-gray-800 text-lg font-semibold">Internal Chats</h4>

        <Select
          radius="sm"
          size="md"
          name="year_selector"
          selectedKeys={[yearToSelect]} // Use yearToSelect as the default selected year
          defaultSelectedKeys={[yearToSelect]} // Use yearToSelect as the default selected year
          onSelectionChange={(key) => onYearChange(key.currentKey)}
          placeholder="Select Year"
          className="w-32 "
          variant="bordered"
          classNames={{
            trigger: [
              "border-1 rounded-lg",
              "data-[open=true]:border-2 data-[open=true]:border-[#0098F5]",
              "data-[focus=true]:border-2 data-[focus=true]:border-[#0098F5]",
              "dark:data-[open=true]:border-2 dark:data-[open=true]:border-[#0098F5]",
              "dark:data-[focus=true]:border-2 dark:data-[focus=true]:border-[#0098F5]",
            ],
          }}
        >
          {years.map((year) => (
            <SelectItem key={year} value={year}>
              {year}
            </SelectItem>
          ))}
        </Select>
      </CardHeader>
      <CardBody>
        <div className="flex justify-center">
          <BarChart width={800} height={400} data={data} barSize={26} className="custom_chart">
            <XAxis
              dataKey="name"
              tickLine={false}
              ticks={allMonths}
            // interval={0} // Force all labels to display
            />
            <YAxis tickLine={false} allowDecimals={false} />
            <CartesianGrid strokeDasharray="3 3" />
            <Tooltip content={<CustomTooltip />} cursor={<CustomCursor />} />
            <Bar dataKey="value" fill="#0098F5" />
          </BarChart>
        </div>
      </CardBody>
    </Card>
  );
};

export default InternalChatsChart;

import { Card, CardBody, CardHeader } from "@nextui-org/card";
import {
  Bar,
  BarChart,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div
        style={{
          backgroundColor: "#ffffff", // White background
          border: "1px solid #ddd",  // Light gray border
          borderRadius: "8px",       // Rounded corners
          padding: "10px",           // Padding inside the tooltip
          boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)", // Subtle shadow
        }}
      >
        <p style={{ margin: 0, fontSize: "14px", color: "#555" }}>
          <strong>{label}</strong>
        </p>
        <p style={{ margin: "5px 0 0", fontSize: "14px", color: "#888" }}>
        Count: {payload[0]?.value}
        </p>
      </div>
    );
  }
  return null;
};

const CustomCursor = (props) => {
  const { x, y, width, height } = props; // Props from Tooltip cursor
  return (
    <rect
      x={x}
      y={y}
      width={width}
      height={height}
      fill="#EBF7FF" // Light blue hover effect
      stroke="#0098F580" // Add a light border
      strokeWidth={0}
    />
  );
};


const UserTypeBreakdown = ({ typeBreakdown }) => {
  const data = [
    { name: "Admin User", value: typeBreakdown.admin_user },
    { name: "Department User", value: typeBreakdown.department_user },
    { name: "Guest User", value: typeBreakdown.guest_user },
  ];

  return (
    <Card className="shadow-lg " radius="sm">
      <CardHeader>
        <h4 className="text-gray-800 text-lg font-semibold">
          User Type Breakdown
        </h4>
      </CardHeader>
      <CardBody className="px-2">
        <ResponsiveContainer width="100%" height={300}>
          <BarChart
            data={data}
            layout="vertical"
            margin={{ top: 20, right: 20, bottom: 20, left: 40 }}
          >
            <XAxis
              type="number"
              tickFormatter={(value) => `${value}`} // Format values (e.g., 0, 100, 200)
              // ticks={[0, 100, 200, 300, 500]} // Define specific tick values
              tick={{ fontSize: 12, fill: "#888", fontWeight: "bold" }} // Customize tick style
              tickLine={false} // Removes the tick lines
              allowDecimals={false}
            />
            <YAxis
              type="category"
              dataKey="name"
              axisLine={false} // Removes the Y-axis line
              tick={{ fontSize: 14, fill: "#555" }} // Keeps the labels and customizes their appearance
              tickLine={false} // Removes the tick lines
            />
              <Tooltip content={<CustomTooltip />} cursor={<CustomCursor />} />
            <Bar dataKey="value" fill="#0098F5" barSize={15} radius={5} />
          </BarChart>
        </ResponsiveContainer>
      </CardBody>
    </Card>
  );
};

export default UserTypeBreakdown;

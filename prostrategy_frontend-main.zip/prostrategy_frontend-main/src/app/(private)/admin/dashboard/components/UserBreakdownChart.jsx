import React from "react";
import { Card, CardBody, CardHeader } from "@nextui-org/card";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from "recharts";

const CustomTooltip = ({ active, payload, label }) => {
  
  if (active && payload && payload.length) {
    return (
      <div
        style={{
          backgroundColor: "#ffffff", // White background
          border: "1px solid #ddd",  // Light gray border
          borderRadius: "8px",       // Rounded corners
          padding: "10px",           // Padding inside the tooltip
          boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)", // Subtle shadow
        }}
      >
        <p style={{ margin: 0, fontSize: "14px", color: "#555" }}>
          <strong> {payload[0]?.name}: {payload[0]?.value}</strong>
        </p>
      </div>
    );
  }
  return null;
};



const UserBreakdownChart = ({ breakdown }) => {
  const data = [
    { name: "Active", value: breakdown.active },
    { name: "Inactive", value: breakdown.inactive },
    { name: "Pending", value: breakdown.pending },
  ];

  // Calculate total for percentages
  const total = data.reduce((acc, item) => acc + item.value, 0);

  // Define colors for pie slices
  const colors = ["#0098F5", "#0098F580", "#EBF7FF"];

  return (
    <Card className="shadow-lg w-full" radius="sm">
      <CardHeader>
        <h4 className="text-gray-800 text-lg font-semibold">User Breakdown</h4>
      </CardHeader>
      <CardBody>
        {/* <div className="flex items-center gap-4"> */}
        {/* Pie Chart */}
        <div style={{ width: "100%", height: 300 }}>
          <ResponsiveContainer>
            <PieChart >
              <Pie dataKey="value" data={data}  >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`}  fill={colors[index]} />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Custom Legend */}
        <div className="">
          {data.map((item, index) => (
            <div className="mb-4 px-5" key={index}>
              <div
                key={index}
                className="flex items-center justify-between text-gray-800"
              >
                {/* Legend Details */}
                <div className="flex gap-2 items-center">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: colors[index] }}
                  ></div>
                  <p className="font-semibold">{item.name}</p>
                </div>
                <p className="font-semibold text-sm">
                  {((item.value / total) * 100).toFixed(1)}%
                </p>
              </div>
              <p className="text-sm text-gray-500 mt-1 ml-5">
                {item.value} Users
              </p>
            </div>
          ))}
        </div>
        {/* </div> */}
      </CardBody>
    </Card>
  );
};

export default UserBreakdownChart;

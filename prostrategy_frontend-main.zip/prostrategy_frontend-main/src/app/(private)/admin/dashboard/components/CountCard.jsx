import { Card, CardBody, CardFooter, CardHeader } from "@nextui-org/card";
import Swal from "sweetalert2/dist/sweetalert2.js";
import { useNavigate } from "react-router-dom"; // Ensure `useNavigate` is imported
import withReactContent from 'sweetalert2-react-content';
import ProstrategyLogo from "../../../../../assets/icons/ProstrategyLogo";
const MySwal = withReactContent(Swal);

const CountCard = ({ count, allowed, title, currentPlan }) => {
  const navigate = useNavigate(); // Initialize navigate for handling routing



  // Function to show the upgrade popup
  const upgradePopup = () => {
    if (["Free", "Essential", "Plus"].includes(currentPlan.plan_name)) {
      MySwal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>
            <h2 className="text-xl font-semibold">Information!</h2>
            <p className="mt-2"> {`Need additional ${title}? Click here to upgrade your current plan.`}</p>
          </div>
        ),
        confirmButtonText: "Go to Plans",
        customClass: {
          confirmButton:
            "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
        },
      }).then((result) => {
        if (result.isConfirmed) {
          navigate("/settings/account_tab"); // Redirect to subscription plans
        }
      });
    } else {
      MySwal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>
            <h2 className="text-xl font-semibold">Information!</h2>
            <p className="mt-2">{`Need additional ${title}?. please contact admin.`}</p>
          </div>
        ),
        confirmButtonText: "Okay",
        customClass: {
          confirmButton:
            "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
        },
      })
    }
  };

  return (
    <Card className="shadow-lg" radius="sm">
      <CardHeader>
        <h4 className="text-gray-800 text-lg font-semibold">{title}</h4>
      </CardHeader>
      <CardBody className="text-center text-3xl font-bold">{count}</CardBody>
      <CardFooter className="flex justify-between items-center">
        <p className="text-gray-500 text-sm">
          Allowed {title}:{" "}
          <span className="text-black">
            {allowed == "100" ? "Unlimited" : title === 'Departments' ? 'Unlimited' : allowed}
          </span>
        </p>
        {/* Show the Upgrade link if the allowed count is not unlimited */}
        {allowed != "100" && (
          <span
            className="text-blue-500 hover:underline cursor-pointer text-sm"
            onClick={upgradePopup} // Trigger the upgradePopup function
          >
            Upgrade
          </span>
        )}
      </CardFooter>
    </Card>
  );
};

export default CountCard;

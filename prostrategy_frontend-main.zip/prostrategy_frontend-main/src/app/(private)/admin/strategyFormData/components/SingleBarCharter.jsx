
// import React from 'react';
// import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, CartesianGrid, Rectangle, Cell } from 'recharts';

// // Helper to format values into K/M/B
// const formatLarge = (num) => {
//   if (num >= 1e9) return (num / 1e9).toFixed(1) + "B";
//   if (num >= 1e6) return (num / 1e6).toFixed(1) + "M";
//   if (num >= 1e3) return (num / 1e3).toFixed(1) + "K";
//   return num;
// };

// // Custom Tooltip component to handle dollar sign formatting
// const CustomTooltip = ({ active, payload, label, doller = '', text = '' }) => {
//   if (active && payload && payload.length) {
//     return (
//       <div className="custom-tooltip" style={{
//         backgroundColor: '#fff',
//         padding: '10px',
//         border: '1px solid #ccc',
//         borderRadius: '4px'
//       }}>
//         <p className="label">{`Year: ${label}`}</p>
//         <p style={{ color: payload[0].color }}>
//           {`${payload[0].name}: ${doller}${formatLarge(payload[0].value)}${text}`}
//         </p>
//       </div>
//     );
//   }
//   return null;
// };

// const SingleBarCharter = ({ chartname, chartdata, item, text = "", doller = "" }) => {

//   // Prepare the chart data - keep values as numbers
//   const data = Object.entries(chartdata).map(([year, value]) => ({
//     name: year,
//     [chartname]: value, // Keep as number
//   }));

//   const colors = [
//     "#8884d8", "#82ca9d", "#ffc658", "#7b68ee", "#33a6a6", "#94a5d3", "#ff6361", "#a28dd1", "#003186", "#005bc0",
//     "#f54291", "#5d737e", "#ff9800", "#3191d7", "#ed6a00", "#94a5d3", "#ffc400", "489e34", "#6e1054", "#d027d0"
//   ];

//   const formatYAxis = (value) => `${doller}${formatLarge(value)}${text}`;

//   return (
//     <div style={{ width: "100%", height: 400, padding: 20 }}>
//       <p className="text-lg font-semibold text-center">{chartname}</p>
//       <ResponsiveContainer width="100%" height="100%">
//         <BarChart
//           width={500}
//           height={300}
//           data={data}
//           margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
//         >
//           <CartesianGrid strokeDasharray="3 3" />
//           <XAxis dataKey="name" tick={{ fontSize: 10 }} />
//           <YAxis tickFormatter={formatYAxis} tick={{ fontSize: 10 }} />

//           <Tooltip
//             content={<CustomTooltip doller={doller} text={text} />}
//           />
//           <Legend
//             wrapperStyle={{ color: "black", fontSize: 16 }}
//           />
//           <Bar
//             dataKey={chartname}
//             activeBar={<Rectangle stroke="blue" />}
//             activeFill="#6e1054"
//             barSize={20}
//           >
//             {data.map((entry, index) => (
//               <Cell
//                 key={`cell-${index}`}
//                 fill={colors[index % colors.length]}
//               />
//             ))}
//           </Bar>
//         </BarChart>
//       </ResponsiveContainer>
//     </div>
//   );
// };

// export default SingleBarCharter;


// import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, CartesianGrid, Rectangle, Cell } from 'recharts';

const formatLarge = (num) => {
  if (num >= 1e9) return (num / 1e9).toFixed(1) + "B";
  if (num >= 1e6) return (num / 1e6).toFixed(1) + "M";
  if (num >= 1e3) return (num / 1e3).toFixed(1) + "K";
  return num;
};

const CustomTooltip = ({ active, payload, label, doller = '', text = '' }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip" style={{
        backgroundColor: '#fff',
        padding: '10px',
        border: '1px solid #ccc',
        borderRadius: '4px'
      }}>
        <p className="label">{`Year: ${label}`}</p>
        {payload.map((entry, index) => {
          const deptName = entry.payload?.deptName || entry.name;
          return (
            <p key={`item-${index}`} style={{ color: entry.color }}>
              {`${deptName}: ${doller}${formatLarge(entry.value)}${text}`}
            </p>
          );
        })}
      </div>
    );
  }
  return null;
};

const SingleBarCharter = ({ chartname, chartdata, text = "", doller = "" }) => {
  // Process the chart data with proper handling for empty objects
  const data = Object.entries(chartdata).map(([year, value]) => {
    // Handle empty objects by setting value to 0
    if (typeof value === 'object' && value !== null && Object.keys(value).length === 0) {
      return {
        name: year,
        [chartname]: 0
      };
    }

    // Handle department data structure
    if (typeof value === 'object' && value !== null) {
      const departments = Object.keys(value);
      if (departments.length > 0) {
        const firstDept = departments[0];
        const deptValue = value[firstDept];

        // Handle case where department value is an object with value property
        const numericValue = typeof deptValue === 'object' && deptValue !== null
          ? (deptValue.value || 0)
          : (deptValue || 0);

        return {
          name: year,
          [chartname]: numericValue,
          deptName: firstDept,
          deptColor: value[firstDept]?.dept_color
        };
      }
    }

    // Handle simple numeric values
    return {
      name: year,
      [chartname]: value || 0, // Fallback to 0 if value is null/undefined
    };
  });

  // Get department colors from the data
  const departmentColors = {};
  Object.values(chartdata).forEach(yearData => {
    if (typeof yearData === 'object' && yearData !== null) {
      Object.entries(yearData).forEach(([dept, data]) => {
        if (data?.dept_color && !departmentColors[dept]) {
          departmentColors[dept] = data.dept_color;
        }
      });
    }
  });

  const colors = [
    "#8884d8", "#82ca9d", "#ffc658", "#7b68ee", "#33a6a6", "#94a5d3", "#ff6361", "#a28dd1", "#003186", "#005bc0",
    "#f54291", "#5d737e", "#ff9800", "#3191d7", "#ed6a00", "#94a5d3", "#ffc400", "489e34", "#6e1054", "#d027d0"
  ];

  const formatYAxis = (value) => `${doller}${formatLarge(value)}${text}`;

  return (
    <div style={{ width: "100%", height: 400, padding: 20 }}>
      <p className="text-lg font-semibold text-center">{chartname}</p>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={data}
          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" tick={{ fontSize: 10 }} />
          <YAxis tickFormatter={formatYAxis} tick={{ fontSize: 10 }} />
          <Tooltip content={<CustomTooltip doller={doller} text={text} />} />
          <Legend wrapperStyle={{ color: "black", fontSize: 16 }} />
          <Bar
            dataKey={chartname}
            activeBar={<Rectangle stroke="blue" />}
            activeFill="#6e1054"
            barSize={20}
          >
            {data.map((entry, index) => {
              const fillColor = entry.deptColor ||
                (entry.deptName && departmentColors[entry.deptName]) ||
                colors[index % colors.length];
              return <Cell key={`cell-${index}`} fill={fillColor} />;
            })}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};


export default SingleBarCharter;
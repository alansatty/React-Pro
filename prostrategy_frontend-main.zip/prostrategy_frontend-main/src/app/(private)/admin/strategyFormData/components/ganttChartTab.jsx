// import {
//   differenceInDays,
//   endOfYear,
//   format,
//   parse,
//   startOfYear,
// } from "date-fns";

// import { ScrollShadow } from "@nextui-org/scroll-shadow";
// import { useCallback, useEffect, useRef, useState } from "react";
// import usePermissionsStore from "../../../../../stores/usePermissionStore";
// import useApi from "../../../../../hooks/useApi";
// import { apiList } from "../../../../../services";
// import { Popover, PopoverContent, PopoverTrigger } from "@nextui-org/popover";
// import { CardBody, CardHeader } from "@nextui-org/card";
// import { PageSpinner } from "../../../../../components";
// import { Pagination } from "@nextui-org/pagination";
// import { getCurrentDate } from "../../../../../utils/helpers";
// import { StartDateFilter } from "./StartDateFilter";
// import { EndDateFilter } from "./EndDateFilter";
// import { Button } from "@nextui-org/button";
// import { IconRotate } from "@tabler/icons-react";
// import { mutate } from "swr";
// import { Divider } from "@nextui-org/divider";
// import { select } from "@nextui-org/theme";
// import StrategicPlanMultiSelect from "./StrategicPlanMultiSelect";
// import toast from "react-hot-toast";
// import Swal from "sweetalert2/dist/sweetalert2.js";
// import withReactContent from "sweetalert2-react-content";
// import { useNavigate } from "react-router-dom";
// import ProstrategyLogo from "../../../../../assets/icons/ProstrategyLogo";
// import axios from "axios";
// const MySwal = withReactContent(Swal);

// export default function GanttChartTab() {
//   const [page, setPage] = useState(1);
//   const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
//   const [isNoData, setIsNoData] = useState(false);
//   const [startDate, setFilterStartDate] = useState("");
//   const [endDate, setFilterEndDate] = useState("");
//   const [perPage, setPerPage] = useState(10);
//   const [isDropdownOpen, setIsDropdownOpen] = useState(false);
//   const dropdownRef = useState(null);
//   const [selectedPlans, setSelectedPlans] = useState(new Set());
//   const hasShownError = useRef(false);
//   const navigate = useNavigate();
//   const [isError, setIsError] = useState(false);
//   const [strategicPlans, setStrategicPlans] = useState([]);
//   const [hasStrategicPlanError, setHasStrategicPlanError] = useState(true);
//   const hasFetchedStrategicPlans = useRef(false);

//   // Fetch strategic plans only once on mount
//   useEffect(() => {
//     if (!hasFetchedStrategicPlans.current) {
//       hasFetchedStrategicPlans.current = true;

//       const fetchStrategicPlans = async () => {
//         const storedUser = localStorage.getItem("prostrategy_auth");
//         const token = storedUser ? JSON.parse(storedUser)?.token : null;
//         try {
//           const response = await axios.get(
//             '/organization/strategic_plan_list_for_strategic_analysis',
//             {
//               headers: {
//                 Authorization: `Bearer ${token}`,
//               },
//             }
//           );

//           if (response?.data) {
//             setStrategicPlans(response.data.data);
//             setHasStrategicPlanError(false);
//           }
//         } catch (error) {
//           console.error('Error fetching strategic plans:', error?.response);
//           setHasStrategicPlanError(true);
//           if (error?.response?.data?.message) {
//             handleIntialStrategy(error.response.data.message);
//           }
//         }
//       };

//       fetchStrategicPlans();
//     }
//   }, []);

//   // Set initial selected plan when strategic plans are loaded
//   useEffect(() => {
//     if (!hasStrategicPlanError && strategicPlans?.length > 0) {
//       const currentStrategicHas = strategicPlans.find(item => item.id === strategicPlan)
//       if (currentStrategicHas?.id) {
//         // current selected plan have initial strategic settings will get from here and set in state
//         setSelectedPlans(new Set([currentStrategicHas.id.toString()]));
//       } else {
//         setSelectedPlans(new Set([strategicPlans[0]?.id.toString()]));
//       }
//     }
//   }, [strategicPlans, hasStrategicPlanError, strategicPlan]);

//   const handleIntialStrategy = useCallback((errorMessage) => {
//     if (errorMessage && !hasShownError.current) {
//       hasShownError.current = true;
//       MySwal.fire({
//         html: (
//           <div className="flex flex-col items-center">
//             <div className="w-18 h-20 mb-2">
//               <ProstrategyLogo />
//             </div>
//             <h2 className="text-xl font-semibold">Warning!</h2>
//             <p className="mt-2">
//               {"Please set initial strategic data first."}
//             </p>
//           </div>
//         ),
//         confirmButtonText: "Go to initial strategic data",
//         customClass: {
//           confirmButton:
//             "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
//         },
//         allowOutsideClick: false,
//         allowEscapeKey: false,
//       }).then((result) => {
//         if (result.isConfirmed) {
//           navigate("/settings/strategic_data_tab");
//         }
//       });
//     }
//   }, [navigate]);

//   // Only fetch these APIs when we have valid strategic plans
//   const shouldFetchApis = !hasStrategicPlanError && selectedPlans.size > 0;
//   const isValidDateSelection = startDate && endDate;

//   // API for year list
//   const { data: StrategicPlanYearList, isLoading: yearListLoading } = useApi(
//     shouldFetchApis
//       ? apiList.admin.StrategicPlanYearList.list.key(Array.from(selectedPlans).join(","))
//       : null,
//     shouldFetchApis
//       ? apiList.admin.StrategicPlanYearList.list.call(Array.from(selectedPlans).join(","))
//       : null
//   );

//   // Main data API - only fetch when we have year list data too
//   const shouldFetchData = shouldFetchApis && StrategicPlanYearList;
//   const { data, isLoading } = useApi(
//     shouldFetchData
//       ? apiList.admin.strategyFormData.list.key(
//         perPage,
//         page,
//         Array.from(selectedPlans).join(","),
//         null,
//         null,
//         isValidDateSelection ? startDate : undefined,
//         isValidDateSelection ? endDate : undefined
//       )
//       : null,
//     shouldFetchData
//       ? apiList.admin.strategyFormData.list.call(
//         perPage,
//         page,
//         Array.from(selectedPlans).join(","),
//         null,
//         null,
//         isValidDateSelection ? startDate : undefined,
//         isValidDateSelection ? endDate : undefined
//       )
//       : null
//   );

//   // Rest of your component code...
//   const handlePerPageChange = (size) => {
//     setPerPage(size);
//     setPage(1);
//     mutate(
//       apiList.admin.strategyFormData.list.key(
//         size,
//         page,
//         Array.from(selectedPlans).join(","), // Use selectedPlans instead of strategicPlan
//         null,
//         null,
//         startDate,
//         endDate
//       )
//     );
//   }


//   useEffect(() => {
//     setPage(1);
//   }, [strategicPlan]);

//   useEffect(() => {
//     if (strategicPlan) {
//       setIsNoData(false);
//       mutate(
//         apiList.admin.strategyFormData.list.key(
//           page,
//           Array.from(selectedPlans).join(","),
//           null,
//           null,
//           startDate,
//           endDate
//         )
//       );
//     }
//   }, [strategicPlan]);


//   useEffect(() => {
//     if (strategicPlan && startDate === "" && endDate === "") {
//       setIsNoData(false);
//       mutate(
//         apiList.admin.strategyFormData.list.key(
//           page,
//           Array.from(selectedPlans).join(","),
//           null,
//           null,
//           "",
//           ""
//         )
//       );
//     }
//   }, [startDate, endDate]);

//   useEffect(() => {
//     if (data?.data.length === 0) {
//       setIsNoData(true);
//     } else {
//       setIsNoData(false);
//     }
//   }, [data]);
//   // 556d9330 - 12a5 - 45d1 - b044 - dbb72ebecd01
//   // const colorClasses = ["bg-primary text-primary-foreground"];

//   // Instead, create a function to get the color class for a project
//   const getProjectColorClass = (project) => {
//     // Default color if department_color is not available
//     if (!project.department_color) {
//       return "bg-primary text-primary-foreground";
//     }

//     // Use the department_color from the project data
//     // Assuming department_color is a hex code or a valid CSS color
//     return `bg-[${project.department_color}] text-white`;

//     // OR if department_color is a Tailwind color class name:
//     // return `bg-${project.department_color} text-${project.department_color}-foreground`;
//   };

//   const calculateDatePercentage = (date, totalYears) => {
//     const startOfYear = new Date(date.getFullYear(), 0, 0);
//     const dayOfYear = Math.floor((date - startOfYear) / (1000 * 60 * 60 * 24));
//     const yearIndex = date.getFullYear() - years[0];

//     return ((yearIndex + dayOfYear / 365) / totalYears) * 100;

//   };

//   const years = [];
//   for (let year = StrategicPlanYearList?.start_year; year <= StrategicPlanYearList?.end_year; year++) {
//     years.push(year);
//   }


//   const parseCustomDate = (dateString) =>
//     parse(dateString, "MM-dd-yyyy", new Date());

//   const ProjectTimelineView = ({ project }) => {
//     const startDate = parseCustomDate(project.start_date);
//     const endDate = parseCustomDate(project.production_date);

//     const calculateDatePercentageInYear = (date, yearStart) => {
//       const dayOfYear = differenceInDays(date, yearStart);
//       return (dayOfYear / 365) * 100;
//     };

//     return (
//       <div className="relative h-8 w-full bg-gray-100 rounded-md overflow-hidden">
//         {years.map((year, yearIndex) => {
//           const yearStart = startOfYear(new Date(year, 0, 1));
//           const yearEnd = endOfYear(new Date(year, 11, 31));
//           const projectInYear = startDate <= yearEnd && endDate >= yearStart;

//           if (projectInYear) {
//             const startInYear = startDate < yearStart ? yearStart : startDate;
//             const endInYear = endDate > yearEnd ? yearEnd : endDate;

//             const startPercentage = Math.round(
//               calculateDatePercentageInYear(startInYear, yearStart)
//             );
//             const endPercentage = Math.round(
//               calculateDatePercentageInYear(endInYear, yearStart)
//             );
//             const widthPercentage = endPercentage - startPercentage;

//             return (
//               <div
//                 key={year}
//                 className={`absolute h-full bg-primary text-primary-foreground`}
//                 style={{
//                   left: `${(yearIndex / years.length) * 100 + startPercentage / years.length}%`,
//                   width: `${widthPercentage / years.length}%`,
//                   boxSizing: "border-box",
//                   border: "2px solid transparent",
//                 }}
//               />
//             );
//           }
//           return null;
//         })}

//         {years.map((year, index) => (
//           <div
//             key={year}
//             className="absolute h-full border-l border-gray-400"
//             style={{ left: `${(index / years.length) * 100}%` }}
//           >
//             <span className="absolute top-2 left-1 text-xs text-black">
//               {year}
//             </span>
//           </div>
//         ))}
//       </div>
//     );
//   };

//   const handlePageChange = (newPage) => {
//     setPage(newPage);
//   };

//   if (isLoading || !strategicPlan) {
//     return <PageSpinner />;
//   }

//   const resetFields = () => {
//     onClear();
//     setIsNoData(false);
//     // mutate(apiList.admin.strategyFormData.list.key(page, strategicPlan, null, null, startDate, endDate))
//   };

//   const onClear = () => {
//     setFilterEndDate("");
//     setFilterStartDate("");
//   };

//   const shouldShowResetButton = () => {
//     return startDate || endDate;
//   };

//   return (
//     <>
//       <div className="sticky left-0">
//         <StrategicPlanMultiSelect
//           setSelectedPlans={setSelectedPlans}
//           selectedPlans={selectedPlans}
//         />
//         <div className="flex justify-start gap-3 pt-2">
//           <div className="flex justify-start flex-col lg:flex-row w-full items-center gap-3 lg:max-w-[40%]">
//             <StartDateFilter
//               setFilterStartDate={setFilterStartDate}
//               startDate={startDate}
//               minDate={StrategicPlanYearList?.start_year}
//               maxDate={StrategicPlanYearList?.end_year}
//             />
//             <EndDateFilter
//               setFilterEndDate={setFilterEndDate}
//               startDate={startDate}
//               endDate={endDate}
//               endYear={StrategicPlanYearList?.end_year}
//             />
//           </div>
//           {shouldShowResetButton() && (
//             <Button
//               color="default"
//               variant="flat"
//               size="sm"
//               radius="sm"
//               onPress={resetFields}
//             >
//               <IconRotate size={18} />
//               Reset Filters
//             </Button>
//           )}
//           <div className="relative mt-2" ref={dropdownRef}>
//             <button
//               onClick={(e) => {
//                 e.stopPropagation();
//                 setIsDropdownOpen(!isDropdownOpen);
//               }}
//               className="flex items-center gap-1 text-sm text-gray-600 hover:text-primary"
//             >
//               {perPage} Records Per Page
//               <span className="text-xs">{isDropdownOpen ? '▲' : '▼'}</span>
//             </button>

//             {isDropdownOpen && (
//               <div
//                 className="absolute top-full right-0 mt-0.5 bg-white border border-gray-200 rounded-md shadow-lg z-[100] w-24 max-h-60 overflow-y-auto"
//               >
//                 {[10, 20, 30, 40, 50, 100].map((size) => (
//                   <div
//                     key={size}
//                     onClick={(e) => {
//                       e.stopPropagation();
//                       handlePerPageChange(size);
//                       setIsDropdownOpen(false);
//                     }}
//                     className={`px-3 py-2 text-sm hover:bg-gray-100 cursor-pointer ${size === perPage ? "bg-gray-100 font-medium" : ""
//                       }`}
//                   >
//                     {size}
//                   </div>
//                 ))}
//               </div>
//             )}
//           </div>
//           <div className="flex items-center gap-4">
//             {/* Records Per Page Dropdown - Click to open */}


//             {data?.total_pages > 1 && (
//               <Pagination
//                 classNames={{
//                   wrapper: "bg-white",
//                   item: "bg-white text-black",
//                   cursor: "bg-white text-primary",
//                   prev: "bg-white text-black",
//                   next: "bg-white text-black",
//                 }}
//                 className="bg-white"
//                 radius="none"
//                 variant="light"
//                 isCompact
//                 showControls
//                 showShadow={false}
//                 page={page}
//                 total={data.total_pages}
//                 onChange={handlePageChange}
//               />
//             )}
//           </div>
//         </div>
//       </div>

//       {/* <div> */}
//       <div className="mt-3 ">
//         <>
//           {/* <ScrollShadow className="w-full "> */}
//           <div className={`${years.length >= 10}` ? "min-w-[3000px] bg-white" : "min-w-[2000px] bg-white"}>
//             {/* Sticky header container - positioned below the parent's fixed header */}
//             <div className=" sticky top-0 z-50 bg-white "> {/* Adjust top value based on your parent header height */}
//               {/* Years row */}
//               <div className="flex border-b bg-[#E9ECF2]">
//                 {years.map((year, index) => (
//                   <div
//                     key={year}
//                     className={`p-3 text-center font-medium flex-1 ${index < years.length - 1 ? "border-r border-gray-300" : ""
//                       }`}
//                   >
//                     {year}
//                   </div>
//                 ))}
//               </div>
//               {/* Quarters row */}
//               <div className="flex">
//                 {years.map((year, yearIndex) => (
//                   <div key={year} className="flex flex-1">
//                     {[1, 2, 3, 4].map((quarter) => (
//                       <div
//                         key={`${year}-Q${quarter}`}
//                         className={`flex-1 p-2 text-sm text-gray-600 text-center border-r border-dashed ${quarter === 4 && yearIndex === years.length - 1
//                           ? "border-none"
//                           : "last:border-solid last:border-gray-300"
//                           }`}
//                       >
//                         Q{quarter}
//                       </div>
//                     ))}
//                   </div>
//                 ))}
//               </div>
//             </div>

//             {/* Timeline Grid */}
//             <div className="relative min-h-[1000vh]">
//               {/* Grid Background */}
//               <div className="flex absolute inset-0">
//                 {years.map((year, yearIndex) => (
//                   <div
//                     key={year}
//                     className={`flex flex-1 ${yearIndex < years.length - 1 ? "border-r border-gray-300" : ""
//                       }`}
//                   >
//                     {[1, 2, 3, 4].map((quarter) => (
//                       <div
//                         key={`${year}-Q${quarter}`}
//                         className="flex-1 border-r border-dashed last:border-r-0"
//                       />
//                     ))}
//                   </div>
//                 ))}
//               </div>

//               {/* Projects */}
//               {data?.data.map((project, index) => {
//                 const startDate = parseCustomDate(project.start_date);
//                 const endDate = parseCustomDate(project.production_date);
//                 const startPercentage = Math.round(
//                   calculateDatePercentage(startDate, years.length)
//                 );
//                 const endPercentage = Math.round(
//                   calculateDatePercentage(endDate, years.length)
//                 );

//                 const colorClass = getProjectColorClass(project);
//                 const formateDate = (date) => format(date, "MM-dd-yyyy");

//                 return (
//                   <Popover key={project.id}>
//                     <PopoverTrigger>
//                       <div
//                         className={`absolute rounded-md border p-2 text-sm shadow-md cursor-pointer hover:opacity-90`}
//                         style={{
//                           left: `${startPercentage}%`,
//                           width: `${endPercentage - startPercentage}%`,
//                           top: `${30 + index * 60}px`,
//                           backgroundColor: project.department_color || '#3b82f6',
//                           color: 'white'
//                         }}
//                       >

//                         <p className="font-medium truncate">{project.name}</p>
//                         <p className="text-xs truncate">
//                           {project.department_choices} • {project.start_date}
//                           - {project.production_date}
//                         </p>
//                       </div>
//                     </PopoverTrigger>
//                     <PopoverContent>
//                       <div className="rounded-sm w-[500px]">
//                         <CardHeader className="gap-4">
//                           <h3 className="text-lg font-semibold">
//                             {project.name}
//                           </h3>
//                           <p className="text-default-500">
//                             {project.department_choices}
//                           </p>
//                         </CardHeader>
//                         <CardBody>
//                           <div className="space-y-4">
//                             <div>
//                               <h4 className="font-semibold mb-1">Timeline</h4>
//                               <ProjectTimelineView project={project} />
//                             </div>
//                             <div className="grid grid-cols-2 gap-4">
//                               <div>
//                                 <h4 className="font-semibold mb-1">
//                                   Start Date
//                                 </h4>
//                                 <p className="text-sm">
//                                   {formateDate(project.start_date)}
//                                 </p>
//                               </div>
//                               <div>
//                                 <h4 className="font-semibold mb-1">
//                                   End Date
//                                 </h4>
//                                 <p className="text-sm">
//                                   {formateDate(project.production_date)}
//                                 </p>
//                               </div>
//                             </div>
//                           </div>
//                         </CardBody>
//                       </div>
//                     </PopoverContent>
//                   </Popover>
//                 );
//               })}
//             </div>
//           </div>
//           {/* </ScrollShadow> */}
//           <div className="mt-4">
//             <Divider orientation="horizontal" className="my-4" />
//             <div className="flex justify-between items-center">
//               <div className="text-sm text-gray-600">
//                 ©{" "}
//                 {getCurrentDate({
//                   includeYear: true,
//                   includeMonth: false,
//                   includeDay: false,
//                 })}{" "}
//                 ProStrategy.ai . All Rights Reserved | Support Contact us
//               </div>


//             </div>
//           </div>
//         </>
//       </div>
//       {/* </div > */}
//     </>
//   );
// }


import {
  differenceInDays,
  endOfYear,
  format,
  parse,
  startOfYear,
} from "date-fns";

import { ScrollShadow } from "@nextui-org/scroll-shadow";
import { useCallback, useEffect, useRef, useState } from "react";
import usePermissionsStore from "../../../../../stores/usePermissionStore";
import useApi from "../../../../../hooks/useApi";
import { apiList } from "../../../../../services";
import { Popover, PopoverContent, PopoverTrigger } from "@nextui-org/popover";
import { CardBody, CardHeader } from "@nextui-org/card";
import { PageSpinner } from "../../../../../components";
import { Pagination } from "@nextui-org/pagination";
import { getCurrentDate } from "../../../../../utils/helpers";
import { StartDateFilter } from "./StartDateFilter";
import { EndDateFilter } from "./EndDateFilter";
import { Button } from "@nextui-org/button";
import { IconRotate } from "@tabler/icons-react";
import { mutate } from "swr";
import { Divider } from "@nextui-org/divider";
import { select } from "@nextui-org/theme";
import StrategicPlanMultiSelect from "./StrategicPlanMultiSelect";
import toast from "react-hot-toast";
import Swal from "sweetalert2/dist/sweetalert2.js";
import withReactContent from "sweetalert2-react-content";
import { useNavigate } from "react-router-dom";
import ProstrategyLogo from "../../../../../assets/icons/ProstrategyLogo";
import axios from "axios";
import hasPlanPermission from "../../../../../utils/hasPlanPermission";
const MySwal = withReactContent(Swal);

export default function GanttChartTab() {
  const [page, setPage] = useState(1);
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
  const [isNoData, setIsNoData] = useState(false);
  const [startDate, setFilterStartDate] = useState("");
  const [endDate, setFilterEndDate] = useState("");
  const [perPage, setPerPage] = useState(10);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useState(null);
  const [selectedPlans, setSelectedPlans] = useState(new Set());
  const hasShownError = useRef(false);
  const navigate = useNavigate();
  const [isError, setIsError] = useState(false);
  const [strategicPlans, setStrategicPlans] = useState([]);
  const [hasStrategicPlanError, setHasStrategicPlanError] = useState(true);
  const hasFetchedStrategicPlans = useRef(false);
  const [isHasPlanPermission, setIsHasPlanPermission] = useState(false)

  useEffect(() => {
    if (hasPlanPermission('select_multiple_strategic_plans')) {
      setIsHasPlanPermission(true)
    }
  }, [])

  // Fetch strategic plans only once on mount

  useEffect(() => {
    if (!hasFetchedStrategicPlans.current) {
      hasFetchedStrategicPlans.current = true;

      const fetchStrategicPlans = async () => {
        const storedUser = localStorage.getItem("prostrategy_auth");
        const token = storedUser ? JSON.parse(storedUser)?.token : null;
        try {

          const response = await axios.get(
            '/organization/strategic_plan_list_for_strategic_analysis',
            {
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );

          if (response?.data) {
            setStrategicPlans(response.data.data);
            setHasStrategicPlanError(false);
          }
        } catch (error) {
          console.error('Error fetching strategic plans:', error?.response);
          setHasStrategicPlanError(true);
          if (error?.response?.data?.message) {
            handleIntialStrategy(error.response.data.message);
          }
        }
      };

      fetchStrategicPlans();
    }
  }, [isHasPlanPermission]);

  // Set initial selected plan when strategic plans are loaded
  useEffect(() => {
    if (!hasStrategicPlanError && strategicPlans?.length > 0) {
      const currentStrategicHas = strategicPlans.find(item => item.id === strategicPlan)
      if (currentStrategicHas?.id) {
        // current selected plan have initial strategic settings will get from here and set in state
        setSelectedPlans(new Set([currentStrategicHas.id.toString()]));
      } else {
        setSelectedPlans(new Set([strategicPlans[0]?.id.toString()]));
      }
    }

  }, [strategicPlans, hasStrategicPlanError, strategicPlan]);

  const handleIntialStrategy = useCallback((errorMessage) => {
    if (errorMessage && !hasShownError.current) {
      hasShownError.current = true;
      MySwal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>
            <h2 className="text-xl font-semibold">Warning!</h2>
            <p className="mt-2">
              {"Please set initial strategic data first."}
            </p>
          </div>
        ),
        confirmButtonText: "Go to initial strategic data",
        customClass: {
          confirmButton:
            "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
        },
        allowOutsideClick: false,
        allowEscapeKey: false,
      }).then((result) => {
        if (result.isConfirmed) {
          navigate("/settings/strategic_data_tab");
        }
      });
    }
  }, [navigate]);

  // Only fetch these APIs when we have valid strategic plans
  const shouldFetchApis = !hasStrategicPlanError && selectedPlans.size > 0;
  const isValidDateSelection = startDate && endDate;

  // API for year list
  const { data: StrategicPlanYearList, isLoading: yearListLoading } = useApi(
    shouldFetchApis
      ? apiList.admin.StrategicPlanYearList.list.key(Array.from(selectedPlans).join(","))
      : null,
    shouldFetchApis
      ? apiList.admin.StrategicPlanYearList.list.call(Array.from(selectedPlans).join(","))
      : null
  );

  // Main data API - only fetch when we have year list data too
  const shouldFetchData = shouldFetchApis && StrategicPlanYearList;
  const { data, isLoading, error } = useApi(
    shouldFetchData || !isHasPlanPermission
      ? apiList.admin.strategyFormData.list.key(
        perPage,
        page,
        !isHasPlanPermission ? Array.from([strategicPlan]).join(",") : Array.from(selectedPlans).join(","),
        null,
        null,
        isValidDateSelection ? startDate : undefined,
        isValidDateSelection ? endDate : undefined
      )
      : null,
    shouldFetchData || !isHasPlanPermission
      ? apiList.admin.strategyFormData.list.call(
        perPage,
        page,
        !isHasPlanPermission ? Array.from([strategicPlan]).join(",") : Array.from(selectedPlans).join(","),
        null,
        null,
        isValidDateSelection ? startDate : undefined,
        isValidDateSelection ? endDate : undefined,
        null,
        null,
        null,
        null,
        "gantt_chart"
      )
      : null
  );


  // Rest of your component code...
  const handlePerPageChange = (size) => {
    setPerPage(size);
    setPage(1);
    mutate(
      apiList.admin.strategyFormData.list.key(
        size,
        page,
        !isHasPlanPermission ? Array.from([strategicPlan]).join(",") : Array.from(selectedPlans).join(","), // Use selectedPlans instead of strategicPlan
        null,
        null,
        startDate,
        endDate
      )
    );
  }


  useEffect(() => {
    setPage(1);
  }, [strategicPlan]);

  useEffect(() => {
    if (strategicPlan) {
      setIsNoData(false);
      mutate(
        apiList.admin.strategyFormData.list.key(
          page,
          !isHasPlanPermission ? Array.from([strategicPlan]).join(",") : Array.from(selectedPlans).join(","),
          null,
          null,
          startDate,
          endDate
        )
      );
    }
  }, [strategicPlan]);


  useEffect(() => {
    if (strategicPlan && startDate === "" && endDate === "") {
      setIsNoData(false);
      mutate(
        apiList.admin.strategyFormData.list.key(
          page,
          !isHasPlanPermission ? Array.from([strategicPlan]).join(",") : Array.from(selectedPlans).join(","),
          null,
          null,
          "",
          ""
        )
      );
    }
  }, [startDate, endDate]);

  useEffect(() => {
    if (data?.data.length === 0) {
      setIsNoData(true);
    } else {
      setIsNoData(false);
    }
  }, [data]);
  // 556d9330 - 12a5 - 45d1 - b044 - dbb72ebecd01
  // const colorClasses = ["bg-primary text-primary-foreground"];

  // Instead, create a function to get the color class for a project
  const getProjectColorClass = (project) => {
    // Default color if department_color is not available
    if (!project.department_color) {
      return "bg-primary text-primary-foreground";
    }

    // Use the department_color from the project data
    // Assuming department_color is a hex code or a valid CSS color
    return `bg-[${project.department_color}] text-white`;

    // OR if department_color is a Tailwind color class name:
    // return `bg-${project.department_color} text-${project.department_color}-foreground`;
  };

  const calculateDatePercentage = (date, totalYears) => {
    const startOfYear = new Date(date.getFullYear(), 0, 0);
    const dayOfYear = Math.floor((date - startOfYear) / (1000 * 60 * 60 * 24));
    const yearIndex = date.getFullYear() - years[0];

    return ((yearIndex + dayOfYear / 365) / totalYears) * 100;

  };

  const years = [];
  for (let year = StrategicPlanYearList?.start_year; year <= StrategicPlanYearList?.end_year; year++) {
    years.push(year);
  }


  const parseCustomDate = (dateString) =>
    parse(dateString, "MM-dd-yyyy", new Date());

  const ProjectTimelineView = ({ project }) => {
    const startDate = parseCustomDate(project.start_date);
    const endDate = parseCustomDate(project.production_date);

    const calculateDatePercentageInYear = (date, yearStart) => {
      const dayOfYear = differenceInDays(date, yearStart);
      return (dayOfYear / 365) * 100;
    };

    return (
      <div className="relative h-8 w-full bg-gray-100 rounded-md overflow-hidden">
        {years.map((year, yearIndex) => {
          const yearStart = startOfYear(new Date(year, 0, 1));
          const yearEnd = endOfYear(new Date(year, 11, 31));
          const projectInYear = startDate <= yearEnd && endDate >= yearStart;

          if (projectInYear) {
            const startInYear = startDate < yearStart ? yearStart : startDate;
            const endInYear = endDate > yearEnd ? yearEnd : endDate;

            const startPercentage = Math.round(
              calculateDatePercentageInYear(startInYear, yearStart)
            );
            const endPercentage = Math.round(
              calculateDatePercentageInYear(endInYear, yearStart)
            );
            const widthPercentage = endPercentage - startPercentage;

            return (
              <div
                key={year}
                className={`absolute h-full bg-primary text-primary-foreground`}
                style={{
                  left: `${(yearIndex / years.length) * 100 + startPercentage / years.length}%`,
                  width: `${widthPercentage / years.length}%`,
                  boxSizing: "border-box",
                  border: "2px solid transparent",
                }}
              />
            );
          }
          return null;
        })}

        {years.map((year, index) => (
          <div
            key={year}
            className="absolute h-full border-l border-gray-400"
            style={{ left: `${(index / years.length) * 100}%` }}
          >
            <span className="absolute top-2 left-1 text-xs text-black">
              {year}
            </span>
          </div>
        ))}
      </div>
    );
  };

  const handlePageChange = (newPage) => {
    setPage(newPage);
  };

  if (isLoading || !strategicPlan) {
    return <PageSpinner />;
  }

  const resetFields = () => {
    onClear();
    setIsNoData(false);
    // mutate(apiList.admin.strategyFormData.list.key(page, strategicPlan, null, null, startDate, endDate))
  };

  const onClear = () => {
    setFilterEndDate("");
    setFilterStartDate("");
  };

  const shouldShowResetButton = () => {
    return startDate || endDate;
  };

  return (
    <>
      {isHasPlanPermission && (
        <StrategicPlanMultiSelect
          setSelectedPlans={setSelectedPlans}
          selectedPlans={selectedPlans}
          isHasPlanPermission={isHasPlanPermission}
        />
      )}
      <div className="sticky left-0 z-50">
        <div className="flex justify-start gap-3 pt-2">
          <div className="flex justify-start flex-col lg:flex-row w-full items-center gap-3 lg:max-w-[40%]">
            <StartDateFilter
              setFilterStartDate={setFilterStartDate}
              startDate={startDate}
              minDate={StrategicPlanYearList?.start_year}
              maxDate={StrategicPlanYearList?.end_year}
            />
            <EndDateFilter
              setFilterEndDate={setFilterEndDate}
              startDate={startDate}
              endDate={endDate}
              endYear={StrategicPlanYearList?.end_year}
            />
          </div>
          {shouldShowResetButton() && (
            <Button
              color="default"
              variant="flat"
              size="sm"
              radius="sm"
              onPress={resetFields}
            >
              <IconRotate size={18} />
              Reset Filters
            </Button>
          )}
          <div className="relative mt-2" ref={dropdownRef}>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsDropdownOpen(!isDropdownOpen);
              }}
              className="flex items-center gap-1 text-sm text-gray-600 hover:text-primary"
            >
              {perPage} Records Per Page
              <span className="text-xs">{isDropdownOpen ? '▲' : '▼'}</span>
            </button>

            {isDropdownOpen && (
              <div
                className="absolute top-full right-0 mt-0.5 bg-white border border-gray-200 rounded-md shadow-lg z-[100] w-24 max-h-60 overflow-y-auto"
              >
                {[10, 20, 30, 40, 50, 100].map((size) => (
                  <div
                    key={size}
                    onClick={(e) => {
                      e.stopPropagation();
                      handlePerPageChange(size);
                      setIsDropdownOpen(false);
                    }}
                    className={`px-3 py-2 text-sm hover:bg-gray-100 cursor-pointer ${size === perPage ? "bg-gray-100 font-medium" : ""
                      }`}
                  >
                    {size}
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="flex items-center gap-4">
            {/* Records Per Page Dropdown - Click to open */}


            {data?.total_pages > 1 && (
              <Pagination
                classNames={{
                  wrapper: "bg-white",
                  item: "bg-white text-black",
                  cursor: "bg-white text-primary",
                  prev: "bg-white text-black",
                  next: "bg-white text-black",
                }}
                className="bg-white"
                radius="none"
                variant="light"
                isCompact
                showControls
                showShadow={false}
                page={page}
                total={data.total_pages}
                onChange={handlePageChange}
              />
            )}
          </div>
        </div>
      </div>

      {/* <div> */}
      <div className="mt-3 ">
        <>
          {/* <ScrollShadow className="w-full "> */}
          <div className={`${years.length >= 10}` ? "min-w-[3000px] bg-white" : "min-w-[2000px] bg-white"}>
            {/* Sticky header container - positioned below the parent's fixed header */}
            <div className=" sticky top-0 z-20 bg-white "> {/* Adjust top value based on your parent header height */}
              {/* Years row */}
              <div className="flex border-b bg-[#E9ECF2]">
                {years.map((year, index) => (
                  <div
                    key={year}
                    className={`p-3 text-center font-medium flex-1 ${index < years.length - 1 ? "border-r border-gray-300" : ""
                      }`}
                  >
                    {year}
                  </div>
                ))}
              </div>
              {/* Quarters row */}
              <div className="flex">
                {years.map((year, yearIndex) => (
                  <div key={year} className="flex flex-1">
                    {[1, 2, 3, 4].map((quarter) => (
                      <div
                        key={`${year}-Q${quarter}`}
                        className={`flex-1 p-2 text-sm text-gray-600 text-center border-r border-dashed ${quarter === 4 && yearIndex === years.length - 1
                          ? "border-none"
                          : "last:border-solid last:border-gray-300"
                          }`}
                      >
                        Q{quarter}
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            </div>

            {/* Timeline Grid */}
            <div className="relative min-h-[1000vh]">
              {/* Grid Background */}
              <div className="flex absolute inset-0">
                {years.map((year, yearIndex) => (
                  <div
                    key={year}
                    className={`flex flex-1 ${yearIndex < years.length - 1 ? "border-r border-gray-300" : ""
                      }`}
                  >
                    {[1, 2, 3, 4].map((quarter) => (
                      <div
                        key={`${year}-Q${quarter}`}
                        className="flex-1 border-r border-dashed last:border-r-0"
                      />
                    ))}
                  </div>
                ))}
              </div>

              {/* Projects */}
              {data?.data.map((project, index) => {
                const startDate = parseCustomDate(project.start_date);
                const endDate = parseCustomDate(project.production_date);
                const startPercentage = Math.round(
                  calculateDatePercentage(startDate, years.length)
                );
                const endPercentage = Math.round(
                  calculateDatePercentage(endDate, years.length)
                );

                const colorClass = getProjectColorClass(project);
                const formateDate = (date) => format(date, "MM-dd-yyyy");

                return (
                  <Popover key={project.id}>
                    <PopoverTrigger>
                      <div
                        className={`absolute rounded-md border p-2 text-sm shadow-md cursor-pointer hover:opacity-90`}
                        style={{
                          left: `${startPercentage}%`,
                          width: `${endPercentage - startPercentage}%`,
                          top: `${30 + index * 60}px`,
                          backgroundColor: project.department_color || '#3b82f6',
                          color: 'white'
                        }}
                      >

                        <p className="font-medium truncate">{project.name}</p>
                        <p className="text-xs truncate">
                          {project.department_choices} • {project.start_date}
                          - {project.production_date}
                        </p>
                      </div>
                    </PopoverTrigger>
                    <PopoverContent>
                      <div className="rounded-sm w-[500px]">
                        <CardHeader className="gap-4">
                          <h3 className="text-lg font-semibold">
                            {project.name}
                          </h3>
                          <p className="text-default-500">
                            {project.department_choices}
                          </p>
                        </CardHeader>
                        <CardBody>
                          <div className="space-y-4">
                            <div>
                              <h4 className="font-semibold mb-1">Timeline</h4>
                              <ProjectTimelineView project={project} />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <h4 className="font-semibold mb-1">
                                  Start Date
                                </h4>
                                <p className="text-sm">
                                  {formateDate(project.start_date)}
                                </p>
                              </div>
                              <div>
                                <h4 className="font-semibold mb-1">
                                  End Date
                                </h4>
                                <p className="text-sm">
                                  {formateDate(project.production_date)}
                                </p>
                              </div>
                            </div>
                          </div>
                        </CardBody>
                      </div>
                    </PopoverContent>
                  </Popover>
                );
              })}
            </div>
          </div>
          {/* </ScrollShadow> */}
          <div className="mt-4">
            <Divider orientation="horizontal" className="my-4" />
            <div className="flex justify-between items-center">
              <div className="text-sm text-gray-600">
                ©{" "}
                {getCurrentDate({
                  includeYear: true,
                  includeMonth: false,
                  includeDay: false,
                })}{" "}
                ProStrategy.ai . All Rights Reserved | Support Contact us
              </div>


            </div>
          </div>
        </>
      </div>
      {/* </div > */}
    </>
  );
}
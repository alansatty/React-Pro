

import { useMemo, useState, useRef, useEffect } from "react"
import toast from "react-hot-toast"
import { Chip } from "@nextui-org/chip"
import { Checkbox } from "@nextui-org/checkbox"
import { IconChevronDown, IconChevronUp } from "@tabler/icons-react";

const CustomMultiSelect = ({
    items = [],
    selectedItems,
    setSelectedItems,
    placeholder = "Select items",
    itemLabel = "name",
    itemValue = "id",
    isLoading = false,
    errorMessage = "At least one item must be selected",
    className = "",
    disabled = false,
    maxHeight = "max-h-60",
    // defaultSelectedItem
}) => {

    const [isOpen, setIsOpen] = useState(false)
    const dropdownRef = useRef(null)

    const selectedKeys = useMemo(() => {
        return Array.from(selectedItems)
    }, [selectedItems])

    // Close dropdown when clicking outside
    useEffect(() => {
        const handleClickOutside = (event) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                setIsOpen(false)
            }
        }

        document.addEventListener("mousedown", handleClickOutside)
        return () => {
            document.removeEventListener("mousedown", handleClickOutside)
        }
    }, [])
    const handleSelectionChange = (key) => {
        if (disabled) return

        const newSelection = new Set(selectedItems)

        if (newSelection.has(key)) {
            // Only apply the "last item" validation when changing selection through the dropdown
            if (newSelection.size === 1) {
                toast.error(errorMessage)
                return
            }
            newSelection.delete(key)
        } else {
            newSelection.add(key)
        }

        setSelectedItems(newSelection)
    }

    const handleRemoveItem = (key, event) => {

        // Create new selection without the item to be removed
        const newSelection = new Set(selectedItems)
        newSelection.delete(key)

        // Update the selection directly (bypassing the validation in handleSelectionChange)
        setSelectedItems(newSelection)
    }


    const toggleDropdown = () => {
        if (!disabled) {
            setIsOpen(!isOpen)
        }
    }

    const handleOptionClick = (key, event) => {

        event.stopPropagation()
        handleSelectionChange(key)
        setIsOpen(false)
        // Don't close dropdown here to allow multiple selections   
    }

    return (
        <div className={`relative ${className}`} ref={dropdownRef}>
            {/* Dropdown Trigger */}
            <div
                className={`
                    flex flex-wrap items-center gap-2 min-h-12 p-3 border rounded-lg 
                    border-default-300 bg-content1 
                    hover:border-default-400 transition-colors cursor-pointer
                    ${disabled ? "opacity-50 cursor-not-allowed" : ""}
                    ${isOpen ? "border-default-500 ring-1 ring-default-200" : ""}
                `}
                onClick={toggleDropdown}
            >
                <div className="flex flex-wrap gap-2 flex-1 min-h-6">
                    {selectedKeys.length === 0 && (
                        <span className="text-default-500 text-sm flex items-center">{placeholder}</span>
                    )}
                    {selectedKeys.map((key) => {
                        const item = items.find((i) => i[itemValue] === key)
                        const isLastItem = selectedKeys.length === 1

                        return (
                            <Chip
                                key={key}
                                onClose={!disabled && !isLastItem ? (event) => handleRemoveItem(key, event) : undefined}
                                variant="flat"
                                size="sm"
                                classNames={{
                                    base: `bg-default-100 text-default-800 ${isLastItem ? "bg-default-200" : ""}`,
                                    closeButton: `text-default-500 hover:bg-default-200 ${isLastItem || disabled ? "hidden" : ""}`,
                                }}
                            // endContent={isLastItem ? <span className="text-xs ml-1 opacity-60">(required)</span> : null}
                            >
                                {item?.[itemLabel]}
                            </Chip>
                        )
                    })}
                </div>

                {/* Dropdown Arrow */}
                <div className="flex items-center ml-2">
                    {isOpen ? (
                        <IconChevronUp className="w-4 h-4 text-default-500" />
                    ) : (
                        <IconChevronDown className="w-4 h-4 text-default-500" />
                    )}
                </div>
            </div>

            {/* Dropdown Options */}
            {isOpen && (
                <div
                    className={`
                        absolute z-[9999] top-full left-0 right-0 mt-1
                        flex flex-col gap-1 ${maxHeight} overflow-y-auto p-1 
                        border border-default-300 rounded-lg bg-white shadow-lg
                        ${disabled ? "opacity-50" : ""}
                    `}
                >
                    {isLoading ? (
                        <div className="text-default-500 text-sm p-3 text-center">
                            <div className="animate-pulse">Loading options...</div>
                        </div>
                    ) : items.length === 0 ? (
                        <div className="text-default-500 text-sm p-3 text-center">No options available</div>
                    ) : (
                        items.map((item) => {
                            const isSelected = selectedItems.has(item[itemValue])
                            const isLastSelected = isSelected && selectedKeys.length === 1

                            return (
                                <div
                                    key={item[itemValue]}
                                    className={`
                                        flex items-center gap-3 p-3 rounded-lg transition-colors
                                        ${disabled ? "cursor-not-allowed" : "cursor-pointer hover:bg-default-100"}
                                        ${isSelected ? "bg-default-100" : ""}
                                    `}
                                    onClick={(event) => !disabled && handleOptionClick(item[itemValue], event)}
                                >
                                    <Checkbox
                                        isSelected={isSelected}
                                        isDisabled={disabled || isLastSelected}
                                        onChange={(event) => !disabled && handleOptionClick(item[itemValue], event)}
                                    />
                                    <span className="flex-1 text-sm">
                                        {item[itemLabel]}
                                    </span>
                                    {isLastSelected && <span className="text-xs text-default-500">Required</span>}
                                </div>
                            )
                        })
                    )}
                </div>
            )}

            {/* Helper Text */}
            {/* {selectedKeys.length === 1 && (
                <div className="text-xs text-default-500 px-1 mt-1">
                    ⚠️ At least one item must remain selected
                </div>
            )} */}
        </div>
    )
}

export default CustomMultiSelect
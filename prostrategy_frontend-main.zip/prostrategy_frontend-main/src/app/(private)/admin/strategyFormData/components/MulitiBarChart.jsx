
// import React from "react";
// import {
//   BarChart,
//   Bar,
//   XAxis,
//   YAxis,
//   CartesianGrid,
//   Tooltip,
//   Legend,
//   ResponsiveContainer,
// } from "recharts";

// // Helper to format values into K/M/B
// const formatLarge = (num) => {
//   if (num >= 1e9) return (num / 1e9).toFixed(1) + "B";
//   if (num >= 1e6) return (num / 1e6).toFixed(1) + "M";
//   if (num >= 1e3) return (num / 1e3).toFixed(1) + "K";
//   return num;
// };

// // Custom Tooltip component
// const CustomTooltip = ({ active, payload, label, doller = '', text = '' }) => {
//   if (active && payload && payload.length) {
//     return (
//       <div className="custom-tooltip" style={{
//         backgroundColor: '#fff',
//         padding: '10px',
//         border: '1px solid #ccc',
//         borderRadius: '4px'
//       }}>
//         <p className="label">{`Year: ${label}`}</p>
//         {payload.map((entry, index) => (
//           <p key={`item-${index}`} style={{ color: entry.color }}>
//             {
//               doller === '%' ? `${entry.name}: ${formatLarge(entry.value)}${text}${doller}`
//                 : `${entry.name}: ${doller}${formatLarge(entry.value)}${text}`

//             }
//           </p>
//         ))}
//       </div>
//     );
//   }
//   return null;
// };

// const MultiBarChart = ({ chartdata, chartname, text = "", doller = "" }) => {
//   if (!chartdata || !Object.keys(chartdata).length) return null;

//   // 1️⃣ Gather all unique categories (series keys)
//   const allCategories = new Set();
//   Object.values(chartdata).forEach((yearData) => {
//     Object.keys(yearData).forEach((cat) => allCategories.add(cat));
//   });
//   const categoryList = Array.from(allCategories);

//   // 2️⃣ Build category → color map and also normalize data values
//   const categoryColors = {};
//   const data = Object.entries(chartdata).map(([year, values]) => {
//     const record = { name: year };

//     categoryList.forEach((cat) => {
//       const payload = values[cat];

//       if (payload && typeof payload === "object" && "value" in payload) {
//         // nested { value, dept_color }
//         record[cat] = payload.value;
//         if (payload.dept_color && !categoryColors[cat]) {
//           categoryColors[cat] = payload.dept_color;
//         }
//       } else {
//         // numeric series like asset_growth: 123
//         record[cat] = payload ?? 0;
//       }
//     });

//     return record;
//   });

//   // 3️⃣ Auto-size bars
//   const barSize =
//     categoryList.length <= 4 ? 20 : Math.max(10, 120 / categoryList.length);
//   const formatYAxis = (value) => doller === '%' ? `${formatLarge(value)}${text}${doller}` : `${doller}${formatLarge(value)}${text}`;

//   return (
//     <div style={{ width: "100%", height: 400, padding: 20 }}>
//       <p className="text-lg font-semibold text-center">{chartname}</p>
//       <ResponsiveContainer width="100%" height="100%">
//         <BarChart
//           data={data}
//           margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
//         >
//           <CartesianGrid strokeDasharray="3 3" />
//           <XAxis dataKey="name" tick={{ fontSize: 10 }} />
//           <YAxis tickFormatter={formatYAxis} tick={{ fontSize: 10 }} />
//           <Tooltip
//             content={<CustomTooltip doller={doller} text={text} />}
//           />
//           <Legend />

//           {categoryList.map((cat) => (
//             <Bar
//               key={cat}
//               dataKey={cat}
//               barSize={barSize}
//               // use the extracted dept_color or fallback
//               fill={categoryColors[cat] || "#888888"}
//               activeFill="blue"
//             />
//           ))}
//         </BarChart>
//       </ResponsiveContainer>
//     </div>
//   );
// };

// export default MultiBarChart;


import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell,
} from "recharts";

// Helper to format values into K/M/B
const formatLarge = (num) => {
  if (num >= 1e9) return (num / 1e9).toFixed(1) + "B";
  if (num >= 1e6) return (num / 1e6).toFixed(1) + "M";
  if (num >= 1e3) return (num / 1e3).toFixed(1) + "K";
  return num;
};

// Custom Tooltip component
const CustomTooltip = ({ active, payload, label, doller = '', text = '' }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip" style={{
        backgroundColor: '#fff',
        padding: '10px',
        border: '1px solid #ccc',
        borderRadius: '4px'
      }}>
        <p className="label">{`Year: ${label}`}</p>
        {payload.map((entry, index) => (
          <p key={`item-${index}`} style={{ color: "black" }}>
            {
              doller === '%' ? `${entry.name}: ${formatLarge(entry.value)}${text}${doller}`
                : `${entry.name}: ${doller}${formatLarge(entry.value)}${text}`
            }
          </p>
        ))}
      </div>
    );
  }
  return null;
};

const MultiBarChart = ({ chartdata, chartname, text = "", doller = "" }) => {
  if (!chartdata || !Object.keys(chartdata).length) return null;

  // 1️⃣ Gather all unique categories (series keys)
  const allCategories = new Set();
  Object.values(chartdata).forEach((yearData) => {
    Object.keys(yearData).forEach((cat) => allCategories.add(cat));
  });
  const categoryList = Array.from(allCategories);

  // 2️⃣ Build data with color information for each bar
  const data = Object.entries(chartdata).map(([year, values]) => {
    const record = { name: year };

    // Store color information for each category in this year
    record.colors = {};

    categoryList.forEach((cat) => {
      const payload = values[cat];

      if (payload && typeof payload === "object" && "value" in payload) {
        // nested { value, dept_color }
        record[cat] = payload.value;
        record.colors[cat] = payload.dept_color;
      } else {
        // numeric series like asset_growth: 123
        record[cat] = payload ?? 0;
        record.colors[cat] = "#888888"; // default color
      }
    });

    return record;
  });

  // Custom Legend component
  const CustomLegend = ({ payload }) => {
    return (
      <ul
        style={{
          display: "flex",
          flexWrap: "wrap",
          justifyContent: "center",
          alignItems: "center",
          listStyle: "none",
          padding: 0,
          margin: 0,
        }}
      >
        {payload.map((entry, index) => (
          <li
            key={`item-${index}`}
            style={{
              marginRight: 16,
              marginBottom: 8,
              display: "flex",
              alignItems: "center",
              color: "black",
              fontSize: 14,
            }}
          >
            <span
              style={{
                display: "inline-block",
                width: 12,
                height: 12,
                backgroundColor: entry.color || "#000",
                marginRight: 5,
                borderRadius: 2,
              }}
            />
            {entry.value}
          </li>
        ))}
      </ul>
    );
  };





  // 3️⃣ Auto-size bars
  const barSize =
    categoryList.length <= 4 ? 20 : Math.max(10, 120 / categoryList.length);
  const formatYAxis = (value) => doller === '%' ? `${formatLarge(value)}${text}${doller}` : `${doller}${formatLarge(value)}${text}`;

  return (
    <div style={{ width: "100%", height: 400, padding: 20 }}>
      <p className="text-lg font-semibold text-center">{chartname}</p>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={data}
          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" tick={{ fontSize: 10 }} />
          <YAxis tickFormatter={formatYAxis} tick={{ fontSize: 10 }} />
          <Tooltip
            content={<CustomTooltip doller={doller} text={text} />}
          />
          <Legend content={<CustomLegend />} />

          {categoryList.map((cat) => {
            // get first available color for this category
            const sampleColor =
              data.find((d) => d.colors[cat])?.colors[cat] || "#888888";

            return (
              <Bar
                key={cat}
                dataKey={cat}
                barSize={barSize}
                fill={sampleColor} 
              >
                {data.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={entry.colors[cat] || "#888888"} // ✅ bars use this
                  />
                ))}
              </Bar>
            );
          })}
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default MultiBarChart;
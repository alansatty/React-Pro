import { Input } from "@nextui-org/input";
export const EndDateFilter = ({ setFilterEndDate, startDate, endDate, endYear }) => {

    const endYearString = endYear ? `${endYear}-12-31` : '';
    return (
        <>
            <Input
                type="date"
                label="End Date"
                variant="bordered"
                size="sm"
                className="min-w-40"
                min={startDate || "2024-01-01"}
                isDisabled={!startDate}
                max={endYearString}
                onChange={(e) => setFilterEndDate(e.target.value)}
                value={endDate}
                classNames={{
                    inputWrapper: [
                        "data-[focus=true]:border-2 data-[focus=true]:border-[#0098F5]",
                        "dark:data-[focus=true]:border-2 dark:data-[focus=true]:border-[#0098F5]",
                    ],
                }}
            />
        </>
    );
};
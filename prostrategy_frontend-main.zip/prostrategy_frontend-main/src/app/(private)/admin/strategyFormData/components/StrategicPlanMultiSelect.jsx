import { useEffect, useState } from "react";
import { apiList } from "../../../../../services";
import useApi from "../../../../../hooks/useApi";
import CustomMultiSelect from "./CustomMultiSelect";
import toast from "react-hot-toast";

const StrategicPlanMultiSelect = ({ setSelectedPlans, selectedPlans, isHasPlanPermission }) => {
  const { data: strategicPlans, isLoading: strategicLoading, error, } = useApi(
    isHasPlanPermission ? apiList.admin.strategicPlanWithIntialData.list.key : null,
    isHasPlanPermission ? apiList.admin.strategicPlanWithIntialData.list.call() : null
  );

  useEffect(() => {
    if (strategicPlans?.data?.length > 0 && selectedPlans.size === 0) {
      // Set first plan as default
      setSelectedPlans(new Set([strategicPlans.data[0]?.id]));
    }
  }, [strategicPlans, selectedPlans.size, setSelectedPlans]);

  return (
    <CustomMultiSelect
      items={strategicPlans?.data || []}
      selectedItems={selectedPlans}
      setSelectedItems={setSelectedPlans}
      placeholder="Select strategic plans"
      isLoading={strategicLoading}
      // defaultSelectedItem={strategicPlans?.data[0]?.id}
      errorMessage="At least one strategic plan must be selected"
      className="mt-3"
    />
  );
};

export default StrategicPlanMultiSelect;
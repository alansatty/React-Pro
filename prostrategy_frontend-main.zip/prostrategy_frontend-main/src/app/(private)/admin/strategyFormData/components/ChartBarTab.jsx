
// import { useState, useEffect, useRef, useCallback } from 'react';
// import SingleBarCharter from './SingleBarCharter';
// import MultiBarChart from './MulitiBarChart';
// import usePermissionsStore from '../../../../../stores/usePermissionStore';
// import { useNavigate } from 'react-router-dom';
// import ProstrategyLogo from "../../../../../assets/icons/ProstrategyLogo";
// import Swal from "sweetalert2/dist/sweetalert2.js";
// import withReactContent from "sweetalert2-react-content";
// import axios from 'axios';
// import { useAuth } from '../../../../../providers/authProviders';
// import StrategicPlanMultiSelect from './StrategicPlanMultiSelect';
// import { PageSpinner } from '../../../../../components';
// import useApi from '../../../../../hooks/useApi';
// import { apiList } from '../../../../../services';
// import { set } from 'date-fns';

// const MySwal = withReactContent(Swal);

// export default function ChartBarTab() {
//   const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
//   const [chartData, setChartData] = useState([]);
//   const [selectedPlans, setSelectedPlans] = useState(new Set());
//   const [multiChartData, setMultiChartData] = useState([]);
//   const [hasInitialDataError, setHasInitialDataError] = useState(false);
//   const [isLoading, setIsLoading] = useState(false);
//   const [error, setError] = useState(null);
//   const navigate = useNavigate();
//   const auth = useAuth();
//   const controllerRef = useRef(null);
//   const [chartValues, setChartValues] = useState(null);
//   const hasShownError = useRef(false);
//   const [isError, setIsError] = useState(false);
//   const [strategicPlans, setStrategicPlans] = useState([]);
//   const [hasStrategicPlanError, setHasStrategicPlanError] = useState(true);
//   const hasFetchedStrategicPlans = useRef(false);
//   const initialSelectedPlansSet = useRef(false);
//   const hasInitialGraphFetch = useRef(false); // Add this to track initial fetch

//   // Memoized error handler - Remove navigate dependency to prevent recreation
//   const handleIntialStrategy = useCallback((errorMessage) => {
//     if (errorMessage && !hasShownError.current) {
//       hasShownError.current = true;
//       MySwal.fire({
//         html: (
//           <div className="flex flex-col items-center">
//             <div className="w-18 h-20 mb-2">
//               <ProstrategyLogo />
//             </div>
//             <h2 className="text-xl font-semibold">Warning!</h2>
//             <p className="mt-2">
//               {errorMessage || "Please set initial strategic data first."}
//             </p>
//           </div>
//         ),
//         confirmButtonText: "Go to initial strategic data",
//         customClass: {
//           confirmButton:
//             "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
//         },
//         allowOutsideClick: false,
//         allowEscapeKey: false,
//       }).then((result) => {
//         if (result.isConfirmed) {
//           navigate("/settings/strategic_data_tab");
//         }
//       });
//     }
//   }, []); // Remove navigate dependency

//   // Fetch strategic plans only once on mount
//   useEffect(() => {
//     if (!hasFetchedStrategicPlans.current) {
//       hasFetchedStrategicPlans.current = true;
//       const fetchStrategicPlans = async () => {
//         const storedUser = localStorage.getItem("prostrategy_auth");
//         const token = storedUser ? JSON.parse(storedUser)?.token : null;
//         try {
//           const response = await axios.get(
//             '/organization/strategic_plan_list_for_strategic_analysis',
//             {
//               headers: {
//                 Authorization: `Bearer ${token}`,
//               },
//             }
//           );
//           if (response?.data) {
//             setStrategicPlans(response.data.data);
//             setHasStrategicPlanError(false);
//           }
//         } catch (error) {
//           console.error('Error fetching strategic plans:', error?.response);
//           setHasStrategicPlanError(true);
//           if (error?.response?.data?.message) {
//             handleIntialStrategy(error.response.data.message);
//           }
//         }
//       };
//       fetchStrategicPlans();
//     }
//   }, [handleIntialStrategy]);

//   // Set initial selected plan when strategic plans are loaded
//   useEffect(() => {
//     if (!initialSelectedPlansSet.current && !hasStrategicPlanError && strategicPlans?.length > 0) {
//       initialSelectedPlansSet.current = true;
//       const currentStrategicHas = strategicPlans.find(item => item.id === strategicPlan);
//       if (currentStrategicHas?.id) {
//         setSelectedPlans(new Set([currentStrategicHas.id.toString()]));
//       } else {
//         setSelectedPlans(new Set([strategicPlans[0]?.id.toString()]));
//       }
//     }
//   }, [strategicPlans, hasStrategicPlanError, strategicPlan]);

//   // Reset states when strategic plan changes
//   useEffect(() => {
//     setHasInitialDataError(false);
//     setChartData([]);
//     setMultiChartData([]);
//     setIsLoading(true);
//     hasInitialGraphFetch.current = false; // Reset the fetch flag when strategic plan changes
//   }, [strategicPlan]);

//   // Simplified fetchStrategicGraphs function (not a useCallback)
//   const fetchStrategicGraphs = async (planIds) => {
//     if (hasStrategicPlanError || planIds.size === 0) return;

//     setIsLoading(true);
//     setError(null);

//     try {
//       const planPath = `/?strategic_plan_ids=${Array.from(planIds).join(",")}`;
//       const url = `/organization/strategic_form_data/strategic_graphs${planPath}`;
//       const response = await axios.get(url, {
//         headers: {
//           'Authorization': `Bearer ${auth.user.token}`,
//         },
//       });

//       if (response.data?.status === "success" && response.data?.data) {
//         setChartValues(response.data);
//         setHasInitialDataError(false);
//       }
//     } catch (err) {
//       if (axios.isCancel(err)) {
//         console.log('Request canceled:', err.message);
//         return;
//       }
//       console.error("Error fetching strategic graphs:", err);
//       // setError(err.response || err);
//       // if (err.response?.status === 401) {
//       //   MySwal.fire({
//       //     title: 'Session Expired',
//       //     text: 'Your session has expired. Please log in again.',
//       //     icon: 'warning',
//       //     confirmButtonText: 'OK'
//       //   }).then(() => {
//       //     navigate('/login');
//       //   });
//       // }
//       // // else if (err.response?.status === 400) {
//       //   setHasInitialDataError(true);
//       //   setChartData([]);
//       //   setMultiChartData([]);
//       //   handleIntialStrategy("Please update the initial strategic data in settings to get graph data.");
//       // }
//     } finally {
//       setIsLoading(false);
//     }
//   };

//   // Fetch graphs only when selected plans change and it's the initial fetch
//   useEffect(() => {
//     if (initialSelectedPlansSet.current && !hasInitialGraphFetch.current && selectedPlans.size > 0) {
//       hasInitialGraphFetch.current = true;
//       fetchStrategicGraphs(selectedPlans);
//     }

//   }, [selectedPlans, initialSelectedPlansSet.current]);

//   const handlePlanSelectionChange = (newSelectedPlans) => {
//     setSelectedPlans(newSelectedPlans);
//     fetchStrategicGraphs(newSelectedPlans);
//   };

//   const hasData = chartData.length > 0 || multiChartData.length > 0;

//   if (!strategicPlan) {
//     return <div className="text-center py-4 col-span-2">No strategic plan selected.</div>;
//   }

//   if (isLoading) {
//     return <p className="text-center py-4 col-span-2"><PageSpinner /></p>;
//   }

//   if (hasInitialDataError) {
//     return <div className="text-center py-4 col-span-2">No records.</div>;
//   }

//   return (
//     <>
//       <StrategicPlanMultiSelect
//         setSelectedPlans={handlePlanSelectionChange}
//         selectedPlans={selectedPlans}
//       />
//       {chartValues && chartValues.data && (
//         <div className="grid grid-cols-2 gap-4">
//           {Object.entries(chartValues?.data).map(([key, item], index) => {
//             const graphType = item.common_value?.graph_type?.toLowerCase();
//             if (graphType === "single") {
//               return (
//                 <SingleBarCharter
//                   key={index}
//                   chartname={item?.common_value?.name}
//                   chartdata={item?.year_based_value}
//                   doller={item?.common_value?.metric_measurement === 'dollor' ? '$' : ''}
//                   text=""
//                 />
//               );
//             }
//             if (graphType === "multiple") {
//               return (
//                 <MultiBarChart
//                   key={index}
//                   chartname={item?.common_value.name}
//                   chartdata={item?.year_based_value}
//                   doller={item?.common_value?.metric_measuremen}
//                   text=""
//                 />
//               );
//             }
//             return null;
//           })}
//         </div>
//       )}

//       {(!chartValues || !chartValues.data || Object.keys(chartValues.data).length === 0) && (
//         <div className="text-center py-4 col-span-2">
//           No records.
//         </div>
//       )}
//     </>
//   );
// }




import { useState, useEffect, useRef, useCallback } from 'react';
import SingleBarCharter from './SingleBarCharter';
import MultiBarChart from './MulitiBarChart';
import usePermissionsStore from '../../../../../stores/usePermissionStore';
import { useNavigate } from 'react-router-dom';
import ProstrategyLogo from "../../../../../assets/icons/ProstrategyLogo";
import Swal from "sweetalert2/dist/sweetalert2.js";
import withReactContent from "sweetalert2-react-content";
import axios from 'axios';
import { useAuth } from '../../../../../providers/authProviders';
import StrategicPlanMultiSelect from './StrategicPlanMultiSelect';
import { PageSpinner } from '../../../../../components';
import hasPlanPermission from '../../../../../utils/hasPlanPermission';
const MySwal = withReactContent(Swal);

export default function ChartBarTab() {
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
  const [chartData, setChartData] = useState([]);
  const [selectedPlans, setSelectedPlans] = useState(new Set());
  const [multiChartData, setMultiChartData] = useState([]);
  const [hasInitialDataError, setHasInitialDataError] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  const auth = useAuth();
  const controllerRef = useRef(null);
  const [chartValues, setChartValues] = useState(null);
  const hasShownError = useRef(false);
  const [isError, setIsError] = useState(false);
  const [strategicPlans, setStrategicPlans] = useState([]);
  const [hasStrategicPlanError, setHasStrategicPlanError] = useState(true);
  const hasFetchedStrategicPlans = useRef(false);
  const initialSelectedPlansSet = useRef(false);
  const hasInitialGraphFetch = useRef(false);
  const previousStrategicPlan = useRef(strategicPlan)
  const [isHasPlanPermission, setIsHasPlanPermission] = useState(false)
  const hasFetchedData = useRef(false)

  useEffect(() => {
    if (hasPlanPermission('select_multiple_strategic_plans')) {
      setIsHasPlanPermission(true)
    }
  }, [])

  // Memoized error handler - Remove navigate dependency to prevent recreation
  const handleIntialStrategy = useCallback((errorMessage) => {
    if (errorMessage && !hasShownError.current) {

      hasShownError.current = true;
      MySwal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>
            <h2 className="text-xl font-semibold">Warning!</h2>
            <p className="mt-2">
              {errorMessage || "Please set initial strategic data first."}
            </p>
          </div>
        ),
        confirmButtonText: "Go to initial strategic data",
        customClass: {
          confirmButton:
            "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
        },
        allowOutsideClick: false,
        allowEscapeKey: false,
      }).then((result) => {
        if (result.isConfirmed) {
          navigate("/settings/strategic_data_tab");
        }
      });
    }
  }, []);

  // Fetch strategic plans only once on mount
  useEffect(() => {
    if (!hasFetchedStrategicPlans.current) {
      hasFetchedStrategicPlans.current = true;
      const fetchStrategicPlans = async () => {
        const storedUser = localStorage.getItem("prostrategy_auth");
        const token = storedUser ? JSON.parse(storedUser)?.token : null;
        try {
          const response = await axios.get(
            '/organization/strategic_plan_list_for_strategic_analysis',
            {
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );
          if (response?.data) {
            setStrategicPlans(response.data.data);
            setHasStrategicPlanError(false);
          }
        } catch (error) {
          console.error('Error fetching strategic plans:', error?.response);
          setHasStrategicPlanError(true);
          if (error?.response?.data?.message) {
            handleIntialStrategy(error.response.data.message);
          }
        }
      };
      fetchStrategicPlans();
    }
  }, [handleIntialStrategy]);


  // Set initial selected plan when strategic plans are loaded
  useEffect(() => {
    if (!initialSelectedPlansSet.current && !hasStrategicPlanError && strategicPlans?.length > 0) {
      initialSelectedPlansSet.current = true;
      const currentStrategicHas = strategicPlans.find(item => item.id === strategicPlan);
      if (currentStrategicHas?.id) {
        setSelectedPlans(new Set([currentStrategicHas.id.toString()]));
      } else {
        setSelectedPlans(new Set([strategicPlans[0]?.id.toString()]));
      }
    }
  }, [strategicPlans, hasStrategicPlanError, strategicPlan]);

  // Reset states when strategic plan changes
  useEffect(() => {
    setHasInitialDataError(false);
    setChartData([]);
    setMultiChartData([]);
    setIsLoading(true);
    hasInitialGraphFetch.current = false; // Reset the fetch flag when strategic plan changes
  }, [strategicPlan]);

  // // Simplified fetchStrategicGraphs function (not a useCallback)
  const fetchStrategicGraphs = async (planIds) => {
    if (hasStrategicPlanError || planIds.size === 0) return;

    setIsLoading(true);
    setError(null);

    try {
      const planPath = `/?strategic_plan_ids=${Array.from(planIds).join(",")}`;
      const url = `/organization/strategic_form_data/strategic_graphs${planPath}`;
      const response = await axios.get(url, {
        headers: {
          'Authorization': `Bearer ${auth.user.token}`,
        },
      });

      if (response.data?.status === "success" && response.data?.data) {
        setChartValues(response.data);
        setHasInitialDataError(false);
      }
    } catch (err) {
      if (axios.isCancel(err)) {
        console.log('Request canceled:', err.message);
        return;
      }
      console.error("Error fetching strategic graphs:", err);

    } finally {
      setIsLoading(false);
    }
  };

  // Fetch graphs only when selected plans change and it's the initial fetch
  useEffect(() => {
    if (initialSelectedPlansSet.current && !hasInitialGraphFetch.current && selectedPlans.size > 0) {
      hasInitialGraphFetch.current = true;
      fetchStrategicGraphs(selectedPlans);
    }

  }, [selectedPlans, initialSelectedPlansSet.current]);

  useEffect(() => {
    if (previousStrategicPlan.current !== strategicPlan) {
      previousStrategicPlan.current = strategicPlan;

      setHasInitialDataError(false);
      setChartData([]);
      setMultiChartData([]);
      setChartValues(null);
      hasInitialGraphFetch.current = false;

      // Find if the new strategic plan exists in our list
      const newPlanExists = strategicPlans.some(plan => plan.id === strategicPlan);

      if (newPlanExists) {
        // Update selected plans to include the new strategic plan
        setSelectedPlans(new Set([strategicPlan.toString()]));
        setIsLoading(true);
      }
    }
  }, [strategicPlan, strategicPlans]);

  const handlePlanSelectionChange = (newSelectedPlans) => {
    setSelectedPlans(newSelectedPlans);
    fetchStrategicGraphs(newSelectedPlans);
  };

  const hasData = chartData.length > 0 || multiChartData.length > 0;

  if (!strategicPlan) {
    return <div className="text-center py-4 col-span-2">No strategic plan selected.</div>;
  }

  if (isLoading) {
    return <p className="text-center py-4 col-span-2"><PageSpinner /></p>;
  }

  if (hasInitialDataError) {
    return <div className="text-center py-4 col-span-2">No records.</div>;
  }


  return (
    <>
      {
        isHasPlanPermission && (
          <StrategicPlanMultiSelect
            setSelectedPlans={handlePlanSelectionChange}
            selectedPlans={selectedPlans}
            isHasPlanPermission={isHasPlanPermission}
          />
        )
      }

      {chartValues && chartValues.data && (
        <div className="grid grid-cols-2 gap-4">
          {Object.entries(chartValues?.data).map(([key, item], index) => {
            const graphType = item.common_value?.graph_type?.toLowerCase();
            if (graphType === "single") {
              return (
                <SingleBarCharter
                  key={index}
                  chartname={item?.common_value?.name}
                  chartdata={item?.year_based_value}
                  doller={item?.common_value?.metric_measurement === 'dollor' ? '$' : ''}
                  text=""
                />
              );
            }
            if (graphType === "multiple") {
              return (
                <MultiBarChart
                  key={index}
                  chartname={item?.common_value.name}
                  chartdata={item?.year_based_value}
                  doller={item?.common_value?.metric_measurement}
                  text=""
                />
              );
            }
            return null;
          })}
        </div>
      )}

      {(!chartValues || !chartValues.data || Object.keys(chartValues.data).length === 0) && (
        <div className="text-center py-4 col-span-2">
          No records.
        </div>
      )}
    </>
  );
}
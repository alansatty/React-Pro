// import { useCallback, useEffect, useRef, useState } from "react";
// import CustomTable from "../../../../../components/Table/CustomTable";
// import usePermissionsStore from "../../../../../stores/usePermissionStore";
// import { useNavigate } from "react-router-dom";
// import ProstrategyLogo from "../../../../../assets/icons/ProstrategyLogo";
// import Swal from "sweetalert2/dist/sweetalert2.js";
// import withReactContent from "sweetalert2-react-content";
// import axios from "axios"; // Import axios
// import { useAuth } from "../../../../../providers/authProviders";
// import { PageSpinner } from "../../../../../components";
// import StrategicPlanMultiSelect from "./StrategicPlanMultiSelect";
// import { apiList } from "../../../../../services";
// import useApi from "../../../../../hooks/useApi";
// const MySwal = withReactContent(Swal);


// const ForecastTable = () => {
//   const auth = useAuth();
//   const [page, setPage] = useState(1);
//   const [forecastData, setForecastData] = useState(null);
//   const [isNoData, setIsNoData] = useState(false);
//   const [isLoading, setIsLoading] = useState(false);
//   const [error, setError] = useState(null);
//   const controllerRef = useRef(null);
//   const [hasInitialDataError, setHasInitialDataError] = useState(false);
//   const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
//   const navigate = useNavigate();
//   const [selectedPlans, setSelectedPlans] = useState(new Set());
//   const hasShownError = useRef(false);
//   const [isError, setIsError] = useState(false);

//   const { data: strategicPlans, error: strategicError, } = useApi(
//     apiList.admin.strategicPlanWithIntialData.list.key,
//     apiList.admin.strategicPlanWithIntialData.list.call()
//   );

//   console.log('strategicc', strategicPlans);



//   // // Initialize with the current strategic plan if it exists
//   // useEffect(() => {
//   //   if (strategicPlans?.data.length > 0) {
//   //     setSelectedPlans(new Set([strategicPlans.data[0]?.id.toString()]));
//   //   }
//   // }, [strategicPlans]);

//   // Set initial selected plan when strategic plans are loaded
//   useEffect(() => {
//     if (strategicPlans?.data?.length > 0) {
//       const currentStrategicHas = strategicPlans.data.find(item => item.id === strategicPlan)
//       console.log('currentStrategicHas', currentStrategicHas);

//       if (currentStrategicHas?.id) {
//         // current selected plan have initial strategic settings will get from here and set in state
//         setSelectedPlans(new Set([currentStrategicHas.id.toString()]));
//       } else {
//         setSelectedPlans(new Set([strategicPlans?.data[0]?.id.toString()]));
//       }
//     }
//   }, [strategicPlans, strategicPlan]);

//   useEffect(() => {
//     fetchForecastData();
//   }, [selectedPlans]);

//   useEffect(() => {
//     if (strategicError?.message && !hasShownError.current) {
//       hasShownError.current = true;
//       setIsError(true)
//       handleIntialStrategy(strategicError.message);
//     }
//   }, [strategicError]);

//   const { data: metricQuestions } = useApi(
//     apiList.admin.departmentStrategies.get_metricQuestions.key(strategicPlan),
//     !isError ?
//       apiList.admin.departmentStrategies.get_metricQuestions.call(strategicPlan) : null
//   )

//   const handleIntialStrategy = (errorMessage) => {
//     if (errorMessage) {
//       MySwal.fire({
//         html: (
//           <div className="flex flex-col items-center">
//             <div className="w-18 h-20 mb-2">
//               <ProstrategyLogo />
//             </div>
//             <h2 className="text-xl font-semibold">Warning!</h2>
//             <p className="mt-2">
//               {"Please set initial strategic data first."}
//             </p>
//           </div>
//         ),
//         confirmButtonText: "Go to initial strategic data",
//         customClass: {
//           confirmButton:
//             "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
//         },
//         allowOutsideClick: false,
//         allowEscapeKey: false,
//       }).then((result) => {
//         if (result.isConfirmed) {
//           navigate("/settings/strategic_data_tab");
//         }
//       });
//     }
//     // ... other reset logic ...
//   }




//   const fetchForecastData = async () => {
//     if (isError) return

//     if (controllerRef.current) {
//       controllerRef.current.abort();
//     }

//     controllerRef.current = new AbortController();
//     setIsLoading(true);
//     setError(null);

//     try {
//       // Don't call API if no plans are selected
//       if (selectedPlans.size === 0) {
//         setForecastData(null);
//         setIsNoData(true);
//         return;
//       }

//       const planPath = `/?strategic_plan_ids=${Array.from(selectedPlans).join(",")}`;
//       const url = `/organization/strategic_form_data/forecast${planPath}`;
//       // const url = `/organization/strategic_form_data/forecast/${strategicPlan}`;

//       const response = await axios.get(url, {
//         headers: { Authorization: `Bearer ${auth.user.token}` },
//         signal: controllerRef.current.signal,
//       });




//       const isDataEmpty =
//         !response?.data?.data ||
//         (Array.isArray(response.data.data) &&
//           response.data.data.length === 0) ||
//         (typeof response.data.data === "object" &&
//           Object.keys(response.data.data).length === 0);

//       if (isDataEmpty) {
//         setIsNoData(true);
//         setForecastData(null);
//       }
//       else {

//         const transformedData = transformForecastData(response.data.data);

//         setForecastData({
//           data: transformedData,
//           total_pages: "",
//         });

//         setIsNoData(false);
//         setHasInitialDataError(false);
//       }
//     } catch (err) {
//       if (axios.isCancel(err)) {
//         return;
//       }

//       console.error("Error fetching forecast data:", err);
//       setError(err.response || err);

//       if (err.response?.status === 400) {
//         setHasInitialDataError(true);
//         setIsNoData(true);
//         MySwal.fire({
//           html: (
//             <div className="flex flex-col items-center">
//               <div className="w-18 h-20 mb-2">
//                 <ProstrategyLogo />
//               </div>
//               <h2 className="text-xl font-semibold">Warning!</h2>
//               <p className="mt-2">
//                 Please update the initial strategic data in settings to get
//                 forecast data.
//               </p>
//             </div>
//           ),
//           confirmButtonText: "Go to initial strategic data",
//           customClass: {
//             confirmButton:
//               "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
//           },
//           allowOutsideClick: false,
//           allowEscapeKey: false,
//         }).then((result) => {
//           if (result.isConfirmed) {
//             navigate("/settings/strategic_data_tab");
//           }
//         });
//       }
//     } finally {
//       setIsLoading(false);
//     }
//   };

//   useEffect(() => {
//     setIsNoData(false);
//     setHasInitialDataError(false);
//     if (strategicPlan) {
//       fetchForecastData();
//     }
//     // Cleanup function to cancel pending request
//     return () => {
//       if (controllerRef.current) {
//         controllerRef.current.abort();
//       }
//     };
//   }, [strategicPlan]);

//   // Transform backend data to table format
//   const transformForecastData = (
//     forecastData
//   ) => {
//     console.log("forecastData", forecastData);

//     // First, collect all years from all metrics
//     const allYears = new Set();
//     Object.values(forecastData).forEach((metric) => {
//       if (metric?.year_based_value) {
//         Object.keys(metric.year_based_value).forEach((year) => allYears.add(year));
//       }
//     });
//     const years = Array.from(allYears).sort();

//     // Separate dynamic and static metrics
//     const dynamicMetrics = [];

//     Object.entries(forecastData).forEach(([key, metric]) => {
//       if (!metric || !metric.common_value) return;

//       // Check if it's a dynamic metric (has year_based_value)
//       dynamicMetrics.push({
//         id: key,
//         name: metric.common_value.name,
//         values: metric.year_based_value,
//         isPercentage: metric.common_value.metric_measurement === "percentage",
//         isDollar: metric.common_value.metric_measurement === "dollor",
//       });
//     });

//     // Process dynamic metrics first
//     const rows = dynamicMetrics.map(metric => {
//       const row = { id: metric.id, metric: metric.name };
//       years.forEach(year => {
//         const value = metric.values[year];
//         if (value === undefined || value === null) {
//           row[year] = "-";
//         } else if (metric.isPercentage) {
//           row[year] = `${value}%`;
//         } else if (metric.isDollar) {
//           row[year] = `$${value}`;
//         } else {
//           row[year] = typeof value === "number"
//             ? value.toLocaleString(undefined, {
//               minimumFractionDigits: 0,
//               maximumFractionDigits: 0,
//             })
//             : value.toString();
//         }
//       });
//       return row;
//     });

//     // Then process static metrics

//     return rows;
//   };

//   const getColumns = () => {
//     // If there's no data, return an empty array
//     if (isNoData) {
//       return [];
//     }

//     const baseColumn = [{ name: "", uid: "metric" }];

//     if (forecastData?.data) {
//       const allYears = new Set();

//       // We need to look at the original response data to get years
//       // Since we don't have apiResponse anymore, we can extract years from the first metric
//       if (forecastData.data.length > 0) {
//         Object.keys(forecastData.data[0]).forEach((key) => {
//           if (key !== "id" && key !== "metric") {
//             allYears.add(key);
//           }
//         });
//       }

//       const years = Array.from(allYears).sort();
//       const yearColumns = years.map((year) => ({
//         name: year,
//         uid: year,
//       }));

//       return [...baseColumn, ...yearColumns];
//     }

//     // Default columns if data is not available
//     return [];
//   };

//   const renderCell = (item, columnKey) => {
//     return item[columnKey];
//   };

//   const handlePageChange = (page) => {
//     setPage(page);
//   };

//   if (isLoading) {
//     return <p className="text-center col-span-2"><PageSpinner /></p>;
//   }

//   // If no strategic plan, render a message
//   if (!strategicPlan) {
//     return (
//       <div className="text-center py-4 col-span-2">
//         No strategic plan selected.
//       </div>
//     );
//   }


//   return (<>
//     <StrategicPlanMultiSelect
//       setSelectedPlans={setSelectedPlans}
//       selectedPlans={selectedPlans}
//     />
//     {forecastData ? (
//       <CustomTable
//         columns={getColumns()}
//         renderCell={renderCell}
//         responceData={forecastData}
//         handlePageChange={handlePageChange}
//         page={page}
//         headerTextClasses="text-gray-700"
//         isOrderBy={true}
//         isClickable={false}
//         striped={true}
//         isLoading={isLoading}
//         isForecast={true}
//         isForcastTable={true}
//       />
//     ) : (
//       <div className="text-center py-4 col-span-2">
//         No records.
//       </div>
//     )}

//   </>
//   );
// };

// export default ForecastTable;


import { useCallback, useEffect, useRef, useState } from "react";
import CustomTable from "../../../../../components/Table/CustomTable";
import usePermissionsStore from "../../../../../stores/usePermissionStore";
import { useNavigate } from "react-router-dom";
import ProstrategyLogo from "../../../../../assets/icons/ProstrategyLogo";
import Swal from "sweetalert2/dist/sweetalert2.js";
import withReactContent from "sweetalert2-react-content";
import axios from "axios"; // Import axios
import { useAuth } from "../../../../../providers/authProviders";
import { PageSpinner } from "../../../../../components";
import StrategicPlanMultiSelect from "./StrategicPlanMultiSelect";
import { apiList } from "../../../../../services";
import useApi from "../../../../../hooks/useApi";
import hasPlanPermission from "../../../../../utils/hasPlanPermission";
const MySwal = withReactContent(Swal);

const ForecastTable = () => {
  const auth = useAuth();
  const [page, setPage] = useState(1);
  const [forecastData, setForecastData] = useState(null);
  const [isNoData, setIsNoData] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const controllerRef = useRef(null);
  const [hasInitialDataError, setHasInitialDataError] = useState(false);
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
  const navigate = useNavigate();
  const [selectedPlans, setSelectedPlans] = useState(new Set());
  const hasShownError = useRef(false);
  const [isError, setIsError] = useState(false);
  const [isHasPlanPermission, setIsHasPlanPermission] = useState(false)
  // const hasFetchedData = useRef(false)

  useEffect(() => {
    if (hasPlanPermission('select_multiple_strategic_plans')) {
      setIsHasPlanPermission(true)
    }
  }, [])

  const { data: strategicPlans, error: strategicError, } = useApi(
    apiList.admin.strategicPlanWithIntialData.list.key,
    apiList.admin.strategicPlanWithIntialData.list.call()
  );

  // // Initialize with the current strategic plan if it exists
  // useEffect(() => {
  //   if (strategicPlans?.data.length > 0) {
  //     setSelectedPlans(new Set([strategicPlans.data[0]?.id.toString()]));
  //   }
  // }, [strategicPlans]);

  // Set initial selected plan when strategic plans are loaded
  useEffect(() => {
    if (strategicPlans?.data?.length > 0) {
      const currentStrategicHas = strategicPlans.data.find(item => item.id === strategicPlan)
      console.log('currentStrategicHas', currentStrategicHas);

      if (currentStrategicHas?.id) {

        // current selected plan have initial strategic settings will get from here and set in state
        setSelectedPlans(new Set([currentStrategicHas.id.toString()]));
      } else {
        setSelectedPlans(new Set([strategicPlans?.data[0]?.id.toString()]));
      }
    }
  }, [strategicPlans, strategicPlan]);

  useEffect(() => {
    if (selectedPlans.size > 0) {

      fetchForecastData();
    }
  }, [selectedPlans]);

  useEffect(() => {
    if (strategicError?.message && !hasShownError.current) {
      hasShownError.current = true;
      setIsError(true)
      handleIntialStrategy(strategicError.message);
    }
  }, [strategicError]);

  const { data: metricQuestions } = useApi(
    apiList.admin.departmentStrategies.get_metricQuestions.key(strategicPlan),
    !isError ?
      apiList.admin.departmentStrategies.get_metricQuestions.call(strategicPlan) : null
  )

  const handleIntialStrategy = (errorMessage) => {
    if (errorMessage) {
      MySwal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>
            <h2 className="text-xl font-semibold">Warning!</h2>
            <p className="mt-2">
              {"Please set initial strategic data first."}
            </p>
          </div>
        ),
        confirmButtonText: "Go to initial strategic data",
        customClass: {
          confirmButton:
            "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
        },
        allowOutsideClick: false,
        allowEscapeKey: false,
      }).then((result) => {
        if (result.isConfirmed) {
          navigate("/settings/strategic_data_tab");
        }
      });
    }
    // ... other reset logic ...
  }


  const fetchForecastData = async (planIds) => {
    if (isError) return
    // if (hasFetchedData.current) return
    // if (controllerRef.current) {
    //   controllerRef.current.abort();
    // }

    // controllerRef.current = new AbortController();
    setIsLoading(true);
    setError(null);

    try {
      // Don't call API if no plans are selected
      if (selectedPlans.size === 0 && isHasPlanPermission) {
        setForecastData(null);
        setIsNoData(true);
        return;
      }
      console.log(isHasPlanPermission, 'isHasPlanPermission');

      const planPath = `/?strategic_plan_ids=${isHasPlanPermission ? Array.from(selectedPlans).join(",") : Array.from([strategicPlan]).join(",")}`;
      const url = `/organization/strategic_form_data/forecast${planPath}`;
      // const url = `/organization/strategic_form_data/forecast/${strategicPlan}`; 

      const response = await axios.get(url, {
        headers: { Authorization: `Bearer ${auth.user.token}` },
        // signal: controllerRef.current.signal,
      });
      // hasFetchedData.current = true
      const isDataEmpty =
        !response?.data?.data ||
        (Array.isArray(response.data.data) &&
          response.data.data.length === 0) ||
        (typeof response.data.data === "object" &&
          Object.keys(response.data.data).length === 0);

      if (isDataEmpty) {
        setIsNoData(true);
        setForecastData(null);
      }
      else {

        const transformedData = transformForecastData(response.data.data);

        setForecastData({
          data: transformedData,
          total_pages: "",
        });

        setIsNoData(false);
        setHasInitialDataError(false);
      }
    } catch (err) {
      if (axios.isCancel(err)) {
        return;
      }

      console.error("Error fetching forecast data:", err);
      setError(err.response || err);

      if (err.response?.status === 400) {
        setHasInitialDataError(true);
        setIsNoData(true);
        MySwal.fire({
          html: (
            <div className="flex flex-col items-center">
              <div className="w-18 h-20 mb-2">
                <ProstrategyLogo />
              </div>
              <h2 className="text-xl font-semibold">Warning!</h2>
              <p className="mt-2">
                Please update the initial strategic data in settings to get
                forecast data.
              </p>
            </div>
          ),
          confirmButtonText: "Go to initial strategic data",
          customClass: {
            confirmButton:
              "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
          },
          allowOutsideClick: false,
          allowEscapeKey: false,
        }).then((result) => {
          if (result.isConfirmed) {
            navigate("/settings/strategic_data_tab");
          }
        });
      }
    } finally {
      setIsLoading(false);
    }
  };

  // useEffect(() => {
  //   hasFetchedData.current = false;
  // }, [strategicPlan]);

  // useEffect(() => {
  //   if (strategicPlan) {
  //     // if (!hasFetchedData.current) {
  //     fetchForecastData();
  //     // }
  //   }
  //   setIsNoData(false);
  //   setHasInitialDataError(false);
  //   // Cleanup function to cancel pending request

  // }, [strategicPlan]);

  // Transform backend data to table format
  const transformForecastData = (
    forecastData
  ) => {

    // First, collect all years from all metrics
    const allYears = new Set();
    Object.values(forecastData).forEach((metric) => {
      if (metric?.year_based_value) {
        Object.keys(metric.year_based_value).forEach((year) => allYears.add(year));
      }
    });
    const years = Array.from(allYears).sort();

    // Separate dynamic and static metrics
    const dynamicMetrics = [];

    Object.entries(forecastData).forEach(([key, metric]) => {
      if (!metric || !metric.common_value) return;

      // Check if it's a dynamic metric (has year_based_value)
      dynamicMetrics.push({
        id: key,
        name: metric.common_value.name,
        values: metric.year_based_value,
        isPercentage: metric.common_value.metric_measurement === "percentage",
        isDollar: metric.common_value.metric_measurement === "dollor",
      });
    });

    // Process dynamic metrics first
    const rows = dynamicMetrics.map(metric => {
      const row = { id: metric.id, metric: metric.name };
      years.forEach(year => {
        const value = metric.values[year];
        if (value === undefined || value === null) {
          row[year] = "-";
        } else if (metric.isPercentage) {
          row[year] = `${value}%`;
        } else if (metric.isDollar) {
          row[year] = `$${value}`;
        } else {
          row[year] = typeof value === "number"
            ? value.toLocaleString(undefined, {
              minimumFractionDigits: 0,
              maximumFractionDigits: 0,
            })
            : value.toString();
        }
      });
      return row;
    });

    // Then process static metrics

    return rows;
  };

  const getColumns = () => {
    // If there's no data, return an empty array
    if (isNoData) {
      return [];
    }

    const baseColumn = [{ name: "", uid: "metric" }];

    if (forecastData?.data) {
      const allYears = new Set();

      // We need to look at the original response data to get years
      // Since we don't have apiResponse anymore, we can extract years from the first metric
      if (forecastData.data.length > 0) {
        Object.keys(forecastData.data[0]).forEach((key) => {
          if (key !== "id" && key !== "metric") {
            allYears.add(key);
          }
        });
      }

      const years = Array.from(allYears).sort();
      const yearColumns = years.map((year) => ({
        name: year,
        uid: year,
      }));

      return [...baseColumn, ...yearColumns];
    }

    // Default columns if data is not available
    return [];
  };

  const renderCell = (item, columnKey) => {
    return item[columnKey];
  };

  const handlePageChange = (page) => {
    setPage(page);
  };

  if (isLoading) {
    return <p className="text-center col-span-2"><PageSpinner /></p>;
  }

  // If no strategic plan, render a message
  if (!strategicPlan) {
    return (
      <div className="text-center py-4 col-span-2">
        No strategic plan selected.
      </div>
    );
  }


  return (<>
    {
      isHasPlanPermission && (
        <StrategicPlanMultiSelect
          setSelectedPlans={setSelectedPlans}
          selectedPlans={selectedPlans}
          isHasPlanPermission={isHasPlanPermission}
        />
      )
    }

    {forecastData ? (
      <CustomTable
        columns={getColumns()}
        renderCell={renderCell}
        responceData={forecastData}
        handlePageChange={handlePageChange}
        page={page}
        headerTextClasses="text-gray-700"
        isOrderBy={true}
        isClickable={false}
        striped={true}
        isLoading={isLoading}
        isForecast={true}
        isForcastTable={true}
      />
    ) : (
      <div className="text-center py-4 col-span-2">
        No records.
      </div>
    )}

  </>
  );
};

export default ForecastTable;

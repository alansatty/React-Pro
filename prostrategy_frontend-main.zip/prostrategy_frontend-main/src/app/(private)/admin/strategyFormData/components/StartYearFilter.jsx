import { Select, SelectItem } from "@nextui-org/select";
import { IconChevronDown } from "@tabler/icons-react";
export const StartYearFilter = ({ setFilterStartYear, startYear, maxYear, minYear }) => {
    const MIN_YEAR = minYear;
    const MAX_YEAR = maxYear;

    return (
        <Select
            selectedKeys={startYear ? [String(startYear)] : []}
            onChange={(e) => setFilterStartYear(Number(e.target.value))}
            selectorIcon={<IconChevronDown color="gray" className="text-2xl" size="4em" />}
            variant="bordered"
            size="sm"
            label="Start Year"
            className="min-w-40"
            scrollShadowProps={{
                isEnabled: true,
                hideScrollBar: false,
            }}
            classNames={{
                listbox: "remove-truncate",
                trigger: [
                    "data-[open=true]:border-2 data-[open=true]:border-[#0098F5]",
                    "data-[focus=true]:border-2 data-[focus=true]:border-[#0098F5]",
                    "dark:data-[open=true]:border-2 dark:data-[open=true]:border-[#0098F5]",
                    "dark:data-[focus=true]:border-2 dark:data-[focus=true]:border-[#0098F5]",
                ],
            }}
            renderValue={(items) => {
                if (!items || items.length === 0) return startYear || "Select year";
                return items.map((item) => item.textValue).join(", ");
            }}
        >
            {Array.from({ length: MAX_YEAR - MIN_YEAR + 1 }, (_, i) => MIN_YEAR + i).map((year) => (
                <SelectItem key={String(year)} value={String(year)} textValue={String(year)}>
                    {year}
                </SelectItem>
            ))}
        </Select>
    );
};
// import { Button } from "@nextui-org/button";
// import { IconRotate } from "@tabler/icons-react";
// import React, { useCallback, useEffect, useRef, useState } from "react";
// import useApi from "../../../../../hooks/useApi";
// import { apiList } from "../../../../../services";
// import CustomTable from "../../../../../components/Table/CustomTable";
// import usePermissionsStore from "../../../../../stores/usePermissionStore";
// import { StartYearFilter } from "./StartYearFilter";
// import { StrategicFormModal } from "../../departments/[id]/_components/StrategicFormModal";
// import { EndYearFilter } from "./EndYearFilter";
// import { StartDateFilter } from "./StartDateFilter";
// import { EndDateFilter } from "./EndDateFilter";
// import { SearchInput } from "../../../../../components";
// import DepartmentSelect from "./DepartmentSelect";
// import StrategicPlanMultiSelect from "./StrategicPlanMultiSelect";
// import toast from "react-hot-toast";
// import withReactContent from "sweetalert2-react-content";
// import Swal from "sweetalert2/dist/sweetalert2.js";
// import ProstrategyLogo from "../../../../../assets/icons/ProstrategyLogo";
// import { useNavigate } from "react-router-dom";
// import axios from "axios";
// const MySwal = withReactContent(Swal);

// // Move fetch function outside component if it doesn't depend on component state
// const fetchStrategicPlans = async () => {
//   const storedUser = localStorage.getItem("prostrategy_auth");
//   const token = storedUser ? JSON.parse(storedUser)?.token : null;
//   try {
//     const response = await axios.get('/organization/strategic_plan_list_for_strategic_analysis',
//       {
//         headers: {
//           Authorization: `Bearer ${token}`,
//         },
//       });
//     return response?.data?.data;
//   } catch (error) {
//     if (error?.response?.data && error?.response?.data?.message && error?.response?.data?.status === "error") {
//       return { error: error.response.data.message };
//     }
//     return { error: "Failed to fetch strategic plans" };
//   }
// }

// export default function DataTable() {

//   const [page, setPage] = useState(1);
//   const [startDate, setFilterStartDate] = useState("");
//   const [endDate, setFilterEndDate] = useState("");
//   const [startYear, setFilterStartYear] = useState(null);
//   const [endYear, setFilterEndYear] = useState(null);
//   const [orderBy, setOrderBy] = useState("");
//   const [sortBy, setSortBy] = useState("");
//   const [search, setSearch] = useState("");
//   const [searchval, setSearchVal] = useState("");
//   const [selectedDepartment, setDepartment] = useState({});
//   const [strategicId, setStrategicId] = useState("");
//   const [departmentId, setDepartmentId] = useState("");
//   const [isOpen, setModalOpen] = useState(false);
//   const [isNoData, setIsNoData] = useState(true);
//   const [selectedPlans, setSelectedPlans] = useState(new Set());
//   const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
//   const [perPage, setPerPage] = useState(10)
//   const hasShownError = useRef(false);
//   const [hasStrategicPlanError, setHasStrategicPlanError] = useState(true);
//   const navigate = useNavigate()
//   const [strategicPlans, setStrategicPlans] = useState([]);
//   const hasFetchedStrategicPlans = useRef(false);

//   const handleIntialStrategy = (errorMessage) => {
//     if (errorMessage && !hasShownError.current) {
//       hasShownError.current = true;
//       MySwal.fire({
//         html: (
//           <div className="flex flex-col items-center">
//             <div className="w-18 h-20 mb-2">
//               <ProstrategyLogo />
//             </div>
//             <h2 className="text-xl font-semibold">Warning!</h2>
//             <p className="mt-2">
//               {"Please set initial strategic data first."}
//             </p>
//           </div>
//         ),
//         confirmButtonText: "Go to initial strategic data",
//         customClass: {
//           confirmButton:
//             "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
//         },
//         allowOutsideClick: false,
//         allowEscapeKey: false,
//       }).then((result) => {
//         if (result.isConfirmed) {
//           navigate("/settings/strategic_data_tab");
//         }
//       });
//     }
//   };

//   // Fetch strategic plans only once on mount
//   useEffect(() => {
//     if (!hasFetchedStrategicPlans.current) {
//       hasFetchedStrategicPlans.current = true;

//       const fetchStrategicPlans = async () => {
//         const storedUser = localStorage.getItem("prostrategy_auth");
//         const token = storedUser ? JSON.parse(storedUser)?.token : null;
//         try {
//           const response = await axios.get(
//             "/organization/strategic_plan_list_for_strategic_analysis",
//             {
//               headers: {
//                 Authorization: `Bearer ${token}`,
//               },
//             }
//           );

//           if (response?.data) {
//             setStrategicPlans(response.data.data);
//             setHasStrategicPlanError(false);
//           }
//         } catch (error) {
//           console.error("Error fetching strategic plans:", error?.response);
//           setHasStrategicPlanError(true);
//           if (error?.response?.data?.message) {
//             handleIntialStrategy(error.response.data.message);
//           }
//         }
//       };

//       fetchStrategicPlans();
//     }
//   }, []);


//   // Set initial selected plan when strategic plans are loaded
//   useEffect(() => {
//     if (!hasStrategicPlanError && strategicPlans?.length > 0) {
//       const currentStrategicHas = strategicPlans.find(item => item.id === strategicPlan)
//       if (currentStrategicHas?.id) {
//         // current selected plan have initial strategic settings will get from here and set in state
//         setSelectedPlans(new Set([currentStrategicHas.id.toString()]));
//       } else {
//         setSelectedPlans(new Set([strategicPlans[0]?.id.toString()]));
//       }
//     }
//   }, [strategicPlans, hasStrategicPlanError, strategicPlan]);

//   // Only fetch these APIs if we have valid strategic plans
//   const shouldFetchApis = !hasStrategicPlanError && strategicPlans?.length > 0;

//   // API for year list
//   const { data: StrategicPlanYearList, isLoading: yearListLoading } = useApi(
//     shouldFetchApis
//       ? apiList.admin.StrategicPlanYearList.list.key(Array.from(selectedPlans).join(","))
//       : null,
//     shouldFetchApis
//       ? apiList.admin.StrategicPlanYearList.list.call(Array.from(selectedPlans).join(","))
//       : null
//   );

//   // API for metric questions
//   const { data: metricQuestions } = useApi(
//     shouldFetchApis
//       ? apiList.admin.departmentStrategies.get_metricQuestions.key(Array.from(selectedPlans).join(","))
//       : null,
//     shouldFetchApis
//       ? apiList.admin.departmentStrategies.get_metricQuestions.call(Array.from(selectedPlans).join(","))
//       : null
//   );

//   // Main data API
//   const { data, isLoading, isValidating } = useApi(
//     shouldFetchApis
//       ? apiList.admin.strategyFormData.list.key(
//         perPage,
//         page,
//         Array.from(selectedPlans).join(","),
//         sortBy,
//         orderBy,
//         startDate && endDate ? startDate : undefined,
//         startDate && endDate ? endDate : undefined,
//         startYear && endYear ? startYear : undefined,
//         startYear && endYear ? endYear : undefined,
//         search,
//         selectedDepartment?.id
//       )
//       : null,
//     shouldFetchApis
//       ? apiList.admin.strategyFormData.list.call(
//         perPage,
//         page,
//         Array.from(selectedPlans).join(","),
//         sortBy,
//         orderBy,
//         startDate && endDate ? startDate : undefined,
//         startDate && endDate ? endDate : undefined,
//         startYear && endYear ? startYear : undefined,
//         startYear && endYear ? endYear : undefined,
//         search,
//         selectedDepartment?.id
//       )
//       : null
//   );

//   // Department list API
//   const { data: departmentList } = useApi(
//     shouldFetchApis
//       ? apiList.admin.strategyFormData.departmentList.list.key
//       : null,
//     shouldFetchApis
//       ? apiList.admin.strategyFormData.departmentList.list.call()
//       : null
//   );




//   // Utility function to check if a date is meaningful (not current date)
//   const onClear = () => {
//     setSearchVal("");
//     setSearch("");
//     setSortBy("");
//     setOrderBy("");
//     setFilterStartYear("");
//     setFilterEndYear("");
//     setFilterEndDate("");
//     setFilterStartDate("");
//     setDepartment("");
//   };

//   const handleOrderBy = (orderByStatus) => {
//     setOrderBy(orderByStatus);
//   };

//   const handleSortyBy = (sortyByStatus) => {
//     setSortBy(sortyByStatus);
//   };

//   const handleFilterStartDate = (startDate) => {
//     setFilterStartDate(startDate);
//   };

//   const handleFilterEndDate = (year) => {
//     setFilterEndDate(year);
//   };

//   const handleFilterStartYear = (year) => {
//     setFilterStartYear(year);
//   };

//   const handleFilterEndYear = (endYear) => {
//     setFilterEndYear(endYear);
//   };

//   const onSearchChange = (value) => {
//     const trimmedValue = value?.trim();
//     if (trimmedValue) {
//       setSearch(trimmedValue);
//       setPage(1);
//     } else {
//       setSearch("");
//     }
//   };

//   // Function to determine if reset button should be shown
//   const shouldShowResetButton = () => {
//     return (
//       startYear ||
//       endYear ||
//       (startDate && startDate.trim() !== "") ||
//       (endDate && endDate.trim() !== "") ||
//       (search && search.trim() !== "") ||
//       (selectedDepartment &&
//         (typeof selectedDepartment === "object"
//           ? Object.keys(selectedDepartment).length > 0
//           : selectedDepartment !== ""))
//     );
//   };

//   const isValidDateSelection = startDate && endDate;
//   const isValidYearSelection = startYear && endYear;



//   // const { data: StrategicPlanYearList, isLoading: yearListLoading, } = useApi(
//   //   !hasStrategicPlanError ?
//   //     apiList.admin.StrategicPlanYearList.list.key(Array.from(selectedPlans).join(","))
//   //     : null,
//   //   !hasStrategicPlanError ?
//   //     apiList.admin.StrategicPlanYearList.list.call(Array.from(selectedPlans).join(",")) : null
//   // );

//   // // API for metric questions
//   // const { data: metricQuestions } = useApi(
//   //   !hasStrategicPlanError ?
//   //     apiList.admin.departmentStrategies.get_metricQuestions.key(Array.from(selectedPlans).join(",")) : undefined,
//   //   !hasStrategicPlanError ?
//   //     apiList.admin.departmentStrategies.get_metricQuestions.call(Array.from(selectedPlans).join(",")) : undefined
//   // )


//   // API calling
//   // const { data, isLoading, isValidating } = useApi(
//   //   !hasStrategicPlanError ?
//   //     apiList.admin.strategyFormData.list.key(
//   //       perPage,
//   //       page,
//   //       Array.from(selectedPlans).join(","),
//   //       // strategicPlan,
//   //       sortBy,
//   //       orderBy,
//   //       isValidDateSelection ? startDate : undefined,
//   //       isValidDateSelection ? endDate : undefined,
//   //       isValidYearSelection ? startYear : undefined,
//   //       isValidYearSelection ? endYear : undefined,
//   //       search,
//   //       selectedDepartment?.id
//   //     ) : null,
//   //   !hasStrategicPlanError ?
//   //     apiList.admin.strategyFormData.list.call(
//   //       perPage,
//   //       page,
//   //       Array.from(selectedPlans).join(","),
//   //       // strategicPlan,
//   //       sortBy,
//   //       orderBy,
//   //       isValidDateSelection ? startDate : undefined,
//   //       isValidDateSelection ? endDate : undefined,
//   //       isValidYearSelection ? startYear : undefined,
//   //       isValidYearSelection ? endYear : undefined,
//   //       search,
//   //       selectedDepartment?.id
//   //     ) : null
//   // );

//   // const { data: departmentList } = useApi(
//   //   apiList.admin.strategyFormData.departmentList.list.key,
//   //   !hasStrategicPlanError ?
//   //     apiList.admin.strategyFormData.departmentList.list.call() : null
//   // );


//   useEffect(() => {
//     setIsNoData(true);

//     if (data) {
//       const isDataValid =
//         data.status === "success" &&
//         data.data &&
//         Array.isArray(data.data) &&
//         data.data.length > 0;

//       if (isDataValid) {
//         setIsNoData(false);
//       } else {
//         setIsNoData(true);
//       }
//     }
//   }, [data]);

//   const handleEditMode = (id) => {
//     const strategic = data?.data.find((item) => item?.goal_strategy_id === id);
//     const departId = strategic?.department_id;
//     setStrategicId(id);
//     setDepartmentId(departId);
//     setModalOpen(true);
//   };

//   const handlePageChange = (newPage) => {
//     setPage(newPage);
//   };

//   const resetFields = () => {
//     onClear();
//   };



//   const renderCell = React.useCallback((users, columnKey, pagef, rowIndex) => {

//     let cellValue = users[columnKey];
//     if (cellValue == 0) {
//       cellValue = "-";
//     }
//     if (!cellValue || cellValue === null || cellValue === undefined || cellValue === "") {
//       cellValue = "-";
//     }

//     const queryPage = pagef ? pagef : 1;
//     const rowsPerPage = 10;
//     const slNumber = (queryPage - 1) * rowsPerPage + (rowIndex + 1);

//     switch (columnKey) {
//       case "sl":
//         return <>{slNumber}</>;
//       default:
//         return cellValue;
//     }
//   }, []);

//   const columns = [
//     { name: "S.No", uid: "sl" },
//     { name: "What is the name of this STRATEGIC INITIATIVE?", uid: "name" },
//     {
//       name: "What department is submitting this STRATEGIC INITIATIVE?",
//       uid: "department_choices",
//     },
//     {
//       name: "What date would you like this project to begin development?",
//       uid: "start_date",
//     },
//     {
//       name: "What date would you like this project to be moved into production environments?",
//       uid: "production_date",
//     },
//     {
//       name: "How many years do you expect this strategy to be reasonably productive?",
//       uid: "expected_years_productive",
//     },
//   ];

//   const handleModalClose = () => {
//     setModalOpen(false);
//   };

//   const metricQuestionsAdding = () => {
//     const startIndex = 6;
//     const metricQuestionsList = metricQuestions?.data?.questions;

//     if (!metricQuestionsList) return columns;

//     const firstPart = columns.slice(0, startIndex);
//     const remainingStaticQuestions = columns.slice(startIndex);

//     const dynamicMetrics = Object.entries(metricQuestionsList)
//       .filter(([_, value]) => value)
//       .map(([key, value]) => ({
//         name: value,
//         uid: key,
//       }));

//     const updatedColumns = [
//       ...firstPart,
//       ...dynamicMetrics,
//       ...remainingStaticQuestions,
//     ];

//     return updatedColumns;
//   };

//   const finalColumns = metricQuestionsAdding()

//   return (
//     <>

//       <StrategicPlanMultiSelect
//         setSelectedPlans={setSelectedPlans}
//         selectedPlans={selectedPlans}
//         handleIntialStrategy={handleIntialStrategy}
//       />

//       <StrategicFormModal
//         isOpen={isOpen}
//         onClose={handleModalClose}
//         strategyIdEntry={strategicId}
//         departmentId={departmentId}
//         isFormExist={true}
//         isEdit={true}
//         mutateKey={apiList.admin.strategyFormData.list.key(
//           perPage,
//           page,
//           Array.from(selectedPlans).join(","), // Use selectedPlans instead of strategicPlan
//           // strategicPlan,
//           sortBy,
//           orderBy,
//           isValidDateSelection ? startDate : undefined,
//           isValidDateSelection ? endDate : undefined,
//           isValidYearSelection ? startYear : undefined,
//           isValidYearSelection ? endYear : undefined,
//           search,
//           selectedDepartment?.id
//         )}
//       />

//       <div className="flex flex-col lg:flex-row justify-between items-center gap-3 pt-2 w-full">
//         <div className="flex justify-start items-center w-full sm:max-w-full lg:max-w-[40%]">
//           <SearchInput
//             onSearch={onSearchChange}
//             onClear={onClear}
//             placeholder="Search..."
//             setSearch={setSearchVal}
//             value={searchval}
//             hover={true}
//           />
//         </div>
//         <div className="flex flex-col lg:flex-row w-full items-center gap-3">
//           <DepartmentSelect
//             setSelectedDeparment={setDepartment}
//             selectedDepartment={selectedDepartment}
//             deparmentsData={departmentList?.data}
//           />
//           <StartDateFilter
//             setFilterStartDate={handleFilterStartDate}
//             startDate={startDate}
//             minDate={StrategicPlanYearList?.start_year}
//             maxDate={StrategicPlanYearList?.end_year}
//           />
//           <EndDateFilter
//             setFilterEndDate={handleFilterEndDate}
//             startDate={startDate}
//             endDate={endDate}
//             endYear={StrategicPlanYearList?.end_year}

//           />
//           <StartYearFilter
//             setFilterStartYear={handleFilterStartYear}
//             startYear={startYear}
//             maxYear={StrategicPlanYearList?.end_year}
//             minYear={StrategicPlanYearList?.start_year}
//           />
//           <EndYearFilter
//             setFilterEndYear={handleFilterEndYear}
//             startYear={startYear}
//             endYear={endYear}
//             minYearr={StrategicPlanYearList?.start_year}
//             maxYear={StrategicPlanYearList?.end_year}
//           />
//         </div>
//         {shouldShowResetButton() && (
//           <div className="flex justify-end">
//             <Button
//               color="default"
//               variant="flat"
//               size="sm"
//               radius="sm"
//               onPress={resetFields}
//             >
//               <IconRotate size={18} />
//               Reset Filters
//             </Button>
//           </div>
//         )}
//       </div>
//       <CustomTable
//         columns={finalColumns}
//         renderCell={renderCell}
//         responceData={data}
//         handlePageChange={handlePageChange}
//         isLoading={isLoading || isValidating || !strategicPlan}
//         page={page}
//         headerTextClasses="text-gray-700 first:min-w-0 min-w-80"
//         handleClick={handleEditMode}
//         handleSortby={handleSortyBy}
//         handleOrderBy={handleOrderBy}
//         isOrderBy={true}
//         isClickable={true}
//         isstricky={true}
//         setPage={setPage}
//         setPerPage={setPerPage}
//         perPage={perPage}
//       />
//     </>
//   );
// }


import { Button } from "@nextui-org/button";
import { IconRotate } from "@tabler/icons-react";
import React, { useCallback, useEffect, useRef, useState } from "react";
import useApi from "../../../../../hooks/useApi";
import { apiList } from "../../../../../services";
import CustomTable from "../../../../../components/Table/CustomTable";
import usePermissionsStore from "../../../../../stores/usePermissionStore";
import { StartYearFilter } from "./StartYearFilter";
import { StrategicFormModal } from "../../departments/[id]/_components/StrategicFormModal";
import { EndYearFilter } from "./EndYearFilter";
import { StartDateFilter } from "./StartDateFilter";
import { EndDateFilter } from "./EndDateFilter";
import { SearchInput } from "../../../../../components";
import DepartmentSelect from "./DepartmentSelect";
import StrategicPlanMultiSelect from "./StrategicPlanMultiSelect";
import toast from "react-hot-toast";
import withReactContent from "sweetalert2-react-content";
import Swal from "sweetalert2/dist/sweetalert2.js";
import ProstrategyLogo from "../../../../../assets/icons/ProstrategyLogo";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import hasPlanPermission from "../../../../../utils/hasPlanPermission";
const MySwal = withReactContent(Swal);

export default function DataTable() {

  const [page, setPage] = useState(1);
  const [startDate, setFilterStartDate] = useState("");
  const [endDate, setFilterEndDate] = useState("");
  const [startYear, setFilterStartYear] = useState(null);
  const [endYear, setFilterEndYear] = useState(null);
  const [orderBy, setOrderBy] = useState("");
  const [sortBy, setSortBy] = useState("");
  const [search, setSearch] = useState("");
  const [searchval, setSearchVal] = useState("");
  const [selectedDepartment, setDepartment] = useState({});
  const [strategicId, setStrategicId] = useState("");
  const [departmentId, setDepartmentId] = useState("");
  const [isOpen, setModalOpen] = useState(false);
  const [isNoData, setIsNoData] = useState(true);
  const [selectedPlans, setSelectedPlans] = useState(new Set());
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);
  const [perPage, setPerPage] = useState(10)
  const hasShownError = useRef(false);
  const [hasStrategicPlanError, setHasStrategicPlanError] = useState(true);
  const navigate = useNavigate()
  const [strategicPlans, setStrategicPlans] = useState([]);
  const hasFetchedStrategicPlans = useRef(false);
  const [isHasPlanPermission, setIsHasPlanPermission] = useState(false)

  useEffect(() => {
    if (hasPlanPermission('select_multiple_strategic_plans')) {
      setIsHasPlanPermission(true)
    }
  }, [])

  const handleIntialStrategy = (errorMessage) => {
    if (errorMessage && !hasShownError.current) {
      hasShownError.current = true;
      MySwal.fire({
        html: (
          <div className="flex flex-col items-center">
            <div className="w-18 h-20 mb-2">
              <ProstrategyLogo />
            </div>
            <h2 className="text-xl font-semibold">Warning!</h2>
            <p className="mt-2">
              {"Please set initial strategic data first."}
            </p>
          </div>
        ),
        confirmButtonText: "Go to initial strategic data",
        customClass: {
          confirmButton:
            "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
        },
        allowOutsideClick: false,
        allowEscapeKey: false,
      }).then((result) => {
        if (result.isConfirmed) {
          navigate("/settings/strategic_data_tab");
        }
      });
    }
  };

  // Fetch strategic plans only once on mount
  useEffect(() => {
    if (!hasFetchedStrategicPlans.current) {
      hasFetchedStrategicPlans.current = true;

      const fetchStrategicPlans = async () => {
        const storedUser = localStorage.getItem("prostrategy_auth");
        const token = storedUser ? JSON.parse(storedUser)?.token : null;
        try {
          const response = await axios.get(
            "/organization/strategic_plan_list_for_strategic_analysis",
            {
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );

          if (response?.data) {
            setStrategicPlans(response.data.data);
            setHasStrategicPlanError(false);
          }
        } catch (error) {
          console.error("Error fetching strategic plans:", error?.response);
          setHasStrategicPlanError(true);
          if (error?.response?.data?.message) {
            handleIntialStrategy(error.response.data.message);
          }
        }
      };

      fetchStrategicPlans();
    }
  }, []);


  // Set initial selected plan when strategic plans are loaded
  useEffect(() => {
    if (!hasStrategicPlanError && strategicPlans?.length > 0) {
      const currentStrategicHas = strategicPlans.find(item => item.id === strategicPlan)
      if (currentStrategicHas?.id) {
        // current selected plan have initial strategic settings will get from here and set in state
        setSelectedPlans(new Set([currentStrategicHas.id.toString()]));
      } else {
        setSelectedPlans(new Set([strategicPlans[0]?.id.toString()]));
      }
    }
  }, [strategicPlans, hasStrategicPlanError, strategicPlan]);

  // Only fetch these APIs if we have valid strategic plans
  const shouldFetchApis = !hasStrategicPlanError && strategicPlans?.length > 0;

  // API for year list
  const { data: StrategicPlanYearList, } = useApi(
    shouldFetchApis
      ? apiList.admin.StrategicPlanYearList.list.key(!isHasPlanPermission ? Array.from([strategicPlan]).join(",") : Array.from(selectedPlans).join(","))
      : null,
    shouldFetchApis
      ? apiList.admin.StrategicPlanYearList.list.call(!isHasPlanPermission ? Array.from([strategicPlan]).join(",") : Array.from(selectedPlans).join(","))
      : null
  );

  // API for metric questions
  const { data: metricQuestions } = useApi(
    shouldFetchApis
      ? apiList.admin.departmentStrategies.get_metricQuestions.key(!isHasPlanPermission ? Array.from([strategicPlan]).join(",") : Array.from(selectedPlans).join(","))
      : null,
    shouldFetchApis
      ? apiList.admin.departmentStrategies.get_metricQuestions.call(!isHasPlanPermission ? Array.from([strategicPlan]).join(",") : Array.from(selectedPlans).join(","))
      : null
  );

  // Main data API
  const { data, isLoading, isValidating } = useApi(
    shouldFetchApis || !isHasPlanPermission
      ? apiList.admin.strategyFormData.list.key(
        perPage,
        page,
        !isHasPlanPermission ? Array.from([strategicPlan]).join(",") : Array.from(selectedPlans).join(","),
        sortBy,
        orderBy,
        startDate && endDate ? startDate : undefined,
        startDate && endDate ? endDate : undefined,
        startYear && endYear ? startYear : undefined,
        startYear && endYear ? endYear : undefined,
        search,
        selectedDepartment?.id
      )
      : null,
    shouldFetchApis || !isHasPlanPermission
      ? apiList.admin.strategyFormData.list.call(
        perPage,
        page,
        !isHasPlanPermission ? Array.from([strategicPlan]).join(",") : Array.from(selectedPlans).join(","),
        sortBy,
        orderBy,
        startDate && endDate ? startDate : undefined,
        startDate && endDate ? endDate : undefined,
        startYear && endYear ? startYear : undefined,
        startYear && endYear ? endYear : undefined,
        search,
        selectedDepartment?.id,
        "data"
      )
      : null
  );

  // Department list API
  const { data: departmentList } = useApi(
    shouldFetchApis
      ? apiList.admin.strategyFormData.departmentList.list.key
      : null,
    shouldFetchApis
      ? apiList.admin.strategyFormData.departmentList.list.call()
      : null
  );




  // Utility function to check if a date is meaningful (not current date)
  const onClear = () => {
    setSearchVal("");
    setSearch("");
    setSortBy("");
    setOrderBy("");
    setFilterStartYear("");
    setFilterEndYear("");
    setFilterEndDate("");
    setFilterStartDate("");
    setDepartment("");
  };

  const handleOrderBy = (orderByStatus) => {
    setOrderBy(orderByStatus);
  };

  const handleSortyBy = (sortyByStatus) => {
    setSortBy(sortyByStatus);
  };

  const handleFilterStartDate = (startDate) => {
    setFilterStartDate(startDate);
  };

  const handleFilterEndDate = (year) => {
    setFilterEndDate(year);
  };

  const handleFilterStartYear = (year) => {
    setFilterStartYear(year);
  };

  const handleFilterEndYear = (endYear) => {
    setFilterEndYear(endYear);
  };

  const onSearchChange = (value) => {
    const trimmedValue = value?.trim();
    if (trimmedValue) {
      setSearch(trimmedValue);
      setPage(1);
    } else {
      setSearch("");
    }
  };

  // Function to determine if reset button should be shown
  const shouldShowResetButton = () => {
    return (
      startYear ||
      endYear ||
      (startDate && startDate.trim() !== "") ||
      (endDate && endDate.trim() !== "") ||
      (search && search.trim() !== "") ||
      (selectedDepartment &&
        (typeof selectedDepartment === "object"
          ? Object.keys(selectedDepartment).length > 0
          : selectedDepartment !== ""))
    );
  };

  const isValidDateSelection = startDate && endDate;
  const isValidYearSelection = startYear && endYear;



  // const { data: StrategicPlanYearList, isLoading: yearListLoading, } = useApi(
  //   !hasStrategicPlanError ?
  //     apiList.admin.StrategicPlanYearList.list.key(Array.from(selectedPlans).join(","))
  //     : null,
  //   !hasStrategicPlanError ?
  //     apiList.admin.StrategicPlanYearList.list.call(Array.from(selectedPlans).join(",")) : null
  // );

  // // API for metric questions
  // const { data: metricQuestions } = useApi(
  //   !hasStrategicPlanError ?
  //     apiList.admin.departmentStrategies.get_metricQuestions.key(Array.from(selectedPlans).join(",")) : undefined,
  //   !hasStrategicPlanError ?
  //     apiList.admin.departmentStrategies.get_metricQuestions.call(Array.from(selectedPlans).join(",")) : undefined
  // )


  // API calling
  // const { data, isLoading, isValidating } = useApi(
  //   !hasStrategicPlanError ?
  //     apiList.admin.strategyFormData.list.key(
  //       perPage,
  //       page,
  //       Array.from(selectedPlans).join(","),
  //       // strategicPlan,
  //       sortBy,
  //       orderBy,
  //       isValidDateSelection ? startDate : undefined,
  //       isValidDateSelection ? endDate : undefined,
  //       isValidYearSelection ? startYear : undefined,
  //       isValidYearSelection ? endYear : undefined,
  //       search,
  //       selectedDepartment?.id
  //     ) : null,
  //   !hasStrategicPlanError ?
  //     apiList.admin.strategyFormData.list.call(
  //       perPage,
  //       page,
  //       Array.from(selectedPlans).join(","),
  //       // strategicPlan,
  //       sortBy,
  //       orderBy,
  //       isValidDateSelection ? startDate : undefined,
  //       isValidDateSelection ? endDate : undefined,
  //       isValidYearSelection ? startYear : undefined,
  //       isValidYearSelection ? endYear : undefined,
  //       search,
  //       selectedDepartment?.id
  //     ) : null
  // );

  // const { data: departmentList } = useApi(
  //   apiList.admin.strategyFormData.departmentList.list.key,
  //   !hasStrategicPlanError ?
  //     apiList.admin.strategyFormData.departmentList.list.call() : null
  // );


  useEffect(() => {
    setIsNoData(true);

    if (data) {
      const isDataValid =
        data.status === "success" &&
        data.data &&
        Array.isArray(data.data) &&
        data.data.length > 0;

      if (isDataValid) {
        setIsNoData(false);
      } else {
        setIsNoData(true);
      }
    }
  }, [data]);

  const handleEditMode = (id) => {
    const strategic = data?.data.find((item) => item?.goal_strategy_id === id);
    const departId = strategic?.department_id;
    setStrategicId(id);
    setDepartmentId(departId);
    setModalOpen(true);
  };

  const handlePageChange = (newPage) => {
    setPage(newPage);
  };

  const resetFields = () => {
    onClear();
  };



  const renderCell = React.useCallback((users, columnKey, pagef, rowIndex) => {

    let cellValue = users[columnKey];
    if (cellValue == 0) {
      cellValue = "-";
    }
    if (!cellValue || cellValue === null || cellValue === undefined || cellValue === "") {
      cellValue = "-";
    }

    const queryPage = pagef ? pagef : 1;
    const rowsPerPage = 10;
    const slNumber = (queryPage - 1) * rowsPerPage + (rowIndex + 1);

    switch (columnKey) {
      case "sl":
        return <>{slNumber}</>;
      default:
        return cellValue;
    }
  }, []);

  const columns = [
    { name: "S.No", uid: "sl" },
    { name: "What is the name of this STRATEGIC INITIATIVE?", uid: "name" },
    {
      name: "What department is submitting this STRATEGIC INITIATIVE?",
      uid: "department_choices",
    },
    {
      name: "What date would you like this project to begin development?",
      uid: "start_date",
    },
    {
      name: "What date would you like this project to be moved into production environments?",
      uid: "production_date",
    },
    {
      name: "How many years do you expect this strategy to be reasonably productive?",
      uid: "expected_years_productive",
    },
  ];

  const handleModalClose = () => {
    setModalOpen(false);
  };

  const metricQuestionsAdding = () => {
    const startIndex = 6;
    const metricQuestionsList = metricQuestions?.data?.questions;

    if (!metricQuestionsList) return columns;

    const firstPart = columns.slice(0, startIndex);
    const remainingStaticQuestions = columns.slice(startIndex);

    const dynamicMetrics = Object.entries(metricQuestionsList)
      .filter(([_, value]) => value)
      .map(([key, value]) => ({
        name: value,
        uid: key,
      }));

    const updatedColumns = [
      ...firstPart,
      ...dynamicMetrics,
      ...remainingStaticQuestions,
    ];

    return updatedColumns;
  };

  const finalColumns = metricQuestionsAdding()

  return (
    <>
      {
        isHasPlanPermission && (
          <StrategicPlanMultiSelect
            setSelectedPlans={setSelectedPlans}
            selectedPlans={selectedPlans}
            isHasPlanPermission={isHasPlanPermission}
            handleIntialStrategy={handleIntialStrategy}

          />
        )
      }


      <StrategicFormModal
        isOpen={isOpen}
        onClose={handleModalClose}
        strategyIdEntry={strategicId}
        departmentId={departmentId}
        isFormExist={true}
        isEdit={true}
        mutateKey={apiList.admin.strategyFormData.list.key(
          perPage,
          page,
          !isHasPlanPermission ? Array.from([strategicPlan]).join(",") : Array.from(selectedPlans).join(","), // Use selectedPlans instead of strategicPlan
          // strategicPlan,
          sortBy,
          orderBy,
          isValidDateSelection ? startDate : undefined,
          isValidDateSelection ? endDate : undefined,
          isValidYearSelection ? startYear : undefined,
          isValidYearSelection ? endYear : undefined,
          search,
          selectedDepartment?.id
        )}
      />

      <div className="flex flex-col lg:flex-row justify-between items-center gap-3 pt-2 w-full">
        <div className="flex justify-start items-center w-full sm:max-w-full lg:max-w-[40%]">
          <SearchInput
            onSearch={onSearchChange}
            onClear={onClear}
            placeholder="Search..."
            setSearch={setSearchVal}
            value={searchval}
            hover={true}
          />
        </div>
        <div className="flex flex-col lg:flex-row w-full items-center gap-3">
          <DepartmentSelect
            setSelectedDeparment={setDepartment}
            selectedDepartment={selectedDepartment}
            deparmentsData={departmentList?.data}
          />
          <StartDateFilter
            setFilterStartDate={handleFilterStartDate}
            startDate={startDate}
            minDate={StrategicPlanYearList?.start_year}
            maxDate={StrategicPlanYearList?.end_year}
          />
          <EndDateFilter
            setFilterEndDate={handleFilterEndDate}
            startDate={startDate}
            endDate={endDate}
            endYear={StrategicPlanYearList?.end_year}

          />
          <StartYearFilter
            setFilterStartYear={handleFilterStartYear}
            startYear={startYear}
            maxYear={StrategicPlanYearList?.end_year}
            minYear={StrategicPlanYearList?.start_year}
          />
          <EndYearFilter
            setFilterEndYear={handleFilterEndYear}
            startYear={startYear}
            endYear={endYear}
            minYearr={StrategicPlanYearList?.start_year}
            maxYear={StrategicPlanYearList?.end_year}
          />
        </div>
        {shouldShowResetButton() && (
          <div className="flex justify-end">
            <Button
              color="default"
              variant="flat"
              size="sm"
              radius="sm"
              onPress={resetFields}
            >
              <IconRotate size={18} />
              Reset Filters
            </Button>
          </div>
        )}
      </div>
      <CustomTable
        columns={finalColumns}
        renderCell={renderCell}
        responceData={data}
        handlePageChange={handlePageChange}
        isLoading={isLoading || isValidating || !strategicPlan}
        page={page}
        headerTextClasses="text-gray-700 first:min-w-0 min-w-80"
        handleClick={handleEditMode}
        handleSortby={handleSortyBy}
        handleOrderBy={handleOrderBy}
        isOrderBy={true}
        isClickable={true}
        isstricky={true}
        setPage={setPage}
        setPerPage={setPerPage}
        perPage={perPage}
      />
    </>
  );
}

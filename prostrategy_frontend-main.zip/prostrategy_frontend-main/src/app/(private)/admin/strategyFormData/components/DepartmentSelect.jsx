import { Select, SelectItem } from '@nextui-org/select'
import { IconChevronDown } from '@tabler/icons-react'

const DepartmentSelect = ({ setSelectedDeparment, selectedDepartment, deparmentsData }) => {
    const departments = Array.isArray(deparmentsData) ? deparmentsData : [];
    const selectedDepartmentItem = departments.find(item => item?.name === selectedDepartment.name);
    const selectedId = selectedDepartmentItem?.id;

    const handleSelectionChange = (keys) => {
        const selectedKey = Array.from(keys)[0];
        const selectedItem = departments.find(item => item?.id === selectedKey);

        if (selectedItem) {
            setSelectedDeparment(selectedItem);
        }
    }


    return (
        <Select
            items={departments}
            selectorIcon={
                <IconChevronDown
                    color="gray"
                    className="h-12 w-12 text-gray-100"
                />
            }
            variant="bordered"
            size="sm"
            label="Select Department"
            placeholder={selectedDepartmentItem ? selectedDepartmentItem.name : 'Select a department'}
            className="min-w-48"
            onSelectionChange={handleSelectionChange}
            classNames={{
                listbox: "remove-truncate",
                trigger: [
                    "data-[open=true]:border-2 data-[open=true]:border-[#0098F5]",
                    "data-[focus=true]:border-2 data-[focus=true]:border-[#0098F5]",
                    "dark:data-[open=true]:border-2 dark:data-[open=true]:border-[#0098F5]",
                    "dark:data-[focus=true]:border-2 dark:data-[focus=true]:border-[#0098F5]",
                ],
            }
            }
            selectedKeys={selectedId ? [selectedId] : []}
        >
            {(item) => (
                <SelectItem key={item.id} value={item.id}>
                    {item.name}
                </SelectItem>
            )}
        </Select >
    )
}

export default DepartmentSelect
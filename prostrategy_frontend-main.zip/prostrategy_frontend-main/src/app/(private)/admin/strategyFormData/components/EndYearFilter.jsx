import { Select, SelectItem } from "@nextui-org/select";
import { IconChevronDown } from "@tabler/icons-react";

export const EndYearFilter = ({ setFilterEndYear, startYear, endYear, minYearr, maxYear }) => {
  const MIN_YEAR = minYearr;
  const MAX_YEAR = maxYear;
  const minYear = startYear || MIN_YEAR;

  return (
    <Select
      selectedKeys={endYear ? [String(endYear)] : []}
      onChange={(e) => setFilterEndYear(Number(e.target.value))}
      selectorIcon={
        <IconChevronDown color="gray" className="text-2xl" size="4em" />
      }
      scrollShadowProps={{
        isEnabled: true,
        hideScrollBar: false,
      }}
      variant="bordered"
      size="sm"
      label="End Year"
      className="min-w-40"
      isDisabled={!startYear}
      classNames={{
        listbox: "remove-truncate",
        trigger: [
          "data-[open=true]:border-2 data-[open=true]:border-[#0098F5]",
          "data-[focus=true]:border-2 data-[focus=true]:border-[#0098F5]",
          "dark:data-[open=true]:border-2 dark:data-[open=true]:border-[#0098F5]",
          "dark:data-[focus=true]:border-2 dark:data-[focus=true]:border-[#0098F5]",
        ],
      }}
      renderValue={(items) => {
        if (!items || items.length === 0)
          return (
            endYear || (startYear ? "Select year" : "Select start year first")
          );
        return items.map((item) => item.textValue).join(", ");
      }}
    >
      {Array.from(
        { length: MAX_YEAR - minYear + 1 },
        (_, i) => minYear + i
      ).map((year) => (
        <SelectItem
          key={String(year)}
          value={String(year)}
          textValue={String(year)}
        >
          {year}
        </SelectItem>
      ))}
    </Select>
  );
};

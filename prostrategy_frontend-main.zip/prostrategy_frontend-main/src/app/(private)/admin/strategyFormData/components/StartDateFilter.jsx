import { Input } from "@nextui-org/input";

export const StartDateFilter = ({ setFilterStartDate, startDate, minDate, maxDate }) => {
    const minDateString = minDate ? `${minDate}-01-01` : '';
    const maxDateString = maxDate ? `${maxDate}-12-31` : '';

    return (
        <>
            <Input
                type="date"
                label="Start Date"
                variant="bordered"
                size="sm"
                className="min-w-40"
                min={minDateString}
                max={maxDateString}
                onChange={(e) => setFilterStartDate(e.target.value)}
                value={startDate}
                classNames={{
                    inputWrapper: [
                        "data-[focus=true]:border-2 data-[focus=true]:border-[#0098F5]",
                        "dark:data-[focus=true]:border-2 dark:data-[focus=true]:border-[#0098F5]",
                        "focus-within:border-2 focus-within:border-[#0098F5]",
                        "dark:focus-within:border-2 dark:focus-within:border-[#0098F5]",
                    ],
                }}
            />
        </>
    );
};
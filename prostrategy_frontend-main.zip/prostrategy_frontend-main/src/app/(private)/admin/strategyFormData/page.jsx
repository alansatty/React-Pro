import { Card, CardBody } from "@nextui-org/card";
import {
  IconBrandDatabricks,
  IconChartArrows,
  IconChartArea,
  IconTrendingUp,
  IconTargetArrow,
} from "@tabler/icons-react";
import { useNavigate, useParams } from "react-router-dom";
import GanttChartTab from "./components/ganttChartTab";
import DataTable from "./components/dataTable";
import hasPermission from "../../../../utils/hasPermission";
import ChartBarTab from "./components/ChartBarTab";
import ForecastTable from "./components/ForecastTable";
import { GSComparison } from "../GSComparison/page";
import { useState } from "react";
import hasPlanPermission from "../../../../utils/hasPlanPermission";


function CreateTitle({ title, Icon }) {
  return (
    <div className="flex items-center space-x-2">
      <Icon />
      <span>{title}</span>
    </div>
  );
}

function StrategyFormData() {
  const navigate = useNavigate();
  const { tabId } = useParams();
  const [selectedPlans, setSelectedPlans] = useState(new Set());

  let tabs = [
    ...(hasPermission("dept_strategy_data", "has_access")
      ? [
        {
          id: "goals_and_strategy",
          label: <CreateTitle title="Goals & Strategies" Icon={IconTargetArrow} />,
          content: <GSComparison />
        },

        {
          id: "data_tab",
          label: <CreateTitle title="Data" Icon={IconBrandDatabricks} />,
          content: <DataTable />,
        },
        ...(hasPlanPermission("gantt_chart_forecast_graph") ? [
          {
            id: "gantt_chart_tab",
            label: <CreateTitle title="Gantt Chart" Icon={IconChartArrows} />,
            content: <GanttChartTab />,
          },

          {
            id: "Forecast",
            label: <CreateTitle title="Forecast" Icon={IconTrendingUp} />,
            content: <ForecastTable />
          },

          {
            id: "Graphs",
            label: <CreateTitle title="Graph" Icon={IconChartArea} />,
            content: <ChartBarTab />,
          },
        ] : [])
      ] : [])
  ];

  return (
    <div className="flex flex-col h-full">
      <Card shadow="sm" radius="md" className="p-2 flex flex-col h-full overflow-x-hidden">
        <CardBody className="p-0 flex flex-col h-full">
          {/* Fixed header */}
          <div className="sticky top-0 bg-white z-30 px-4 pt-4">
            <h2 className="text-gray-700 font-semibold text-xl mb-4">
              Strategy Analysis
            </h2>

            {/* Custom tabs */}
            <div className="flex gap-8 border-b border-divider">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  className={`px-2 h-12 relative ${tabId === tab.id ? "text-[#0098F5]" : "text-gray-600"
                    }`}
                  onClick={() => navigate(`/strategy_form_data/${tab.id}`)}
                >
                  <div className="flex items-center space-x-2">
                    {tab.label.props.Icon && <tab.label.props.Icon />}
                    <span>{tab.label.props.title}</span>
                  </div>
                  {tabId === tab.id && (
                    <div className="absolute bottom-0 left-0 w-full h-0.5 bg-[#0098F5]"></div>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Scrollable content */}
          <div className="scroll-for overflow-y-auto flex-grow pt-0 pb-4 pr-4 pl-4" >
            {tabs.find((tab) => tab.id === tabId)?.content}
          </div>
        </CardBody>
      </Card>
    </div>
  );
}

export default StrategyFormData;

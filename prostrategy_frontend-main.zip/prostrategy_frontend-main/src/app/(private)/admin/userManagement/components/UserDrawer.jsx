import { IconSquareRoundedX } from "@tabler/icons-react";
import { PageSpinner } from "../../../../../components";
import useApi from "../../../../../hooks/useApi";
import { apiList } from "../../../../../services";
import UserAddForm from "../createUser/_components/UserAddForm";
import SlidingPane from "react-sliding-pane";

export const UserDrawer = ({
    drawerState,
    setDrawerState,
    title,
    subTitle = "",
    selectedId,
    page = 1,
    handleMutate,
}) => {

    const {
        data: DepartmentsData,
        error: departmentError,
        isLoading: isLoadingDepartment,
    } = useApi(
        apiList.admin.user.departmentDropdown.key,
        apiList.admin.user.departmentDropdown.call()
    );

    const {
        data: DepartmentList,
        isLoading: dipartmentListLoading,
        error: dipartmentListError,
    } = useApi(
        apiList.admin.user.autoSuggestion.key,
        apiList.admin.user.autoSuggestion.call()
    );

    return (
        <div>
            <SlidingPane
                overlayClassName="z-50 "
                width="600px"
                isOpen={drawerState}
                title={<span className="font-semibold text-black">{title}</span>}
                subtitle={subTitle}
                closeIcon={
                    <span className="text-xl">
                        {" "}
                        <IconSquareRoundedX color="#11181C" className="w-8 h-8" />
                    </span>
                }
                onRequestClose={() => {
                    setDrawerState(false);
                }}
            >
                {/* {isLoading ? (
                    <PageSpinner />
                ) : ( */}
                <UserAddForm
                    departmentList={DepartmentList?.data}
                    // initialData={data?.data}
                    setDrawerState={setDrawerState}
                    userId={selectedId ? selectedId : null}
                    page={page}
                    handleMutate={handleMutate}
                />
                {/* )} */}
                {/* here contnent  */}
            </SlidingPane>
        </div>
    );
};

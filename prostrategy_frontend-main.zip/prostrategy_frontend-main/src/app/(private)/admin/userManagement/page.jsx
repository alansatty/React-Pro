import { Select, SelectItem } from "@nextui-org/select";
import CustomTable from "../../../../components/Table/CustomTable";
import { Button } from "@nextui-org/button";
import {
  IconChevronDown,
  IconEdit,
  IconPlus,
  IconRotate,
  IconTrash,
  IconMailForward,
  IconLoader
} from "@tabler/icons-react";
import { useNavigate } from "react-router-dom";
import React, { useCallback, useEffect, useState } from "react";
import { apiList } from "../../../../services";
import useApi from "../../../../hooks/useApi";
import { Card } from "@nextui-org/card";
import { Tooltip } from "@nextui-org/tooltip";
import { useAuth } from "../../../../providers/authProviders";
import { mutate } from "swr";
import toast from "react-hot-toast";
import ConfirmationModal from "../../../../components/ConfirmationModal/ConfirmationModal";
import { PermissionWrapper, SearchInput } from "../../../../components";
import hasPlanPermission from "../../../../utils/hasPlanPermission";
import Swal from "sweetalert2/dist/sweetalert2.js";
import withReactContent from "sweetalert2-react-content";
import ProstrategyLogo from "../../../../assets/icons/ProstrategyLogo";
import { useDisclosure } from "@nextui-org/modal";
import { UserDrawer } from "./components/UserDrawer";
const MySwal = withReactContent(Swal);

function UserManagement() {
  const navigate = useNavigate();
  const [page, setPage] = useState(1);
  const [userType, setUserType] = useState("");
  const [status, setStatus] = useState("");
  const [role, setRole] = useState("");
  const [department, setDepartment] = useState("");
  const [search, setSearch] = useState("");
  const [searchval, setSearchVal] = useState("");
  const [selectedItem, setSelectedItem] = useState(null);
  const [confirmation, setConfirmation] = useState(false);
  const [resentMailUserId, setResentMailUserId] = useState('')
  const [resentMailUserEmail, setResentMailUserEmail] = useState('')
  const [isResending, setIsResending] = useState(false);
  const [selectedId, setSeletedId] = useState('')
  const { isOpen, onOpen, onOpenChange } = useDisclosure();
  const [perPage, setPerPage] = useState(10)



  const [columns, setColumns] = useState([
    { name: "#", uid: "sl" },
    { name: "Name", uid: "name" },
    { name: "Email", uid: "email" },
    { name: "User Type", uid: "user_type" },
    { name: "Role", uid: "role" },
    { name: "Departments", uid: "departments" },
    { name: "Status", uid: "status" },
    { name: "", uid: "actions" },
  ]);

  const auth = useAuth();

  const {
    data: tableData,
    isLoading,
    isValidating,
  } = useApi(
    apiList.admin.user.index.key(perPage, page, null, {
      user_type: userType,
      user_status: status,
      role: role,
      department: department,
      search: search,
    }),
    apiList.admin.user.index.call(perPage, page, null, {
      user_type: userType,
      user_status: status,
      role: role,
      department: department,
      search: search,
    })
  );
  // resent mail api calling
  useEffect(() => {
    if (resentMailUserId && resentMailUserEmail) {
      handleResentMail()
    }
  }, [resentMailUserId, resentMailUserEmail])

  useEffect(() => {
    if (tableData && tableData.user_type === "organization_guest") {
      setColumns((prevColumns) =>
        prevColumns.filter((col) => col.uid !== "departments")
      );
    }
  }, [tableData]);

  const { trigger: deleteUser, } = useApi(
    null,
    apiList.admin.user.delete.call(),
    { method: "DELETE" }
  );

  const {
    data: rolesData,
    isLoading: isLoadingRoles,
  } = useApi(
    apiList.admin.user.rolesDropdown.key(userType),
    apiList.admin.user.rolesDropdown.call(userType)
  );



  const {
    data: DepartmentsData,
    isLoading: isLoadingDeparment,
  } = useApi(
    apiList.admin.user.departmentDropdown.key,
    apiList.admin.user.departmentDropdown.call()
  );

  const {
    data: currentPlanData,
  } = useApi(
    apiList.admin.subscription.current_plan.key(),
    apiList.admin.subscription.current_plan.call()
  );


  // Mail resend api call
  const { trigger: resentMail } = useApi(
    null,
    apiList.admin.user.resentMail.call(resentMailUserId),
    { method: "POST" }
  )

  const refreshUserData = useCallback(() => {
    mutate(apiList.admin.user.index.key(perPage, page, null, {
      user_type: userType,
      user_status: status,
      role: role,
      department: department,
      search: search,
    }));
    setSeletedId('')
  }, [page, userType, status, role, department, search]);

  const handleResentMail = async () => {
    setIsResending(true)
    try {
      await resentMail({
        requestBody: {
          email: resentMailUserEmail
        }
      })
      toast.success("Email resent successfully");
    } catch (error) {
      console.error("Error resend mail:", error);
    } finally {
      setIsResending(false);
      setResentMailUserId(null);
      setResentMailUserEmail('');
    }
  }

  const handlePageChange = (newPage) => {
    setPage(newPage);
  };

  const deleteUsers = (item) => {
    setSelectedItem(item);
    setConfirmation(true);
  };

  // resend mail calling
  const resentUsers = async (user) => {
    if (!isResending) {
      setResentMailUserId(user.id);
      setResentMailUserEmail(user.email);
    }

  }


  const confirmDeleteRole = async () => {
    try {
      const res = await deleteUser({
        dynamicPath: selectedItem.id + "/delete",
      });
      if (res.status == "success") {
        mutate(apiList.admin.user.index.key(perPage, 1));
        toast.success(res?.msg);
      }
    } catch (error) {
      console.log(error);
      if (error?.status == 400) {
        toast.error(error?.data?.msg);
      }
      // toast.error("Something went wrong!");
    } finally {
      setConfirmation(false);
    }
  };


  const resetFields = () => {
    setUserType("");
    setStatus("");
    setRole("");
    setDepartment("");
    setSearch("");
    setSearchVal("");
    onClear();
  };

  let statusText = {
    Active: "Active",
    InActive: "Inactive",
    Pending: "Pending",
  }

  const renderCell = React.useCallback((users, columnKey, pagef, rowIndex) => {
    let cellValue = users[columnKey];

    if (!cellValue) {
      cellValue = "-";
    }

    const queryPage = pagef ? pagef : 1;
    const rowsPerPage = 10;
    const slNumber = (queryPage - 1) * rowsPerPage + (rowIndex + 1);
    const isAction =
      auth?.user?.user_id == users?.id || users?.is_account_owner
        ? false
        : true;
    switch (columnKey) {
      case "sl":
        return <>{slNumber}</>;
      case "status":
        return <>{statusText[cellValue]}</>;
      case "departments":
        const firstDepartment = cellValue[0]?.name || "-";
        const additionalCount =
          cellValue.length > 1 ? ` + ${cellValue.length - 1}` : "";

        return (
          <>
            {firstDepartment}

            {additionalCount && (
              <Tooltip
                content={cellValue.map((department, index) => {
                  return (
                    <div>
                      {" "}
                      {index + 1}: {department.name}
                    </div>
                  );
                })}
                classNames={{
                  content: ["flex flex-col items-start "],
                }}
                className="max-w-[200px]"
              >
                <div className="relative max-w-fit min-w-min inline-flex items-center justify-between box-border whitespace-nowrap px-1 h-6 rounded-lg bg-[#EBF7FF] text-black font-medium ml-1 py-1 text-tiny">
                  <span className="flex-1 text-inherit font-normal px-1">
                    {additionalCount}
                  </span>
                </div>
              </Tooltip>
            )}
          </>
        );
      case "actions":
        return (
          <>
            {isAction && (
              <div className="relative flex items-center gap-2">
                <PermissionWrapper resource={"users"} actions={["edit"]}>
                  <Tooltip content="Edit user">
                    <span className="text-lg text-default-500 cursor-pointer active:opacity-50">
                      <IconEdit
                        onClick={
                          (e) => {
                            e.preventDefault()
                            e.stopPropagation()
                            setSeletedId(users?.id)
                            onOpenChange(true);
                          }
                          // () => navigate(`/users/edit/${users?.id}`);
                        }
                      />
                    </span>
                  </Tooltip>
                </PermissionWrapper>
                <PermissionWrapper resource={"users"} actions={["delete"]}>
                  <Tooltip color="danger" content="Delete user">
                    <span className="text-lg text-danger cursor-pointer active:opacity-50">
                      <IconTrash onClick={() => deleteUsers(users)} />
                    </span>
                  </Tooltip>
                </PermissionWrapper>
                {users?.status === "Pending" && (
                  <Tooltip content="Resent mail">
                    <span className="text-lg text-primary cursor-pointer active:opacity-50">
                      {isResending && resentMailUserId === users.id ? (
                        <IconLoader className="animate-spin" />
                      ) : (
                        <IconMailForward
                          onClick={() => resentUsers(users)}
                          className={isResending ? "opacity-50 pointer-events-none" : ""}
                        />
                      )}
                    </span>
                  </Tooltip>
                )}
              </div>
            )}
          </>
        );
      default:
        return cellValue;
    }
  }, [auth?.user?.user_id, isResending, resentMailUserId]);

  const onSearchChange = (value) => {
    const trimmedValue = value?.trim();
    if (trimmedValue) {
      setSearch(trimmedValue);
      setPage(1);
    } else {
      setSearch("");
    }
  };

  const onClear = () => {
    setSearch("");
    setSearchVal("");
  };

  const checkPlanPermission = () => {
    if (
      hasPlanPermission("users_allowed_count", tableData?.overall_user_count)
    ) {
      onOpenChange(true);
    } else {
      if (
        ["Free", "Essential", "Plus"].includes(currentPlanData?.data?.plan_name)
      ) {
        MySwal.fire({
          html: (
            <div className="flex flex-col items-center">
              <div className="w-18 h-20 mb-2">
                <ProstrategyLogo />
              </div>
              <h2 className="text-xl font-semibold">Warning!</h2>
              <p className="mt-2">User creation on this plan is exceeded. Please update your plan</p>
            </div>
          ),
          confirmButtonText: "Go to plans",
          customClass: {
            confirmButton:
              "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
          },
        }).then((result) => {
          if (result.isConfirmed) {
            navigate("/settings/account_tab"); // Perform navigation after clicking "Okay"
          }
        });
      } else {
        MySwal.fire({
          html: (
            <div className="flex flex-col items-center">
              <div className="w-18 h-20 mb-2">
                <ProstrategyLogo />
              </div>
              <h2 className="text-xl font-semibold">Warning!</h2>
              <p className="mt-2">User creation on this plan is exceeded. please contact admin.</p>
            </div>
          ),
          confirmButtonText: "Okay",
          customClass: {
            confirmButton:
              "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded",
          },
        });
      }
    }
  };



  return (
    <Card className=" bg-white " shadow="none">
      <UserDrawer
        selectedId={selectedId}
        title={selectedId ? "Edit User" : "Create New User"}
        drawerState={isOpen}
        setDrawerState={onOpenChange}
        handleMutate={refreshUserData}
      />
      <ConfirmationModal
        isLoading={false}
        isOpen={confirmation}
        onClose={setConfirmation}
        onConfirm={confirmDeleteRole}
      />

      <div className="flex flex-col gap-4">
        <div className="flex justify-between">
          {" "}
          <h2 className="pl-2 text-gray-700 font-semibold text-xl mt-2">
            User Management
          </h2>
          <PermissionWrapper resource="users" actions={["create"]}>
            <Button
              size="md"
              color="primary"
              startContent={<IconPlus className="mb-1" />}
              radius="sm"
              className="font-medium py-[23px] w-full md:w-auto "
              onPress={() => {
                setSeletedId('');
                checkPlanPermission()
              }}
            >
              Add User
            </Button>
          </PermissionWrapper>
          {/* )} */}
        </div>
        <div className="flex flex-col lg:flex-row justify-between items-center gap-3 w-full">
          <div className="flex justify-start items-center w-full sm:max-w-full lg:max-w-[44%]">
            <SearchInput
              onSearch={onSearchChange}
              onClear={onClear}
              placeholder="Search name or email"
              setSearch={setSearchVal}
              value={searchval}
            />

          </div>
          <div className="flex flex-col lg:flex-row w-full items-center gap-3">
            {auth.user.user_type == "organization_admin" && (
              <Select
                onChange={(e) => setUserType(e.target.value)}
                selectorIcon={
                  <IconChevronDown
                    color="gray"
                    className="text-2xl"
                    size="4em"
                  />
                }
                selectedKeys={[userType]}
                variant="bordered"
                size="sm"
                label="Select User Type"
                className="min-w-40"
                classNames={{
                  listbox: "remove-truncate",
                  trigger: [
                    "data-[open=true]:border-2 data-[open=true]:border-[#0098F5]",
                    "data-[focus=true]:border-2 data-[focus=true]:border-[#0098F5]",
                    "dark:data-[open=true]:border-2 dark:data-[open=true]:border-[#0098F5]",
                    "dark:data-[focus=true]:border-2 dark:data-[focus=true]:border-[#0098F5]",
                  ],
                }}
              >
                <SelectItem key="organization_admin" value="organization_admin">
                  Admin User
                </SelectItem>
                <SelectItem
                  key="organization_department"
                  value="organization_department"
                >
                  Department User
                </SelectItem>
                <SelectItem key="organization_guest" value="organization_guest">
                  Guest User
                </SelectItem>
              </Select>
            )}
            <Select
              items={rolesData?.data || []}
              isLoading={isLoadingRoles}
              selectorIcon={
                <IconChevronDown
                  color="gray"
                  className="h-12 w-12 text-gray-100"
                />
              }
              variant="bordered"
              size="sm"
              label="Select Role"
              className="min-w-40"
              onChange={(e) => setRole(e.target.value)}
              classNames={{
                listbox: "remove-truncate",
                trigger: [
                  "data-[open=true]:border-2 data-[open=true]:border-[#0098F5]",
                  "data-[focus=true]:border-2 data-[focus=true]:border-[#0098F5]",
                  "dark:data-[open=true]:border-2 dark:data-[open=true]:border-[#0098F5]",
                  "dark:data-[focus=true]:border-2 dark:data-[focus=true]:border-[#0098F5]",
                ],
              }}
              selectedKeys={[role]}
            >
              {(item) => (
                <SelectItem key={item?.id} value={item?.id}>
                  {item?.name}
                </SelectItem>
              )}
            </Select>
            {((tableData?.user_type == "organization_admin" &&
              userType == "organization_admin") ||
              userType == "" ||
              userType == "organization_department") &&
              tableData?.user_type !== "organization_guest" && (
                <Select
                  onChange={(e) => setDepartment(e.target.value)}
                  selectedKeys={[department]}
                  selectorIcon={
                    <IconChevronDown
                      color="gray"
                      className="h-12 w-12 text-gray-100"
                    />
                  }
                  name="Departments"
                  variant="bordered"
                  size="sm"
                  label="Select Department"
                  className="min-w-48"
                  isLoading={isLoadingDeparment}
                  items={DepartmentsData?.data || []}
                  classNames={{
                    listbox: "remove-truncate",
                    trigger: [
                      "data-[open=true]:border-2 data-[open=true]:border-[#0098F5]",
                      "data-[focus=true]:border-2 data-[focus=true]:border-[#0098F5]",
                      "dark:data-[open=true]:border-2 dark:data-[open=true]:border-[#0098F5]",
                      "dark:data-[focus=true]:border-2 dark:data-[focus=true]:border-[#0098F5]",
                    ],
                  }}
                >
                  {(dat) => (
                    <SelectItem key={dat?.id} value={dat?.id}>
                      {dat?.name}
                    </SelectItem>
                  )}
                </Select>
              )}

            <Select
              onChange={(e) => setStatus(e.target.value)}
              selectorIcon={
                <IconChevronDown color="gray" className="text-2xl" size="4em" />
              }
              selectedKeys={[status]}
              variant="bordered"
              size="sm"
              label="Select Status"
              className="min-w-40"
              classNames={{
                listbox: "remove-truncate",
                trigger: [
                  "data-[open=true]:border-2 data-[open=true]:border-[#0098F5]",
                  "data-[focus=true]:border-2 data-[focus=true]:border-[#0098F5]",
                  "dark:data-[open=true]:border-2 dark:data-[open=true]:border-[#0098F5]",
                  "dark:data-[focus=true]:border-2 dark:data-[focus=true]:border-[#0098F5]",
                ],
              }}
            >
              <SelectItem key="pending" value="pending">
                Pending
              </SelectItem>
              <SelectItem key="active" value="active">
                Active
              </SelectItem>
              <SelectItem key="in_active" value="in-acte">
                Inactive
              </SelectItem>
            </Select>
          </div>
        </div>
        {(userType || role || department || searchval || status) && (
          <div className="flex justify-end">
            <Button
              color="default"
              variant="flat"
              size="sm"
              radius="sm"
              onClick={resetFields}
            >
              <IconRotate size={18} />
              Reset Filters
            </Button>
          </div>
        )}
      </div>
      <CustomTable
        columns={columns}
        renderCell={renderCell}
        responceData={tableData}
        handlePageChange={handlePageChange}
        isLoading={isLoading || isValidating}
        page={page}
        setPage={setPage}
        setPerPage={setPerPage}
        perPage={perPage}
      />
    </Card>
  );
}

export default UserManagement;

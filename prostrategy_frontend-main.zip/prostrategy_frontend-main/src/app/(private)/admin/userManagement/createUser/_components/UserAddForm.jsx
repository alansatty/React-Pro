import { FormInput, PageSpinner } from "../../../../../../components";
import { Controller, useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { Button } from "@nextui-org/button";
import { Select, SelectItem } from "@nextui-org/select";
import { Divider } from "@nextui-org/divider";
import { useBeforeUnload, useNavigate } from "react-router-dom";
import useApi from "../../../../../../hooks/useApi";
import { apiList } from "../../../../../../services";
import { useEffect, useMemo, useState } from "react";
import axios from "axios";
import { useAuth } from "../../../../../../providers/authProviders";
import toast from "react-hot-toast";
import AlerModal from "../../../../../../components/Alert/AlertModal";
import { UserSchema } from "../../../../../../../validationSchema/authValidation";
import hasPermission from "../../../../../../utils/hasPermission";
import usePermissionsStore from "../../../../../../stores/usePermissionStore";

function  UserAddForm({ userId, handleMutate, setDrawerState }) {
  const navigate = useNavigate();
  const auth = useAuth();
  const authToken = useMemo(() => auth?.user?.token, [auth?.user?.token]);
  const [updatedData, setUpdatedData] = useState({});
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
    reset,
    setError,
    trigger: trigg,
    clearErrors,
  } = useForm({
    resolver: yupResolver(UserSchema(userId)),
    mode: "onChange",
  });

  const [rolesDropdown, setRolesDropdown] = useState([]);
  const [loading, setLoading] = useState(false);
  const userType = watch("user_type");
  const [isAlert, setIsAlert] = useState(false);
  const [isFetching, setIsFetching] = useState(!!userId); // Flag to control rendering
  const [roleselect, setRoleSelect] = useState("");
  const [validationErrors, setValidationErrors] = useState({});
  const [selectedDepts, setselectedDepts] = useState([])
  const {
    data: DepartmentsData,
    error: departmentError,
    isLoading: isLoadingDepartment,
  } = useApi(
    apiList.admin.user.departmentDropdown.key,
    apiList.admin.user.departmentDropdown.call()
  );
  // useBeforeUnload(isDirty); 
  // useUnsavedChanges(isDirty);

  const { trigger, isMutating } = useApi(
    null,
    apiList.admin.user.create.call(),
    { method: "POST" }
  );

  const { trigger: updateUserTrigger, isMutating: isMutateUpdate } = useApi(
    null,
    apiList.admin.user.update.call(userId),
    { method: "PUT" }
  );

  // Fetching user details if userId is present
  useEffect(() => {
    const fetchUserDetails = async () => {
      if (!userId) return;
      setIsFetching(true);
      try {
        const { data } = await axios.get(
          apiList.admin.user.details.call(userId,strategicPlan),
          {
            headers: { Authorization: `Bearer ${authToken}` },
          }
        );


        if (data) {
          const dat = data?.data;
          const departmentIds = dat?.departments?.map(dep => dep.id) || [];
          setselectedDepts(departmentIds)
          reset({
            name: dat?.full_Name,
            email: dat?.email,
            // department: departmentIds,
            user_type: dat?._user_type,
            user_status: dat?.status
          }); // Prepopulate form with fetched data
          setRoleSelect(dat?.role);
          setUpdatedData(dat);
        }
      } catch (error) {
        console.error("Failed to fetch user details:", error);
      } finally {
        setIsFetching(false);
      }
    };

    fetchUserDetails();
  }, [userId, reset, authToken]);

  const validateRole = (value) => {
    if (!value) {
      setError("role", {
        type: "manual",
        message: "Role Is Required",
      });
    } else {
      clearErrors("role");
    }
  };

  // Trigger real-time validation when roleSelect changes
  useEffect(() => {
    validateRole(roleselect);
  }, [roleselect, setError, errors]);

  useEffect(() => {
    if (DepartmentsData?.data.length === 0) {
      setError("department", {
        type: "manual",
        message:
          "You must create a department before proceeding with user creation. Please create a department and try again.",
      });
    } else {
      clearErrors("department");
    }
  }, [DepartmentsData]);

  useEffect(() => {
    if (!userType) {
      setRolesDropdown([]);
      return;
    }

    const fetchRoles = async () => {
      setLoading(true);
      setRolesDropdown([]);
      try {
        const { data } = await axios.get(
          `/organization/roles/dropdown?role_type=${userType}`,
          { headers: { Authorization: `Bearer ${authToken}` } }
        );

        setRolesDropdown(data.data || []);

        if (data.data.length === 0) {
          setError("role", {
            type: "manual",
            message:
              "You must create a role before proceeding with user creation. Please create a role and try again.",
          });
        } else {
          clearErrors("role");
        }
      } catch (error) {
        console.error("Failed to fetch roles:", error);
        setRolesDropdown([]);
      } finally {
        setLoading(false);
      }
    };

    fetchRoles();
  }, [userType]);

  const onSubmitProfile = async (formData) => {

    if (!roleselect) {
      setError("role", {
        type: "custom",
        message: "Role Is Required",
      });

      return; // Prevent form submission if validation fails
    }

    let departmentArray
    if (typeof (formData?.department) == "string") {
      departmentArray = formData?.department?.split(',');
    } else {
      departmentArray = formData?.department
    }


    // Update formData with department as an array


    if (userId) {
      try {
        const formDatanew = { ...formData, role: roleselect, department: departmentArray };
        const response = await updateUserTrigger({ requestBody: formDatanew });
        // setIsAlert(true);
        toast.success('User updated successfully')
        setDrawerState(false)

        if (response && handleMutate) {
          handleMutate();
        }

      } catch (error) {
        if (error?.status === "validation_errors" && error?.data) {
          const validationErrors = error.data;
          for (const [field, messages] of Object.entries(validationErrors)) {
            setError(field, { type: "manual", message: messages[0] });
          }
          return;
        }
        if (error?.status == 400) {
          toast.error(error?.data?.msg);
        }
        // toast.error("Something went wrong");
      } finally {
        clearErrors("role");
      }
    } else {
      try {
        const formDatanew = { ...formData, role: roleselect, department: departmentArray };
        const response = await trigger({ requestBody: formDatanew });
        // setIsAlert(true);
        toast.success('User create successfully')
        setDrawerState(false)
        if (response && handleMutate) {
          handleMutate();
        }
      } catch (error) {
        if (error?.status === "validation_errors" && error?.data) {
          const validationErrors = error.data;
          for (const [field, messages] of Object.entries(validationErrors)) {
            setError(field, { type: "manual", message: messages[0] });
          }
          return;
        }
        if (error?.status == 400) {
          toast.error(error?.data?.msg);
        }
        // toast.error("Something went wrong");
      } finally {
        clearErrors("role");
      }
    }
  };

  const roles = [
    { id: "organization_admin", name: "Admin User" },
    { id: "organization_department", name: "Department User" },
    { id: "organization_guest", name: "Guest User" },
  ];

  const status = [
    { id: "pending", name: "Pending" },
    { id: "active", name: "Active" },
    { id: "in_active", name: "Inactive" },
  ];

  const buttonClick = () => {
    if (!hasPermission('users', ['list'])) {
      reset()
      navigate('/users/create')
    } else {
      navigate("/users");
    }

  };

  if (isFetching) {
    return <PageSpinner />; // Show spinner while data is fetching
  }

  return (
    <div className=" bg-white rounded-lg ">
      <AlerModal
        isOpen={isAlert}
        onOpenChange={setIsAlert}
        desc={
          userId
            ? "User Updated Successfully"
            : "A new User has been successfully added to the system"
        }
        title={userId ? "User Updated!" : "New User Created!"}
        clickFunction={buttonClick}
      />

      <form onSubmit={handleSubmit(onSubmitProfile)}>
        <div className="relative min-h-[500px]">

          <div className="flex flex-col md:flex-row gap-6">
            <FormInput
              radius="sm"
              buttonClcik
              label={
                <label htmlFor="name">
                  Full Name
                  <span className="text-red-600 text-base ml-1">*</span>
                </label>
              }
              fieldName="name"
              id="name"
              register={register}
              errors={errors}
              placeholder="Full Name"
            />
            <FormInput
              radius="sm"
              id="email"
              label={
                <label htmlFor="email">
                  Email Address
                  <span className="text-red-600 text-base ml-1">*</span>
                </label>
              }
              fieldName="email"
              register={register}
              errors={errors}
              placeholder="Email Address"
            />
          </div>

          <div className="flex flex-col md:flex-row  gap-6 mb-6">
            {userId && (
              <div className="w-1/2">
                <Select
                  radius="sm"
                  name="user_status"
                  items={status}
                  labelPlacement="outside"
                  placeholder="Select Status"
                  classNames={{
                    trigger: [
                      "data-[open=true]:border-2 data-[open=true]:border-[#0098F5]",
                      "data-[focus=true]:border-2 data-[focus=true]:border-[#0098F5]",
                      "dark:data-[open=true]:border-2 dark:data-[open=true]:border-[#0098F5]",
                      "dark:data-[focus=true]:border-2 dark:data-[focus=true]:border-[#0098F5]",
                    ],
                  }}
                  label={
                    <label htmlFor="user_status">
                      Status
                      <span className="text-red-600 text-base ml-1">*</span>
                    </label>
                  }
                  variant="bordered"
                  {...register("user_status")}
                  isInvalid={errors.user_status ? true : false}
                >
                  {(item) => <SelectItem value={item.id} isReadOnly={item.id === "pending"}>{item.name}</SelectItem>}
                </Select>
                {errors.user_status && (
                  <span className="text-tiny text-danger">
                    {errors.user_status?.message}
                  </span>
                )}
              </div>
            )}


            <div className="w-1/2">
              <Select
                radius="sm"
                name="user_type"
                items={roles}
                labelPlacement="outside"
                placeholder="Select User Type"
                classNames={{
                  trigger: [
                    "data-[open=true]:border-2 data-[open=true]:border-[#0098F5]",
                    "data-[focus=true]:border-2 data-[focus=true]:border-[#0098F5]",
                    "dark:data-[open=true]:border-2 dark:data-[open=true]:border-[#0098F5]",
                    "dark:data-[focus=true]:border-2 dark:data-[focus=true]:border-[#0098F5]",
                  ],
                }}
                label={
                  <label htmlFor="user_type">
                    User Type
                    <span className="text-red-600 text-base ml-1">*</span>
                  </label>
                }
                variant="bordered"
                {...register("user_type")}
                isInvalid={errors.user_type ? true : false}
              >
                {(item) => <SelectItem value={item.id}>{item.name}</SelectItem>}
              </Select>
              {errors.user_type && (
                <span className="text-tiny text-danger">
                  {errors.user_type?.message}
                </span>
              )}
            </div>
            {userType && (
              <div className="w-1/2">
                <Select
                  classNames={{
                    trigger: [
                      "data-[open=true]:border-2 data-[open=true]:border-[#0098F5]",
                      "data-[focus=true]:border-2 data-[focus=true]:border-[#0098F5]",
                      "dark:data-[open=true]:border-2 dark:data-[open=true]:border-[#0098F5]",
                      "dark:data-[focus=true]:border-2 dark:data-[focus=true]:border-[#0098F5]",
                    ],
                  }}
                  radius="sm"
                  name="role"
                  variant="bordered"
                  isDisabled={
                    !Array.isArray(rolesDropdown) || rolesDropdown.length === 0
                  }
                  items={rolesDropdown}
                  isLoading={loading}
                  labelPlacement="outside"
                  label={
                    <label htmlFor="role">
                      Role
                      <span className="text-red-600 text-base ml-1">*</span>
                    </label>
                  }
                  placeholder="Select Role"
                  // value={watch("role") || ""} //
                  // {...register("role")}
                  //debug
                  onChange={(e) => setRoleSelect(e.target.value)}
                  selectedKeys={[roleselect]}
                  isInvalid={errors.role ? true : false}
                >
                  {(item) => (
                    <SelectItem key={item?.id} value={item?.id}>
                      {item.name}
                    </SelectItem>
                  )}
                </Select>

                {errors.role && (
                  <span className="text-tiny text-danger ">
                    {errors.role?.message}
                  </span>
                )}
              </div>
            )}

            {userType === "organization_department" && (
              <div className="w-1/2">
                <Select
                  classNames={{
                    trigger: [
                      "data-[open=true]:border-2 data-[open=true]:border-[#0098F5]",
                      "data-[focus=true]:border-2 data-[focus=true]:border-[#0098F5]",
                      "dark:data-[open=true]:border-2 dark:data-[open=true]:border-[#0098F5]",
                      "dark:data-[focus=true]:border-2 dark:data-[focus=true]:border-[#0098F5]",
                    ],
                  }}
                  labelPlacement="outside"
                  name="department"
                  variant="bordered"
                  selectedKeys={selectedDepts}
                  onSelectionChange={setselectedDepts}
                  label={
                    <label htmlFor="department">
                      Department
                      <span className="text-red-600 text-base ml-1">*</span>
                    </label>
                  }
                  selectionMode="multiple"
                  radius="sm"
                  placeholder="Select Department"
                  isLoading={isLoadingDepartment}
                  isDisabled={
                    !Array.isArray(DepartmentsData?.data) ||
                    DepartmentsData?.data?.length === 0
                  }
                  items={DepartmentsData?.data || []}
                  {...register("department")}
                  errors={errors}
                  isInvalid={errors.department ? true : false}
                >
                  {(dat) => (
                    <SelectItem key={dat?.id} value={dat?.id}>
                      {dat?.name}
                    </SelectItem>
                  )}
                </Select>
                {errors.department && (
                  <span className="text-tiny text-danger ">
                    {errors.department?.message}
                  </span>
                )}
              </div>
            )}
          </div>

          <div className="absolute w-full">
            <div className="flex justify-start ">
              <Button
                isLoading={userId ? isMutateUpdate : isMutating}
                type="submit"
                className="mt-9 px-8"
                color="primary"
                radius="sm"
              >
                {userId ? "Save Changes" : "Create"}
              </Button>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}

export default UserAddForm;

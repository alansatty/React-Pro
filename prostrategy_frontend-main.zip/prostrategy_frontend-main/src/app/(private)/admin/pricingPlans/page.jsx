import React, { useEffect, useState } from "react";
import PlanCard from "./components/PlanCard";
import { Radio, RadioGroup } from "@nextui-org/radio";

import useApi from "../../../../hooks/useApi";
import { apiList } from "../../../../services";
import { PageSpinner } from "../../../../components";

const PricingPlans = () => {
  const [billingPeriod, setBillingPeriod] = useState("monthly");

  const { data, error, isLoading } = useApi(
    apiList.admin.subscription.get_plans.key(),
    apiList.admin.subscription.get_plans.call()
  );
  

  const {
    data: currentPlan,
    error: currentPlanError,
    currentPlanLoading,
  } = useApi(
    apiList.admin.subscription.current_plan.key(),
    apiList.admin.subscription.current_plan.call()
  );

  useEffect(() => {
    if (currentPlan?.data?.duration) {
      const duration = currentPlan.data.duration.toLowerCase();
      setBillingPeriod(duration);
    }
  }, [currentPlan]);

  if (isLoading || currentPlanLoading) {
    return <PageSpinner />;
  }


  return (
    <div className="flex flex-col items-center">
      <h2 className="text-2xl font-bold mb-6 mt-3">Choose your right plan</h2>

      <RadioGroup
        orientation="horizontal"
        className="mb-10"
        value={billingPeriod}
        onValueChange={(value) => setBillingPeriod(value)}
      >
        <Radio value="monthly" className="mr-5">
          Monthly
        </Radio>
        <Radio value="yearly">Yearly</Radio>
      </RadioGroup>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-5xl">
        {data?.data?.map(
          (plan, index) =>
            (plan?.plan_type !== "free") && (
              <PlanCard
                key={plan?.id}
                plan={plan}
                index={index}
                billingPeriod={billingPeriod}
              />
            )
        )}
      </div>
    </div>
  );
};

export default PricingPlans;

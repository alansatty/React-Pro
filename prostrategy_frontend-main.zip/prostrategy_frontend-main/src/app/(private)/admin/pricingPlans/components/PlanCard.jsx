import { Button } from "@nextui-org/button";
import React from "react";
import { useNavigate } from "react-router-dom";

import { PageSpinner } from "../../../../../components";
import useApi from "../../../../../hooks/useApi";
import { apiList } from "../../../../../services";
import Checked_icon from "../../../../../assets/icons/checked-icon";

const PlanCard = ({ index, plan, billingPeriod }) => {
  const navigate = useNavigate();

  const { data, error, isLoading } = useApi(
    apiList.admin.subscription.current_plan.key(),
    apiList.admin.subscription.current_plan.call()
  );

  if (isLoading) {
    return <PageSpinner />;
  }



  const currentPlanId = data?.data?.current_plan_id;

  // Determine button text
  let buttonText = "Upgrade Plan";
  if (
    currentPlanId === plan.id &&
    data?.data?.duration?.toLowerCase() == billingPeriod
  ) {
    buttonText = "Current Plan";
  } else if (
    (billingPeriod === "monthly" &&
      plan.price_month_dollar < data?.data?.price) ||
    (billingPeriod === "yearly" && plan.price_year_dollar < data?.data?.price)
  ) {
    buttonText = "Downgrade";
  }

  return (
    <div
      key={index}
      className="bg-blue-50 border border-gray-300 rounded-lg flex flex-col "
    >
      <div className="mb-7 p-6 ">
        <span className="text-xs  text-white bg-[#02205F] p-2 text-center rounded-md uppercase	">
          {plan.name} plan
        </span>
        <div className="mt-5 flex items-start ">
          <span className=" text-[#32239] text-3xl mr-1">$</span>
          <span className="text-5xl font-bold text-[#0A1734]">
            {billingPeriod == "monthly"
              ? plan.price_month_dollar
              : plan.price_year_dollar}
          </span>
          <span className=" text-gray-500 ml-1">
            {billingPeriod == "monthly" ? "/month" : "/year"}
          </span>
        </div>
      </div>

      <div className="bg-white text-center p-6 h-full rounded-b-lg flex flex-col justify-between">
        <ul className="space-y-2 mb-6 text-gray-600">
          {plan.detail_content.map((feature, i) => (
            <li className="flex gap-2" key={i}>
              <span>
                <Checked_icon/>
              </span>
              <span className="text-start">{feature}</span>
            </li>
          ))}
        </ul>
        <Button
          radius="sm"
          type="submit"
          color="primary"
          className="bg-appSecondary"
          isDisabled={buttonText === "Current Plan"}
          onClick={() =>
            navigate(`/checkout/${plan.id}?period=${billingPeriod}`)
          }
        >
          {buttonText}
        </Button>
      </div>
    </div>
  );
};

export default PlanCard;

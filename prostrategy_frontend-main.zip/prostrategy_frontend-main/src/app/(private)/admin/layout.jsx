import { useEffect, useState } from "react";
import { cn } from "../../../utils/twMege";
import {
  Link,
  NavLink,
  Outlet,
  useLocation,
} from "react-router-dom";
import {
  IconSquare,
} from "@tabler/icons-react";
import {
  SidebarBody,
  SidebarLink,
  Sidebar,
} from "../../../components/Sidebar/Sidebar";
import { PageSpinner, Topbar } from "../../../components";
import ProstrategyLogo from "../../../assets/icons/ProstrategyLogo";
import DashboardIcon from "../../../assets/icons/dashboard";
import DepartmentsIcon from "../../../assets/icons/departments";
import SettingsIcon from "../../../assets/icons/settings";
import OrganisationIcon from "../../../assets/icons/organisation";
import usePermissionsStore from "../../../stores/usePermissionStore";
import { useAuth } from "../../../providers/authProviders";
import { apiList } from "../../../services";
import useApi from "../../../hooks/useApi";
import hasPermission from "../../../utils/hasPermission";
import ChatsIcon from "../../../assets/icons/chats";
import { Select, SelectItem } from "@nextui-org/select";
import StrategicPlansIcon from "../../../assets/icons/strategicPlans-icon";
import hasPlanPermission from "../../../utils/hasPlanPermission";
import StrategyIcon from "../../../assets/icons/strategy-icon";
import BinderIcon from "../../../assets/icons/binder-icon";
import toast from "react-hot-toast";
import { useSWRConfig } from "swr";

function AdminLayout() {
  const location = useLocation();
  const auth = useAuth();
  const { cache, mutate } = useSWRConfig();
  let storedStrategicPlan = localStorage.getItem("strategicPlanchagedValue");
  const {
    setPermissions,
    setPlanPermissions,
    setStrategicPlan,
    // strategicPlan,
  } = usePermissionsStore();
  const strategicPlan = usePermissionsStore((state) => state.strategicPlan);

  const {
    data: permissions,
    isLoading,
    error: permissionError,
  } = useApi(
    apiList.auth.getPermissions.key(auth?.user?.id),
    apiList.auth.getPermissions.call(),

  );

  useEffect(() => {
    if (permissions && permissions?.organization_status === "inactive") {
      toast.error("Your organization is inactive. Please contact Admin.");
      cache.clear();
      auth.logOut();
    }
  }, [permissions]);


  const fetchStrategicPlans = async () => {
    const token = auth?.user?.token;
    const baseURL = import.meta.env.VITE_API_BASE_URL;
    try {
      const response = await fetch(
        `${baseURL}/organization/strategic_plan/list`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`, // Attach token in Authorization header
          },
        }
      );
      const result = await response.json();

      setStrategicPlan(result?.data[0]?.id);
    } catch (err) {
      console.log(err, "error on fetch strategic plans");
    }
  };

  const {
    data: strategicPlans,
    isLoading: strategicLoading,
  } = useApi(
    apiList.admin.strategicPlans.list.key(1, 10, auth?.user?.id),
    apiList.admin.strategicPlans.list.call(),

  );

  useEffect(() => {
    if (!storedStrategicPlan) {

      fetchStrategicPlans();
    }
  }, []);

  useEffect(() => {
    if (
      !strategicPlan &&
      !strategicLoading &&
      strategicPlans?.data?.length > 0
    ) {
      // Check if the strategic plan is already set in local storage
      if (storedStrategicPlan) {
        setStrategicPlan(storedStrategicPlan);
      } else {
        setStrategicPlan(strategicPlans.data[0].id);
      }

    }

    () => {
      setStrategicPlan("");
    };
  }, [strategicLoading, strategicPlans?.data, strategicPlan, setStrategicPlan]);


  useEffect(() => {
    if (permissions?.data) {
      setPermissions(permissions.data);
    }
    if (permissions?.subscription_plan_details) {
      setPlanPermissions(permissions.subscription_plan_details);
    }
  }, [permissions, setPermissions, setPlanPermissions]);

  // const handleStrategicPlanChange = (selectedKey) => {

  //   setStrategicPlan(selectedKey.currentKey);
  //   localStorage.setItem("strategicPlanchagedValue", selectedKey.currentKey)
  // };
  const handleStrategicPlanChange = (selectedKey) => {
    if (selectedKey.currentKey === null || selectedKey.currentKey === undefined
      || selectedKey.anchorKey === null || selectedKey.anchorKey === undefined) {
      return
    }

    const newPlan = selectedKey.currentKey;
    const currentPlan = storedStrategicPlan || strategicPlan;

    // Only update if the plan has actually changed
    if (newPlan !== currentPlan) {
      setStrategicPlan(newPlan);
      localStorage.setItem("strategicPlanchagedValue", newPlan);
    }
  };

  const links = [
    {
      label: "Dashboard",
      href: "/dashboard",
      icon: (
        <DashboardIcon
          className={cn(
            location.pathname.includes("/dashboard") ? "text-[#1E86FF]" : ""
          )}
        />
      ),
    },

    // Admin settings (requires admin + specific permissions)
    ...(hasPermission("dept_strategy_gantt_chart", "has_access") ||
      hasPermission("dept_strategy_data", "has_access")
      ? [
      ]
      : []),
    {
      label: "Settings",
      href: "/settings",
      icon: (
        <SettingsIcon
          className={cn(
            location.pathname.includes("/settings") ? "text-[#1E86FF]   " : ""
          )}
        />
      ),
    },

    // Organization foundations
    ...(hasPlanPermission("mission_vision_value") ||
      hasPlanPermission("sustainable_objectives"))
      ? [{
        label: "Organization Foundations",
        href: "/organizationgoals/bussiness_target",
        icon: (
          <OrganisationIcon
            className={cn(
              location.pathname.includes("/organizationgoals")
                ? "text-[#1E86FF]"
                : ""
            )}
          />
        ),
      }]
      : [],

    // Departments
    ...(hasPermission("department", ["list"]) &&
      hasPlanPermission("departments_allowed_count"))
      ? [{
        label: "Departments Foundations",
        href: "/departments",
        icon: (
          <DepartmentsIcon
            className={cn(
              location.pathname.includes("/departments")
                ? "text-[#1E86FF]"
                : ""
            )}
          />
        ),
      }]
      : [],

    // Strategy Analysis
    ...(hasPermission("dept_strategy_gantt_chart", "has_access") ||
      hasPermission("dept_strategy_data", "has_access"))
      ? [{
        label: "Strategy Analysis",
        href: "/strategy_form_data/goals_and_strategy",
        icon: (
          <StrategyIcon
            className={cn(
              location.pathname.includes("/strategy_form_data")
                ? "text-[#1E86FF]"
                : ""
            )}
          />
        ),
      }]
      : [],

    // Strategic Report (always visible)
    // {
    //   label: "Strategic Report",
    //   href: "/strategic-planing-report",
    //   icon: (
    //     <BinderIcon
    //       className={cn(
    //         location.pathname.includes("/template") ? "text-[#1E86FF]" : ""
    //       )}
    //     />
    //   ),
    // },

    {
      label: "Strategic Report",
      href: "/strategic_report",
      icon: (
        <BinderIcon
          className={cn(
            location.pathname.includes("/template") ? "text-[#1E86FF]" : ""
          )}
        />
      ),
    },

    // Chats
    ...(hasPlanPermission("internal_chat"))
      ? [{
        label: "Chats",
        href: "/chats",
        icon: (
          <ChatsIcon
            className={cn(
              location.pathname.includes("/chats") ? "text-[#1E86FF]" : ""
            )}
          />
        ),
      }]
      : [],

    // Strategic Plans
    // ...(hasPermission("strategic_plans", ["list"]))
    //   ? [{
    //     label: "Strategic Plans",
    //     href: "/settings/strategic_plans",
    //     icon: (
    //       <StrategicPlansIcon />
    //     ),
    //   }]
    //   : [],
  ];
  const [open, setOpen] = useState(false);

  if (isLoading || strategicLoading) return <PageSpinner />;

  return (
    <>
      <Topbar />
      <div
        className={cn(
          "flex flex-col md:flex-row bg-white w-full flex-1 mx-auto border border-neutral-200 overflow-hidden h-screen"
        )}
      >
        <Sidebar open={open} setOpen={setOpen}>
          <SidebarBody className="justify-between gap-10">
            <div className="flex px-4 flex-col flex-1 overflow-y-auto overflow-x-hidden justify-between">
              <NavLink to="/">
                <ProstrategyLogo />
              </NavLink><Select
                radius="sm"
                size="md"
                name="strategic_plans"
                items={strategicPlans?.data || []}
                placeholder="Strategic plan"
                className="mt-3"
                classNames={{
                  trigger: [
                    "border-1 rounded-lg",
                    "data-[open=true]:border-2 data-[open=true]:border-[#0098F5]",
                    "data-[focus=true]:border-2 data-[focus=true]:border-[#0098F5]",
                    "dark:data-[open=true]:border-2 dark:data-[open=true]:border-[#0098F5]",
                    "dark:data-[focus=true]:border-2 dark:data-[focus=true]:border-[#0098F5]",
                  ],
                }}
                scrollShadowProps={{
                  isEnabled: true,
                  hideScrollBar: false,
                }}
                variant="flat"
                selectedKeys={
                  storedStrategicPlan
                    ? [storedStrategicPlan]
                    : strategicPlan
                      ? [strategicPlan]
                      : strategicPlans?.data?.[0]?.id
                        ? [strategicPlans.data[0].id]
                        : []
                }
                onSelectionChange={(selected) => {
                  handleStrategicPlanChange(selected);
                  // const selectedKey = selected.currentKey;
                  // const currentKey = strategicPlan;

                  // // Only update if selection changed
                  // if (selectedKey !== currentKey) {
                  // }
                }}
              >
                {(item) => (
                  <SelectItem key={item.id} value={item.id}>
                    {item.name}
                  </SelectItem>
                )}
              </Select>

              {/* <Select
                radius="sm"
                size="md"
                name="strategic_plans"
                items={strategicPlans?.data || []}
                placeholder="Strategic plan"
                className="mt-3"
                classNames={{
                  trigger: [
                    "border-1 rounded-lg",
                    "data-[open=true]:border-2 data-[open=true]:border-[#0098F5]",
                    "data-[focus=true]:border-2 data-[focus=true]:border-[#0098F5]",
                    "dark:data-[open=true]:border-2 dark:data-[open=true]:border-[#0098F5]",
                    "dark:data-[focus=true]:border-2 dark:data-[focus=true]:border-[#0098F5]",
                  ],
                }}
                scrollShadowProps={{
                  isEnabled: true,
                  hideScrollBar: false,
                }}
                variant="flat"
                selectedKeys={
                  storedStrategicPlan
                    ? [storedStrategicPlan]
                    : strategicPlan
                      ? [strategicPlan]
                      : strategicPlans?.data?.[0]?.id
                        ? [strategicPlans.data[0].id]
                        : []
                }
                onSelectionChange={handleStrategicPlanChange}
              >
                {(item) => (
                  <SelectItem key={item.id} value={item.id}>
                    {item.name}
                  </SelectItem>
                )}
              </Select>
                */}

              <div className="mt-6 flex flex-col gap-2">
                {links.map((link, idx) => (
                  <SidebarLink
                    key={idx}
                    link={link}
                    className={cn(
                      location.pathname === link.href ||
                        (link.href === "/settings" && location.pathname.startsWith("/settings/"))
                        ? "border-1 rounded-xl border-[rgba(0,152,245,0.5)] bg-[#EBF7FF] font-semibold"
                        : ""
                    )}
                  />
                ))}
              </div>
              {permissions?.agent && (
                <div className="mt-20">
                  <Link
                    to={permissions?.agent_link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center p-3 border border-gray-200 rounded-xl hover:bg-[#EBF7FF] transition-colors"
                  >
                    <div className="w-10 h-10 rounded-full overflow-hidden mr-3">
                      <img
                        src={permissions?.organization_agent_logo}
                        alt="Avatar"
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          e.target.onerror = null;
                          e.target.src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='40' height='40' viewBox='0 0 40 40' fill='none'%3E%3Ccircle cx='20' cy='20' r='20' fill='%23E0E0E0'/%3E%3Cpath d='M20 21.25C22.7614 21.25 25 19.0114 25 16.25C25 13.4886 22.7614 11.25 20 11.25C17.2386 11.25 15 13.4886 15 16.25C15 19.0114 17.2386 21.25 20 21.25Z' fill='%23A0A0A0'/%3E%3Cpath d='M12.5 28.75C12.5 24.742 15.742 21.5 19.75 21.5H20.25C24.258 21.5 27.5 24.742 27.5 28.75V28.75H12.5V28.75Z' fill='%23A0A0A0'/%3E%3C/svg%3E";
                        }}
                      />
                    </div>
                    <div>
                      <div className="font-semibold text-gray-800">{permissions?.organization_agent_name}</div>
                      <div className="text-xs text-gray-500">Your AI Agent</div>
                    </div>
                  </Link>
                </div>
              )}
            </div>


          </SidebarBody>
        </Sidebar>
        <section className="w-full mt-10 px-10 relative overflow-y-auto pb-5 pt-10 bg-[#F4F7FA]">
          <Outlet />
        </section>
      </div >
    </>
  );
}

export default AdminLayout;

export const LogoIcon = () => {
  return (
    <Link href="#">
      <IconSquare />
    </Link>
  );
};
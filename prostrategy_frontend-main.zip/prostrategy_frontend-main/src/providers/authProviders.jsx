import { useContext, createContext, useState } from "react";
import usePermissionsStore from "../stores/usePermissionStore";

const AuthContext = createContext();


const AuthProvider = ({ children }) => {

  const { setStrategicPlan } = usePermissionsStore();

  const [user, setUser] = useState(() => {
    const storedUser = localStorage.getItem("prostrategy_auth");
    return storedUser ? JSON.parse(storedUser) : null;
  });
  const loginAction = async (data) => {
    try {
      if (data) {
        const {
          token,
          email,
          name,
          user_id,
          organization_id,
          user_permission,
          user_type,
        } = data;
        const user = {
          token: token,
          email: email,
          name: name,
          user_id: user_id,
          organization_id: organization_id,
          user_permission: user_permission,
          user_type: user_type,
        };
        setUser(user);
        // setToken(data.token);
        localStorage.setItem("prostrategy_auth", JSON.stringify(user));
        return;
      }
      throw new Error(data.message);
    } catch (err) {
      console.error(err);
    }
  };

  const logOut = () => {
    setUser(null);
    setStrategicPlan("");
    localStorage.removeItem("prostrategy_auth");
    localStorage.clear();
  };

  return (
    <AuthContext.Provider value={{ user, loginAction, logOut }}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthProvider;

export const useAuth = () => {
  return useContext(AuthContext);
};

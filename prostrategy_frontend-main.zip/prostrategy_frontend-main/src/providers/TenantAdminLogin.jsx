import React, { useEffect, useRef, useState } from 'react'
import { useAuth } from './authProviders';
import toast from 'react-hot-toast';
import { useNavigate, useSearchParams } from 'react-router-dom';
import axios from 'axios';
import { Spinner } from '@nextui-org/spinner';

const TenantAdminLogin = ({ children }) => {

    const [searchParams, setSearchParams] = useSearchParams();
    const [tenantLoginLoading, setTenantLoginLoading] = useState(true)
    const tenantEmail = searchParams.get('token')
    const tenant_id = searchParams.get('id')
    const adminToken = searchParams.get('adminToken')

    const auth = useAuth();

    const tenantLoginRef = useRef(false)

    const removeEmailParam = () => {
        if (searchParams.has('token')) {
            searchParams.delete('token');
            setSearchParams(searchParams);
        }
        if (searchParams.has('id')) {
            searchParams.delete('id');
            setSearchParams(searchParams);
        }

        if (searchParams.has('adminToken')) {
            searchParams.delete('adminToken');
            setSearchParams(searchParams);
        }
    };

    const tenantAdminLogin = async () => {
        try {
            if (auth.user) {
                auth.logOut();
                await new Promise(resolve => setTimeout(resolve, 100))
            }


            const response = await axios.post(
                `/auth/tenant_admin_login/`,
                {
                    email: tenantEmail,
                    organization_id: tenant_id
                },
                {
                    headers: {
                        Authorization: `Bearer ${adminToken}`,
                        'Content-Type': 'application/json',
                    },
                }
            );

            auth.loginAction(response.data.data);
            toast.success("Login completed Successfully !");

        } catch (error) {
            removeEmailParam()
            toast.error(error?.response?.data?.msg || 'failed to tenant login')
        } finally {
            setTenantLoginLoading(false)
        }

    }

    useEffect(() => {

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (tenantEmail && emailRegex.test(atob(tenantEmail)) && !tenantLoginRef.current) {
            tenantAdminLogin()
            tenantLoginRef.current = true
        }
    }, [tenantEmail])

    useEffect(() => {
        if (!tenantEmail && !tenantLoginRef.current) {
            setTenantLoginLoading(false)
        }
    }, [tenantLoginLoading, tenantEmail])

    if (tenantLoginLoading) return (
        <>
            <div className="flex items-center justify-center pb-10 relative w-full min-h-screen ">
                <div className="p-3"><Spinner /></div>
            </div>
        </>
    )
    return <>
        {children}
    </>
}

export default TenantAdminLogin
# Prostrategy AI 🤖

This project is built using React, Vite, Tailwind CSS, and Next UI. It follows the Next.js file structure approach, making it modular and scalable.

## Features

- React + Vite: Fast and optimized development experience with React powered by Vite.
- Tailwind CSS: Utility-first CSS framework for rapid UI development.
- Next UI: A modern React UI library with beautifully designed components.
- clsx + tailwind-merge: Utility libraries for conditionally joining class names and merging Tailwind CSS classes without conflicts.
- Next.js File Structure: Organized using the app, page, and layout structure for maintainable and scalable code.

## Installation

1. Clone the repository:
   git clone https://github.com/zaigodevops/prostrategy_frontend.git
   
   
2. Navigate to the project directory:
   `cd prostrategy_frontend`

3. Install dependencies:
   `npm install`


## Running the Project

To run the project locally:
   `npm run dev`
This will start the development server, usually at http://localhost:5173

## Building the Project

To create a production build:
   `npm run build`
This will generate optimized production files in the dist directory.

# Code Repository Movement

This document outlines the process for moving code between branches during deployment to different servers.

## Branch Movement Workflow

### 1. Deploying to Development Server
- **Source Branch:** `main`
- **Target Branch:** `beta`

#### Process:
- The code from the `main` branch is merged into the `beta` branch.
- The `beta` branch is then deployed to the Development Server.

### 2. Deploying to QA Server
- **Source Branch:** `beta`
- **Target Branch:** `qa`

#### Process:
- The code from the `beta` branch is merged into the `qa` branch.
- The `qa` branch is then deployed to the QA Server.

### 3. Deploying to Production Server
- **Source Branch:** `qa`
- **Target Branch:** `production`

#### Process:
- The code from the `qa` branch is merged into the `production` branch.
- The `production` branch is then deployed to the Production Server.

## Branch Movement Table

| Deployment Stage               | Source Branch | Target Branch  |
|---------------------------------|----------------|----------------|
| **Deploying to Development Server** | `main`         | `beta`         |
| **Deploying to QA Server**           | `beta`         | `qa`           |
| **Deploying to Production Server**   | `qa`           | `production`   |

## Notes
- Ensure all necessary tests are completed before merging branches.
- Resolve any merge conflicts before proceeding with the deployment.
- Coordinate with the team to prevent overlapping deployments.

## Additional Information

After installing a new component from Next UI, ensure you update the tailwind.config.js file to include the new components.

For more details on using Next UI components or configuring Tailwind CSS, refer to the official documentation of each library.


Built with ❤️ using React, Vite, and Tailwind CSS.

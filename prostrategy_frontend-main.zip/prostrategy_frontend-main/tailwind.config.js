const { nextui } = require("@nextui-org/theme");
/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
    "./node_modules/@nextui-org/theme/dist/**/*.{js,ts,jsx,tsx}",
    './node_modules/@nextui-org/theme/dist/components/(button|card|checkbox|input|tabs|modal|dropdown|radio|tabs|table|select|divider|pagination|spinner|breadcrumbs|skeleton).js'
  ],
  theme: {
    extend: {
      gridTemplateColumns: {
        '16': 'repeat(16, minmax(0, 1fr))',
      },
      fontFamily: {
        sans: ['Axiforma', 'sans-serif'],
      },
      fontWeight: {
        thin: 100,
        light: 300,
        normal: 400,
        medium: 500,
        heavy: 800,
        black: 900,
      },
      colors: {
        appSecondary: "#0098F5"
      },
      animation: {
        shake: "shake 0.5s ease-in-out",
        shakeInfinite: "shake 2.5s ease-in-out infinite"
      },
      keyframes: {
        shake: {
          "0%, 100%": { transform: "translateX(0)" },
          "25%": { transform: "translateX(-5px)" },
          "50%": { transform: "translateX(5px)" },
          "75%": { transform: "translateX(-5px)" },
        },
      },
      // backgroundImage: {
      //   'auth-bg': "url('./src/assets/authBgImage.svg')",
      // }
    },
  },
  plugins: [nextui(
    {
      themes: {
        light: {
          
          // light theme configurations
          colors: {
            primary: {
              DEFAULT: "#0098F5",
              focus: '#0098F5'
              // foreground: "#000000",
            },
            focus: "#0098F5",
          },
        },
        dark: {
          // dark theme configurations
          colors: {
            primary: {
              DEFAULT: "#0098F5",
              focus: '#0098F5'
              // foreground: "#000000",
            },
            focus: "#0098F5",
          },
        },
      }
    }
  )],
  
}

      // theme: {
      //   extend: {
      //     light: {
      //       colors: {
      //         primary:{
      //           DEFAULT: "#0098F5",
      //         },
      //         secondary: {
      //           DEFAULT: "#0098F5",
      //         }
      //       }
      //     }
      //   },
      // },
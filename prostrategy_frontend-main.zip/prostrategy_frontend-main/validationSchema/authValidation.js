import * as yup from "yup";

export const loginValidation = yup.object().shape({
  email: yup
    .string()
    .trim()
    .required("Email is required")
    .email("Invalid email format")
    .min(3, "Email must be at least 3 characters")
    .max(200, "Email must not exceed 200 characters"),
  password: yup
    .string()
    .trim()
    .required("Password is required")
    .min(8, "Password must be at least 8 characters")
    .max(255, "Password must not exceed 255 characters"),
});

export const signupValidation = yup.object().shape({
  name: yup
    .string()
    .trim()
    .required("Full name is required")
    .min(3, "Full name must be at least 3 characters")
    .max(50, "Full name must not exceed 50 characters"),
  organization_name: yup
    .string()
    .trim()
    .required("Organization name is required")
    .min(3, "Organization name must be at least 3 characters")
    .max(50, "Organization name must not exceed 50 characters"),
  email: yup
    .string()
    .trim()
    .required("Email is required")
    .email("Invalid email format")
    .min(3, "Email must be at least 3 characters")
    .max(200, "Email must not exceed 200 characters"),
  password: yup
    .string()
    .trim()
    .required("Password is required")
    .min(8, "Password must be at least 8 characters")
    .max(255, "Password must not exceed 255 characters"),
  confirmPassword: yup
    .string()
    .trim()
    .oneOf([yup.ref("password"), null], "Passwords must match")
    .required("Confirm password is required"),
  terms: yup
    .boolean()
    .oneOf([true], "You must accept the terms and conditions")
    .required("You must accept the terms and conditions"),
});

export const resetPasswordValidation = yup.object().shape({
  email: yup
    .string()
    .trim()
    .required("Email is required")
    .email("Invalid email format")
    .min(3, "Email must be at least 3 characters")
    .max(200, "Email must not exceed 200 characters"),
});

export const changePasswordValidation = yup.object().shape({
  new_password: yup
    .string()
    .trim()
    .required("Password is required")
    .min(8, "Password must be at least 8 characters")
    .max(255, "Password must not exceed 255 characters"),
  confirm_password: yup
    .string()
    .trim()
    .oneOf([yup.ref("new_password"), null], "Passwords must match")
    .required("Confirm password is required"),
});

export const DepartmentSchema = yup.object().shape({
  name: yup
    .string()
    .trim()
    .required("Department is required")
    .min(3, "Department must be at least 3 characters")
    .max(50, "Department must not exceed 50 characters"),
});

export const RoleSchema = yup.object().shape({
  name: yup
    .string()
    .trim()
    .required("Role name is required")
    .min(3, "Role name must be at least 3 characters")
    .max(50, "Role name must not exceed 50 characters"),
});

// export const UserSchema =  yup.object().shape({
//   name: yup
//     .string()
//     .trim()
//     .required("Full Name is required")
//     .min(3, "Full name must be at least 3 characters")
//     .max(50, "Full name must not exceed 50 characters"),

//   email: yup
//     .string()
//     .email("Email must be a valid email address")
//     .required("Email address is required"),

//   user_type: yup.string().required("User type is required"),

//   department: yup.lazy((value, context) => {
//     // Check if the user_type is 'organization_department'
//     if (context.parent.user_type === "organization_department") {
//       return yup.string().required("Department is required");
//     }
//     // For other user types, no validation required
//     return yup.string().notRequired();
//   }),
// });

export const UserSchema = (user_id) => {
  const baseSchema = {
    name: yup
      .string()
      .trim()
      .required("Full Name is required")
      .min(3, "Full name must be at least 3 characters")
      .max(50, "Full name must not exceed 50 characters"),

    email: yup
      .string()
      .email("Email must be a valid email address")
      .required("Email address is required"),

    user_type: yup.string().required("User type is required"),

    department: yup.lazy((value, context) => {
      if (context.parent.user_type === "organization_department") {
        // Check if value is a string or an array
        return yup
          .mixed()
          .test("is-valid-department", "Department is required", (val) => {
            if (typeof val === "string") {
              return !!val.trim(); // Check if non-empty string
            }
            if (Array.isArray(val)) {
              return val.length > 0; // Check if array has elements
            }
            return false;
          });
      }
      return yup.mixed().notRequired();
    }),
  };

  // Conditionally add the 'user_status' field only if user_id exists
  if (user_id) {
    baseSchema.user_status = yup.string().required("Status is required");
  }

  return yup.object().shape(baseSchema);
};

export const MissionSchema = yup.object().shape({
  mission: yup
    .string()
    .trim()
    .required("Mission statement is required")
    .min(10, "Mission statement be at least 10 characters")
    .max(1054, "Mission statement must not exceed 1054 characters"),
});

export const SustainSchema = yup.object().shape({
  sustain: yup
    .string()
    .trim()
    .required("Pillar statement is required")
    .test(
      'wordCount',
      'Pillar statement must be between 10 to 40 words',
      (value) => {
        if (!value) return false;
        const wordCount = value.trim().split(/\s+/).filter(word => word.length > 0).length;
        return wordCount >= 10 && wordCount <= 40;
      }
    )
    .min(10, "Pillar statement must be at least 10 characters")
    .max(1054, "Pillar statement must not exceed 1054 characters")
});

export const ValueSchema = yup.object().shape({
  value: yup
    .string()
    .trim()
    .required("Value statement is required")
    .min(10, "Value statement be at least 10 characters")
    .max(1054, "Value statement must not exceed 1054 characters"),
});

export const VisionSchema = yup.object().shape({
  vision: yup
    .string()
    .trim()
    .required("Vision statement is required")
    .min(10, "Vision statement be at least 10 characters")
    .max(1054, "Vision statement must not exceed 1054 characters"),
});

export const focalPointSchema = yup.object().shape({
  focalOne: yup
    .string()
    .trim()
    .nullable() // Allow null or undefined values
    .test(
      "min-length",
      "Focal Point One must be at least 3 characters",
      (value) => !value || value.length >= 3 // Apply min validation only if value exists
    )
    .test(
      "max-length",
      "Focal Point One must not exceed 256 characters",
      (value) => !value || value.length <= 256 // Apply max validation only if value exists
    ),
  focalTwo: yup
    .string()
    .trim()
    .nullable()
    .test(
      "min-length",
      "Focal Point Two must be at least 3 characters",
      (value) => !value || value.length >= 3
    )
    .test(
      "max-length",
      "Focal Point Two must not exceed 256 characters",
      (value) => !value || value.length <= 256
    ),
  focalThree: yup
    .string()
    .trim()
    .nullable()
    .test(
      "min-length",
      "Focal Point Three must be at least 3 characters",
      (value) => !value || value.length >= 3
    )
    .test(
      "max-length",
      "Focal Point Three must not exceed 256 characters",
      (value) => !value || value.length <= 256
    ),
  focalFour: yup
    .string()
    .trim()
    .nullable()
    .test(
      "min-length",
      "Focal Point Four must be at least 3 characters",
      (value) => !value || value.length >= 3
    )
    .test(
      "max-length",
      "Focal Point Four must not exceed 256 characters",
      (value) => !value || value.length <= 256
    ),
});

export const organizationSchema = yup.object().shape({
  organization_description: yup
    .string()
    .trim()
    .required("Organization Description Field Required")
    .transform((value) => (value === "" ? null : value))
    .test(
      "word-count",
      "Description must be between 10 and 60 words",
      (value) => {
        if (!value) return true;

        // Count words by splitting on whitespace and filtering out empty strings
        const wordCount = value
          .split(/\s+/)
          .filter((word) => word.length > 0).length;

        return wordCount >= 10 && wordCount <= 60;
      }
    ),

  organization_logo: yup
    .mixed()
    .nullable()
    .test(
      "fileValidation",
      "Only image files are allowed (JPG, PNG, WebP)",
      function (value) {
        // Accept empty values (null, undefined, '')
        if (!value) return true;

        // Accept string URLs (existing images)
        if (typeof value === "string") return true;

        // For File objects, validate type
        if (value instanceof File) {
          const supportedFormats = [
            "image/jpeg",
            "image/jpg",
            "image/png",
            "image/webp",
          ];
          return supportedFormats.includes(value.type);
        }

        // Reject other types
        return false;
      }
    )
    .test("fileSize", "File size must be less than 10MB", function (value) {
      // Skip validation for non-File values
      if (!value || typeof value === "string" || !(value instanceof File))
        return true;

      // Check file size for File objects
      return value.size <= 10 * 1024 * 1024; // 10MB
    }),
  organization_agent_logo: yup
    .mixed()
    .nullable()
    .test(
      "fileValidation",
      "Only image files are allowed (JPG, PNG, WebP)",
      function (value) {
        // Accept empty values (null, undefined, '')
        if (!value) return true;

        // Accept string URLs (existing images)
        if (typeof value === "string") return true;

        // For File objects, validate type
        if (value instanceof File) {
          const supportedFormats = [
            "image/jpeg",
            "image/jpg",
            "image/png",
            "image/webp",
          ];
          return supportedFormats.includes(value.type);
        }

        // Reject other types
        return false;
      }
    )
    .test("fileSize", "File size must be less than 10MB", function (value) {
      // Skip validation for non-File values
      if (!value || typeof value === "string" || !(value instanceof File))
        return true;

      // Check file size for File objects
      return value.size <= 10 * 1024 * 1024; // 10MB
    }),
  organization_web_address: yup
    .string()
    .trim()
    .nullable()
    .transform((value) => (value === "" ? null : value)) // Convert empty string to null
    .notRequired()
    .test(
      "length-when-present",
      "web address must be between 10 and 1054 characters",
      (value) => {
        // If null/undefined/empty, it's valid
        if (!value) return true;
        // Otherwise check length
        return value.length >= 10 && value.length <= 1054;
      }
    ),
});

export const validationSchemaDepartment = yup.object().shape({
  departmentName: yup
    .string()
    .trim() // Prevent leading/trailing spaces
    .min(3, "Department Name must be at least 3 characters")
    .max(50, "Department Name Cannot Exceed 50 Characters")
    .matches(/^[a-zA-Z0-9\s]+$/, "Special characters are not allowed") // Restrict special characters
    .required("Department Name is required"),

  departmentType: yup
    .string()
    .trim() // Prevent leading/trailing spaces
    .min(3, "Department Type must be at least 3 characters")
    .max(99, "Department Type Cannot Exceed 99 Character")
    .matches(/^[a-zA-Z0-9\s]+$/, "Special characters are not allowed") // Restrict special characters
    .required("Department Type is required"),

  departmentInformation: yup
    .string()
    .trim()
    .nullable()
    .notRequired()
    .min(3, "Department Information must be at least 3 characters")
    .max(1054, "Department Information must be at most 1054 characters"),
});

export const CriteriaSchema = yup.object().shape({
  criteria1: yup
    .string()
    .trim()
    .required("Criteria 1 is required")
    .min(3, "Criteria 1 must be at least 3 characters")
    .max(256, "Criteria 1 must not exceed 256 characters"),
  criteria2: yup
    .string()
    .trim()
    .required("Criteria 2 is required")
    .min(3, "Criteria 2 must be at least 3 characters")
    .max(256, "Criteria 2 must not exceed 256 characters"),
  criteria3: yup
    .string()
    .trim()
    .required("Criteria 3 is required")
    .min(3, "Criteria 3 must be at least 3 characters")
    .max(256, "Criteria 3 must not exceed 256 characters"),
  criteria4: yup
    .string()
    .trim()
    .required("Criteria 4 is required")
    .min(3, "Criteria 4 must be at least 3 characters")
    .max(256, "Criteria 4 must not exceed 256 characters"),
  criteria5: yup
    .string()
    .trim()
    .required("Criteria 5 is required")
    .min(3, "Criteria 5 must be at least 3 characters")
    .max(256, "Criteria 5 must not exceed 256 characters"),
  criteria6: yup
    .string()
    .trim()
    .nullable()
    .test(
      "min-length",
      "Criteria 6 must be at least 3 characters",
      (value) => !value || value.length >= 3
    )
    .test(
      "max-length",
      "Criteria 6 must not exceed 256 characters",
      (value) => !value || value.length <= 256
    ),
  criteria7: yup
    .string()
    .trim()
    .nullable()
    .test(
      "min-length",
      "Criteria 7 must be at least 3 characters",
      (value) => !value || value.length >= 3
    )
    .test(
      "max-length",
      "Criteria 7 must not exceed 256 characters",
      (value) => !value || value.length <= 256
    ),
});

export const DynamicObjectivesSchema = yup.object().shape({
  dynamic_objective1: yup
    .string()
    .trim()
    .nullable() // Allow null or undefined values
    .test(
      "min-length",
      "User key area must be at least 3 characters",
      (value) => !value || value.length >= 3 // Apply min validation only if value exists
    )
    .test(
      "max-length",
      "User key area must not exceed 256 characters",
      (value) => !value || value.length <= 256 // Apply max validation only if value exists
    ),

  dynamic_objective2: yup
    .string()
    .trim()
    .nullable() // Allow null or undefined values
    .test(
      "min-length",
      "User key area must be at least 3 characters",
      (value) => !value || value.length >= 3 // Apply min validation only if value exists
    )
    .test(
      "max-length",
      "User key area must not exceed 256 characters",
      (value) => !value || value.length <= 256 // Apply max validation only if value exists
    ),
  dynamic_objective3: yup
    .string()
    .trim()
    .nullable() // Allow null or undefined values
    .test(
      "min-length",
      "User key area must be at least 3 characters",
      (value) => !value || value.length >= 3 // Apply min validation only if value exists
    )
    .test(
      "max-length",
      "User key area must not exceed 256 characters",
      (value) => !value || value.length <= 256 // Apply max validation only if value exists
    ),
  dynamic_objective4: yup
    .string()
    .trim()
    .nullable() // Allow null or undefined values
    .test(
      "min-length",
      "User key area must be at least 3 characters",
      (value) => !value || value.length >= 3 // Apply min validation only if value exists
    )
    .test(
      "max-length",
      "User key area must not exceed 256 characters",
      (value) => !value || value.length <= 256 // Apply max validation only if value exists
    ),
});

export const profileSchema = yup.object().shape({
  name: yup
    .string()
    .trim()
    .required("Full name is required")
    .min(3, "Full name must be at least 3 characters")
    .max(50, "Full name must not exceed 50 characters"),
  email: yup
    .string()
    .trim()
    .required("Email is required")
    .email("Invalid email format")
    .min(3, "Email must be at least 3 characters")
    .max(200, "Email must not exceed 200 characters"),
});

export const PaymentInfoSchema = yup.object().shape({
  name: yup
    .string()
    .trim()
    .required("Full name is required")
    .min(3, "Full name must be at least 3 characters")
    .max(50, "Full name must not exceed 50 characters"),
  email: yup
    .string()
    .trim()
    .required("Email is required")
    .email("Invalid email format")
    .min(3, "Email must be at least 3 characters")
    .max(200, "Email must not exceed 200 characters"),
  line1: yup
    .string()
    .trim()
    .required("Address Line 1 is required")
    .min(5, "Address Line 1 must be at least 5 characters")
    .max(250, "Address Line 1 must not exceed 250 characters"),
  line2: yup
    .string()
    .trim()
    .nullable() // Allow null or undefined values
    .test(
      "min-length",
      "Address Line 2 must be at least 5 characters",
      (value) => !value || value.length >= 5 // Apply min validation only if value exists
    )
    .test(
      "man-length",
      "Address Line 2 must not exceed 250 characters",
      (value) => !value || value.length <= 250 // Apply max validation only if value exists
    ),
  city: yup
    .object()
    .shape({
      value: yup.string().required("City is required"),
      label: yup.string().required("City is required"),
    })
    .required("City is required"),

  state: yup
    .object()
    .shape({
      value: yup.string().required("State is required"),
      label: yup.string().required("State is required"),
    })
    .required("State is required"),

  country: yup
    .object()
    .shape({
      value: yup.string().required("Country is required"),
      label: yup.string().required("Country is required"),
    })
    .required("Country is required"),
  postal_code: yup
    .string()
    .trim()
    .required("Zip Code is required")
    .matches(/^\d{5,6}$/, "Zip Code must be 5 or 6 digits"),
});

export const PublicPaymentInfoSchema = yup.object().shape({
  organization_name: yup
    .string()
    .trim()
    .required("Organization is required")
    .min(3, "Organization must be at least 3 characters")
    .max(50, "Organization must not exceed 50 characters"),
  name: yup
    .string()
    .trim()
    .required("Full name is required")
    .min(3, "Full name must be at least 3 characters")
    .max(50, "Full name must not exceed 50 characters"),
  email: yup
    .string()
    .trim()
    .required("Email is required")
    .email("Invalid email format")
    .min(3, "Email must be at least 3 characters")
    .max(200, "Email must not exceed 200 characters"),
  line1: yup
    .string()
    .trim()
    .required("Address Line 1 is required")
    .min(5, "Address Line 1 must be at least 5 characters")
    .max(250, "Address Line 1 must not exceed 250 characters"),
  line2: yup
    .string()
    .trim()
    .nullable() // Allow null or undefined values
    .test(
      "min-length",
      "Address Line 2 must be at least 5 characters",
      (value) => !value || value.length >= 5 // Apply min validation only if value exists
    )
    .test(
      "man-length",
      "Address Line 2 must not exceed 250 characters",
      (value) => !value || value.length <= 250 // Apply max validation only if value exists
    ),
  city: yup
    .object()
    .shape({
      value: yup.string().required("City is required"),
      label: yup.string().required("City is required"),
    })
    .required("City is required"),

  state: yup
    .object()
    .shape({
      value: yup.string().required("State is required"),
      label: yup.string().required("State is required"),
    })
    .required("State is required"),
  country: yup
    .object()
    .shape({
      value: yup.string().required("Country is required"),
      label: yup.string().required("Country is required"),
    })
    .required("Country is required"),
  postal_code: yup
    .string()
    .trim()
    .required("Zip Code is required")
    .matches(/^\d{5,6}$/, "Zip Code must be 5 or 6 digits"),
});

export const StrategicPLanSchema = yup.object().shape({
  strategic_plan_name: yup
    .string()
    .trim()
    .required("Strategic Plan is required")
    .min(3, "Strategic Plan Name must be at least 3 characters")
    .max(50, "Strategic Plan Cannot Exceed 50 Characters")
    .matches(/^[a-zA-Z0-9\s]+$/, "Special characters are not allowed"),

  strategicInformation: yup
    .string()
    .trim() // Prevent leading/trailing spaces
    .required("Strategic Plan Information is required")
    .min(3, "Strategic Plan Information must be at least 3 characters")
    .max(250, "Strategic Plan Information must be at most 250 characters"),
  applicable_date: yup
    .date()
    .typeError("Applicable date is required")
    .required("Applicable date is required")
    .test(
      "is-not-in-past",
      "Applicable date cannot be in the past.",
      function (value) {
        return (
          !value ||
          new Date(value).setHours(0, 0, 0, 0) >=
          new Date().setHours(0, 0, 0, 0)
        );
      }
    ),
});

export const SwotFormSchema = (fieldCount, ActiveOption) => {
  const schema = {};
  for (let i = 1; i <= fieldCount; i++) {
    if (i <= 5) {
      // Required fields
      schema[`${ActiveOption}-criteria${i}`] = yup
        .string()
        .trim()
        .required(`${ActiveOption} ${i} is required`)
        .min(3, `${ActiveOption} ${i} must be at least 3 characters`)
        .max(256, `${ActiveOption} ${i} must not exceed 256 characters`);
    } else {
      // Optional fields
      schema[`${ActiveOption}-criteria${i}`] = yup
        .string()
        .trim()
        .nullable()
        .test(
          "min-length",
          `${ActiveOption} ${i} must be at least 3 characters`,
          (value) => !value || value.length >= 3
        )
        .test(
          "max-length",
          `${ActiveOption} ${i} must not exceed 256 characters`,
          (value) => !value || value.length <= 256
        );
    }
  }
  return yup.object().shape(schema);
};

export const strategicdataFormSchema = yup.object().shape({
  start_year: yup
    .number()
    .transform((value, originalValue) =>
      originalValue === "" ? undefined : Number(originalValue)
    )
    .typeError("Start year is required.")
    .required("Start year is required.")
    .min(2024, "Year must be between 2024 and 2030")
    .max(2030, "Year must be between 2024 and 2030"),

  metrics: yup.array().of(
    yup.object().shape({
      include: yup.boolean(),
      metric: yup.string().when('include', {
        is: true,
        then: (schema) => schema
          .required('Metric name is required')
          .max(20, 'Metric must be 20 characters or less')
          .test(
            'no-whitespace-only',
            'Metric must contain at least one non-space character',
            (value) => {
              return value ? value.trim().length > 0 : false
            }),
        otherwise: (schema) => schema.notRequired()
      }),
      metric_format: yup.string().when('include', {
        is: true,
        then: (schema) => schema.required('Metric format is required')
          .oneOf(['dollar', 'number'], 'Invalid format'),
        otherwise: (schema) => schema.notRequired()
      }),
      data_form_question: yup.string().when('include', {
        is: true,
        then: (schema) => schema
          .required('Question is required')
          .test(
            'no-whitespace-only',
            'Metric question must contain at least one non-space character',
            (value) => value ? value.trim().length > 0 : false
          )
          .test(
            'max-length',
            'Question cannot exceed 180 characters',
            (value) => value ? value.trim().length <= 180 : false
          )
          .transform((value) => value ? value.trim() : value), // Auto-trim input
        otherwise: (schema) => schema.notRequired()
      }),
      help_text: yup.string().when('include', {
        is: true,
        then: (schema) => schema
          .required('Help text is required')
          .test(
            'no-whitespace-only',
            'Metric help text must contain at least one non-space character',
            (value) => value ? value.trim().length > 0 : false
          )
          .test(
            'max-length',
            'Help text cannot exceed 180 characters',
            (value) => value ? value.trim().length <= 180 : false
          )
          .transform((value) => value ? value.trim() : value), // Auto-trim input
        otherwise: (schema) => schema.notRequired()
      }),
      calculation_type: yup.string().when('include', {
        is: true,
        then: (schema) => schema.required('Calculation type is required')
          .oneOf(['static', 'dynamic'], 'Invalid calculation type'),
        otherwise: (schema) => schema.notRequired()
      }),

      value: yup.string().when(['include', 'calculation_type'], {
        is: (include, calculation_type) => include && calculation_type === 'dynamic',
        then: (schema) => schema.required('Value is required for dynamic calculations'),
        otherwise: (schema) => schema.notRequired()
      })
    })
  ),
});

export const createStrategyFormSchema = (minYear = 2024, maxYear = 2030, metricQuestions = {}, yearRangeInput) => {
  // Create base schema
  const schema = {
    department_choices: yup.string().required("Department is required."),
    start_date: yup
      .string()
      .required("Start date is required")
      .test("date-range", `Date must be between ${minYear} and ${maxYear}`, function (value) {
        if (!value) return true;
        const year = new Date(value).getFullYear();
        return year >= minYear && year <= maxYear;
      }),
    production_date: yup
      .string()
      .required("Production date is required")
      .test("date-range", `Date must be between ${minYear} and ${maxYear}`, function (value) {
        if (!value) return true;
        const year = new Date(value).getFullYear();
        return year >= minYear && year <= maxYear;
      })
      .test(
        "after-start-date",
        "Production date must be after start date",
        function (value) {
          const { start_date } = this.parent;
          if (!start_date || !value) return true;
          return new Date(value) > new Date(start_date);
        }
      ),
    expected_years_productive: yup
      .number()
      .typeError("Expected years productive must be a number.")
      .required("Expected years productive is required.")

  };

  // Add metric validations only if the question exists
  if (metricQuestions.metric_one) {
    schema.metric_one = yup
      .number()
      .typeError("Value must be a number.")
      .required("Value is required.")
      .min(-1, "Value must be at least 0")
      .max(1000000000, "Value must not exceed 1,000,000,000.")
      .test(
        "max-decimals",
        "Value must not have more than two decimal places.",
        (value) =>
          value === undefined || /^\d+(\.\d{1,2})?$/.test(value.toString())
      );
  }

  if (metricQuestions.metric_two) {
    schema.metric_two = yup
      .number()
      .typeError("Value must be a number.")
      .required("Value is required.")
      .min(-1, "Value must be at least 0.")
      .max(1000000000, "Value must not exceed 1,000,000,000.")
      .integer("New members must be a whole number.");
  }

  if (metricQuestions.metric_three) {
    schema.metric_three = yup
      .number()
      .typeError("Value must be a number.")
      .required("Value is required.")
      .min(-1, "Value must be at least 0.")
      .max(1000000000, "Value must not exceed 1,000,000,000.")
      .integer("New members must be a whole number.");
  }

  if (metricQuestions.metric_four) {
    schema.metric_four = yup
      .number()
      .typeError("Value must be a number.")
      .required("Value is required.")
      .min(-1, "Value must be at least 0.")
      .max(1000000000, "Value must not exceed 1,000,000,000.")
      .integer("New members must be a whole number.");
  }
  if (metricQuestions.metric_five) {
    schema.metric_five = yup
      .number()
      .typeError("Value must be a number.")
      .required("Value is required.")
      .min(-1, "Value must be at least 0.")
      .max(1000000000, "Value must not exceed 1,000,000,000.")
      .test(
        "max-decimals",
        "Annual Opex must not have more than two decimal places.",
        (value) =>
          value === undefined || /^\d+(\.\d{1,2})?$/.test(value.toString())
      );
  }
  if (metricQuestions.metric_six) {
    schema.metric_six = yup
      .number()
      .typeError("Value must be a number.")
      .required("Value is required.")
      .min(-1, "Value must be at least 0.")
      .max(1000000000, "Value must not exceed 1,000,000,000.")
      .test(
        "max-decimals",
        "Value must not have more than two decimal places.",
        (value) =>
          value === undefined || /^\d+(\.\d{1,2})?$/.test(value.toString())
      );
  }
  if (metricQuestions.metric_seven) {
    schema.metric_seven = yup
      .number()
      .typeError("Value must be a number.")
      .required("Value is required.")
      .min(-1, "Value must be at least 0.")
      .max(1000000000, "Value must not exceed 1,000,000,000.")
      .test(
        "max-decimals",
        "Value must not have more than two decimal places.",
        (value) =>
          value === undefined || /^\d+(\.\d{1,2})?$/.test(value.toString())
      );
  }
  if (metricQuestions.metric_eight) {
    schema.metric_eight = yup
      .number()
      .typeError("Value must be a number.")
      .required("Value is required.")
      .min(-1, "Value must be at least 0.")
      .max(1000000000, "Value must not exceed 1,000,000,000.")
      .test(
        "max-decimals",
        "Value must not have more than two decimal places.",
        (value) =>
          value === undefined || /^\d+(\.\d{1,2})?$/.test(value.toString())
      )
  }



  return yup.object().shape(schema);
};